import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '15mb' }));

import crypto from 'crypto';

// Secret key for HMAC signature verification (never exposed to frontend)
const SERVER_SECRET = process.env.PAYPER_SERVER_SECRET || 'payper-secure-secret-key-2026-auth';

// Strict plan pricing dictionary in USD & FCFA
const PLAN_PRICING: Record<string, { usd: number; fcfa: number }> = {
  free: { usd: 0, fcfa: 0 },
  standard: { usd: 5, fcfa: 3000 },
  pro: { usd: 12, fcfa: 7500 },
};

interface ServerSubscriptionRecord {
  id: string;
  userId: string;
  plan: 'free' | 'standard' | 'pro';
  status: 'inactive' | 'pending' | 'active' | 'expired' | 'cancelled' | 'payment_failed';
  startDate: string;
  endDate?: string;
  amountUSD: number;
  lastPaymentId?: string;
  paymentProvider?: string;
  updatedAt: string;
}

// In-memory server-authoritative ledger for active runtime sessions
const subscriptionLedger = new Map<string, ServerSubscriptionRecord>();

// Helper to compute an HMAC-SHA256 signature on subscription data
function signSubscriptionPayload(sub: {
  userId: string;
  plan: string;
  status: string;
  endDate?: string;
  amountUSD: number;
}): string {
  const payload = `${sub.userId}:${sub.plan}:${sub.status}:${sub.endDate || ''}:${sub.amountUSD}`;
  return crypto.createHmac('sha256', SERVER_SECRET).update(payload).digest('hex');
}

// Helper to verify a subscription payload against the HMAC signature
function verifySubscriptionSignature(sub: {
  userId: string;
  plan: string;
  status: string;
  endDate?: string;
  amountUSD: number;
  signature?: string;
}): boolean {
  if (!sub.signature) return false;
  const expected = signSubscriptionPayload(sub);
  return crypto.timingSafeEqual(Buffer.from(sub.signature), Buffer.from(expected));
}

// Check expiration for a subscription record
function evaluateExpiration(record: ServerSubscriptionRecord): ServerSubscriptionRecord {
  if (record.status === 'active' && record.endDate) {
    const expiry = new Date(record.endDate).getTime();
    const now = Date.now();
    if (now > expiry) {
      record.status = 'expired';
      record.updatedAt = new Date().toISOString();
    }
  }
  return record;
}

// ==========================================
// SUBSCRIPTION REST API ENDPOINTS
// ==========================================

// App info endpoint
app.get('/api/payper/info', (_req, res) => {
  res.json({
    name: 'PAYPER',
    tagline: 'Facturation Pro pour l\'Afrique',
    pricing: PLAN_PRICING,
    supportedProviders: ['wave', 'orange_money', 'card', 'paystack', 'flutterwave'],
  });
});

// 1. Get current server-authoritative subscription status
app.get('/api/subscription/status', (req, res) => {
  const userId = (req.query.userId as string) || 'default_user';
  let record = subscriptionLedger.get(userId);

  if (!record) {
    // Default free inactive record
    record = {
      id: `sub_${userId}_free`,
      userId,
      plan: 'free',
      status: 'inactive',
      startDate: new Date().toISOString(),
      amountUSD: 0,
      updatedAt: new Date().toISOString(),
    };
    subscriptionLedger.set(userId, record);
  } else {
    record = evaluateExpiration(record);
  }

  const signature = signSubscriptionPayload(record);
  res.json({
    subscription: {
      ...record,
      signature,
    },
    isValid: record.status === 'active' && record.plan !== 'free',
    serverTime: new Date().toISOString(),
  });
});

// 2. Initiate Checkout (creates a pending subscription transaction)
app.post('/api/subscription/checkout', (req, res) => {
  const { userId = 'default_user', plan, paymentProvider = 'wave' } = req.body;

  if (!plan || !['standard', 'pro'].includes(plan)) {
    return res.status(400).json({ error: 'Plan invalide. Choisissez standard ou pro.' });
  }

  const pricing = PLAN_PRICING[plan];
  const transactionId = `pay_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;

  // Create or update record in pending status
  const pendingRecord: ServerSubscriptionRecord = {
    id: `sub_${userId}_${plan}`,
    userId,
    plan,
    status: 'pending',
    startDate: new Date().toISOString(),
    amountUSD: pricing.usd,
    lastPaymentId: transactionId,
    paymentProvider,
    updatedAt: new Date().toISOString(),
  };

  subscriptionLedger.set(userId, pendingRecord);
  const signature = signSubscriptionPayload(pendingRecord);

  res.json({
    success: true,
    message: `Initialisation du paiement de ${pricing.usd} USD pour le plan ${plan.toUpperCase()}`,
    transactionId,
    amountUSD: pricing.usd,
    amountFCFA: pricing.fcfa,
    status: 'pending',
    provider: paymentProvider,
    subscription: {
      ...pendingRecord,
      signature,
    },
    paymentInstructions: {
      note: 'En attente de confirmation du prestataire de paiement externe.',
      checkoutRef: transactionId,
    },
  });
});

// 3. Confirm Payment (backend-verified transition to active status)
app.post('/api/subscription/confirm', (req, res) => {
  const { userId = 'default_user', transactionId, simulatedOutcome } = req.body;
  let record = subscriptionLedger.get(userId);

  if (!record) {
    return res.status(404).json({ error: 'Aucune souscription en attente trouvée.' });
  }

  // Support test outcomes: 'failed', 'expired', 'confirmed' (default)
  if (simulatedOutcome === 'failed') {
    record.status = 'payment_failed';
    record.updatedAt = new Date().toISOString();
    subscriptionLedger.set(userId, record);
    const sig = signSubscriptionPayload(record);
    return res.status(400).json({
      success: false,
      status: 'payment_failed',
      error: 'Le paiement a été refusé par l\'émetteur ou a échoué.',
      subscription: { ...record, signature: sig },
    });
  }

  if (simulatedOutcome === 'expired') {
    record.status = 'expired';
    record.endDate = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(); // Yesterday
    record.updatedAt = new Date().toISOString();
    subscriptionLedger.set(userId, record);
    const sig = signSubscriptionPayload(record);
    return res.json({
      success: true,
      status: 'expired',
      subscription: { ...record, signature: sig },
    });
  }

  // Normal successful confirmation
  const now = new Date();
  const endDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // 30 days active validity

  record.status = 'active';
  record.startDate = now.toISOString();
  record.endDate = endDate.toISOString();
  record.lastPaymentId = transactionId || record.lastPaymentId || `pay_${Date.now()}`;
  record.updatedAt = now.toISOString();

  subscriptionLedger.set(userId, record);
  const signature = signSubscriptionPayload(record);

  res.json({
    success: true,
    status: 'active',
    message: `Paiement vérifié avec succès. Votre abonnement ${record.plan.toUpperCase()} est actif pour 30 jours.`,
    subscription: {
      ...record,
      signature,
    },
  });
});

// 4. Verify client subscription & Anti-Tampering Check
app.post('/api/subscription/verify', (req, res) => {
  const clientSub = req.body;
  if (!clientSub || !clientSub.userId) {
    return res.status(400).json({ valid: false, error: 'Données d\'abonnement manquantes' });
  }

  // Free plans are always valid
  if (clientSub.plan === 'free') {
    return res.json({
      valid: true,
      plan: 'free',
      status: clientSub.status || 'inactive',
    });
  }

  // For paid plans, verify against server ledger
  const serverRecord = subscriptionLedger.get(clientSub.userId);
  if (!serverRecord) {
    return res.status(403).json({
      valid: false,
      reason: 'Aucun enregistrement côté serveur pour cet utilisateur',
      plan: 'free',
      status: 'inactive',
    });
  }

  evaluateExpiration(serverRecord);

  // Check if signature matches
  let signatureValid = false;
  try {
    signatureValid = verifySubscriptionSignature({
      userId: clientSub.userId,
      plan: serverRecord.plan,
      status: serverRecord.status,
      endDate: serverRecord.endDate,
      amountUSD: serverRecord.amountUSD,
      signature: clientSub.signature,
    });
  } catch {
    signatureValid = false;
  }

  if (!signatureValid || serverRecord.plan !== clientSub.plan || serverRecord.status !== clientSub.status) {
    return res.status(403).json({
      valid: false,
      reason: 'Falsification détectée ou désynchronisation avec le serveur',
      serverStatus: serverRecord.status,
      serverPlan: serverRecord.plan,
    });
  }

  const isAccessAllowed = serverRecord.status === 'active';
  res.json({
    valid: isAccessAllowed,
    plan: serverRecord.plan,
    status: serverRecord.status,
    endDate: serverRecord.endDate,
  });
});

// 5. Cancel subscription
app.post('/api/subscription/cancel', (req, res) => {
  const { userId = 'default_user' } = req.body;
  let record = subscriptionLedger.get(userId);

  if (!record) {
    return res.status(404).json({ error: 'Aucun abonnement trouvé' });
  }

  record.status = 'cancelled';
  record.updatedAt = new Date().toISOString();
  subscriptionLedger.set(userId, record);

  const signature = signSubscriptionPayload(record);
  res.json({
    success: true,
    message: 'Abonnement annulé avec succès.',
    subscription: { ...record, signature },
  });
});

// 6. Server-side Gatekeeper: Verify Premium Feature Access
app.post('/api/premium/verify-access', (req, res) => {
  const { userId = 'default_user', feature } = req.body;
  let record = subscriptionLedger.get(userId);

  if (!record) {
    return res.status(403).json({ allowed: false, error: 'Abonnement requis' });
  }

  evaluateExpiration(record);

  if (record.status !== 'active') {
    return res.status(403).json({
      allowed: false,
      status: record.status,
      error: `Votre abonnement est ${record.status}. Veuillez renouveler votre forfait.`,
    });
  }

  if (feature === 'transfers' && record.plan !== 'pro') {
    return res.status(403).json({
      allowed: false,
      error: 'La fonctionnalité Transfert d\'argent nécessite l\'offre Pro.',
    });
  }

  res.json({ allowed: true, plan: record.plan, status: record.status });
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        host: '0.0.0.0',
        port: PORT,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`PAYPER server running on port ${PORT}`);
  });
}

startServer();
