import React, { useState, useEffect } from 'react';
import { getBoutique, isUserLoggedIn, getUserAccount, saveBoutique } from './lib/storage';
import { executeDailyAutomationCycle } from './lib/automations';
import { syncAllDataWithSupabase } from './lib/supabase';
import { WelcomePage } from './pages/WelcomePage';
import { DashboardPage } from './pages/DashboardPage';
import { InvoicesPage } from './pages/InvoicesPage';
import { ClientsPage } from './pages/ClientsPage';
import { BoutiquesPage } from './pages/BoutiquesPage';
import { InvoiceDetailPage } from './pages/InvoiceDetailPage';
import { PublicInvoicePage } from './pages/PublicInvoicePage';
import { PricingPage } from './pages/PricingPage';
import { SettingsPage } from './pages/SettingsPage';
import { AutomationsPage } from './pages/AutomationsPage';
import { AnalyticsPage } from './pages/AnalyticsPage';
import { CustomizationPage } from './pages/CustomizationPage';
import { AppLayout } from './components/layout/AppLayout';
import { ToastProvider } from './components/common/Toast';
import { PayperSplashScreen } from './components/payper-splash-screen';
import { AuthScreen } from './components/common/AuthScreen';
import { Invoice, Boutique } from './types';
import { AnimatePresence } from 'motion/react';

export default function App() {
  const [showSplash, setShowSplash] = useState<boolean>(() => {
    // Show splash screen on first visit of the session
    return sessionStorage.getItem('payper_splash_seen') !== 'true';
  });
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => isUserLoggedIn());
  const [activeBoutique, setActiveBoutique] = useState<Boutique | null>(() => getBoutique());

  const handleSplashComplete = () => {
    sessionStorage.setItem('payper_splash_seen', 'true');
    setShowSplash(false);
  };

  const ensureBoutique = (): Boutique => {
    let boutique = activeBoutique || getBoutique();
    if (!boutique || !boutique.name || boutique.name.trim().length < 2) {
      const user = getUserAccount();
      const defaultBoutique: Boutique = {
        id: `btq_${Date.now()}`,
        userId: user.id || undefined,
        name: user.name?.trim() ? `Boutique de ${user.name.trim()}` : 'Ma Boutique PAYPER',
        devise: 'FCFA',
        country: user.country || 'Sénégal',
        countryCode: user.countryCode || '+221',
        city: 'Dakar',
        phone: user.phone || '',
        createdAt: new Date().toISOString(),
        isActive: true,
      };
      saveBoutique(defaultBoutique);
      boutique = defaultBoutique;
    }
    return boutique;
  };

  const isBoutiqueComplete = (): boolean => {
    const boutique = activeBoutique || getBoutique();
    if (!boutique) return false;
    if (!boutique.name || boutique.name.trim().length < 2) return false;
    return true;
  };

  // Parse current route from window.location.hash or fallback
  const getInitialRoute = (): string => {
    // Check if public invoice URL
    const hash = window.location.hash;
    const search = window.location.search;
    if (hash.includes('public-invoice') || search.includes('data=')) {
      return '/public-invoice';
    }

    if (!isUserLoggedIn()) {
      return '/welcome';
    }

    // A logged-in user always has a boutique and lands on dashboard
    ensureBoutique();

    if (hash.startsWith('#')) {
      const cleanHash = hash.replace(/^#/, '');
      if (cleanHash && cleanHash !== '/' && cleanHash !== '/welcome') {
        return cleanHash;
      }
    }

    return '/dashboard';
  };

  const [currentRoute, setCurrentRoute] = useState<string>(getInitialRoute);

  const navigate = (path: string) => {
    setCurrentRoute(path);
    window.location.hash = path;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      const search = window.location.search;
      if (hash.includes('public-invoice') || search.includes('data=')) {
        setCurrentRoute('/public-invoice');
        return;
      }

      if (!isUserLoggedIn()) {
        return;
      }

      if (hash === '#welcome' || hash === '#/welcome' || !hash || hash === '#' || hash === '#/') {
        navigate('/dashboard');
        return;
      }

      if (hash.startsWith('#')) {
        const clean = hash.replace(/^#/, '');
        if (clean) {
          setCurrentRoute(clean);
        }
      }
    };

    const handleBoutiqueUpdated = () => {
      const b = getBoutique();
      setActiveBoutique(b);
      if (b && b.name && b.name.trim().length >= 2) {
        const hash = window.location.hash.replace(/^#/, '');
        if (!hash || hash === '/welcome' || hash === '/' || currentRoute === '/welcome') {
          navigate('/dashboard');
        }
      }
    };

    const handleAuthUpdated = () => {
      const logged = isUserLoggedIn();
      setIsLoggedIn(logged);
      if (logged) {
        syncAllDataWithSupabase().catch(() => {});
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    window.addEventListener('payper_boutique_updated', handleBoutiqueUpdated);
    window.addEventListener('payper_auth_updated', handleAuthUpdated);

    // Initial background sync with Supabase Cloud if user is logged in
    if (isUserLoggedIn()) {
      syncAllDataWithSupabase().catch(() => {});
    }

    // Run background automation cycle (idempotent daily check for recurring and reminders)
    try {
      executeDailyAutomationCycle();
    } catch {
      // silent background check
    }

    return () => {
      window.removeEventListener('hashchange', handleHashChange);
      window.removeEventListener('payper_boutique_updated', handleBoutiqueUpdated);
      window.removeEventListener('payper_auth_updated', handleAuthUpdated);
    };
  }, []);

  // Handle invoice created from global modal or page
  const handleInvoiceCreated = (invoice: Invoice) => {
    navigate(`/invoice/${invoice.id}`);
  };

  // Route 1: Public Invoice (External recipient view, no app layout)
  if (currentRoute === '/public-invoice' || currentRoute.startsWith('/public-invoice')) {
    return (
      <ToastProvider>
        <PublicInvoicePage onGoToOnboarding={() => navigate('/welcome')} />
      </ToastProvider>
    );
  }

  // Route 2: Account Logged Out Screen
  if (!isLoggedIn) {
    return (
      <ToastProvider>
        <AnimatePresence>
          {showSplash && (
            <PayperSplashScreen
              onComplete={handleSplashComplete}
              durationMs={4000}
            />
          )}
        </AnimatePresence>
        <AuthScreen
          onLoginSuccess={(destination: string) => {
            const b = ensureBoutique();
            setActiveBoutique(b);
            setIsLoggedIn(true);
            navigate(destination || '/dashboard');
          }}
        />
      </ToastProvider>
    );
  }

  // If user is logged in and accidentally navigates to /welcome, redirect straight to dashboard
  if (currentRoute === '/welcome') {
    navigate('/dashboard');
  }

  // Helper to render active route inside SaaS AppLayout
  const renderCurrentPage = () => {
    if (currentRoute.startsWith('/invoice/')) {
      const id = currentRoute.replace('/invoice/', '');
      return <InvoiceDetailPage invoiceId={id} onNavigate={navigate} />;
    }

    switch (currentRoute) {
      case '/dashboard':
        return <DashboardPage onNavigate={navigate} />;
      case '/invoices':
        return <InvoicesPage onNavigate={navigate} />;
      case '/analytics':
        return <AnalyticsPage onNavigate={navigate} />;
      case '/clients':
        return <ClientsPage onNavigate={navigate} />;
      case '/boutiques':
        return <BoutiquesPage onNavigate={navigate} />;
      case '/pricing':
        return <PricingPage onPlanChanged={() => {}} />;
      case '/customization':
        return <CustomizationPage onNavigate={navigate} />;
      case '/automations':
        return <AutomationsPage onNavigate={navigate} />;
      case '/settings':
        return <SettingsPage onNavigate={navigate} />;
      default:
        return <DashboardPage onNavigate={navigate} />;
    }
  };

  return (
    <ToastProvider>
      <AnimatePresence>
        {showSplash && (
          <PayperSplashScreen
            onComplete={handleSplashComplete}
            durationMs={4000}
          />
        )}
      </AnimatePresence>

      <AppLayout
        currentPath={currentRoute}
        onNavigate={navigate}
        onInvoiceCreated={handleInvoiceCreated}
      >
        {renderCurrentPage()}
      </AppLayout>
    </ToastProvider>
  );
}
