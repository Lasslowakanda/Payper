import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  TrendingUp,
  DollarSign,
  FileCheck2,
  Users,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Info,
  ChevronRight,
  CheckCircle2,
} from 'lucide-react';
import { AnalyticsStats, DayDataPoint } from '../../lib/analytics';
import { formatCurrency, formatDate } from '../../lib/invoice';
import { Currency, Invoice } from '../../types';

interface AnalyticsChartsProps {
  stats: AnalyticsStats;
  currency: Currency;
  onSelectDay: (dayPoint: DayDataPoint) => void;
  onFilterByStatus?: (status: 'all' | 'paid' | 'pending') => void;
  onSelectClient?: (clientName: string) => void;
}

export const AnalyticsCharts: React.FC<AnalyticsChartsProps> = ({
  stats,
  currency,
  onSelectDay,
  onFilterByStatus,
  onSelectClient,
}) => {
  const { dailySeries, revenue, collectionRate, topClients } = stats;

  // Active hover/touch state on Revenue Trend Chart
  const [hoveredPointIndex, setHoveredPointIndex] = useState<number | null>(null);

  // Maximum revenue among daily points for scaling
  const maxDayRevenue = Math.max(...dailySeries.map(d => d.revenue), 100);
  const maxDayInvoices = Math.max(...dailySeries.map(d => d.invoicesCount), 1);
  const totalBilled = stats.revenue.current + stats.pendingAmount.current;

  // Selected point for tooltip fallback
  const activePoint =
    hoveredPointIndex !== null && dailySeries[hoveredPointIndex]
      ? dailySeries[hoveredPointIndex]
      : null;

  // SVG Coordinates calculation for Revenue Line Chart
  const chartWidth = 800;
  const chartHeight = 260;
  const paddingX = 40;
  const paddingY = 30;
  const innerWidth = chartWidth - paddingX * 2;
  const innerHeight = chartHeight - paddingY * 2;

  const pointsCount = dailySeries.length;
  const stepX = pointsCount > 1 ? innerWidth / (pointsCount - 1) : innerWidth;

  const linePoints = dailySeries.map((d, i) => {
    const x = paddingX + i * stepX;
    const ratio = d.revenue / (maxDayRevenue * 1.15 || 1);
    const y = chartHeight - paddingY - ratio * innerHeight;
    return { x, y, data: d, index: i };
  });

  // SVG path strings
  const linePathD =
    linePoints.length === 1
      ? `M ${paddingX} ${linePoints[0].y} L ${chartWidth - paddingX} ${linePoints[0].y}`
      : linePoints.reduce((acc, curr, idx) => {
          if (idx === 0) return `M ${curr.x} ${curr.y}`;
          // Smooth bezier curve
          const prev = linePoints[idx - 1];
          const cx1 = prev.x + (curr.x - prev.x) / 2;
          const cy1 = prev.y;
          const cx2 = prev.x + (curr.x - prev.x) / 2;
          const cy2 = curr.y;
          return `${acc} C ${cx1} ${cy1}, ${cx2} ${cy2}, ${curr.x} ${curr.y}`;
        }, '');

  const areaPathD =
    linePoints.length > 0
      ? `${linePathD} L ${linePoints[linePoints.length - 1].x} ${chartHeight - paddingY} L ${linePoints[0].x} ${chartHeight - paddingY} Z`
      : '';

  return (
    <div className="space-y-6">
      {/* =========================================================================
          GRAPHIQUE 1 : ÉVOLUTION DU CHIFFRE D'AFFAIRES (Linéaire avec survol & clic)
          ========================================================================= */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 shadow-xs border border-neutral-200/80">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-50 text-[#00C48C] flex items-center justify-center">
                <TrendingUp className="w-4 h-4 stroke-[2.5]" />
              </div>
              <h2 className="text-base sm:text-lg font-bold text-[#111827]">
                Graphique 1 · Évolution du chiffre d'affaires
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-neutral-500 mt-1">
              Survolez ou touchez un point pour voir le détail de la journée. Cliquez pour ouvrir la liste des factures.
            </p>
          </div>

          {/* Quick value badge */}
          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="text-xs text-neutral-400 font-medium">CA sur la période</div>
              <div className="text-lg sm:text-xl font-black text-[#111827]">
                {formatCurrency(stats.revenue.current, currency)}
              </div>
            </div>
            {stats.revenue.percentChange !== null && (
              <div
                className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold ${
                  stats.revenue.trend === 'up'
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                    : stats.revenue.trend === 'down'
                    ? 'bg-rose-50 text-rose-700 border border-rose-200'
                    : 'bg-neutral-100 text-neutral-700'
                }`}
              >
                {stats.revenue.trend === 'up' ? (
                  <ArrowUpRight className="w-3.5 h-3.5 stroke-[3]" />
                ) : stats.revenue.trend === 'down' ? (
                  <ArrowDownRight className="w-3.5 h-3.5 stroke-[3]" />
                ) : null}
                <span>
                  {stats.revenue.percentChange > 0 ? '+' : ''}
                  {stats.revenue.percentChange}%
                </span>
              </div>
            )}
          </div>
        </div>

        {/* SVG Interactive Chart Canvas */}
        <div className="relative w-full overflow-hidden bg-neutral-50/60 rounded-2xl border border-neutral-100 p-2 sm:p-4">
          {dailySeries.length === 0 ? (
            <div className="py-16 text-center text-sm text-neutral-400">
              Aucune donnée pour cette période.
            </div>
          ) : (
            <>
              <svg
                viewBox={`0 0 ${chartWidth} ${chartHeight}`}
                className="w-full h-[220px] sm:h-[260px] select-none"
                preserveAspectRatio="none"
              >
                <defs>
                  {/* Emerald Gradient for Revenue Fill */}
                  <linearGradient id="emeraldGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#00C48C" stopOpacity="0.35" />
                    <stop offset="70%" stopColor="#00C48C" stopOpacity="0.08" />
                    <stop offset="100%" stopColor="#00C48C" stopOpacity="0.0" />
                  </linearGradient>

                  <linearGradient id="lineStrokeGradient" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="#FF8A00" />
                    <stop offset="60%" stopColor="#00C48C" />
                    <stop offset="100%" stopColor="#009e70" />
                  </linearGradient>
                </defs>

                {/* Horizontal reference grid lines */}
                {[0.25, 0.5, 0.75, 1].map((ratio, idx) => {
                  const y = chartHeight - paddingY - ratio * innerHeight;
                  const val = Math.round(maxDayRevenue * ratio);
                  return (
                    <g key={idx}>
                      <line
                        x1={paddingX}
                        y1={y}
                        x2={chartWidth - paddingX}
                        y2={y}
                        stroke="#E5E7EB"
                        strokeDasharray="4 4"
                        strokeWidth="1"
                      />
                      <text
                        x={paddingX - 6}
                        y={y + 3}
                        textAnchor="end"
                        fontSize="9"
                        fill="#9CA3AF"
                        fontWeight="500"
                      >
                        {val > 1000 ? `${Math.round(val / 1000)}k` : val}
                      </text>
                    </g>
                  );
                })}

                {/* Bottom baseline */}
                <line
                  x1={paddingX}
                  y1={chartHeight - paddingY}
                  x2={chartWidth - paddingX}
                  y2={chartHeight - paddingY}
                  stroke="#D1D5DB"
                  strokeWidth="1.5"
                />

                {/* Shaded Area under Curve */}
                {areaPathD && (
                  <path d={areaPathD} fill="url(#emeraldGradient)" />
                )}

                {/* Curve Line */}
                {linePathD && (
                  <path
                    d={linePathD}
                    fill="none"
                    stroke="url(#lineStrokeGradient)"
                    strokeWidth="3.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                )}

                {/* Vertical indicator line for hovered point */}
                {hoveredPointIndex !== null && linePoints[hoveredPointIndex] && (
                  <line
                    x1={linePoints[hoveredPointIndex].x}
                    y1={paddingY}
                    x2={linePoints[hoveredPointIndex].x}
                    y2={chartHeight - paddingY}
                    stroke="#FF8A00"
                    strokeWidth="1.5"
                    strokeDasharray="3 3"
                  />
                )}

                {/* Interactive Points */}
                {linePoints.map(p => {
                  const isHovered = hoveredPointIndex === p.index;
                  const hasRevenue = p.data.revenue > 0;

                  return (
                    <g
                      key={p.index}
                      className="cursor-pointer transition-transform"
                      onMouseEnter={() => setHoveredPointIndex(p.index)}
                      onTouchStart={() => setHoveredPointIndex(p.index)}
                      onClick={() => onSelectDay(p.data)}
                    >
                      {/* Generous touch target */}
                      <circle
                        cx={p.x}
                        cy={p.y}
                        r="16"
                        fill="transparent"
                      />

                      {/* Outer pulse when hovered */}
                      {isHovered && (
                        <circle
                          cx={p.x}
                          cy={p.y}
                          r="10"
                          fill="#FF8A00"
                          fillOpacity="0.25"
                        />
                      )}

                      {/* Main node */}
                      <circle
                        cx={p.x}
                        cy={p.y}
                        r={isHovered ? '6' : hasRevenue ? '4.5' : '3'}
                        fill={isHovered ? '#FF8A00' : hasRevenue ? '#00C48C' : '#D1D5DB'}
                        stroke="#FFFFFF"
                        strokeWidth="2"
                      />
                    </g>
                  );
                })}
              </svg>

              {/* Dynamic Interactive Tooltip Box on Hover */}
              <AnimatePresence>
                {activePoint && (
                  <motion.div
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 6 }}
                    className="mt-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 sm:p-4 bg-white rounded-2xl shadow-md border border-neutral-200"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-orange-50 text-[#FF8A00] flex items-center justify-center font-bold text-xs">
                        <Calendar className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-xs text-neutral-400 font-medium">
                          Journée sélectionnée
                        </div>
                        <div className="text-sm font-bold text-[#111827]">
                          {formatDate(activePoint.dateKey)}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 flex-wrap">
                      <div>
                        <div className="text-[11px] text-neutral-400 font-medium">Encaissé</div>
                        <div className="text-sm sm:text-base font-extrabold text-[#00C48C]">
                          {formatCurrency(activePoint.revenue, currency)}
                        </div>
                      </div>

                      {activePoint.pending > 0 && (
                        <div>
                          <div className="text-[11px] text-neutral-400 font-medium">En attente</div>
                          <div className="text-sm sm:text-base font-extrabold text-[#FF8A00]">
                            {formatCurrency(activePoint.pending, currency)}
                          </div>
                        </div>
                      )}

                      <div>
                        <div className="text-[11px] text-neutral-400 font-medium">Factures</div>
                        <div className="text-sm font-bold text-neutral-800">
                          {activePoint.invoicesCount} ({activePoint.paidCount} payée{activePoint.paidCount > 1 ? 's' : ''})
                        </div>
                      </div>

                      <button
                        onClick={() => onSelectDay(activePoint)}
                        className="py-1.5 px-3 rounded-xl bg-[#FF8A00] hover:bg-[#e67c00] text-white text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1"
                      >
                        <span>Voir cette journée</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </>
          )}
        </div>
      </div>

      {/* =========================================================================
          ROW 2 : GRAPHIQUE 2 (Revenus & Paiements) & GRAPHIQUE 3 (Évolution des factures)
          ========================================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* GRAPHIQUE 2 : Revenus et paiements */}
        <div className="bg-white rounded-3xl p-5 sm:p-7 shadow-xs border border-neutral-200/80 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-orange-50 text-[#FF8A00] flex items-center justify-center">
                  <DollarSign className="w-4 h-4 stroke-[2.5]" />
                </div>
                <h3 className="text-base font-bold text-[#111827]">
                  Graphique 2 · Revenus et paiements
                </h3>
              </div>
              <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-neutral-100 text-neutral-700">
                Taux : {collectionRate}%
              </span>
            </div>
            <p className="text-xs text-neutral-500 mb-6">
              Ventilation entre les montants encaissés ({formatCurrency(stats.revenue.current, currency)}) et les impayés ({formatCurrency(stats.pendingAmount.current, currency)}).
            </p>

            {/* Horizontal Stacked Bar */}
            <div className="space-y-2 mb-6">
              <div className="h-6 w-full bg-neutral-100 rounded-full overflow-hidden flex p-1 gap-1">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{
                    width: totalBilled > 0 ? `${(stats.revenue.current / totalBilled) * 100}%` : '50%',
                  }}
                  transition={{ duration: 0.6, ease: 'easeOut' }}
                  className="h-full bg-gradient-to-r from-emerald-500 to-[#00C48C] rounded-full"
                  title={`Encaissé : ${formatCurrency(stats.revenue.current, currency)}`}
                />
                <motion.div
                  initial={{ width: 0 }}
                  animate={{
                    width: totalBilled > 0 ? `${(stats.pendingAmount.current / totalBilled) * 100}%` : '50%',
                  }}
                  transition={{ duration: 0.6, ease: 'easeOut' }}
                  className="h-full bg-gradient-to-r from-amber-400 to-[#FF8A00] rounded-full"
                  title={`En attente : ${formatCurrency(stats.pendingAmount.current, currency)}`}
                />
              </div>

              <div className="flex items-center justify-between text-xs font-semibold px-1">
                <button
                  onClick={() => onFilterByStatus && onFilterByStatus('paid')}
                  className="flex items-center gap-1.5 text-[#00C48C] hover:underline cursor-pointer"
                >
                  <span className="w-2.5 h-2.5 rounded-full bg-[#00C48C]" />
                  <span>Encaissé : {formatCurrency(stats.revenue.current, currency)}</span>
                </button>
                <button
                  onClick={() => onFilterByStatus && onFilterByStatus('pending')}
                  className="flex items-center gap-1.5 text-[#FF8A00] hover:underline cursor-pointer"
                >
                  <span className="w-2.5 h-2.5 rounded-full bg-[#FF8A00]" />
                  <span>Impayé : {formatCurrency(stats.pendingAmount.current, currency)}</span>
                </button>
              </div>
            </div>

            {/* 2 Stat summary blocks */}
            <div className="grid grid-cols-2 gap-3 pt-4 border-t border-neutral-100">
              <div
                onClick={() => onFilterByStatus && onFilterByStatus('paid')}
                className="p-3.5 rounded-2xl bg-emerald-50/50 border border-emerald-100/60 cursor-pointer hover:bg-emerald-50 transition-colors"
              >
                <div className="text-[11px] font-semibold text-emerald-800">Factures réglées</div>
                <div className="text-lg font-black text-emerald-700 mt-0.5">
                  {stats.paidInvoicesCount.current} factures
                </div>
                <div className="text-[10px] text-emerald-600 mt-1 font-medium">
                  {totalBilled > 0 ? Math.round((stats.revenue.current / totalBilled) * 100) : 0}% du volume total
                </div>
              </div>

              <div
                onClick={() => onFilterByStatus && onFilterByStatus('pending')}
                className="p-3.5 rounded-2xl bg-orange-50/50 border border-orange-100/60 cursor-pointer hover:bg-orange-50 transition-colors"
              >
                <div className="text-[11px] font-semibold text-orange-800">Restant à percevoir</div>
                <div className="text-lg font-black text-orange-700 mt-0.5">
                  {stats.pendingInvoices.length} factures
                </div>
                <div className="text-[10px] text-orange-600 mt-1 font-medium">
                  Relances disponibles sur WhatsApp
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* GRAPHIQUE 3 : Évolution des factures */}
        <div className="bg-white rounded-3xl p-5 sm:p-7 shadow-xs border border-neutral-200/80 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                  <FileCheck2 className="w-4 h-4 stroke-[2.5]" />
                </div>
                <h3 className="text-base font-bold text-[#111827]">
                  Graphique 3 · Évolution des factures
                </h3>
              </div>
              <span className="text-xs font-bold text-neutral-500">
                Total : {stats.invoicesCount.current}
              </span>
            </div>
            <p className="text-xs text-neutral-500 mb-5">
              Suivi quotidien des factures créées, payées et en attente au cours de la période sélectionnée.
            </p>

            {/* Daily Bar Histogram */}
            <div className="h-[140px] flex items-end gap-1.5 pt-4 pb-2 px-1 border-b border-neutral-100 overflow-x-auto">
              {dailySeries.slice(-20).map((d, idx) => {
                const totalH = maxDayInvoices > 0 ? (d.invoicesCount / maxDayInvoices) * 100 : 0;
                const paidH = d.invoicesCount > 0 ? (d.paidCount / d.invoicesCount) * totalH : 0;
                const pendingH = totalH - paidH;

                return (
                  <div
                    key={idx}
                    onClick={() => onSelectDay(d)}
                    className="flex-1 min-w-[14px] max-w-[28px] h-full flex flex-col justify-end items-center group cursor-pointer relative"
                    title={`${d.displayDate} : ${d.invoicesCount} factures (${d.paidCount} payées)`}
                  >
                    {/* Tooltip on bar hover */}
                    <div className="absolute -top-7 hidden group-hover:flex px-1.5 py-0.5 rounded bg-[#111827] text-white text-[9px] font-bold whitespace-nowrap z-20">
                      {d.displayDate}: {d.invoicesCount}
                    </div>

                    <div
                      className="w-full rounded-t-sm overflow-hidden flex flex-col justify-end transition-all group-hover:brightness-95"
                      style={{ height: `${Math.max(totalH, d.invoicesCount > 0 ? 8 : 2)}%` }}
                    >
                      {pendingH > 0 && (
                        <div
                          className="w-full bg-[#FF8A00]"
                          style={{ height: `${pendingH}%` }}
                        />
                      )}
                      {paidH > 0 && (
                        <div
                          className="w-full bg-[#00C48C]"
                          style={{ height: `${paidH}%` }}
                        />
                      )}
                      {d.invoicesCount === 0 && (
                        <div className="w-full h-1 bg-neutral-200" />
                      )}
                    </div>
                    <span className="text-[8px] text-neutral-400 mt-1 truncate max-w-full">
                      {d.displayDate.split(' ')[0]}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Legend */}
            <div className="flex items-center justify-center gap-6 mt-4 text-xs font-semibold text-neutral-600">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-sm bg-[#00C48C]" />
                <span>Factures réglées ({stats.paidInvoicesCount.current})</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-sm bg-[#FF8A00]" />
                <span>En attente ({stats.pendingInvoices.length})</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          GRAPHIQUE 4 : ACTIVITÉ DES CLIENTS
          ========================================================================= */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 shadow-xs border border-neutral-200/80">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <Users className="w-4 h-4 stroke-[2.5]" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-[#111827]">
                Graphique 4 · Activité des clients sur la période
              </h3>
              <p className="text-xs sm:text-sm text-neutral-500">
                {stats.clientsCount.current} client{stats.clientsCount.current > 1 ? 's' : ''} enregistré{stats.clientsCount.current > 1 ? 's' : ''} avec factures actives sur cette période.
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs text-neutral-400">Total clients actifs</span>
            <div className="text-lg font-black text-[#111827]">
              {stats.clientsCount.current}
            </div>
          </div>
        </div>

        {/* Top Clients Table / Cards */}
        {topClients.length === 0 ? (
          <div className="py-10 text-center text-sm text-neutral-400 bg-neutral-50 rounded-2xl border border-neutral-100">
            Aucun client actif sur cette période.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {topClients.slice(0, 6).map((client, idx) => {
              const clientShare = stats.revenue.current > 0 ? Math.round((client.paidAmount / stats.revenue.current) * 100) : 0;
              return (
                <div
                  key={idx}
                  onClick={() => onSelectClient && onSelectClient(client.name)}
                  className="p-4 rounded-2xl bg-neutral-50 hover:bg-orange-50/40 border border-neutral-200/70 hover:border-orange-200 transition-all cursor-pointer group flex flex-col justify-between"
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-orange-100 text-[#FF8A00] font-bold text-xs flex items-center justify-center uppercase">
                        {client.name.slice(0, 2)}
                      </div>
                      <div>
                        <div className="text-sm font-bold text-[#111827] group-hover:text-[#FF8A00] transition-colors truncate max-w-[150px]">
                          {client.name}
                        </div>
                        <div className="text-[11px] text-neutral-400">
                          {client.city || 'Client'}
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-neutral-200/70 text-neutral-700">
                      #{idx + 1}
                    </span>
                  </div>

                  <div className="pt-2 border-t border-neutral-200/60 flex items-center justify-between text-xs">
                    <div>
                      <span className="text-[10px] text-neutral-400">Factures : </span>
                      <span className="font-bold text-neutral-700">{client.invoicesCount}</span>
                    </div>
                    <div className="text-right">
                      <div className="font-extrabold text-[#00C48C]">
                        {formatCurrency(client.paidAmount, currency)}
                      </div>
                      {client.totalAmount > client.paidAmount && (
                        <div className="text-[10px] text-amber-600 font-semibold">
                          +{formatCurrency(client.totalAmount - client.paidAmount, currency)} impayé
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
