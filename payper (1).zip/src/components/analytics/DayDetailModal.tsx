import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Calendar,
  CheckCircle2,
  Clock,
  ArrowRight,
  Share2,
  ExternalLink,
  DollarSign,
  FileText,
} from 'lucide-react';
import { DayDataPoint } from '../../lib/analytics';
import { formatCurrency, formatDate } from '../../lib/invoice';
import { Currency, Invoice } from '../../types';
import { updateInvoice } from '../../lib/storage';
import { useToast } from '../common/Toast';

interface DayDetailModalProps {
  dayPoint: DayDataPoint | null;
  currency: Currency;
  onClose: () => void;
  onNavigateToInvoice: (invoiceId: string) => void;
  onInvoiceUpdated?: () => void;
}

export const DayDetailModal: React.FC<DayDetailModalProps> = ({
  dayPoint,
  currency,
  onClose,
  onNavigateToInvoice,
  onInvoiceUpdated,
}) => {
  const { showToast } = useToast();

  if (!dayPoint) return null;

  const handleMarkPaid = (inv: Invoice, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated: Invoice = { ...inv, isPaid: true };
    updateInvoice(updated);
    showToast(`Facture ${inv.id} marquée comme payée !`, 'success');
    if (onInvoiceUpdated) onInvoiceUpdated();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/50 backdrop-blur-xs"
      />

      {/* Modal Dialog */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative z-10 bg-white rounded-3xl shadow-2xl max-w-2xl w-full p-5 sm:p-7 overflow-hidden max-h-[90vh] flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-100 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-orange-50 border border-orange-100 flex items-center justify-center text-[#FF8A00]">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-[#111827]">
                Détail du {formatDate(dayPoint.dateKey)}
              </h2>
              <div className="text-xs text-neutral-400">
                {dayPoint.invoicesCount} facture{dayPoint.invoicesCount > 1 ? 's' : ''} enregistrée{dayPoint.invoicesCount > 1 ? 's' : ''} ce jour
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 rounded-xl transition-colors cursor-pointer"
            aria-label="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick summary stats */}
        <div className="grid grid-cols-2 gap-3 my-4 shrink-0">
          <div className="p-3.5 bg-emerald-50/70 border border-emerald-100 rounded-2xl">
            <div className="text-[11px] font-semibold text-emerald-800">Encaissé ce jour</div>
            <div className="text-lg font-black text-[#00C48C] mt-0.5">
              {formatCurrency(dayPoint.revenue, currency)}
            </div>
            <div className="text-[10px] text-emerald-700 font-medium mt-0.5">
              {dayPoint.paidCount} facture{dayPoint.paidCount > 1 ? 's' : ''} payée{dayPoint.paidCount > 1 ? 's' : ''}
            </div>
          </div>

          <div className="p-3.5 bg-orange-50/70 border border-orange-100 rounded-2xl">
            <div className="text-[11px] font-semibold text-orange-800">Restant à encaisser</div>
            <div className="text-lg font-black text-[#FF8A00] mt-0.5">
              {formatCurrency(dayPoint.pending, currency)}
            </div>
            <div className="text-[10px] text-orange-700 font-medium mt-0.5">
              {dayPoint.pendingCount} facture{dayPoint.pendingCount > 1 ? 's' : ''} en attente
            </div>
          </div>
        </div>

        {/* Invoice list */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 py-1">
          {dayPoint.invoices.length === 0 ? (
            <div className="py-12 text-center text-sm text-neutral-400">
              Aucune facture générée ce jour-là.
            </div>
          ) : (
            dayPoint.invoices.map(inv => {
              return (
                <div
                  key={inv.id}
                  onClick={() => {
                    onClose();
                    onNavigateToInvoice(inv.id);
                  }}
                  className="p-3.5 sm:p-4 rounded-2xl bg-neutral-50 hover:bg-orange-50/40 border border-neutral-200/80 hover:border-orange-200 transition-all cursor-pointer group flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        inv.isPaid ? 'bg-emerald-100 text-[#00C48C]' : 'bg-orange-100 text-[#FF8A00]'
                      }`}
                    >
                      <FileText className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-[#111827] truncate">
                          {inv.clientName}
                        </span>
                        <span
                          className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                            inv.isPaid
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {inv.isPaid ? 'PAYÉE' : 'EN ATTENTE'}
                        </span>
                      </div>
                      <div className="text-xs text-neutral-500 truncate mt-0.5">
                        {inv.id} · {inv.description || 'Prestation'}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right">
                      <div className="text-sm sm:text-base font-extrabold text-[#111827]">
                        {formatCurrency(inv.amount, inv.devise || currency)}
                      </div>
                      <div className="text-[10px] text-neutral-400">
                        {formatDate(inv.date)}
                      </div>
                    </div>

                    {!inv.isPaid && (
                      <button
                        onClick={e => handleMarkPaid(inv, e)}
                        className="py-1 px-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold shadow-xs cursor-pointer"
                        title="Marquer comme payée"
                      >
                        Encaisser
                      </button>
                    )}

                    <ArrowRight className="w-4 h-4 text-neutral-400 group-hover:text-[#FF8A00] transition-colors" />
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-neutral-100 mt-4 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="py-2.5 px-5 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-xs font-bold transition-colors cursor-pointer"
          >
            Fermer
          </button>
        </div>
      </motion.div>
    </div>
  );
};
