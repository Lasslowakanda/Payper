import React from 'react';
import { motion } from 'motion/react';
import { X, Printer, Download, FileText, CheckCircle2 } from 'lucide-react';
import { AnalyticsStats } from '../../lib/analytics';
import { formatCurrency, formatDate } from '../../lib/invoice';
import { Boutique, Currency } from '../../types';
import { PayperLogo } from '../common/PayperLogo';

interface PrintReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  stats: AnalyticsStats;
  boutique: Boutique | null;
  currency: Currency;
}

export const PrintReportModal: React.FC<PrintReportModalProps> = ({
  isOpen,
  onClose,
  stats,
  boutique,
  currency,
}) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const boutiqueName = boutique?.name || 'Ma Boutique';
  const totalBilled = stats.revenue.current + stats.pendingAmount.current;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/60 backdrop-blur-xs"
      />

      {/* Report Modal */}
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.96 }}
        className="relative z-10 bg-white rounded-3xl shadow-2xl max-w-3xl w-full p-6 sm:p-8 overflow-y-auto max-h-[92vh] flex flex-col"
      >
        {/* Top bar (hidden in print) */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-100 print:hidden shrink-0">
          <div>
            <h2 className="text-lg font-bold text-[#111827]">
              Rapport d'activité & Statistiques
            </h2>
            <p className="text-xs text-neutral-400">
              Prêt pour impression ou sauvegarde en PDF
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 py-2 px-4 rounded-xl bg-[#FF8A00] hover:bg-[#e67c00] text-white text-xs font-bold transition-all shadow-sm cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimer / Sauvegarder PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-neutral-400 hover:text-neutral-700 rounded-xl hover:bg-neutral-100 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div className="pt-6 space-y-6 printable-report">
          {/* Header */}
          <div className="flex items-start justify-between border-b border-neutral-200 pb-5">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <PayperLogo size="sm" />
                <span className="text-xs px-2 py-0.5 rounded bg-neutral-100 text-neutral-600 font-bold uppercase">
                  Rapport Analytique
                </span>
              </div>
              <h1 className="text-2xl font-black text-[#111827]">{boutiqueName}</h1>
              <div className="text-xs text-neutral-500 mt-0.5">
                {boutique?.city || 'Afrique'} · {boutique?.phone || ''}
              </div>
            </div>

            <div className="text-right">
              <div className="text-xs text-neutral-400 font-medium">Période d'analyse</div>
              <div className="text-sm font-bold text-[#111827]">{stats.periodLabel}</div>
              <div className="text-[11px] text-neutral-400 mt-1">
                Généré le {new Date().toLocaleDateString('fr-FR')} à {new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </div>

          {/* Core Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200/80">
              <div className="text-[11px] font-semibold text-neutral-500 uppercase">
                Chiffre d'affaires
              </div>
              <div className="text-lg font-black text-[#00C48C] mt-1">
                {formatCurrency(stats.revenue.current, currency)}
              </div>
              {stats.revenue.percentChange !== null && (
                <div className="text-[10px] text-neutral-500 mt-1">
                  Évol : {stats.revenue.percentChange > 0 ? '+' : ''}{stats.revenue.percentChange}%
                </div>
              )}
            </div>

            <div className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200/80">
              <div className="text-[11px] font-semibold text-neutral-500 uppercase">
                Factures créées
              </div>
              <div className="text-lg font-black text-[#111827] mt-1">
                {stats.invoicesCount.current}
              </div>
              <div className="text-[10px] text-neutral-500 mt-1">
                {stats.paidInvoicesCount.current} payées ({stats.collectionRate}%)
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200/80">
              <div className="text-[11px] font-semibold text-neutral-500 uppercase">
                Impayés
              </div>
              <div className="text-lg font-black text-[#FF8A00] mt-1">
                {formatCurrency(stats.pendingAmount.current, currency)}
              </div>
              <div className="text-[10px] text-neutral-500 mt-1">
                {stats.pendingInvoices.length} factures en attente
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200/80">
              <div className="text-[11px] font-semibold text-neutral-500 uppercase">
                Clients actifs
              </div>
              <div className="text-lg font-black text-[#111827] mt-1">
                {stats.clientsCount.current}
              </div>
              <div className="text-[10px] text-neutral-500 mt-1">
                sur cette période
              </div>
            </div>
          </div>

          {/* Breakdown Table */}
          <div>
            <h3 className="text-sm font-bold text-[#111827] mb-3">
              Liste des factures de la période ({stats.currentInvoices.length})
            </h3>
            <div className="border border-neutral-200 rounded-2xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-600 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="py-2.5 px-3">Numéro</th>
                    <th className="py-2.5 px-3">Date</th>
                    <th className="py-2.5 px-3">Client</th>
                    <th className="py-2.5 px-3">Montant</th>
                    <th className="py-2.5 px-3 text-right">Statut</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {stats.currentInvoices.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-6 text-center text-neutral-400">
                        Aucune facture sur cette période.
                      </td>
                    </tr>
                  ) : (
                    stats.currentInvoices.slice(0, 50).map(inv => (
                      <tr key={inv.id} className="hover:bg-neutral-50/50">
                        <td className="py-2.5 px-3 font-semibold text-neutral-800">{inv.id}</td>
                        <td className="py-2.5 px-3 text-neutral-500">{formatDate(inv.date)}</td>
                        <td className="py-2.5 px-3 font-bold text-neutral-900">{inv.clientName}</td>
                        <td className="py-2.5 px-3 font-extrabold text-[#111827]">
                          {formatCurrency(inv.amount, inv.devise || currency)}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          <span
                            className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              inv.isPaid
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-amber-100 text-amber-800'
                            }`}
                          >
                            {inv.isPaid ? 'PAYÉE' : 'EN ATTENTE'}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Footer note */}
          <div className="pt-4 border-t border-neutral-100 flex items-center justify-between text-[11px] text-neutral-400">
            <span>Rapport certifié édité par PAYPER</span>
            <span>Page 1 / 1</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
