import React from 'react';

interface IntegrationAppLogoProps {
  appId: string;
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export const IntegrationAppLogo: React.FC<IntegrationAppLogoProps> = ({
  appId,
  className = '',
  size = 'md',
}) => {
  const sizeClasses = {
    sm: 'w-7 h-7 p-1 rounded-lg',
    md: 'w-12 h-12 p-2 rounded-2xl',
    lg: 'w-16 h-16 p-2.5 rounded-3xl',
    xl: 'w-20 h-20 p-3 rounded-3xl',
  };

  const containerSize = sizeClasses[size];

  switch (appId) {
    case 'zapier':
      // Official Zapier Asterisk in vibrant orange box
      return (
        <div
          className={`flex items-center justify-center bg-[#FF4F00] shadow-sm shrink-0 ${containerSize} ${className}`}
          title="Zapier"
        >
          <svg viewBox="0 0 40 40" className="w-full h-full fill-white" aria-hidden="true">
            {/* Zapier Asterisk (5 points) */}
            <rect x="17.5" y="4" width="5" height="32" rx="2.5" />
            <rect
              x="17.5"
              y="4"
              width="5"
              height="32"
              rx="2.5"
              transform="rotate(72 20 20)"
            />
            <rect
              x="17.5"
              y="4"
              width="5"
              height="32"
              rx="2.5"
              transform="rotate(144 20 20)"
            />
            <rect
              x="17.5"
              y="4"
              width="5"
              height="32"
              rx="2.5"
              transform="rotate(216 20 20)"
            />
            <rect
              x="17.5"
              y="4"
              width="5"
              height="32"
              rx="2.5"
              transform="rotate(288 20 20)"
            />
          </svg>
        </div>
      );

    case 'systeme_io':
      // Official Systeme.io Royal Blue with signature 'S'
      return (
        <div
          className={`flex items-center justify-center bg-gradient-to-br from-[#0B57D0] to-[#0047BA] shadow-sm shrink-0 ${containerSize} ${className}`}
          title="Systeme.io"
        >
          <svg viewBox="0 0 48 48" className="w-full h-full fill-white" aria-hidden="true">
            <path
              d="M34 14.5c-1.8-2.6-5.2-4.5-9.8-4.5-7.2 0-12.2 4.6-12.2 11.2 0 10.4 14.4 7.4 14.4 13.8 0 2.8-2.6 4.8-6.4 4.8-4.2 0-7.8-2-10-5.2l-3.2 4.2c2.8 4 7.6 6.6 13.2 6.6 8 0 13.6-4.8 13.6-11.6 0-10.8-14.4-7.8-14.4-14.2 0-2.4 2.2-4.2 5.4-4.2 3.6 0 6.4 1.4 8.2 3.8l3.2-4.7z"
              fill="#FFFFFF"
            />
          </svg>
        </div>
      );

    case 'whatsapp_business':
      // Official WhatsApp Green with phone speech bubble
      return (
        <div
          className={`flex items-center justify-center bg-[#25D366] shadow-sm shrink-0 ${containerSize} ${className}`}
          title="WhatsApp Business"
        >
          <svg viewBox="0 0 48 48" className="w-full h-full fill-white" aria-hidden="true">
            <path d="M24 4C13 4 4 13 4 24c0 3.8 1.1 7.3 3 10.3L4 44l10.1-2.9C17 42.9 20.4 44 24 44c11 0 20-9 20-20S35 4 24 4zm11.7 28.3c-.5 1.4-2.5 2.6-4.1 2.8-1.1.2-2.5.3-7.2-1.6-6-2.5-9.9-8.6-10.2-9-.3-.4-2.4-3.2-2.4-6.1s1.5-4.3 2.1-4.9c.5-.6 1.2-.8 1.7-.8.4 0 .8 0 1.2.1.4.1.9-.1 1.4 1.1.5 1.3 1.8 4.4 2 4.7.2.4.3.8.1 1.3-.2.4-.4.7-.7 1-.3.3-.6.7-.9 1-.3.3-.6.7-.3 1.3.4.6 1.7 2.8 3.6 4.5 2.5 2.2 4.6 2.9 5.2 3.2.6.3 1 .3 1.4-.2.4-.5 1.7-2 2.2-2.7.5-.7 1-.6 1.6-.3.6.3 3.9 1.8 4.6 2.2.7.3 1.1.5 1.3.8.2.3.2 1.8-.3 3.2z" />
          </svg>
        </div>
      );

    case 'instagram':
      // Official Instagram Gradient with Camera
      return (
        <div
          className={`flex items-center justify-center bg-gradient-to-tr from-[#F58529] via-[#DD2A7B] to-[#8134AF] shadow-sm shrink-0 ${containerSize} ${className}`}
          title="Instagram"
        >
          <svg viewBox="0 0 48 48" className="w-full h-full fill-none stroke-white" strokeWidth="3.5" aria-hidden="true">
            <rect x="8" y="8" width="32" height="32" rx="10" />
            <circle cx="24" cy="24" r="7.5" />
            <circle cx="33.5" cy="14.5" r="1.5" fill="white" stroke="none" />
          </svg>
        </div>
      );

    case 'facebook_messenger':
      // Official Messenger Gradient with Lightning bolt
      return (
        <div
          className={`flex items-center justify-center bg-gradient-to-tr from-[#0084FF] via-[#00C6FF] to-[#0078FF] shadow-sm shrink-0 ${containerSize} ${className}`}
          title="Facebook Messenger"
        >
          <svg viewBox="0 0 48 48" className="w-full h-full fill-white" aria-hidden="true">
            <path d="M24 4C12.4 4 3 12.8 3 23.7c0 6.2 3.1 11.7 7.9 15.3V44l4.8-2.6c2.5.7 5.2 1 7.9 1 11.6 0 21-8.8 21-19.7S35.6 4 24 4zm2.1 24.8l-5.4-5.8-10.5 5.8 11.5-12.3 5.4 5.8 10.5-5.8-11.5 12.3z" />
          </svg>
        </div>
      );

    case 'facebook':
      // Official Facebook Blue with 'f'
      return (
        <div
          className={`flex items-center justify-center bg-[#1877F2] shadow-sm shrink-0 ${containerSize} ${className}`}
          title="Facebook"
        >
          <svg viewBox="0 0 48 48" className="w-full h-full fill-white" aria-hidden="true">
            <path d="M40 4H8C5.8 4 4 5.8 4 8v32c0 2.2 1.8 4 4 4h17.2V28.5H19.5v-6h5.7V18c0-5.6 3.4-8.7 8.5-8.7 2.4 0 4.5.2 5.1.3v5.9h-3.5c-2.7 0-3.3 1.3-3.3 3.2v3.8h6.6l-.9 6h-5.7V44H40c2.2 0 4-1.8 4-4V8c0-2.2-1.8-4-4-4z" />
          </svg>
        </div>
      );

    case 'google_sheets':
      // Official Google Sheets Emerald green document with table grid
      return (
        <div
          className={`flex items-center justify-center bg-[#0F9D58] shadow-sm shrink-0 ${containerSize} ${className}`}
          title="Google Sheets"
        >
          <svg viewBox="0 0 48 48" className="w-full h-full" aria-hidden="true">
            <rect x="8" y="6" width="32" height="36" rx="4" fill="#FFFFFF" />
            <rect x="14" y="16" width="20" height="4" rx="1" fill="#0F9D58" />
            <rect x="14" y="23" width="9" height="4" rx="1" fill="#0F9D58" />
            <rect x="25" y="23" width="9" height="4" rx="1" fill="#0F9D58" />
            <rect x="14" y="30" width="9" height="4" rx="1" fill="#0F9D58" />
            <rect x="25" y="30" width="9" height="4" rx="1" fill="#0F9D58" />
          </svg>
        </div>
      );

    case 'google_calendar':
      // Official Google Calendar Clean 4-color layout
      return (
        <div
          className={`flex items-center justify-center bg-white border border-neutral-200 shadow-sm shrink-0 ${containerSize} ${className}`}
          title="Google Calendar"
        >
          <svg viewBox="0 0 48 48" className="w-full h-full" aria-hidden="true">
            <rect x="6" y="8" width="36" height="34" rx="6" fill="#4285F4" />
            <rect x="10" y="16" width="28" height="22" rx="3" fill="#FFFFFF" />
            <rect x="14" y="6" width="4" height="6" rx="2" fill="#EA4335" />
            <rect x="30" y="6" width="4" height="6" rx="2" fill="#EA4335" />
            <text
              x="24"
              y="32"
              fontFamily="sans-serif"
              fontSize="14"
              fontWeight="bold"
              fill="#4285F4"
              textAnchor="middle"
            >
              31
            </text>
          </svg>
        </div>
      );

    case 'email':
      // Professional corporate email indigo/blue
      return (
        <div
          className={`flex items-center justify-center bg-gradient-to-br from-indigo-500 to-blue-600 shadow-sm shrink-0 ${containerSize} ${className}`}
          title="E-mail"
        >
          <svg viewBox="0 0 48 48" className="w-full h-full fill-white" aria-hidden="true">
            <path d="M40 8H8C5.8 8 4 9.8 4 12v24c0 2.2 1.8 4 4 4h32c2.2 0 4-1.8 4-4V12c0-2.2-1.8-4-4-4zm-2.4 6L24 23.3 10.4 14h27.2zM8 34V16.8l15 10.3c.6.4 1.4.4 2 0l15-10.3V34H8z" />
          </svg>
        </div>
      );

    case 'payper':
    default:
      // Official PAYPER Brand Icon
      return (
        <div
          className={`flex items-center justify-center bg-gradient-to-br from-[#FF8A00] to-[#E67C00] shadow-sm shrink-0 ${containerSize} ${className}`}
          title="PAYPER"
        >
          <div className="flex items-center justify-center font-black text-white text-base tracking-tighter">
            <span>P</span>
            <span className="text-[#00C48C]">P</span>
          </div>
        </div>
      );
  }
};
