import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  CheckCircle2,
  AlertCircle,
  Clock,
  ArrowRight,
  ShieldCheck,
  Zap,
  Play,
  Layers,
  ExternalLink,
  HelpCircle,
  Copy,
  Check,
} from 'lucide-react';
import { IntegrationApp, saveIntegrationConfig } from '../../lib/integrations';
import { IntegrationAppLogo } from './IntegrationAppLogo';
import { useToast } from '../common/Toast';

interface IntegrationDetailModalProps {
  app: IntegrationApp | null;
  isOpen: boolean;
  onClose: () => void;
  onCreateWorkflow: (appId: string) => void;
  onConfigSaved: () => void;
}

export const IntegrationDetailModal: React.FC<IntegrationDetailModalProps> = ({
  app,
  isOpen,
  onClose,
  onCreateWorkflow,
  onConfigSaved,
}) => {
  const { showToast } = useToast();
  const [webhookInput, setWebhookInput] = useState('');
  const [isCopied, setIsCopied] = useState(false);

  // Sync webhook input when app changes
  React.useEffect(() => {
    if (app) {
      setWebhookInput(app.webhookUrl || '');
    }
  }, [app]);

  if (!isOpen || !app) return null;

  const isConnected = app.status === 'CONNECTED';
  const isComingSoon = app.status === 'COMING_SOON';
  const requiresSetup = app.status === 'REQUIRES_SETUP';

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    if (!webhookInput.trim()) {
      showToast('Veuillez renseigner une URL de webhook valide.', 'error');
      return;
    }

    try {
      new URL(webhookInput.trim());
    } catch {
      showToast('Format d\'URL invalide (doit commencer par https://).', 'error');
      return;
    }

    saveIntegrationConfig(app.id, webhookInput.trim(), true);
    showToast(`Intégration « ${app.name} » configurée avec succès ✓`, 'success');
    onConfigSaved();
  };

  const handleDisconnect = () => {
    saveIntegrationConfig(app.id, '', false);
    setWebhookInput('');
    showToast(`Intégration « ${app.name} » déconnectée.`, 'info');
    onConfigSaved();
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setIsCopied(true);
    showToast('Exemple copié dans le presse-papiers ✓', 'info');
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/60 backdrop-blur-xs"
      />

      {/* Modal Dialog */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative z-10 bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-neutral-100 overflow-hidden my-6 max-h-[90vh] flex flex-col"
      >
        {/* Header with Brand Styling */}
        <div className="p-6 sm:p-7 border-b border-neutral-100 bg-neutral-50/60 flex items-start justify-between gap-4">
          <div className="flex items-center gap-4 min-w-0">
            <IntegrationAppLogo appId={app.id} size="lg" />
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <h2 className="text-xl sm:text-2xl font-black text-[#111827] tracking-tight">
                  {app.name}
                </h2>

                {/* Status Badge */}
                {isConnected ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Connecté</span>
                  </span>
                ) : requiresSetup ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>Configuration requise</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-neutral-100 text-neutral-600 border border-neutral-200">
                    <Clock className="w-3.5 h-3.5" />
                    <span>Bientôt disponible</span>
                  </span>
                )}
              </div>

              <p className="text-xs sm:text-sm text-neutral-500 leading-relaxed">
                {app.shortDescription}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-200/60 rounded-xl transition-colors cursor-pointer shrink-0"
            aria-label="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 sm:p-7 overflow-y-auto space-y-6 text-xs sm:text-sm">
          {/* Detailed Description */}
          <div>
            <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-2">
              À propos de l'intégration
            </h3>
            <p className="text-neutral-700 leading-relaxed text-xs sm:text-sm">
              {app.fullDescription}
            </p>
            {app.docsNote && (
              <div className="mt-2.5 p-3 rounded-xl bg-orange-50/60 border border-orange-100/80 text-[11px] text-neutral-600 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-[#FF8A00] shrink-0 mt-0.5" />
                <span>{app.docsNote}</span>
              </div>
            )}
          </div>

          {/* Section: Prérequis éventuels */}
          <div>
            <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-neutral-600" />
              <span>Prérequis nécessaires</span>
            </h3>
            <ul className="space-y-2">
              {app.prerequisites.map((req, i) => (
                <li
                  key={i}
                  className="flex items-start gap-2.5 text-neutral-700 text-xs bg-neutral-50/80 p-2.5 rounded-xl border border-neutral-100"
                >
                  <span className="w-5 h-5 rounded-lg bg-white border border-neutral-200 flex items-center justify-center font-bold text-[11px] text-[#FF8A00] shrink-0">
                    {i + 1}
                  </span>
                  <span className="mt-0.5">{req}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Section: Automatisations possibles (Scénarios d'usage) */}
          <div>
            <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-[#FF8A00]" />
              <span>Automatisations & scénarios possibles</span>
            </h3>
            <div className="space-y-2.5">
              {app.possibleAutomations.map((scenario, i) => (
                <div
                  key={i}
                  className="p-3.5 rounded-2xl border border-neutral-100 bg-white hover:border-neutral-200 transition-all shadow-2xs"
                >
                  <div className="font-bold text-[#111827] text-xs flex items-center gap-1.5 mb-1">
                    <Zap className="w-3.5 h-3.5 text-[#FF8A00]" />
                    <span>{scenario.title}</span>
                  </div>
                  <p className="text-[11px] text-neutral-500 leading-relaxed">
                    {scenario.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Grid: Déclencheurs (Triggers) & Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Triggers */}
            <div className="rounded-2xl border border-neutral-100 bg-neutral-50/60 p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#111827] flex items-center gap-1.5">
                  <Play className="w-3.5 h-3.5 text-[#00C48C]" />
                  <span>Déclencheurs (Triggers)</span>
                </span>
                <span className="text-[10px] font-bold text-neutral-400">Quand...</span>
              </div>
              <div className="space-y-1.5">
                {app.triggers.map((trig) => (
                  <div
                    key={trig.id}
                    className="p-2.5 rounded-xl bg-white border border-neutral-100 text-xs"
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span className="font-bold text-neutral-800">{trig.name}</span>
                      {trig.isSupported ? (
                        <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                          Supporté
                        </span>
                      ) : (
                        <span className="text-[10px] font-medium text-neutral-400 bg-neutral-100 px-1.5 py-0.5 rounded">
                          Bientôt
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-neutral-500 mt-0.5">{trig.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="rounded-2xl border border-neutral-100 bg-neutral-50/60 p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#111827] flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-[#FF8A00]" />
                  <span>Actions</span>
                </span>
                <span className="text-[10px] font-bold text-neutral-400">Faire...</span>
              </div>
              <div className="space-y-1.5">
                {app.actions.map((act) => (
                  <div
                    key={act.id}
                    className="p-2.5 rounded-xl bg-white border border-neutral-100 text-xs"
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span className="font-bold text-neutral-800">{act.name}</span>
                      {act.isSupported ? (
                        <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                          Supporté
                        </span>
                      ) : (
                        <span className="text-[10px] font-medium text-neutral-400 bg-neutral-100 px-1.5 py-0.5 rounded">
                          Bientôt
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-neutral-500 mt-0.5">{act.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Section Configuration / Connexion */}
          <div className="pt-2 border-t border-neutral-100">
            {isComingSoon ? (
              <div className="p-4 rounded-2xl bg-neutral-100 text-neutral-600 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-neutral-400" />
                  <span className="text-xs font-medium">
                    Cette intégration sera disponible très prochainement dans PAYPER.
                  </span>
                </div>
                <button
                  disabled
                  className="py-2 px-4 rounded-xl text-xs font-bold bg-neutral-300 text-neutral-500 cursor-not-allowed"
                >
                  Bientôt disponible
                </button>
              </div>
            ) : app.requiresConfig ? (
              <form onSubmit={handleSaveConfig} className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-[#111827] uppercase tracking-wider mb-1">
                    {app.configLabel || 'URL du Webhook de liaison'}
                  </label>
                  <input
                    type="url"
                    required
                    placeholder={app.configPlaceholder || 'https://...'}
                    value={webhookInput}
                    onChange={(e) => setWebhookInput(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-xs sm:text-sm font-medium text-neutral-900 focus:outline-none focus:border-[#FF8A00] focus:ring-1 focus:ring-[#FF8A00]"
                  />
                  <p className="text-[11px] text-neutral-400 mt-1">
                    Renseignez l'URL fournie par {app.name} pour synchroniser les événements PAYPER en temps réel.
                  </p>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  {isConnected && (
                    <button
                      type="button"
                      onClick={handleDisconnect}
                      className="py-2.5 px-4 rounded-xl text-xs font-semibold text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
                    >
                      Déconnecter
                    </button>
                  )}
                  <button
                    type="submit"
                    className="py-2.5 px-5 rounded-xl text-xs font-bold text-white bg-[#FF8A00] hover:bg-[#e67c00] transition-all shadow-sm cursor-pointer"
                  >
                    {isConnected ? 'Mettre à jour la configuration' : 'Connecter cette application'}
                  </button>
                </div>
              </form>
            ) : (
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <div>
                    <span className="text-xs font-bold text-emerald-900 block">
                      Intégration active et prête à l'emploi
                    </span>
                    <span className="text-[11px] text-emerald-700">
                      Utilisable directement dans vos workflows et relances automatiques.
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    onCreateWorkflow(app.id);
                    onClose();
                  }}
                  className="py-2 px-4 rounded-xl text-xs font-bold bg-[#00C48C] hover:bg-[#00ad7a] text-white transition-all shadow-sm cursor-pointer shrink-0 flex items-center justify-center gap-1.5"
                >
                  <span>Créer un workflow</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 border-t border-neutral-100 bg-neutral-50 flex flex-col-reverse sm:flex-row sm:items-center justify-between gap-2.5 sm:gap-3">
          <button
            onClick={onClose}
            className="w-full sm:w-auto py-2.5 px-4 rounded-xl text-xs font-semibold text-neutral-600 hover:bg-neutral-200/60 transition-colors cursor-pointer text-center min-h-[44px]"
          >
            Fermer
          </button>

          {!isComingSoon && (
            <button
              onClick={() => {
                onCreateWorkflow(app.id);
                onClose();
              }}
              className="w-full sm:w-auto py-2.5 px-5 rounded-xl text-xs font-bold text-white bg-[#FF8A00] hover:bg-[#e67c00] transition-all shadow-sm flex items-center justify-center gap-2 cursor-pointer min-h-[44px]"
            >
              <Zap className="w-4 h-4" />
              <span>Utiliser dans les workflows</span>
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
};
