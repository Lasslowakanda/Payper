import React, { useState } from 'react';
import {
  CheckCircle2,
  AlertCircle,
  Clock,
  Eye,
  ArrowRight,
  Settings,
  Zap,
  Layers,
  ExternalLink,
  ShieldCheck,
  Search,
} from 'lucide-react';
import { IntegrationApp, getEffectiveIntegrations } from '../../lib/integrations';
import { IntegrationAppLogo } from './IntegrationAppLogo';
import { IntegrationDetailModal } from './IntegrationDetailModal';

interface IntegrationsGalleryProps {
  onCreateWorkflow: (appId: string) => void;
}

export const IntegrationsGallery: React.FC<IntegrationsGalleryProps> = ({
  onCreateWorkflow,
}) => {
  const [integrations, setIntegrations] = useState<IntegrationApp[]>(() =>
    getEffectiveIntegrations()
  );
  const [selectedApp, setSelectedApp] = useState<IntegrationApp | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const reload = () => {
    setIntegrations(getEffectiveIntegrations());
  };

  const filteredIntegrations = integrations.filter((app) => {
    const matchesCategory =
      filterCategory === 'all' ||
      (filterCategory === 'connected' && app.status === 'CONNECTED') ||
      app.category === filterCategory;

    const matchesSearch =
      app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.shortDescription.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesSearch;
  });

  const connectedCount = integrations.filter((i) => i.status === 'CONNECTED').length;

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-300">
      {/* Top Banner introducing the Integrations Gallery */}
      <div className="bg-gradient-to-r from-orange-50 via-white to-emerald-50/40 rounded-3xl p-6 sm:p-7 border border-orange-100 flex flex-col md:flex-row md:items-center justify-between gap-5 shadow-2xs">
        <div className="space-y-1.5 max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="text-xl">⚡</span>
            <span className="text-xs font-bold uppercase tracking-wider text-[#FF8A00]">
              Écosystème & Connecteurs PAYPER
            </span>
            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-[#00C48C] text-[11px] font-bold">
              {connectedCount} active{connectedCount > 1 ? 's' : ''}
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-[#111827] tracking-tight">
            Connectez vos applications favorites
          </h2>
          <p className="text-xs sm:text-sm text-neutral-600 leading-relaxed">
            Automatisez vos factures, synchronisez vos ventes et relancez vos clients sans effort en connectant PAYPER à vos outils quotidiens.
          </p>
        </div>

        {/* Search Bar */}
        <div className="relative w-full md:w-72 shrink-0">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Rechercher une application..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white border border-neutral-200/90 text-xs sm:text-sm text-neutral-800 placeholder-neutral-400 focus:outline-none focus:border-[#FF8A00] focus:ring-1 focus:ring-[#FF8A00] shadow-2xs"
          />
        </div>
      </div>

      {/* Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden">
        {[
          { id: 'all', label: 'Toutes les applications' },
          { id: 'connected', label: `Connectées (${connectedCount})` },
          { id: 'messaging', label: 'Messagerie & Chat' },
          { id: 'marketing', label: 'Marketing & Tunnels' },
          { id: 'automation', label: 'Automatisations' },
          { id: 'productivity', label: 'Comptabilité & Feuilles' },
        ].map((f) => (
          <button
            key={f.id}
            onClick={() => setFilterCategory(f.id)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              filterCategory === f.id
                ? 'bg-[#111827] text-white shadow-2xs'
                : 'bg-white text-neutral-600 hover:bg-neutral-100 border border-neutral-200/70'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* =================================================================== */}
      {/* RESPONSIVE GRID: 2 COLUMNS ON MOBILE/TABLET, MULTI-COLUMNS ON PC    */}
      {/* =================================================================== */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-4 sm:gap-5">
        {filteredIntegrations.map((app) => {
          const isConnected = app.status === 'CONNECTED';
          const requiresSetup = app.status === 'REQUIRES_SETUP';
          const isComingSoon = app.status === 'COMING_SOON';

          return (
            <div
              key={app.id}
              className="group bg-white rounded-3xl border border-neutral-200/80 hover:border-neutral-300 shadow-2xs hover:shadow-md transition-all duration-200 flex flex-col justify-between overflow-hidden p-5 sm:p-6"
            >
              <div>
                {/* Card Top: Official Logo + Name + Status Indicator */}
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className="flex items-center gap-3 min-w-0">
                    <IntegrationAppLogo appId={app.id} size="md" />
                    <div className="min-w-0">
                      <h3 className="text-base sm:text-lg font-bold text-[#111827] truncate group-hover:text-[#FF8A00] transition-colors">
                        {app.name}
                      </h3>
                      <span className="text-[11px] font-medium text-neutral-400 capitalize block">
                        {app.category === 'messaging'
                          ? 'Messagerie'
                          : app.category === 'marketing'
                          ? 'Tunnels de vente'
                          : app.category === 'automation'
                          ? 'No-code & Webhook'
                          : app.category === 'productivity'
                          ? 'Productivité'
                          : app.category === 'social'
                          ? 'Réseaux sociaux'
                          : 'Cœur PAYPER'}
                      </span>
                    </div>
                  </div>

                  {/* Real Connection Status Indicator */}
                  {isConnected ? (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 shrink-0">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      <span>Connecté</span>
                    </span>
                  ) : requiresSetup ? (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-50 text-amber-700 border border-amber-200 shrink-0">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                      <span>À configurer</span>
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium bg-neutral-100 text-neutral-500 border border-neutral-200 shrink-0">
                      <Clock className="w-3 h-3" />
                      <span>Bientôt</span>
                    </span>
                  )}
                </div>

                {/* Card Body: Short Description */}
                <p className="text-xs text-neutral-600 leading-relaxed line-clamp-3 mb-4">
                  {app.shortDescription}
                </p>

                {/* Key feature pills */}
                <div className="mb-4 pt-3 border-t border-neutral-100 flex flex-wrap gap-1.5">
                  {app.triggers.slice(0, 2).map((t) => (
                    <span
                      key={t.id}
                      className="text-[10px] font-medium text-neutral-600 bg-neutral-50 border border-neutral-100 px-2 py-0.5 rounded-md truncate max-w-[160px]"
                    >
                      ⚡ {t.name}
                    </span>
                  ))}
                  {app.actions.slice(0, 1).map((a) => (
                    <span
                      key={a.id}
                      className="text-[10px] font-medium text-neutral-600 bg-neutral-50 border border-neutral-100 px-2 py-0.5 rounded-md truncate max-w-[160px]"
                    >
                      ✓ {a.name}
                    </span>
                  ))}
                </div>
              </div>

              {/* Card Footer: Action Buttons */}
              <div className="pt-3 border-t border-neutral-100 flex items-center justify-between gap-2 mt-auto">
                {/* Action: Découvrir les automatisations */}
                <button
                  onClick={() => setSelectedApp(app)}
                  className="inline-flex items-center gap-1 text-xs font-bold text-neutral-700 hover:text-[#FF8A00] transition-colors cursor-pointer py-1.5 px-1"
                >
                  <Eye className="w-3.5 h-3.5 text-[#FF8A00]" />
                  <span>Découvrir</span>
                </button>

                {/* Primary Action Button: Connecter / Configurer / Actif */}
                {isComingSoon ? (
                  <button
                    disabled
                    className="py-2 px-3 rounded-xl text-xs font-semibold bg-neutral-100 text-neutral-400 cursor-not-allowed"
                  >
                    Bientôt disponible
                  </button>
                ) : isConnected ? (
                  <button
                    onClick={() => setSelectedApp(app)}
                    className="inline-flex items-center gap-1.5 py-1.5 px-3 rounded-xl text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 transition-all cursor-pointer shadow-2xs"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Configuré</span>
                  </button>
                ) : (
                  <button
                    onClick={() => setSelectedApp(app)}
                    className="inline-flex items-center gap-1.5 py-1.5 px-3.5 rounded-xl text-xs font-bold text-white bg-[#FF8A00] hover:bg-[#e67c00] transition-all shadow-2xs active:scale-95 cursor-pointer"
                  >
                    <span>{requiresSetup ? 'Configurer' : 'Connecter'}</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Detail Slide-over / Modal for the selected application */}
      <IntegrationDetailModal
        app={selectedApp}
        isOpen={Boolean(selectedApp)}
        onClose={() => setSelectedApp(null)}
        onCreateWorkflow={(appId) => {
          setSelectedApp(null);
          onCreateWorkflow(appId);
        }}
        onConfigSaved={() => {
          reload();
          if (selectedApp) {
            const updated = getEffectiveIntegrations().find((a) => a.id === selectedApp.id);
            if (updated) setSelectedApp(updated);
          }
        }}
      />
    </div>
  );
};
