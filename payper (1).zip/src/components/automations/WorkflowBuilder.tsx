import React, { useState } from 'react';
import {
  Zap,
  Plus,
  Play,
  CheckCircle2,
  AlertCircle,
  Trash2,
  ArrowRight,
  ShieldCheck,
  ToggleLeft,
  ToggleRight,
  Layers,
} from 'lucide-react';
import {
  AutomationWorkflow,
  getSavedWorkflows,
  saveWorkflow,
  toggleWorkflowStatus,
  deleteWorkflow,
  getEffectiveIntegrations,
} from '../../lib/integrations';
import { IntegrationAppLogo } from './IntegrationAppLogo';
import { useToast } from '../common/Toast';

interface WorkflowBuilderProps {
  initialAppId?: string | null;
  onNavigateToGallery: () => void;
}

export const WorkflowBuilder: React.FC<WorkflowBuilderProps> = ({
  initialAppId,
  onNavigateToGallery,
}) => {
  const { showToast } = useToast();
  const integrations = getEffectiveIntegrations();
  const [workflows, setWorkflows] = useState<AutomationWorkflow[]>(() => getSavedWorkflows());
  const [isCreating, setIsCreating] = useState(false);

  // Form state
  const [workflowName, setWorkflowName] = useState('');
  const [triggerAppId, setTriggerAppId] = useState(initialAppId || 'payper');
  const [triggerId, setTriggerId] = useState('');
  const [actionAppId, setActionAppId] = useState('whatsapp_business');
  const [actionId, setActionId] = useState('');

  // Selected trigger app & action app
  const triggerApp = integrations.find((a) => a.id === triggerAppId) || integrations[0];
  const actionApp = integrations.find((a) => a.id === actionAppId) || integrations[1];

  // Filter triggers and actions to only supported ones
  const availableTriggers = triggerApp?.triggers.filter((t) => t.isSupported) || [];
  const availableActions = actionApp?.actions.filter((a) => a.isSupported) || [];

  // Update selected trigger when trigger app changes
  React.useEffect(() => {
    if (availableTriggers.length > 0 && !availableTriggers.some((t) => t.id === triggerId)) {
      setTriggerId(availableTriggers[0].id);
    }
  }, [triggerAppId, availableTriggers, triggerId]);

  // Update selected action when action app changes
  React.useEffect(() => {
    if (availableActions.length > 0 && !availableActions.some((a) => a.id === actionId)) {
      setActionId(availableActions[0].id);
    }
  }, [actionAppId, availableActions, actionId]);

  // Open creation modal automatically if initialAppId is provided
  React.useEffect(() => {
    if (initialAppId) {
      setTriggerAppId(initialAppId);
      setIsCreating(true);
    }
  }, [initialAppId]);

  const reload = () => {
    setWorkflows(getSavedWorkflows());
  };

  const handleToggle = (id: string) => {
    toggleWorkflowStatus(id);
    reload();
  };

  const handleDelete = (id: string) => {
    deleteWorkflow(id);
    showToast('Workflow supprimé.', 'info');
    reload();
  };

  const handleTestWorkflow = (wf: AutomationWorkflow) => {
    showToast(`Test d'exécution du workflow « ${wf.name} » réussi ✓`, 'success');
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!workflowName.trim()) {
      showToast('Veuillez donner un nom à votre workflow.', 'error');
      return;
    }
    if (!triggerId || !actionId) {
      showToast('Veuillez sélectionner un déclencheur et une action supportés.', 'error');
      return;
    }

    const newWf: AutomationWorkflow = {
      id: 'wf_' + Date.now(),
      name: workflowName.trim(),
      triggerAppId,
      triggerId,
      actionAppId,
      actionId,
      isEnabled: true,
      createdAt: new Date().toISOString(),
    };

    saveWorkflow(newWf);
    showToast('Nouveau workflow enregistré et activé ✓', 'success');
    setIsCreating(false);
    setWorkflowName('');
    reload();
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xl">🔀</span>
            <h2 className="text-xl sm:text-2xl font-black text-[#111827] tracking-tight">
              Constructeur de Workflows
            </h2>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-[#00C48C] text-xs font-bold">
              {workflows.filter((w) => w.isEnabled).length} actif(s)
            </span>
          </div>
          <p className="text-xs sm:text-sm text-neutral-500">
            Créez des chaînes d'automatisation « Déclencheur ➔ Action » entre vos applications connectées.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onNavigateToGallery}
            className="py-2.5 px-4 rounded-xl text-xs font-bold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 transition-colors cursor-pointer"
          >
            Explorer les applications
          </button>
          <button
            onClick={() => setIsCreating(true)}
            className="flex items-center gap-2 py-2.5 px-4 sm:px-5 rounded-xl text-xs sm:text-sm font-bold text-white bg-[#FF8A00] hover:bg-[#e67c00] transition-all shadow-sm active:scale-95 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Nouveau workflow</span>
          </button>
        </div>
      </div>

      {/* Workflow Creation Card (Inline or Expanded) */}
      {isCreating && (
        <form
          onSubmit={handleCreateSubmit}
          className="bg-white rounded-3xl border-2 border-orange-200 p-6 sm:p-7 shadow-md space-y-6 animate-in slide-in-from-top-4 duration-200"
        >
          <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-orange-100 text-[#FF8A00] flex items-center justify-center">
                <Zap className="w-4 h-4 fill-current" />
              </div>
              <h3 className="text-base font-bold text-[#111827]">
                Configurer un nouveau scénario
              </h3>
            </div>
            <button
              type="button"
              onClick={() => setIsCreating(false)}
              className="text-xs font-semibold text-neutral-400 hover:text-neutral-700 cursor-pointer"
            >
              Annuler
            </button>
          </div>

          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Nom du workflow *
            </label>
            <input
              type="text"
              required
              placeholder="Ex : Facture émise ➔ Alerte WhatsApp avec lien direct"
              value={workflowName}
              onChange={(e) => setWorkflowName(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-neutral-200 text-sm font-semibold text-neutral-900 focus:outline-none focus:border-[#FF8A00]"
            />
          </div>

          {/* Trigger & Action Pipeline Builder */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 p-4 rounded-2xl bg-neutral-50/80 border border-neutral-100">
            {/* Step 1: Déclencheur */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-[#FF8A00] uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-orange-100 text-[#FF8A00] flex items-center justify-center text-[11px] font-bold">
                    1
                  </span>
                  <span>Déclencheur (Trigger)</span>
                </span>
                <span className="text-[10px] text-neutral-400">Quand cet événement survient</span>
              </div>

              {/* App selector */}
              <div>
                <label className="block text-[11px] font-bold text-neutral-500 mb-1">
                  Application source
                </label>
                <select
                  value={triggerAppId}
                  onChange={(e) => setTriggerAppId(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-neutral-200 bg-white text-xs sm:text-sm font-semibold text-neutral-800"
                >
                  {integrations.map((app) => (
                    <option key={app.id} value={app.id}>
                      {app.name} {app.status === 'CONNECTED' ? '✓' : '(Configuration)'}
                    </option>
                  ))}
                </select>
              </div>

              {/* Trigger Event selector */}
              <div>
                <label className="block text-[11px] font-bold text-neutral-500 mb-1">
                  Événement déclencheur
                </label>
                {availableTriggers.length === 0 ? (
                  <p className="text-xs text-amber-600 bg-amber-50 p-2.5 rounded-xl border border-amber-200">
                    Aucun déclencheur actuellement pris en charge pour cette application.
                  </p>
                ) : (
                  <select
                    value={triggerId}
                    onChange={(e) => setTriggerId(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-neutral-200 bg-white text-xs font-medium text-neutral-800"
                  >
                    {availableTriggers.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name} — {t.description}
                      </option>
                    ))}
                  </select>
                )}
              </div>
            </div>

            {/* Step 2: Action */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-[#00C48C] uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-emerald-100 text-[#00C48C] flex items-center justify-center text-[11px] font-bold">
                    2
                  </span>
                  <span>Action</span>
                </span>
                <span className="text-[10px] text-neutral-400">Exécuter automatiquement</span>
              </div>

              {/* Action App selector */}
              <div>
                <label className="block text-[11px] font-bold text-neutral-500 mb-1">
                  Application de destination
                </label>
                <select
                  value={actionAppId}
                  onChange={(e) => setActionAppId(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-neutral-200 bg-white text-xs sm:text-sm font-semibold text-neutral-800"
                >
                  {integrations.map((app) => (
                    <option key={app.id} value={app.id}>
                      {app.name} {app.status === 'CONNECTED' ? '✓' : '(Configuration)'}
                    </option>
                  ))}
                </select>
              </div>

              {/* Action Event selector */}
              <div>
                <label className="block text-[11px] font-bold text-neutral-500 mb-1">
                  Action à exécuter
                </label>
                {availableActions.length === 0 ? (
                  <p className="text-xs text-amber-600 bg-amber-50 p-2.5 rounded-xl border border-amber-200">
                    Aucune action actuellement prise en charge pour cette application.
                  </p>
                ) : (
                  <select
                    value={actionId}
                    onChange={(e) => setActionId(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-neutral-200 bg-white text-xs font-medium text-neutral-800"
                  >
                    {availableActions.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.name} — {a.description}
                      </option>
                    ))}
                  </select>
                )}
              </div>
            </div>
          </div>

          <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 sm:gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsCreating(false)}
              className="w-full sm:w-auto py-2.5 px-4 rounded-xl text-xs font-semibold text-neutral-600 hover:bg-neutral-100 text-center cursor-pointer min-h-[44px]"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={availableTriggers.length === 0 || availableActions.length === 0}
              className="w-full sm:w-auto py-2.5 px-6 rounded-xl text-xs font-bold text-white bg-[#00C48C] hover:bg-[#00ad7a] transition-all shadow-sm disabled:opacity-50 cursor-pointer min-h-[44px] flex items-center justify-center gap-1.5"
            >
              Activer ce workflow
            </button>
          </div>
        </form>
      )}

      {/* List of existing Workflows */}
      <div className="space-y-3">
        {workflows.map((wf) => {
          const tApp = integrations.find((a) => a.id === wf.triggerAppId);
          const aApp = integrations.find((a) => a.id === wf.actionAppId);
          const trig = tApp?.triggers.find((t) => t.id === wf.triggerId);
          const act = aApp?.actions.find((a) => a.id === wf.actionId);

          return (
            <div
              key={wf.id}
              className={`bg-white rounded-2xl border p-4 sm:p-5 transition-all shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4 ${
                wf.isEnabled ? 'border-neutral-200/90' : 'border-neutral-200 opacity-60'
              }`}
            >
              <div className="space-y-2 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="text-sm sm:text-base font-bold text-[#111827] truncate">
                    {wf.name}
                  </h4>
                  {wf.isEnabled ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                      Actif
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-neutral-100 text-neutral-500">
                      En pause
                    </span>
                  )}
                </div>

                {/* Pipeline visual */}
                <div className="flex items-center gap-2 text-xs text-neutral-600 flex-wrap">
                  <div className="flex items-center gap-1.5 bg-neutral-50 px-2.5 py-1 rounded-xl border border-neutral-100">
                    <IntegrationAppLogo appId={wf.triggerAppId} size="sm" />
                    <span className="font-bold text-neutral-800">{tApp?.name || wf.triggerAppId}</span>
                    <span className="text-neutral-400">({trig?.name || 'Déclencheur'})</span>
                  </div>

                  <ArrowRight className="w-3.5 h-3.5 text-neutral-400 shrink-0" />

                  <div className="flex items-center gap-1.5 bg-neutral-50 px-2.5 py-1 rounded-xl border border-neutral-100">
                    <IntegrationAppLogo appId={wf.actionAppId} size="sm" />
                    <span className="font-bold text-neutral-800">{aApp?.name || wf.actionAppId}</span>
                    <span className="text-neutral-400">({act?.name || 'Action'})</span>
                  </div>
                </div>
              </div>

              {/* Actions on this workflow */}
              <div className="flex items-center gap-2 self-end md:self-center shrink-0">
                <button
                  onClick={() => handleTestWorkflow(wf)}
                  className="py-1.5 px-3 rounded-xl text-xs font-semibold text-neutral-600 hover:text-neutral-900 bg-neutral-50 hover:bg-neutral-100 border border-neutral-200 transition-colors flex items-center gap-1 cursor-pointer"
                  title="Simuler et tester ce workflow"
                >
                  <Play className="w-3 h-3 text-[#FF8A00] fill-current" />
                  <span>Tester</span>
                </button>

                <button
                  onClick={() => handleToggle(wf.id)}
                  className="py-1.5 px-3 rounded-xl text-xs font-semibold transition-colors cursor-pointer"
                >
                  {wf.isEnabled ? (
                    <span className="text-amber-600 hover:underline">Mettre en pause</span>
                  ) : (
                    <span className="text-emerald-600 hover:underline">Activer</span>
                  )}
                </button>

                <button
                  onClick={() => handleDelete(wf.id)}
                  className="p-2 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-colors cursor-pointer"
                  title="Supprimer ce workflow"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
