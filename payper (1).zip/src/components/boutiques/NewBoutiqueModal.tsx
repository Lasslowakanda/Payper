import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Store,
  UploadCloud,
  Check,
  CheckCircle2,
  AlertCircle,
  MapPin,
  ArrowRight,
  Globe,
  Phone,
} from 'lucide-react';
import {
  SUPPORTED_COUNTRIES,
  getCountryByCode,
  getCountryByName,
  validatePhoneNumber,
} from '../../lib/countries';
import { CURRENCIES } from '../../lib/invoice';
import { createBoutique } from '../../lib/storage';
import { Boutique, Currency } from '../../types';
import { useToast } from '../common/Toast';

interface NewBoutiqueModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (boutique: Boutique) => void;
}

export const NewBoutiqueModal: React.FC<NewBoutiqueModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { showToast } = useToast();

  const [name, setName] = useState('');
  const [logoPreview, setLogoPreview] = useState<string>('');
  const [selectedCountry, setSelectedCountry] = useState('Sénégal');
  const [selectedCountryCode, setSelectedCountryCode] = useState('+221');
  const [city, setCity] = useState('Dakar');
  const [devise, setDevise] = useState<Currency>('FCFA');
  const [phoneDigits, setPhoneDigits] = useState('');
  const [website, setWebsite] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Phone validation
  const phoneValidation = validatePhoneNumber(selectedCountryCode, phoneDigits);
  const activeCountry = getCountryByCode(selectedCountryCode);

  const resetForm = () => {
    setName('');
    setLogoPreview('');
    setSelectedCountry('Sénégal');
    setSelectedCountryCode('+221');
    setCity('Dakar');
    setDevise('FCFA');
    setPhoneDigits('');
    setWebsite('');
  };

  const handleCountryChange = (countryName: string) => {
    setSelectedCountry(countryName);
    const countryObj = getCountryByName(countryName);
    setSelectedCountryCode(countryObj.code);
    setCity(countryObj.defaultCity);
    setDevise(countryObj.currency);
  };

  const handleImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      showToast('Veuillez sélectionner une image valide.', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = e => {
      if (typeof e.target?.result === 'string') {
        setLogoPreview(e.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      showToast('Le nom de la boutique est obligatoire.', 'error');
      return;
    }

    if (phoneDigits.trim() && !phoneValidation.isValid) {
      showToast(phoneValidation.message || 'Numéro de téléphone invalide.', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      const cleanDigits = phoneDigits.replace(/[^0-9]/g, '');
      const fullPhone = cleanDigits ? `${selectedCountryCode}${cleanDigits}` : '';
      const whatsappLink = fullPhone
        ? `https://wa.me/${fullPhone.replace(/[^0-9]/g, '')}`
        : undefined;

      const newBoutique = createBoutique({
        name: name.trim(),
        logo: logoPreview || undefined,
        country: selectedCountry,
        countryCode: selectedCountryCode,
        city: city.trim() || activeCountry.defaultCity,
        devise,
        phone: fullPhone || undefined,
        whatsappNumber: fullPhone || undefined,
        whatsappLink,
        website: website.trim() || undefined,
        createdAt: new Date().toISOString(),
      });

      showToast(`Boutique « ${newBoutique.name} » créée et activée !`, 'success');
      resetForm();
      onSuccess(newBoutique);
      onClose();
    } catch {
      showToast('Erreur lors de la création de la boutique.', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/50 backdrop-blur-xs"
      />

      {/* Modal Dialog */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative z-10 bg-white rounded-3xl shadow-2xl max-w-xl w-full p-4 sm:p-8 overflow-hidden max-h-[90vh] flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-100 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-orange-50 border border-orange-100 flex items-center justify-center text-[#FF8A00]">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-[#111827]">
                Ouvrir une nouvelle boutique
              </h2>
              <p className="text-xs text-neutral-500">
                Données, factures et clients 100% séparés
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-neutral-700 rounded-xl hover:bg-neutral-100 transition-colors cursor-pointer"
            aria-label="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="overflow-y-auto flex-1 py-4 space-y-5 pr-1">
          {/* Nom de la boutique */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Nom de la boutique <span className="text-[#FF8A00]">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Ex: Teranga Mode, Wax & Glam, TechShop..."
              className="w-full px-4 py-3 rounded-xl border border-neutral-200 focus:border-[#FF8A00] focus:ring-2 focus:ring-[#FF8A00]/20 text-sm outline-none transition-all font-medium text-[#111827]"
              required
              autoFocus
            />
          </div>

          {/* Logo upload */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Logo de la boutique (Optionnel)
            </label>
            <div className="flex items-center gap-4">
              {logoPreview ? (
                <div className="relative w-16 h-16 rounded-2xl border border-neutral-200 overflow-hidden shrink-0 shadow-xs">
                  <img src={logoPreview} alt="Logo" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setLogoPreview('')}
                    className="absolute inset-0 bg-black/40 text-white flex items-center justify-center text-xs opacity-0 hover:opacity-100 transition-opacity"
                  >
                    Retirer
                  </button>
                </div>
              ) : (
                <div className="w-16 h-16 rounded-2xl bg-orange-50 border border-orange-100 flex items-center justify-center text-[#FF8A00] font-bold text-lg shrink-0">
                  {name ? name.slice(0, 2).toUpperCase() : '🏪'}
                </div>
              )}

              <label className="flex-1 border-2 border-dashed border-neutral-200 hover:border-[#FF8A00] rounded-xl p-3 text-center cursor-pointer transition-colors">
                <UploadCloud className="w-5 h-5 text-neutral-400 mx-auto mb-1" />
                <span className="text-xs font-semibold text-neutral-700 block">
                  Choisir une image de logo
                </span>
                <span className="text-[11px] text-neutral-400">PNG, JPG, SVG</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={e => e.target.files?.[0] && handleImageFile(e.target.files[0])}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* Pays & Devise */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                Pays <span className="text-[#FF8A00]">*</span>
              </label>
              <select
                value={selectedCountry}
                onChange={e => handleCountryChange(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 focus:border-[#FF8A00] focus:ring-2 focus:ring-[#FF8A00]/20 text-sm outline-none transition-all font-medium text-[#111827] bg-white cursor-pointer"
              >
                {SUPPORTED_COUNTRIES.map(c => (
                  <option key={c.country} value={c.country}>
                    {c.flag} {c.country} ({c.code})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                Devise par défaut <span className="text-[#FF8A00]">*</span>
              </label>
              <select
                value={devise}
                onChange={e => setDevise(e.target.value as Currency)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 focus:border-[#FF8A00] focus:ring-2 focus:ring-[#FF8A00]/20 text-sm outline-none transition-all font-bold text-[#111827] bg-white cursor-pointer"
              >
                {CURRENCIES.map(curr => (
                  <option key={curr.code} value={curr.code}>
                    {curr.flag} {curr.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Ville */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Ville & Adresse <span className="text-[#FF8A00]">*</span>
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={city}
                onChange={e => setCity(e.target.value)}
                placeholder="Ex: Dakar, Abidjan, Cotonou..."
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-neutral-200 focus:border-[#FF8A00] focus:ring-2 focus:ring-[#FF8A00]/20 text-sm outline-none transition-all font-medium text-[#111827]"
                required
              />
            </div>
          </div>

          {/* WhatsApp / Phone */}
          <div className="bg-amber-50/40 sm:bg-transparent p-3 sm:p-0 rounded-2xl border sm:border-0 border-amber-200/60">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-neutral-800 uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#00C48C]" />
                <span>Numéro WhatsApp & Contact</span>
              </label>
              {phoneDigits && (
                phoneValidation.isValid ? (
                  <span className="text-[11px] font-bold text-[#00C48C] flex items-center gap-1">
                    <Check className="w-3 h-3 stroke-[3]" /> Conforme
                  </span>
                ) : (
                  <span className="text-[11px] font-medium text-red-500">Invalide</span>
                )
              )}
            </div>
            <div className="flex gap-2">
              <div className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl border border-neutral-200 bg-white sm:bg-neutral-50 text-xs font-bold text-neutral-700 shrink-0 shadow-2xs">
                <span>{activeCountry.flag}</span>
                <span>{selectedCountryCode}</span>
              </div>
              <div className="relative flex-1">
                <input
                  type="tel"
                  inputMode="tel"
                  value={phoneDigits}
                  onChange={e => setPhoneDigits(e.target.value)}
                  placeholder={activeCountry.placeholder}
                  className={`w-full min-h-[44px] px-4 py-2.5 rounded-xl border text-sm outline-none transition-all font-medium text-[#111827] bg-white ${
                    phoneDigits
                      ? phoneValidation.isValid
                        ? 'border-emerald-500 ring-2 ring-emerald-500/10'
                        : 'border-red-400 ring-2 ring-red-400/10'
                      : 'border-neutral-300 focus:border-[#FF8A00] focus:ring-2 focus:ring-[#FF8A00]/20'
                  }`}
                />
                {phoneDigits && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    {phoneValidation.isValid ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-red-500" />
                    )}
                  </div>
                )}
              </div>
            </div>
            {phoneDigits && !phoneValidation.isValid ? (
              <p className="text-[11px] text-red-500 mt-1">{phoneValidation.message}</p>
            ) : (
              <p className="text-[11px] text-neutral-400 mt-1">
                Format : {activeCountry.expectedDigits} (ex : {activeCountry.example})
              </p>
            )}
          </div>

          {/* Site Web */}
          <div>
            <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
              Site web ou Page Instagram (Optionnel)
            </label>
            <div className="relative">
              <Globe className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={website}
                onChange={e => setWebsite(e.target.value)}
                placeholder="Ex: www.maboutique.com ou @maboutique"
                className="w-full min-h-[44px] pl-10 pr-4 py-2.5 rounded-xl border border-neutral-200 focus:border-[#FF8A00] focus:ring-2 focus:ring-[#FF8A00]/20 text-sm outline-none transition-all font-medium text-[#111827]"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-neutral-100 flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 sm:gap-3">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto py-2.5 px-4 rounded-xl text-xs font-semibold text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 transition-colors cursor-pointer text-center min-h-[44px]"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={isSubmitting || (Boolean(phoneDigits) && !phoneValidation.isValid)}
              className="w-full sm:w-auto flex items-center justify-center gap-2 py-3 sm:py-2.5 px-5 rounded-xl text-xs font-bold text-white bg-[#FF8A00] hover:bg-[#e67c00] transition-colors shadow-sm shadow-orange-500/20 active:scale-95 disabled:opacity-50 cursor-pointer min-h-[44px]"
            >
              <Store className="w-4 h-4" />
              <span>{isSubmitting ? 'Création...' : 'Créer et ouvrir la boutique'}</span>
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};
