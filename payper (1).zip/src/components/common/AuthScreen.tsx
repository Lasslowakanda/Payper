import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowLeft,
  ChevronDown,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Lock,
  ArrowRight,
  Zap,
  Smartphone,
  Eye,
  EyeOff,
  User,
  Store,
  CreditCard,
  UploadCloud,
  Check,
  X,
  Camera,
} from 'lucide-react';
import { PayperLogo } from './PayperLogo';
import { PinInput } from './PinInput';
import { PayperSymbolicLoader } from './PayperSymbolicLoader';
import { PayperHeroIllustration } from './PayperHeroIllustration';
import { GreenGlowButton } from './GreenGlowButton';
import {
  WaveMoneyLogo,
  OrangeMoneyLogo,
  AirtelMoneyLogo,
  MoovMoneyLogo,
  MtnMoneyLogo,
  BankCardLogo,
} from './OfficialPaymentLogos';
import {
  SUPPORTED_COUNTRIES,
  SupportedCountry,
  getCountryByCode,
  validatePhoneNumber,
} from '../../lib/countries';
import {
  signUpWithPhoneAndPin,
  signInWithPhoneAndPin,
  resetPinCode,
  normalizeToE164,
  isSupabaseConnected,
} from '../../lib/supabase';
import { setCurrentUser, saveBoutique, saveUserAccount, getBoutiques } from '../../lib/storage';
import { Boutique, UserAccount } from '../../types';
import { useToast } from './Toast';

type AuthStep =
  | 'welcome'          // ÉTAPE 2 : PAGE DE PRÉSENTATION DE PAYPER
  | 'phone'            // ÉTAPE 3 : SAISIE DU NUMÉRO DE TÉLÉPHONE
  | 'create_pin'       // ÉTAPE 4 : CRÉATION DU CODE SECRET À 6 CHIFFRES
  | 'confirm_pin'      // ÉTAPE 5 : CONFIRMATION DU CODE SECRET À 6 CHIFFRES
  | 'user_name'        // ÉTAPE 6 : QUEL EST VOTRE NOM ?
  | 'boutique_profile' // ÉTAPE 7 : NOM ET LOGO DE LA BOUTIQUE
  | 'payment_methods'  // ÉTAPE 7b : CHOIX DU MOYEN DE PAIEMENT
  | 'login'            // ÉCRAN DE CONNEXION (EXISTANT)
  | 'recovery';        // RÉCUPÉRATION DU CODE

interface AuthScreenProps {
  onLoginSuccess: (destination: string) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onLoginSuccess }) => {
  const { showToast } = useToast();

  // Navigation steps of the onboarding flow
  const [currentStep, setCurrentStep] = useState<AuthStep>('welcome');

  // Country Selection (Defaults to RDC +243 or Sénégal +221)
  const [selectedCountry, setSelectedCountry] = useState<SupportedCountry>(() => {
    return SUPPORTED_COUNTRIES.find(c => c.code === '+243') || SUPPORTED_COUNTRIES[0];
  });
  const [isCountryPickerOpen, setIsCountryPickerOpen] = useState(false);

  // Form Fields - Authentication
  const [rawPhone, setRawPhone] = useState('');
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [loginPin, setLoginPin] = useState('');

  // Form Fields - User profile & Boutique onboarding
  const [userName, setUserName] = useState('');
  const [boutiqueName, setBoutiqueName] = useState('');
  const [boutiqueLogo, setBoutiqueLogo] = useState<string>('');
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<
    'wave' | 'orange_money' | 'airtel_money' | 'moov_money' | 'mtn' | 'card'
  >('wave');

  // UI state
  const [isLoading, setIsLoading] = useState(false);
  const [loadingAction, setLoadingAction] = useState<string>('Vérification...');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [recoverySuccess, setRecoverySuccess] = useState(false);

  // Determine post-login destination (always redirect straight to dashboard)
  const resolvePostLoginDestination = (): string => {
    return '/dashboard';
  };

  const resetAllFields = () => {
    setRawPhone('');
    setPin('');
    setConfirmPin('');
    setLoginPin('');
    setUserName('');
    setBoutiqueName('');
    setBoutiqueLogo('');
    setErrorMessage(null);
    setRecoverySuccess(false);
  };

  const goToStep = (step: AuthStep) => {
    setErrorMessage(null);
    setCurrentStep(step);
  };

  // ==========================================
  // ÉTAPE 3 -> ÉTAPE 4 : VALIDATION TÉLÉPHONE
  // ==========================================
  const handlePhoneSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const cleanDigits = rawPhone.replace(/\D/g, '');
    if (!cleanDigits) {
      setErrorMessage('Veuillez saisir votre numéro de téléphone.');
      return;
    }

    const phoneVal = validatePhoneNumber(selectedCountry.code, rawPhone);
    if (!phoneVal.isValid) {
      setErrorMessage(
        phoneVal.message ||
          `Numéro incomplet ou invalide pour ${selectedCountry.country}. Format attendu : ${selectedCountry.expectedDigits}.`
      );
      return;
    }

    // Téléphone valide : transition vers la création du code PIN
    goToStep('create_pin');
  };

  // ==========================================
  // ÉTAPE 4 -> ÉTAPE 5 : VALIDATION DU PIN
  // ==========================================
  const handleCreatePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (pin.length !== 6 || !/^\d{6}$/.test(pin)) {
      setErrorMessage('Le code secret doit comporter exactement 6 chiffres.');
      return;
    }

    // Code valide : transition vers la confirmation
    goToStep('confirm_pin');
  };

  // ==========================================
  // ÉTAPE 5 -> ÉTAPE 6 : CONFIRMATION DU PIN
  // ==========================================
  const handleConfirmPinSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);

    if (confirmPin.length !== 6 || !/^\d{6}$/.test(confirmPin)) {
      setErrorMessage('Veuillez renseigner les 6 chiffres pour confirmer.');
      return;
    }

    if (pin !== confirmPin) {
      setErrorMessage('Les codes ne correspondent pas. Veuillez réessayer.');
      setConfirmPin('');
      return;
    }

    // Code secret confirmé avec succès ! On poursuit vers l'étape Nom
    goToStep('user_name');
  };

  // ==========================================
  // ÉTAPE 6 -> ÉTAPE 7 : QUEL EST VOTRE NOM ?
  // ==========================================
  const handleUserNameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!userName.trim() || userName.trim().length < 2) {
      setErrorMessage('Veuillez renseigner votre prénom et votre nom (au moins 2 caractères).');
      return;
    }

    // Préremplir le nom de la boutique avec une suggestion élégante si vide
    if (!boutiqueName.trim()) {
      setBoutiqueName(`Boutique de ${userName.trim()}`);
    }

    goToStep('boutique_profile');
  };

  // ==========================================
  // ÉTAPE 7 -> ÉTAPE 7b : LOGO & NOM BOUTIQUE
  // ==========================================
  const handleBoutiqueProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!boutiqueName.trim() || boutiqueName.trim().length < 2) {
      setErrorMessage('Veuillez indiquer le nom de votre boutique (au moins 2 caractères).');
      return;
    }

    goToStep('payment_methods');
  };

  // Gestion du téléversement du logo boutique
  const handleLogoUpload = (file: File) => {
    if (!file.type.startsWith('image/')) {
      showToast('Veuillez sélectionner un fichier image valide (PNG, JPG, WEBP).', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = e => {
      if (typeof e.target?.result === 'string') {
        setBoutiqueLogo(e.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  // ==========================================
  // ÉTAPE 7b -> ÉTAPE 8 : FINALISATION ET CRÉATION
  // ==========================================
  const handlePaymentMethodsSubmit = async () => {
    setErrorMessage(null);
    setIsLoading(true);
    setLoadingAction('Création de votre compte et de votre boutique...');

    try {
      // 1. Inscription dans le système d'authentification
      const result = await signUpWithPhoneAndPin(
        selectedCountry.country,
        selectedCountry.code,
        rawPhone,
        pin
      );

      if (!result.success) {
        setErrorMessage(result.error || 'Erreur lors de la création du compte.');
        if (result.isExistingUser) {
          showToast('Ce numéro possède déjà un compte. Veuillez vous connecter.', 'info');
          goToStep('login');
        }
        setIsLoading(false);
        return;
      }

      // 2. Mise à jour du compte utilisateur avec son vrai nom
      const normalizedPhone = normalizeToE164(selectedCountry.code, rawPhone);
      const userId = result.user?.id || `user_${normalizedPhone.replace(/\D/g, '') || Date.now()}`;
      const finalUser: UserAccount = {
        ...(result.user || {
          id: userId,
          phone: normalizedPhone,
          isLoggedIn: true,
          createdAt: new Date().toISOString(),
        }),
        name: userName.trim(),
        phone: normalizedPhone,
        country: selectedCountry.country,
        countryCode: selectedCountry.code,
        isLoggedIn: true,
      };
      setCurrentUser(finalUser);
      saveUserAccount(finalUser);

      // 3. Création et enregistrement de la boutique liée à ce compte
      const fallbackBoutiqueName = userName.trim()
        ? `Boutique de ${userName.trim()}`
        : 'Ma Boutique PAYPER';
      const finalBoutiqueName =
        boutiqueName.trim().length >= 2 ? boutiqueName.trim() : fallbackBoutiqueName;

      const newBoutique: Boutique = {
        id: `btq_${Date.now()}`,
        userId: finalUser.id,
        ownerPhone: normalizedPhone,
        name: finalBoutiqueName,
        logo: boutiqueLogo || undefined,
        paymentMethod: selectedPaymentMethod,
        devise: selectedCountry.currency,
        country: selectedCountry.country,
        countryCode: selectedCountry.code,
        city: selectedCountry.defaultCity,
        phone: normalizedPhone,
        createdAt: new Date().toISOString(),
        isActive: true,
      };
      saveBoutique(newBoutique);

      // 4. Activer les drapeaux pour l'Arrivée sur le Tableau de bord (Étape 8 & 9)
      sessionStorage.setItem('payper_show_welcome_banner', 'true');
      localStorage.setItem('payper_trigger_tour', 'true');

      showToast('Compte et boutique configurés avec succès !', 'success');

      // 5. Redirection vers le véritable tableau de bord existant de PAYPER
      onLoginSuccess('/dashboard');
    } catch (err: any) {
      setErrorMessage(err?.message || 'Une erreur inattendue est survenue.');
    } finally {
      setIsLoading(false);
    }
  };

  // ==========================================
  // ÉCRAN DE CONNEXION (SE CONNECTER)
  // ==========================================
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const cleanDigits = rawPhone.replace(/\D/g, '');
    if (!cleanDigits) {
      setErrorMessage('Veuillez saisir votre numéro de téléphone.');
      return;
    }

    if (loginPin.length !== 6 || !/^\d{6}$/.test(loginPin)) {
      setErrorMessage('Veuillez saisir votre code personnel à 6 chiffres.');
      return;
    }

    setIsLoading(true);
    setLoadingAction('Connexion à votre espace...');

    try {
      const result = await signInWithPhoneAndPin(
        selectedCountry.code,
        rawPhone,
        loginPin
      );

      if (!result.success) {
        setErrorMessage(result.error || 'Numéro de téléphone ou code personnel incorrect.');
        setIsLoading(false);
        return;
      }

      if (result.user) {
        setCurrentUser(result.user);
      }

      showToast('Connexion réussie ! Heureux de vous revoir.', 'success');
      const destination = resolvePostLoginDestination();
      onLoginSuccess(destination);
    } catch (err: any) {
      setErrorMessage('Numéro de téléphone ou code personnel incorrect.');
    } finally {
      setIsLoading(false);
    }
  };

  // ==========================================
  // RÉCUPÉRATION DU CODE
  // ==========================================
  const handleRecoverySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const phoneVal = validatePhoneNumber(selectedCountry.code, rawPhone);
    if (!phoneVal.isValid) {
      setErrorMessage(phoneVal.message || 'Numéro de téléphone invalide.');
      return;
    }

    setIsLoading(true);
    setLoadingAction('Génération d’un code temporaire...');

    try {
      const res = await resetPinCode(selectedCountry.code, rawPhone);
      if (!res.success) {
        setErrorMessage(res.error || 'Numéro introuvable.');
        setIsLoading(false);
        return;
      }

      setRecoverySuccess(true);
      showToast('Instructions de réinitialisation transmises.', 'info');
    } catch (err: any) {
      setErrorMessage('Impossible de traiter la demande pour le moment.');
    } finally {
      setIsLoading(false);
    }
  };

  // Liste des moyens de paiement officiels (Wave, Orange Money, Airtel, Moov, Carte bancaire)
  const PAYMENT_OPTIONS: {
    id: 'wave' | 'orange_money' | 'airtel_money' | 'moov_money' | 'card';
    name: string;
    subtitle: string;
    logo: React.ReactNode;
  }[] = [
    {
      id: 'wave',
      name: 'Wave',
      subtitle: 'Transfert & paiement instantané (0-1%)',
      logo: <WaveMoneyLogo size={42} />,
    },
    {
      id: 'orange_money',
      name: 'Orange Money',
      subtitle: 'Paiement mobile instantané officiel',
      logo: <OrangeMoneyLogo size={42} />,
    },
    {
      id: 'airtel_money',
      name: 'Airtel Money',
      subtitle: 'Paiement mobile sécurisé Airtel',
      logo: <AirtelMoneyLogo size={42} />,
    },
    {
      id: 'moov_money',
      name: 'Moov Money',
      subtitle: 'Paiement mobile officiel Moov Africa',
      logo: <MoovMoneyLogo size={42} />,
    },
    {
      id: 'card',
      name: 'Carte bancaire',
      subtitle: 'Visa, Mastercard & Cartes bancaires',
      logo: <BankCardLogo size={42} />,
    },
  ];

  // 4 badges officiels pour la grille 2x2 comme sur la capture d'écran (Wave, Orange Money, Moov, MTN)
  const PAYMENT_CARDS = [
    {
      id: 'wave' as const,
      name: 'Wave',
      logo: <WaveMoneyLogo size={88} className="w-20 h-20 sm:w-22 sm:h-22" />,
    },
    {
      id: 'orange_money' as const,
      name: 'Orange Money',
      logo: <OrangeMoneyLogo size={88} className="w-20 h-20 sm:w-22 sm:h-22" />,
    },
    {
      id: 'moov_money' as const,
      name: 'Moov Money',
      logo: <MoovMoneyLogo size={88} className="w-20 h-20 sm:w-22 sm:h-22" />,
    },
    {
      id: 'mtn' as const,
      name: 'MTN',
      logo: <MtnMoneyLogo size={88} className="w-20 h-20 sm:w-22 sm:h-22" />,
    },
  ];

  // Avatars rapides pour boutique
  const PRESET_ICONS = ['🏪', '🛍️', '👗', '👟', '📱', '💄', '📦', '💎'];

  const e164Preview = rawPhone ? `${selectedCountry.code} ${rawPhone}` : '';

  // Barre horizontale divisée de progression en vert (remplace tout texte 'étape 1/6')
  const renderProgressBars = (current: number, total: number = 6) => (
    <div className="flex items-center gap-1.5 flex-1 max-w-[210px]" aria-label={`Progression ${current} sur ${total}`}>
      {Array.from({ length: total }).map((_, i) => (
        <div
          key={i}
          className={`h-2 rounded-full flex-1 transition-all duration-300 ${
            i < current ? 'bg-[#00C48C] shadow-xs shadow-emerald-500/30' : 'bg-neutral-200/90'
          }`}
        />
      ))}
    </div>
  );

  // =========================================================
  // ÉTAPE 7b — SÉLECTION DU PAIEMENT (EXACTEMENT COMME SUR LA CAPTURE D'ÉCRAN)
  // =========================================================
  if (currentStep === 'payment_methods') {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#341259] via-[#481577] to-[#6C22AF] flex flex-col justify-between py-6 px-4 sm:px-6 relative overflow-x-hidden selection:bg-purple-300 selection:text-purple-950 antialiased">
        {/* Halo d'ambiance violet */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-lg h-96 bg-purple-500/20 blur-3xl pointer-events-none -z-10" />

        <div className="w-full max-w-md mx-auto flex-1 flex flex-col justify-between">
          <div>
            {/* Barre horizontale divisée de progression (6 segments) et bouton retour */}
            <div className="flex items-center gap-3 pt-2 mb-4">
              <button
                type="button"
                onClick={() => goToStep('boutique_profile')}
                className="p-1.5 -ml-1 text-white/80 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
                title="Retour"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <div className="flex-1 flex items-center gap-1.5 max-w-[210px]">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div
                    key={i}
                    className="h-2 rounded-full flex-1 bg-[#00C48C] shadow-sm shadow-emerald-500/40"
                  />
                ))}
              </div>
            </div>

            {/* Titre et description comme sur la capture */}
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mt-3 mb-2.5 leading-tight">
                Transferts sans tracas
              </h1>
              <p className="text-sm sm:text-base text-white/90 leading-relaxed mb-6 font-normal">
                Avec PAYPER, transférez de l'argent entre Moov, Orange, MTN et Wave en quelques secondes. Simplifiez vos transactions 😁
              </p>
            </motion.div>

            {/* Grille 2x2 des 4 cartes cliquables */}
            <div className="grid grid-cols-2 gap-3.5 sm:gap-4 mb-6">
              {PAYMENT_CARDS.map(opt => {
                const isSelected = selectedPaymentMethod === opt.id;
                return (
                  <motion.button
                    key={opt.id}
                    type="button"
                    whileTap={{ scale: 0.96 }}
                    onClick={() => {
                      setSelectedPaymentMethod(opt.id);
                      setErrorMessage(null);
                    }}
                    className={`aspect-square rounded-3xl flex flex-col items-center justify-center p-3 transition-all cursor-pointer relative ${
                      isSelected
                        ? 'bg-white/20 border-2 border-white ring-4 ring-white/25 shadow-2xl shadow-purple-950/60 scale-[1.02]'
                        : 'bg-white/[0.08] hover:bg-white/[0.14] border border-white/20 hover:border-white/40'
                    }`}
                  >
                    {/* Badge officiel de la marque */}
                    <div className="w-20 h-20 sm:w-22 sm:h-22 flex items-center justify-center drop-shadow-md">
                      {opt.logo}
                    </div>

                    {/* Indicateur de sélection */}
                    {isSelected && (
                      <div className="absolute top-2.5 right-2.5 w-6 h-6 rounded-full bg-white text-purple-900 flex items-center justify-center shadow-md">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </div>
                    )}
                  </motion.button>
                );
              })}
            </div>

            {errorMessage && (
              <div className="p-3 mb-4 bg-red-500/20 border border-red-400/40 rounded-xl flex items-start gap-2.5 text-xs text-white">
                <AlertCircle className="w-4 h-4 text-red-300 shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}
          </div>

          {/* Bouton Commencer immobile au bas de l'écran (Vert avec lumière tournante) */}
          <div className="sticky bottom-0 bg-gradient-to-t from-[#481577] via-[#481577]/95 to-transparent pt-3 pb-3 z-20">
            {isLoading ? (
              <div className="py-4 flex flex-col items-center justify-center">
                <PayperSymbolicLoader context="payments" size="md" />
                <p className="text-xs text-white/80 font-medium mt-3 text-center">
                  {loadingAction}
                </p>
              </div>
            ) : (
              <GreenGlowButton
                fullWidth
                size="lg"
                onClick={handlePaymentMethodsSubmit}
              >
                <span className="text-base font-black">Commencer</span>
              </GreenGlowButton>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FF8A00] flex flex-col justify-between py-6 px-4 sm:px-6 relative overflow-x-hidden selection:bg-white selection:text-[#FF8A00]">
      {/* Halo lumineux et texture d'ambiance orange premium */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-96 bg-gradient-to-b from-orange-400/40 via-orange-500/20 to-transparent blur-3xl pointer-events-none -z-10" />

      {/* Header compact pour écrans formulaires */}
      {currentStep !== 'welcome' && (
        <header className="max-w-md w-full mx-auto flex items-center justify-between mb-4 pt-2">
          <div onClick={() => goToStep('welcome')} className="cursor-pointer bg-white/95 px-3 py-1.5 rounded-2xl shadow-sm backdrop-blur-sm">
            <PayperLogo size="sm" />
          </div>
          <span className="text-[11px] font-bold text-white bg-black/20 backdrop-blur-md border border-white/25 rounded-full px-3 py-1 shadow-xs">
            Espace 100% sécurisé
          </span>
        </header>
      )}

      {/* Conteneur principal avec transition douce entre écrans */}
      <div className="w-full max-w-md mx-auto my-auto py-2">
        <AnimatePresence mode="wait">
          {/* ========================================================= */}
          {/* ÉTAPE 2 — PAGE DE PRÉSENTATION DE PAYPER                   */}
          {/* ========================================================= */}
          {currentStep === 'welcome' && (
            <motion.div
              key="step-welcome"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35, ease: 'easeOut' }}
              className="flex flex-col items-center text-center"
            >
              {/* Illustration synthétique et moderne */}
              <div className="w-full mb-3 flex justify-center">
                <PayperHeroIllustration className="max-w-[340px] sm:max-w-[380px]" />
              </div>

              {/* Titre fort & impactant */}
              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight leading-tight mt-1 drop-shadow-xs">
                Gérez vos factures et encaissements en toute simplicité
              </h1>

              {/* Sous-titre rassurant */}
              <p className="text-sm text-orange-100 font-medium mt-2 max-w-xs leading-relaxed">
                La solution financière pensée pour les commerçants, créateurs et vendeurs modernes en Afrique.
              </p>

              {/* 3 Avantages clés sous forme de pastilles épurées */}
              <div className="w-full grid grid-cols-1 gap-2.5 my-6 text-left">
                <div className="bg-white/95 backdrop-blur-sm p-3.5 rounded-2xl border border-white/40 shadow-sm flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-orange-100 text-[#FF8A00] flex items-center justify-center shrink-0">
                    <Zap className="w-4 h-4 stroke-[2.5]" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-[#111827]">Facturation instantanée</div>
                    <div className="text-[11px] text-neutral-600">Créez et partagez vos factures en un clic sur WhatsApp</div>
                  </div>
                </div>

                <div className="bg-white/95 backdrop-blur-sm p-3.5 rounded-2xl border border-white/40 shadow-sm flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-100 text-[#00C48C] flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-4 h-4 stroke-[2.5]" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-[#111827]">Suivi des paiements</div>
                    <div className="text-[11px] text-neutral-600">Total encaissé, relances automatiques et statuts en temps réel</div>
                  </div>
                </div>

                <div className="bg-white/95 backdrop-blur-sm p-3.5 rounded-2xl border border-white/40 shadow-sm flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                    <Store className="w-4 h-4 stroke-[2.5]" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-[#111827]">Multi-boutiques & Devises</div>
                    <div className="text-[11px] text-neutral-600">FCFA, CDF, GNF, USD : pilotez tous vos commerces au même endroit</div>
                  </div>
                </div>
              </div>

              {/* Bouton principal : Commencer (Vert avec lumière tournante) */}
              <div className="pt-2">
                <GreenGlowButton
                  fullWidth
                  size="lg"
                  onClick={() => goToStep('phone')}
                >
                  <span className="text-base font-black">Commencer maintenant</span>
                  <ArrowRight className="w-5 h-5 stroke-[2.5]" />
                </GreenGlowButton>
              </div>

              {/* Lien secondaire : Déjà un compte ? Se connecter */}
              <div className="mt-4">
                <button
                  type="button"
                  onClick={() => goToStep('login')}
                  className="text-xs font-bold text-white hover:text-orange-100 transition-colors py-2 px-3 rounded-lg hover:bg-black/10 cursor-pointer"
                >
                  Déjà un compte ? <span className="underline underline-offset-2">Se connecter</span>
                </button>
              </div>
            </motion.div>
          )}

          {/* ========================================================= */}
          {/* ÉTAPE 3 — SAISIE DU NUMÉRO DE TÉLÉPHONE                    */}
          {/* ========================================================= */}
          {currentStep === 'phone' && (
            <motion.div
              key="step-phone"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-neutral-100"
            >
              {/* Header avec bouton retour et badge étape */}
              <div className="flex items-center justify-between mb-5">
                <button
                  type="button"
                  onClick={() => goToStep('welcome')}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-500 hover:text-neutral-900 py-1.5 px-2.5 -ml-1 rounded-lg hover:bg-neutral-100 transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Retour</span>
                </button>
                {renderProgressBars(1, 6)}
              </div>

              {/* Titre & Explication */}
              <div className="mb-6 text-center">
                <div className="w-12 h-12 rounded-2xl bg-orange-100 text-[#FF8A00] flex items-center justify-center mx-auto mb-3">
                  <Smartphone className="w-6 h-6" />
                </div>
                <h2 className="text-2xl font-black text-[#111827] tracking-tight">
                  Quel est votre numéro ?
                </h2>
                <p className="text-sm text-neutral-500 mt-1.5 max-w-xs mx-auto leading-relaxed">
                  Votre numéro de téléphone vous servira d'identifiant unique et sécurisé.
                </p>
              </div>

              <form onSubmit={handlePhoneSubmit} className="space-y-4">
                {/* Sélecteur de pays avec indicatif officiel */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-500 mb-1.5">
                    Pays & Indicatif
                  </label>
                  <div className="relative">
                    <button
                      type="button"
                      onClick={() => setIsCountryPickerOpen(prev => !prev)}
                      className="w-full flex items-center justify-between py-3 px-3.5 bg-neutral-50 hover:bg-neutral-100/80 border border-neutral-200 rounded-xl text-left transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-2xl leading-none">{selectedCountry.flag}</span>
                        <div>
                          <div className="text-xs font-bold text-[#111827]">
                            {selectedCountry.country}
                          </div>
                          <div className="text-[11px] font-mono text-neutral-400">
                            {selectedCountry.code} · {selectedCountry.currency}
                          </div>
                        </div>
                      </div>
                      <ChevronDown className="w-4 h-4 text-neutral-400" />
                    </button>

                    {/* Menu déroulant de sélection de pays */}
                    {isCountryPickerOpen && (
                      <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-2xl border border-neutral-100 p-2 z-30 max-h-56 overflow-y-auto">
                        {SUPPORTED_COUNTRIES.map(c => (
                          <button
                            key={c.country}
                            type="button"
                            onClick={() => {
                              setSelectedCountry(c);
                              setIsCountryPickerOpen(false);
                            }}
                            className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left transition-colors cursor-pointer ${
                              selectedCountry.country === c.country
                                ? 'bg-orange-50 text-[#FF8A00] font-bold'
                                : 'hover:bg-neutral-50 text-neutral-700'
                            }`}
                          >
                            <div className="flex items-center gap-2.5">
                              <span className="text-xl">{c.flag}</span>
                              <span className="text-xs">{c.country}</span>
                            </div>
                            <span className="text-xs font-mono font-semibold text-neutral-400">
                              {c.code}
                            </span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Champ de saisie du numéro */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-500 mb-1.5">
                    Numéro de téléphone
                  </label>
                  <div className="relative flex items-center">
                    <div className="absolute left-3.5 flex items-center gap-1.5 text-neutral-500 font-mono font-bold text-sm pointer-events-none">
                      <span>{selectedCountry.flag}</span>
                      <span>{selectedCountry.code}</span>
                    </div>
                    <input
                      type="tel"
                      inputMode="tel"
                      placeholder={selectedCountry.placeholder}
                      value={rawPhone}
                      onChange={e => {
                        setRawPhone(e.target.value);
                        setErrorMessage(null);
                      }}
                      className="w-full pl-28 pr-4 py-3.5 bg-neutral-50 border border-neutral-200 rounded-xl text-base font-bold text-neutral-900 placeholder:text-neutral-300 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] focus:border-[#FF8A00] transition-all font-mono"
                      autoFocus
                    />
                  </div>
                  <p className="text-[11px] text-neutral-400 mt-1.5">
                    Format attendu : {selectedCountry.expectedDigits} chiffres ({selectedCountry.country}).
                  </p>
                </div>

                {errorMessage && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-start gap-2.5 text-xs text-red-700">
                    <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                {/* Bouton immobile en bas même en défilant */}
                <div className="sticky bottom-0 bg-white/95 backdrop-blur-md pt-3 pb-1 mt-3 z-10">
                  <GreenGlowButton
                    fullWidth
                    size="md"
                    type="submit"
                    disabled={!rawPhone.trim()}
                  >
                    <span>Continuer</span>
                    <ArrowRight className="w-4 h-4" />
                  </GreenGlowButton>
                </div>
              </form>

              {/* Option vers connexion si compte existant */}
              <div className="mt-6 pt-4 border-t border-neutral-100 text-center">
                <button
                  type="button"
                  onClick={() => goToStep('login')}
                  className="text-xs text-neutral-500 hover:text-neutral-800"
                >
                  Vous avez déjà un compte ? <span className="text-[#FF8A00] font-bold">Se connecter</span>
                </button>
              </div>
            </motion.div>
          )}

          {/* ========================================================= */}
          {/* ÉTAPE 4 — CRÉATION DU CODE SECRET À 6 CHIFFRES             */}
          {/* ========================================================= */}
          {currentStep === 'create_pin' && (
            <motion.div
              key="step-create-pin"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-neutral-100"
            >
              <div className="flex items-center justify-between mb-5">
                <button
                  type="button"
                  onClick={() => goToStep('phone')}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-500 hover:text-neutral-900 py-1.5 px-2.5 -ml-1 rounded-lg hover:bg-neutral-100 transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Retour</span>
                </button>
                {renderProgressBars(2, 6)}
              </div>

              <div className="mb-6 text-center">
                <div className="w-12 h-12 rounded-2xl bg-orange-100 text-[#FF8A00] flex items-center justify-center mx-auto mb-3">
                  <Lock className="w-6 h-6" />
                </div>
                <h2 className="text-2xl font-black text-[#111827] tracking-tight">
                  Créez votre code secret
                </h2>
                <p className="text-sm text-neutral-500 mt-1.5 max-w-xs mx-auto leading-relaxed">
                  Choisissez un code personnel à 6 chiffres pour sécuriser votre compte PAYPER.
                </p>
                {e164Preview && (
                  <p className="text-xs font-mono font-semibold text-neutral-400 mt-1">
                    Numéro : {e164Preview}
                  </p>
                )}
              </div>

              <form onSubmit={handleCreatePinSubmit} className="space-y-6">
                <div className="flex flex-col items-center justify-center">
                  <PinInput
                    value={pin}
                    onChange={val => {
                      setPin(val);
                      setErrorMessage(null);
                      if (val.length === 6) {
                        setTimeout(() => {
                          goToStep('confirm_pin');
                        }, 250);
                      }
                    }}
                    autoFocus={true}
                  />
                </div>

                <div className="bg-neutral-50 rounded-xl p-3 border border-neutral-100 flex items-center gap-2.5 text-xs text-neutral-600">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Ce code remplacera les mots de passe complexes. Retenez-le bien.</span>
                </div>

                {errorMessage && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-start gap-2.5 text-xs text-red-700">
                    <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                {/* Bouton immobile en bas même en défilant */}
                <div className="sticky bottom-0 bg-white/95 backdrop-blur-md pt-3 pb-1 mt-2 z-10">
                  <GreenGlowButton
                    fullWidth
                    size="md"
                    type="submit"
                    disabled={pin.length !== 6}
                  >
                    <span>Continuer</span>
                    <ArrowRight className="w-4 h-4" />
                  </GreenGlowButton>
                </div>
              </form>
            </motion.div>
          )}

          {/* ========================================================= */}
          {/* ÉTAPE 5 — CONFIRMATION DU CODE SECRET À 6 CHIFFRES         */}
          {/* ========================================================= */}
          {currentStep === 'confirm_pin' && (
            <motion.div
              key="step-confirm-pin"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-neutral-100"
            >
              <div className="flex items-center justify-between mb-5">
                <button
                  type="button"
                  onClick={() => goToStep('create_pin')}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-500 hover:text-neutral-900 py-1.5 px-2.5 -ml-1 rounded-lg hover:bg-neutral-100 transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Retour</span>
                </button>
                {renderProgressBars(3, 6)}
              </div>

              <div className="mb-6 text-center">
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-3">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h2 className="text-2xl font-black text-[#111827] tracking-tight">
                  Confirmez votre code secret
                </h2>
                <p className="text-sm text-neutral-500 mt-1.5 max-w-xs mx-auto leading-relaxed">
                  Entrez à nouveau votre code à 6 chiffres pour vous assurer qu'il est correct.
                </p>
              </div>

              <form onSubmit={handleConfirmPinSubmit} className="space-y-6">
                <div className="flex flex-col items-center justify-center">
                  <PinInput
                    value={confirmPin}
                    onChange={val => {
                      setConfirmPin(val);
                      setErrorMessage(null);
                      if (val.length === 6) {
                        if (val !== pin) {
                          setErrorMessage('Les codes ne correspondent pas. Veuillez réessayer.');
                        } else {
                          setTimeout(() => {
                            goToStep('user_name');
                          }, 250);
                        }
                      }
                    }}
                    autoFocus={true}
                  />
                </div>

                {errorMessage && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-start gap-2.5 text-xs text-red-700">
                    <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                {/* Bouton immobile en bas même en défilant */}
                <div className="sticky bottom-0 bg-white/95 backdrop-blur-md pt-3 pb-1 mt-2 z-10">
                  <GreenGlowButton
                    fullWidth
                    size="md"
                    type="submit"
                    disabled={confirmPin.length !== 6}
                  >
                    <span>Continuer</span>
                    <ArrowRight className="w-4 h-4" />
                  </GreenGlowButton>
                </div>
              </form>
            </motion.div>
          )}

          {/* ========================================================= */}
          {/* ÉTAPE 6 — QUEL EST VOTRE NOM ?                             */}
          {/* ========================================================= */}
          {currentStep === 'user_name' && (
            <motion.div
              key="step-user-name"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-neutral-100"
            >
              <div className="flex items-center justify-between mb-5">
                <button
                  type="button"
                  onClick={() => goToStep('confirm_pin')}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-500 hover:text-neutral-900 py-1.5 px-2.5 -ml-1 rounded-lg hover:bg-neutral-100 transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Retour</span>
                </button>
                {renderProgressBars(4, 6)}
              </div>

              <div className="mb-6 text-center">
                <div className="w-12 h-12 rounded-2xl bg-orange-100 text-[#FF8A00] flex items-center justify-center mx-auto mb-3">
                  <User className="w-6 h-6" />
                </div>
                <h2 className="text-2xl font-black text-[#111827] tracking-tight">
                  Quel est votre nom ?
                </h2>
                <p className="text-sm text-neutral-500 mt-1.5 max-w-xs mx-auto leading-relaxed">
                  Renseignez votre prénom et votre nom pour personnaliser votre compte PAYPER.
                </p>
              </div>

              <form onSubmit={handleUserNameSubmit} className="space-y-5">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-500 mb-1.5">
                    Votre prénom et nom
                  </label>
                  <div className="relative flex items-center">
                    <User className="w-5 h-5 text-neutral-400 absolute left-3.5" />
                    <input
                      type="text"
                      placeholder="Ex : Fatou Diop"
                      value={userName}
                      onChange={e => {
                        setUserName(e.target.value);
                        setErrorMessage(null);
                      }}
                      className="w-full pl-11 pr-4 py-3.5 bg-neutral-50 border border-neutral-200 rounded-xl text-base font-semibold text-neutral-900 placeholder:text-neutral-300 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] focus:border-[#FF8A00] transition-all"
                      autoFocus
                    />
                  </div>
                  <p className="text-[11px] text-neutral-400 mt-1.5">
                    Ce nom apparaîtra sur votre profil d'administrateur et vos communications.
                  </p>
                </div>

                {errorMessage && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-start gap-2.5 text-xs text-red-700">
                    <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                {/* Bouton immobile en bas même en défilant */}
                <div className="sticky bottom-0 bg-white/95 backdrop-blur-md pt-3 pb-1 mt-2 z-10">
                  <GreenGlowButton
                    fullWidth
                    size="md"
                    type="submit"
                    disabled={userName.trim().length < 2}
                  >
                    <span>Continuer</span>
                    <ArrowRight className="w-4 h-4" />
                  </GreenGlowButton>
                </div>
              </form>
            </motion.div>
          )}

          {/* ========================================================= */}
          {/* ÉTAPE 7 — LOGO & NOM DE LA BOUTIQUE                        */}
          {/* ========================================================= */}
          {currentStep === 'boutique_profile' && (
            <motion.div
              key="step-boutique-profile"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-neutral-100"
            >
              <div className="flex items-center justify-between mb-5">
                <button
                  type="button"
                  onClick={() => goToStep('user_name')}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-500 hover:text-neutral-900 py-1.5 px-2.5 -ml-1 rounded-lg hover:bg-neutral-100 transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Retour</span>
                </button>
                {renderProgressBars(5, 6)}
              </div>

              <div className="mb-6 text-center">
                <div className="w-12 h-12 rounded-2xl bg-orange-100 text-[#FF8A00] flex items-center justify-center mx-auto mb-3">
                  <Store className="w-6 h-6" />
                </div>
                <h2 className="text-2xl font-black text-[#111827] tracking-tight">
                  Votre boutique
                </h2>
                <p className="text-sm text-neutral-500 mt-1.5 max-w-xs mx-auto leading-relaxed">
                  Donnez un nom à votre boutique et ajoutez son logo officiel pour vos factures.
                </p>
              </div>

              <form onSubmit={handleBoutiqueProfileSubmit} className="space-y-5">
                {/* Nom de la boutique */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-500 mb-1.5">
                    Nom commercial de la boutique
                  </label>
                  <div className="relative flex items-center">
                    <Store className="w-5 h-5 text-neutral-400 absolute left-3.5" />
                    <input
                      type="text"
                      placeholder="Ex : Chic & Tendance, Épicerie Centrale"
                      value={boutiqueName}
                      onChange={e => {
                        setBoutiqueName(e.target.value);
                        setErrorMessage(null);
                      }}
                      className="w-full pl-11 pr-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl text-base font-semibold text-neutral-900 placeholder:text-neutral-300 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] focus:border-[#FF8A00] transition-all"
                      autoFocus
                    />
                  </div>
                </div>

                {/* Téléversement ou sélection du logo de la boutique */}
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-500 mb-1.5">
                    Logo de la boutique (Optionnel)
                  </label>

                  {boutiqueLogo ? (
                    <div className="flex items-center justify-between p-3.5 bg-neutral-50 rounded-2xl border border-neutral-200">
                      <div className="flex items-center gap-3">
                        <div className="w-14 h-14 rounded-xl border border-neutral-200 overflow-hidden bg-white flex items-center justify-center shadow-xs">
                          {boutiqueLogo.startsWith('data:image') || boutiqueLogo.startsWith('http') ? (
                            <img
                              src={boutiqueLogo}
                              alt="Aperçu Logo"
                              className="w-full h-full object-contain p-1"
                            />
                          ) : (
                            <span className="text-2xl">{boutiqueLogo}</span>
                          )}
                        </div>
                        <div>
                          <div className="text-xs font-bold text-neutral-900">Logo sélectionné</div>
                          <div className="text-[11px] text-emerald-600 font-medium flex items-center gap-1 mt-0.5">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Prêt pour vos factures</span>
                          </div>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => setBoutiqueLogo('')}
                        className="p-2 text-neutral-400 hover:text-red-600 hover:bg-neutral-100 rounded-lg transition-colors cursor-pointer"
                        title="Supprimer le logo"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <label className="border-2 border-dashed border-neutral-200 hover:border-[#FF8A00] rounded-2xl p-4 flex flex-col items-center justify-center text-center cursor-pointer transition-colors bg-neutral-50/50 hover:bg-orange-50/20 group">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={e => {
                            if (e.target.files && e.target.files[0]) {
                              handleLogoUpload(e.target.files[0]);
                            }
                          }}
                          className="hidden"
                        />
                        <div className="w-10 h-10 rounded-full bg-orange-100/80 text-[#FF8A00] flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                          <UploadCloud className="w-5 h-5" />
                        </div>
                        <div className="text-xs font-bold text-neutral-800">
                          Cliquez pour téléverser votre image
                        </div>
                        <div className="text-[11px] text-neutral-400 mt-0.5">
                          PNG, JPG ou WEBP (Max 5 Mo)
                        </div>
                      </label>

                      {/* Avatars rapides pour démarrer immédiatement */}
                      <div className="flex items-center justify-between gap-1.5 pt-1">
                        <span className="text-[11px] text-neutral-400 font-medium">Ou icône rapide :</span>
                        <div className="flex items-center gap-1.5">
                          {PRESET_ICONS.slice(0, 5).map(emoji => (
                            <button
                              key={emoji}
                              type="button"
                              onClick={() => setBoutiqueLogo(emoji)}
                              className="w-8 h-8 rounded-lg bg-neutral-100 hover:bg-orange-100 text-sm flex items-center justify-center transition-colors cursor-pointer"
                            >
                              {emoji}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {errorMessage && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-start gap-2.5 text-xs text-red-700">
                    <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                {/* Bouton immobile en bas même en défilant */}
                <div className="sticky bottom-0 bg-white/95 backdrop-blur-md pt-3 pb-1 mt-2 z-10">
                  <GreenGlowButton
                    fullWidth
                    size="md"
                    type="submit"
                    disabled={boutiqueName.trim().length < 2}
                  >
                    <span>Continuer</span>
                    <ArrowRight className="w-4 h-4" />
                  </GreenGlowButton>
                </div>
              </form>
            </motion.div>
          )}



          {/* ========================================================= */}
          {/* ÉCRAN DE CONNEXION (SE CONNECTER)                          */}
          {/* ========================================================= */}
          {currentStep === 'login' && (
            <motion.div
              key="step-login"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-neutral-100"
            >
              <div className="flex items-center justify-between mb-5">
                <button
                  type="button"
                  onClick={() => goToStep('welcome')}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-500 hover:text-neutral-900 py-1.5 px-2.5 -ml-1 rounded-lg hover:bg-neutral-100 transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Retour</span>
                </button>
                <PayperLogo size="sm" />
              </div>

              <div className="mb-6 text-center">
                <div className="w-12 h-12 rounded-2xl bg-orange-100 text-[#FF8A00] flex items-center justify-center mx-auto mb-3">
                  <Lock className="w-6 h-6" />
                </div>
                <h2 className="text-2xl font-black text-[#111827] tracking-tight">
                  Bon retour sur PAYPER
                </h2>
                <p className="text-sm text-neutral-500 mt-1.5 max-w-xs mx-auto leading-relaxed">
                  Entrez votre numéro et votre code personnel à 6 chiffres pour accéder à votre espace.
                </p>
              </div>

              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-neutral-500 mb-1.5">
                    Numéro de téléphone
                  </label>
                  <div className="relative flex items-center">
                    <div className="absolute left-3.5 flex items-center gap-1.5 text-neutral-500 font-mono font-bold text-sm pointer-events-none">
                      <span>{selectedCountry.flag}</span>
                      <span>{selectedCountry.code}</span>
                    </div>
                    <input
                      type="tel"
                      inputMode="tel"
                      placeholder={selectedCountry.placeholder}
                      value={rawPhone}
                      onChange={e => {
                        setRawPhone(e.target.value);
                        setErrorMessage(null);
                      }}
                      className="w-full pl-28 pr-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl text-base font-bold text-neutral-900 placeholder:text-neutral-300 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-all font-mono"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-bold uppercase tracking-wider text-neutral-500">
                      Code secret (6 chiffres)
                    </label>
                    <button
                      type="button"
                      onClick={() => goToStep('recovery')}
                      className="text-xs text-[#FF8A00] hover:underline font-semibold"
                    >
                      Code oublié ?
                    </button>
                  </div>
                  <div className="flex flex-col items-center justify-center">
                    <PinInput
                      value={loginPin}
                      onChange={val => {
                        setLoginPin(val);
                        setErrorMessage(null);
                      }}
                      autoFocus={false}
                    />
                  </div>
                </div>

                {errorMessage && (
                  <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-start gap-2.5 text-xs text-red-700">
                    <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                {isLoading ? (
                  <div className="py-4 flex flex-col items-center justify-center">
                    <PayperSymbolicLoader context="payments" size="md" />
                    <p className="text-xs text-neutral-500 font-medium mt-3">
                      {loadingAction}
                    </p>
                  </div>
                ) : (
                  <div className="sticky bottom-0 bg-white/95 backdrop-blur-md pt-3 pb-1 mt-3 z-10">
                    <GreenGlowButton
                      fullWidth
                      size="md"
                      type="submit"
                      disabled={!rawPhone.trim() || loginPin.length !== 6}
                    >
                      <span>Se connecter</span>
                      <ArrowRight className="w-4 h-4" />
                    </GreenGlowButton>
                  </div>
                )}
              </form>

              <div className="mt-6 pt-4 border-t border-neutral-100 text-center">
                <button
                  type="button"
                  onClick={() => goToStep('phone')}
                  className="text-xs text-neutral-500 hover:text-neutral-800"
                >
                  Nouveau sur PAYPER ? <span className="text-[#00C48C] font-bold">Créer un compte</span>
                </button>
              </div>
            </motion.div>
          )}

          {/* ========================================================= */}
          {/* ÉCRAN DE RÉCUPÉRATION DU CODE SECRET                       */}
          {/* ========================================================= */}
          {currentStep === 'recovery' && (
            <motion.div
              key="step-recovery"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="bg-white rounded-3xl p-6 sm:p-8 shadow-xl border border-neutral-100"
            >
              <div className="flex items-center justify-between mb-5">
                <button
                  type="button"
                  onClick={() => goToStep('login')}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-500 hover:text-neutral-900 py-1.5 px-2.5 -ml-1 rounded-lg hover:bg-neutral-100 transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Retour connexion</span>
                </button>
                <div className="w-2.5 h-2.5 rounded-full bg-[#FF8A00]" />
              </div>

              <div className="mb-6 text-center">
                <div className="w-12 h-12 rounded-2xl bg-orange-100 text-[#FF8A00] flex items-center justify-center mx-auto mb-3">
                  <HelpCircle className="w-6 h-6" />
                </div>
                <h2 className="text-2xl font-black text-[#111827] tracking-tight">
                  Récupération du code
                </h2>
                <p className="text-sm text-neutral-500 mt-1.5 max-w-xs mx-auto leading-relaxed">
                  Entrez votre numéro enregistré pour recevoir un lien ou réinitialiser votre code secret.
                </p>
              </div>

              {recoverySuccess ? (
                <div className="space-y-4">
                  <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-center">
                    <CheckCircle2 className="w-8 h-8 text-[#00C48C] mx-auto mb-2" />
                    <h3 className="text-sm font-bold text-emerald-900">Demande enregistrée</h3>
                    <p className="text-xs text-emerald-700 mt-1 leading-relaxed">
                      Si ce numéro correspond à un compte PAYPER, un code temporaire ou des instructions de réinitialisation vous ont été transmises.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setRecoverySuccess(false);
                      goToStep('login');
                    }}
                    className="w-full py-3.5 rounded-xl text-sm font-bold text-white bg-[#FF8A00] hover:bg-[#e67c00] transition-all cursor-pointer"
                  >
                    Retour à la connexion
                  </button>
                </div>
              ) : (
                <form onSubmit={handleRecoverySubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-neutral-500 mb-1.5">
                      Votre numéro de téléphone
                    </label>
                    <div className="relative flex items-center">
                      <div className="absolute left-3.5 flex items-center gap-1.5 text-neutral-500 font-mono font-bold text-sm pointer-events-none">
                        <span>{selectedCountry.flag}</span>
                        <span>{selectedCountry.code}</span>
                      </div>
                      <input
                        type="tel"
                        inputMode="tel"
                        placeholder={selectedCountry.placeholder}
                        value={rawPhone}
                        onChange={e => {
                          setRawPhone(e.target.value);
                          setErrorMessage(null);
                        }}
                        className="w-full pl-28 pr-4 py-3 bg-neutral-50 border border-neutral-200 rounded-xl text-base font-bold text-neutral-900 placeholder:text-neutral-300 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-all font-mono"
                      />
                    </div>
                  </div>

                  {errorMessage && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-start gap-2.5 text-xs text-red-700">
                      <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                      <span>{errorMessage}</span>
                    </div>
                  )}

                  {isLoading ? (
                    <div className="py-4 flex flex-col items-center justify-center">
                      <PayperSymbolicLoader context="payments" size="md" />
                      <p className="text-xs text-neutral-500 font-medium mt-3">
                        {loadingAction}
                      </p>
                    </div>
                  ) : (
                    <div className="sticky bottom-0 bg-white/95 backdrop-blur-md pt-3 pb-1 mt-2 z-10">
                      <GreenGlowButton
                        fullWidth
                        size="md"
                        type="submit"
                        disabled={!rawPhone.trim()}
                      >
                        <span>Envoyer la demande</span>
                        <ArrowRight className="w-4 h-4" />
                      </GreenGlowButton>
                    </div>
                  )}
                </form>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Footer minimaliste et confidentiel */}
      <footer className="text-center py-2">
        <div className="flex items-center justify-center gap-2 text-[11px] text-white/80 font-medium">
          <ShieldCheck className="w-3.5 h-3.5 text-white" />
          <span>PAYPER · Chiffrement financier de bout en bout</span>
        </div>
      </footer>
    </div>
  );
};
