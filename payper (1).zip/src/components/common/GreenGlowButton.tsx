import React from 'react';
import { Loader2 } from 'lucide-react';

interface GreenGlowButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
  loading?: boolean;
  loadingText?: string;
}

export const GreenGlowButton: React.FC<GreenGlowButtonProps> = ({
  children,
  className = '',
  size = 'md',
  fullWidth = false,
  disabled = false,
  loading = false,
  loadingText,
  type = 'button',
  onClick,
  ...props
}) => {
  const sizeClasses = {
    sm: 'px-3 py-1.5 text-xs rounded-lg',
    md: 'px-4 py-2.5 text-sm rounded-xl',
    lg: 'px-6 py-3.5 text-base rounded-2xl',
  };

  const innerRadius = {
    sm: 'rounded-[6px]',
    md: 'rounded-[10px]',
    lg: 'rounded-[14px]',
  };

  return (
    <button
      type={type}
      disabled={disabled || loading}
      onClick={onClick}
      className={`relative group inline-flex items-center justify-center p-[2px] overflow-hidden font-bold transition-all active:scale-[0.98] disabled:opacity-60 disabled:pointer-events-none cursor-pointer shadow-md shadow-emerald-500/25 ${
        fullWidth ? 'w-full' : ''
      } ${sizeClasses[size].split(' ').filter(c => c.startsWith('rounded')).join(' ')} ${className}`}
      {...props}
    >
      {/* Lumière rotative qui passe et tourne sur toute la bordure */}
      <span
        aria-hidden="true"
        className="absolute inset-[-250%] animate-[spin_3s_linear_infinite] bg-[conic-gradient(from_0deg,transparent_0_260deg,rgba(255,255,255,0.7)_320deg,#ffffff_350deg,transparent_360deg)] pointer-events-none z-0"
      />

      {/* Cœur du bouton en vert vif (#00C48C) */}
      <span
        className={`relative z-10 w-full h-full flex items-center justify-center gap-2 bg-[#00C48C] hover:bg-[#00b07d] text-white font-bold transition-colors select-none ${innerRadius[size]} ${
          sizeClasses[size].split(' ').filter(c => !c.startsWith('rounded')).join(' ')
        }`}
      >
        {loading ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin shrink-0" />
            <span>{loadingText || children}</span>
          </>
        ) : (
          children
        )}
      </span>
    </button>
  );
};
