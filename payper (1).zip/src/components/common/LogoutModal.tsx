import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { LogOut, X, ShieldAlert } from 'lucide-react';
import { logoutUser, getUserAccount, getBoutiques } from '../../lib/storage';
import { signOutSupabase } from '../../lib/supabase';
import { useToast } from './Toast';

interface LogoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogoutConfirmed?: () => void;
}

export const LogoutModal: React.FC<LogoutModalProps> = ({
  isOpen,
  onClose,
  onLogoutConfirmed,
}) => {
  const { showToast } = useToast();
  const user = getUserAccount();
  const boutiques = getBoutiques();

  const handleLogout = () => {
    signOutSupabase().catch(() => {});
    logoutUser();
    showToast('Déconnexion de votre compte PAYPER réussie.', 'info');
    onClose();
    if (onLogoutConfirmed) {
      onLogoutConfirmed();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 bg-black/50 backdrop-blur-xs"
      />

      {/* Modal Dialog */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative z-10 bg-white rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-2xl border border-neutral-100"
      >
        <div className="flex items-center justify-between pb-3 border-b border-neutral-100 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-red-50 text-red-600 flex items-center justify-center">
              <LogOut className="w-5 h-5" />
            </div>
            <h3 className="text-base font-bold text-[#111827]">
              Déconnexion du compte PAYPER
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg cursor-pointer"
            aria-label="Fermer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 mb-6">
          <p className="text-xs text-neutral-600 leading-relaxed">
            Vous êtes sur le point de vous déconnecter de votre compte utilisateur PAYPER (
            <strong>{user.name}</strong>).
          </p>
          <div className="bg-neutral-50 rounded-xl p-3 border border-neutral-100 text-xs text-neutral-500 space-y-1">
            <div className="font-semibold text-neutral-700">
              Vos données restent en sécurité :
            </div>
            <p>
              • Vos <strong>{boutiques.length} boutiques</strong> et leurs factures associées
              sont conservées.
            </p>
            <p>
              • Vous pourrez vous reconnecter à tout moment pour retrouver l’ensemble de vos
              espaces.
            </p>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="py-2.5 px-4 rounded-xl text-xs font-semibold text-neutral-600 hover:bg-neutral-100 transition-colors cursor-pointer"
          >
            Annuler
          </button>
          <button
            onClick={handleLogout}
            className="py-2.5 px-5 rounded-xl text-xs font-bold text-white bg-red-600 hover:bg-red-700 transition-colors cursor-pointer shadow-sm shadow-red-600/20 active:scale-95"
          >
            Se déconnecter
          </button>
        </div>
      </motion.div>
    </div>
  );
};
