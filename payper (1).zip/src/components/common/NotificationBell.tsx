import React, { useState, useEffect, useRef } from 'react';
import {
  Bell,
  CheckCircle2,
  Clock,
  Store,
  Check,
  X,
  CreditCard,
  FileText,
} from 'lucide-react';
import { getInvoices, getActiveBoutique } from '../../lib/storage';

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  type: 'invoice' | 'payment' | 'boutique' | 'reminder';
  path?: string;
}

interface NotificationBellProps {
  onNavigate?: (path: string) => void;
  className?: string;
}

export const NotificationBell: React.FC<NotificationBellProps> = ({
  onNavigate,
  className = '',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const loadNotifications = () => {
    try {
      const activeBoutique = getActiveBoutique();
      const invoices = getInvoices();
      const readIds: string[] = JSON.parse(
        localStorage.getItem('payper_read_notifications') || '[]'
      );

      const items: AppNotification[] = [];

      // 1. Invoices pending / unpaid
      const pendingInvoices = invoices.filter(inv => !inv.isPaid || inv.status === 'PENDING');
      if (pendingInvoices.length > 0) {
        const latest = pendingInvoices[0];
        items.push({
          id: `pending_${latest.id}`,
          title: `${pendingInvoices.length} facture${pendingInvoices.length > 1 ? 's' : ''} en attente`,
          message: `${latest.clientName || 'Client'} · ${(latest.amount || 0).toLocaleString()} ${activeBoutique?.devise || latest.devise || 'FCFA'}`,
          timestamp: 'Action requise',
          read: readIds.includes(`pending_${latest.id}`),
          type: 'reminder',
          path: '/invoices',
        });
      }

      // 2. Invoices paid
      const paidInvoices = invoices.filter(inv => inv.isPaid || inv.status === 'PAID');
      if (paidInvoices.length > 0) {
        const latestPaid = paidInvoices[0];
        items.push({
          id: `paid_${latestPaid.id}`,
          title: 'Facture encaissée avec succès',
          message: `${latestPaid.invoice_number || latestPaid.id || 'Facture'} réglée pour ${latestPaid.clientName}`,
          timestamp: 'Règlement reçu',
          read: readIds.includes(`paid_${latestPaid.id}`),
          type: 'payment',
          path: '/invoices',
        });
      }

      // 3. Active Boutique status
      if (activeBoutique && activeBoutique.name) {
        items.push({
          id: `boutique_${activeBoutique.id || 'default'}`,
          title: `Boutique active : ${activeBoutique.name}`,
          message: `Prête pour l'émission de factures certifiées`,
          timestamp: 'En service',
          read: readIds.includes(`boutique_${activeBoutique.id || 'default'}`),
          type: 'boutique',
          path: '/boutiques',
        });
      }

      // 4. Default welcome notification if empty
      if (items.length === 0) {
        items.push({
          id: 'welcome_notice',
          title: 'Bienvenue sur votre espace de facturation',
          message: 'Créez votre première facture en un clic.',
          timestamp: "À l'instant",
          read: readIds.includes('welcome_notice'),
          type: 'invoice',
          path: '/invoices',
        });
      }

      setNotifications(items);
    } catch (e) {
      console.error('Error building notifications', e);
    }
  };

  useEffect(() => {
    loadNotifications();

    const handleUpdate = () => loadNotifications();
    window.addEventListener('payper_invoices_updated', handleUpdate);
    window.addEventListener('payper_boutique_updated', handleUpdate);
    window.addEventListener('payper_boutiques_updated', handleUpdate);

    return () => {
      window.removeEventListener('payper_invoices_updated', handleUpdate);
      window.removeEventListener('payper_boutique_updated', handleUpdate);
      window.removeEventListener('payper_boutiques_updated', handleUpdate);
    };
  }, []);

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAllAsRead = () => {
    const allIds = notifications.map(n => n.id);
    localStorage.setItem('payper_read_notifications', JSON.stringify(allIds));
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const handleItemClick = (item: AppNotification) => {
    // Mark this one as read
    const readIds: string[] = JSON.parse(
      localStorage.getItem('payper_read_notifications') || '[]'
    );
    if (!readIds.includes(item.id)) {
      readIds.push(item.id);
      localStorage.setItem('payper_read_notifications', JSON.stringify(readIds));
    }

    setNotifications(prev =>
      prev.map(n => (n.id === item.id ? { ...n, read: true } : n))
    );
    setIsOpen(false);

    if (item.path && onNavigate) {
      onNavigate(item.path);
    }
  };

  const getIcon = (type: AppNotification['type']) => {
    switch (type) {
      case 'payment':
        return <CheckCircle2 className="w-4 h-4 text-emerald-600" />;
      case 'reminder':
        return <Clock className="w-4 h-4 text-[#FF8A00]" />;
      case 'boutique':
        return <Store className="w-4 h-4 text-purple-600" />;
      default:
        return <FileText className="w-4 h-4 text-blue-600" />;
    }
  };

  return (
    <div className={`relative inline-block ${className}`} ref={dropdownRef}>
      {/* Top Bar Notification Bell Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 rounded-xl text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 transition-colors cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#FF8A00]/20"
        aria-label="Notifications"
        title="Voir les notifications"
      >
        <Bell className="w-5 h-5 transition-transform active:scale-95" />
        {unreadCount > 0 && (
          <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center rounded-full bg-[#FF8A00] text-[10px] font-bold text-white shadow-xs ring-2 ring-white animate-pulse">
            {unreadCount}
          </span>
        )}
      </button>

      {/* Floating Notification Panel Dropdown */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 sm:w-88 max-w-[calc(100vw-2rem)] bg-white rounded-2xl shadow-xl border border-neutral-200/90 z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-150">
          {/* Header */}
          <div className="px-4 py-3 bg-neutral-50/80 border-b border-neutral-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-[#111827]">Notifications</span>
              {unreadCount > 0 ? (
                <span className="text-[11px] font-semibold bg-orange-100 text-[#FF8A00] px-2 py-0.5 rounded-full">
                  {unreadCount} nouvelle{unreadCount > 1 ? 's' : ''}
                </span>
              ) : (
                <span className="text-[11px] font-medium text-neutral-400">
                  À jour
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5">
              {unreadCount > 0 && (
                <button
                  onClick={markAllAsRead}
                  className="text-[11px] font-semibold text-[#FF8A00] hover:text-[#e67c00] flex items-center gap-1 cursor-pointer transition-colors"
                  title="Tout marquer comme lu"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Tout lire</span>
                </button>
              )}
              <button
                onClick={() => setIsOpen(false)}
                className="p-1 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 cursor-pointer"
                aria-label="Fermer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* List of Notifications */}
          <div className="divide-y divide-neutral-100 max-h-80 overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="p-6 text-center text-xs text-neutral-400">
                Aucune notification pour le moment.
              </div>
            ) : (
              notifications.map(item => (
                <div
                  key={item.id}
                  onClick={() => handleItemClick(item)}
                  className={`p-3.5 flex items-start gap-3 transition-colors cursor-pointer text-left ${
                    item.read
                      ? 'bg-white hover:bg-neutral-50/80 opacity-75'
                      : 'bg-orange-50/30 hover:bg-orange-50/60'
                  }`}
                >
                  <div className="p-2 rounded-xl bg-neutral-100 shrink-0 mt-0.5">
                    {getIcon(item.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <p className={`text-xs truncate ${item.read ? 'font-medium text-neutral-800' : 'font-bold text-[#111827]'}`}>
                        {item.title}
                      </p>
                      {!item.read && (
                        <span className="w-2 h-2 rounded-full bg-[#FF8A00] shrink-0" />
                      )}
                    </div>
                    <p className="text-[11px] text-neutral-500 mt-0.5 line-clamp-2">
                      {item.message}
                    </p>
                    <span className="text-[10px] text-neutral-400 mt-1 block">
                      {item.timestamp}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Bottom quick action */}
          <div className="px-4 py-2.5 bg-neutral-50/60 border-t border-neutral-100 flex items-center justify-between text-[11px] text-neutral-500">
            <span className="flex items-center gap-1">
              <CreditCard className="w-3 h-3 text-neutral-400" />
              <span>Système de facturation prêt</span>
            </span>
            {onNavigate && (
              <button
                onClick={() => {
                  setIsOpen(false);
                  onNavigate('/invoices');
                }}
                className="font-semibold text-[#FF8A00] hover:underline cursor-pointer"
              >
                Voir factures →
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
