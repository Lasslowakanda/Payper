import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
}

/**
 * 1. Logo officiel Wave Mobile Money (identique à la capture)
 * - Fond cyan Dodger Blue officiel #1DC8FF
 * - Mascotte officielle : manchot / pingouin stylisé avec son aile gauche levée qui salue
 * - Bec et pattes dorés, ventre blanc
 */
export const WaveMoneyLogo: React.FC<LogoProps> = ({ className = '', size = 80 }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Logo officiel Wave Mobile Money"
    >
      <rect width="100" height="100" rx="22" fill="#1DC8FF" />
      <g transform="translate(14, 12)">
        {/* Corps sombre du pingouin */}
        <path
          d="M36 6 C24 6 18 16 18 32 C18 42 19 60 20 68 C20 73 26 76 36 76 C46 76 52 73 52 68 C53 60 54 42 54 32 C54 16 48 6 36 6 Z"
          fill="#000000"
        />
        {/* Aile gauche levée saluant */}
        <path
          d="M20 38 C10 32 4 20 7 14 C10 10 17 14 21 24 Z"
          fill="#000000"
        />
        {/* Aile droite au repos */}
        <path
          d="M52 38 C60 44 65 52 62 58 C59 61 54 57 51 48 Z"
          fill="#000000"
        />
        {/* Ventre blanc arrondi */}
        <ellipse cx="36" cy="48" rx="13.5" ry="20" fill="#FFFFFF" />
        {/* Yeux */}
        <circle cx="29.5" cy="22" r="3.2" fill="#FFFFFF" />
        <circle cx="30.2" cy="22" r="1.6" fill="#000000" />
        <circle cx="42.5" cy="22" r="3.2" fill="#FFFFFF" />
        <circle cx="41.8" cy="22" r="1.6" fill="#000000" />
        {/* Bec doré */}
        <path d="M33 26.5 L39 26.5 L36 32 Z" fill="#FFB703" />
        {/* Pattes dorées */}
        <ellipse cx="28" cy="76" rx="6.5" ry="3.5" fill="#FFB703" />
        <ellipse cx="44" cy="76" rx="6.5" ry="3.5" fill="#FFB703" />
      </g>
    </svg>
  );
};

/**
 * 2. Logo officiel Orange Money (identique à la capture)
 * - Fond noir officiel
 * - Flèche blanche en haut à gauche (direction ↖)
 * - Flèche orange en bas à droite (direction ↘)
 * - Texte "Orange Money" en dessous
 */
export const OrangeMoneyLogo: React.FC<LogoProps> = ({ className = '', size = 80 }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Logo officiel Orange Money"
    >
      <rect width="100" height="100" rx="22" fill="#000000" />
      
      {/* Flèche blanche en haut à gauche (direction ↖) */}
      <path
        d="M24 24 H47 V32 H37.5 L53 47.5 L47.5 53 L32 37.5 V47 H24 V24 Z"
        fill="#FFFFFF"
      />
      
      {/* Flèche orange en bas à droite (direction ↘) */}
      <path
        d="M76 76 H53 V68 H62.5 L47 52.5 L52.5 47 L68 62.5 V53 H76 V76 Z"
        fill="#FF7900"
      />
      
      {/* Texte "Orange Money" en dessous */}
      <text
        x="50"
        y="86"
        textAnchor="middle"
        fill="#FF7900"
        fontSize="9.5"
        fontWeight="800"
        fontFamily="system-ui, -apple-system, sans-serif"
        letterSpacing="0.2"
      >
        Orange Money
      </text>
    </svg>
  );
};

/**
 * 3. Logo officiel Moov Money (identique à la capture)
 * - Fond orange #F25900
 * - MOOV en cyan / bleu ciel officiel
 * - Money en blanc bold
 * - Symbole billet / onde
 */
export const MoovMoneyLogo: React.FC<LogoProps> = ({ className = '', size = 80 }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Logo officiel Moov Money"
    >
      <rect width="100" height="100" rx="22" fill="#F25900" />
      
      {/* MOOV en cyan / bleu ciel officiel */}
      <text
        x="50"
        y="45"
        textAnchor="middle"
        fill="#00BFFF"
        fontSize="21"
        fontWeight="900"
        fontStyle="italic"
        fontFamily="system-ui, -apple-system, sans-serif"
        letterSpacing="-0.5"
      >
        MOOV
      </text>
      
      {/* Money en blanc bold */}
      <text
        x="44"
        y="70"
        textAnchor="middle"
        fill="#FFFFFF"
        fontSize="20"
        fontWeight="900"
        fontFamily="system-ui, -apple-system, sans-serif"
        letterSpacing="-0.5"
      >
        Money
      </text>
      
      {/* Mini icône billet / onde en blanc */}
      <g transform="translate(68, 55)">
        <rect x="0" y="2" width="13" height="9" rx="1.5" fill="#FFFFFF" />
        <path d="M4 2 L8 8 M6 2 L10 8" stroke="#F25900" strokeWidth="1" />
        <path d="M14 4 C16 6 16 9 14 11" stroke="#FFFFFF" strokeWidth="1.5" strokeLinecap="round" fill="none" />
      </g>
    </svg>
  );
};

/**
 * 4. Logo officiel MTN (identique à la capture)
 * - Fond jaune signature MTN #FFCC00
 * - Ovale horizontal noir
 * - Texte "MTN" noir bold
 */
export const MtnMoneyLogo: React.FC<LogoProps> = ({ className = '', size = 80 }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Logo officiel MTN"
    >
      <rect width="100" height="100" rx="22" fill="#FFCC00" />
      
      {/* Ovale noir horizontal */}
      <ellipse
        cx="50"
        cy="50"
        rx="36"
        ry="20"
        stroke="#000000"
        strokeWidth="4.5"
        fill="none"
      />
      
      {/* Texte MTN bold majuscule */}
      <text
        x="50"
        y="58"
        textAnchor="middle"
        fill="#000000"
        fontSize="23"
        fontWeight="900"
        fontFamily="system-ui, -apple-system, sans-serif"
        letterSpacing="1"
      >
        MTN
      </text>
    </svg>
  );
};

/**
 * 5. Logo officiel Airtel Money
 */
export const AirtelMoneyLogo: React.FC<LogoProps> = ({ className = '', size = 80 }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Logo officiel Airtel Money"
    >
      <rect width="100" height="100" rx="22" fill="#ED1C24" />
      <path
        d="M50 20C36.2 20 25 31.2 25 45C25 55.1 31 63.8 39.6 67.8V58.1C34.6 55.1 31.2 50.4 31.2 45C31.2 34.6 39.6 26.2 50 26.2C60.4 26.2 68.8 34.6 68.8 45C68.8 52.3 64.6 58.6 58.5 61.8L55.2 51.2H60.4C60.4 47.7 57.6 45 54.2 45H45.8V74.2H52.1V67.7C65.4 65.5 75 56.4 75 45C75 31.2 63.8 20 50 20Z"
        fill="#FFFFFF"
      />
    </svg>
  );
};

/**
 * 6. Logo officiel Carte Bancaire (Visa & Mastercard & Puce EMV)
 */
export const BankCardLogo: React.FC<LogoProps> = ({ className = '', size = 80 }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-label="Logo officiel Carte Bancaire"
    >
      <rect width="100" height="100" rx="22" fill="#0F172A" />
      <rect x="18" y="24" width="18" height="14" rx="3" fill="#F59E0B" />
      <path d="M24 24V38M30 24V38M18 31H36" stroke="#D97706" strokeWidth="1.5" />
      <circle cx="58" cy="62" r="14" fill="#EB001B" />
      <circle cx="74" cy="62" r="14" fill="#F79E1B" fillOpacity="0.9" />
      <path
        d="M66 50.6C68.4 53.6 70 57.6 70 62C70 66.4 68.4 70.4 66 73.4C63.6 70.4 62 66.4 62 62C62 57.6 63.6 53.6 66 50.6Z"
        fill="#FF5F00"
      />
      <text
        x="64"
        y="35"
        fill="#FFFFFF"
        fontSize="16"
        fontWeight="bold"
        fontFamily="sans-serif"
        fontStyle="italic"
      >
        VISA
      </text>
    </svg>
  );
};
