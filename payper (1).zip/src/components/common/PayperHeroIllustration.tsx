import React from 'react';
import { motion } from 'motion/react';

interface PayperHeroIllustrationProps {
  className?: string;
}

/**
 * Illustration synthétique vectorielle de PAYPER :
 * Représente avec élégance :
 * - Une boutique moderne (toit/auvent stylisé aux couleurs PAYPER)
 * - Un smartphone avec aperçu de transaction / reçu instantané
 * - Factures & paiements mobiles (icônes discrètes de quittance, validation verte, onde NFC)
 * - Design épuré, flat moderne, couleurs PAYPER orange (#FF8A00) et vert (#00C48C).
 */
export const PayperHeroIllustration: React.FC<PayperHeroIllustrationProps> = ({ className = '' }) => {
  return (
    <div className={`relative w-full max-w-sm mx-auto h-48 sm:h-56 flex items-center justify-center select-none ${className}`}>
      {/* Background Soft Glow */}
      <div className="absolute inset-0 bg-gradient-to-tr from-orange-100/60 via-emerald-50/50 to-orange-50/40 rounded-3xl blur-xl -z-10" />

      <svg
        viewBox="0 0 360 220"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full max-h-56 drop-shadow-md"
      >
        <defs>
          <linearGradient id="payperOrangeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FF8A00" />
            <stop offset="100%" stopColor="#FF6B00" />
          </linearGradient>

          <linearGradient id="payperGreenGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00C48C" />
            <stop offset="100%" stopColor="#059669" />
          </linearGradient>

          <linearGradient id="screenGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="100%" stopColor="#F8FAFC" />
          </linearGradient>

          <filter id="shadowLight" x="-10%" y="-10%" width="120%" height="130%" filterUnits="userSpaceOnUse">
            <feDropShadow dx="0" dy="6" stdDeviation="8" floodColor="#0F172A" floodOpacity="0.08" />
          </filter>
        </defs>

        {/* 1. BOUTIQUE / MAGASIN (Arrière-gauche stylisé) */}
        <g id="boutique-structure">
          {/* Base du magasin */}
          <rect x="36" y="74" width="130" height="110" rx="14" fill="#FFFFFF" stroke="#E2E8F0" strokeWidth="2" filter="url(#shadowLight)" />
          
          {/* Auvent rayé signature PAYPER */}
          <path
            d="M 30 74 L 172 74 L 164 50 L 38 50 Z"
            fill="url(#payperOrangeGrad)"
          />
          {/* Bandes de l'auvent */}
          <path d="M 54 50 L 50 74 L 72 74 L 74 50 Z" fill="#FFFFFF" opacity="0.3" />
          <path d="M 94 50 L 92 74 L 114 74 L 116 50 Z" fill="#FFFFFF" opacity="0.3" />
          <path d="M 136 50 L 134 74 L 156 74 L 158 50 Z" fill="#FFFFFF" opacity="0.3" />

          {/* Enseigne boutique */}
          <rect x="66" y="86" width="70" height="18" rx="5" fill="#FFF7ED" stroke="#FDBA74" strokeWidth="1.5" />
          <text x="101" y="99" textAnchor="middle" fill="#EA580C" fontSize="9" fontWeight="bold" fontFamily="system-ui">
            BOUTIQUE
          </text>

          {/* Vitrine / Porte */}
          <rect x="52" y="114" width="42" height="70" rx="6" fill="#F1F5F9" stroke="#CBD5E1" strokeWidth="1.5" />
          <rect x="104" y="114" width="46" height="50" rx="6" fill="#ECFDF5" stroke="#A7F3D0" strokeWidth="1.5" />
          {/* Étagère & articles stylisés dans la vitrine */}
          <line x1="108" y1="138" x2="146" y2="138" stroke="#00C48C" strokeWidth="2" strokeLinecap="round" />
          <rect x="110" y="126" width="10" height="10" rx="2" fill="#FF8A00" />
          <rect x="124" y="124" width="8" height="12" rx="2" fill="#00C48C" />
          <rect x="136" y="127" width="7" height="9" rx="2" fill="#3B82F6" />
        </g>

        {/* 2. FACTURE FLOTTANTE (Entre boutique et mobile) */}
        <g id="floating-invoice" transform="translate(130, 28) rotate(-6)">
          <rect x="0" y="0" width="76" height="98" rx="8" fill="#FFFFFF" stroke="#E2E8F0" strokeWidth="1.5" filter="url(#shadowLight)" />
          {/* Header facture */}
          <rect x="8" y="10" width="28" height="6" rx="2" fill="#FF8A00" />
          <circle cx="64" cy="13" r="4" fill="#00C48C" />
          {/* Lignes facture */}
          <line x1="8" y1="26" x2="68" y2="26" stroke="#E2E8F0" strokeWidth="1.5" />
          <rect x="8" y="34" width="40" height="4" rx="2" fill="#94A3B8" />
          <rect x="54" y="34" width="14" height="4" rx="2" fill="#64748B" />
          <rect x="8" y="44" width="32" height="4" rx="2" fill="#CBD5E1" />
          <rect x="54" y="44" width="14" height="4" rx="2" fill="#64748B" />
          <line x1="8" y1="56" x2="68" y2="56" stroke="#E2E8F0" strokeWidth="1.5" strokeDasharray="3 2" />
          {/* Total & Badge PAYÉ */}
          <rect x="8" y="66" width="22" height="5" rx="2" fill="#1E293B" />
          <rect x="42" y="65" width="26" height="7" rx="2" fill="#00C48C" />
          {/* Sceau de validation vert */}
          <circle cx="38" cy="84" r="7" fill="#ECFDF5" stroke="#00C48C" strokeWidth="1.5" />
          <path d="M 35 84 L 37.5 86.5 L 41.5 81.5" stroke="#00C48C" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </g>

        {/* 3. SMARTPHONE MOBILE MODERNE (Premier plan droite) */}
        <g id="smartphone-device">
          {/* Châssis smartphone */}
          <rect x="210" y="30" width="112" height="175" rx="20" fill="#0F172A" filter="url(#shadowLight)" />
          {/* Écran */}
          <rect x="215" y="35" width="102" height="165" rx="16" fill="url(#screenGrad)" />
          {/* Encoche haut (Dynamic Island) */}
          <rect x="248" y="40" width="36" height="6" rx="3" fill="#0F172A" />

          {/* Contenu écran : Application PAYPER */}
          {/* Header app */}
          <rect x="223" y="54" width="24" height="6" rx="3" fill="#FF8A00" />
          <circle cx="305" cy="57" r="4" fill="#00C48C" />

          {/* Carte de paiement / transaction reçue */}
          <rect x="223" y="68" width="86" height="64" rx="10" fill="url(#payperGreenGrad)" />
          {/* Icône validation */}
          <circle cx="266" cy="88" r="11" fill="#FFFFFF" />
          <path d="M 261 88 L 264.5 91.5 L 271 85" stroke="#00C48C" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          <text x="266" y="109" textAnchor="middle" fill="#FFFFFF" fontSize="8" fontWeight="bold" fontFamily="system-ui">
            Paiement Reçu
          </text>
          <text x="266" y="121" textAnchor="middle" fill="#E6FFFA" fontSize="9" fontWeight="900" fontFamily="system-ui">
            +50 000 FCFA
          </text>

          {/* Bouton rapide d'envoi WhatsApp */}
          <rect x="223" y="140" width="86" height="20" rx="6" fill="#25D366" />
          <text x="266" y="153" textAnchor="middle" fill="#FFFFFF" fontSize="8.5" fontWeight="bold" fontFamily="system-ui">
            Partager WhatsApp
          </text>

          {/* Barre de navigation basse */}
          <rect x="227" y="186" width="78" height="4" rx="2" fill="#CBD5E1" />
        </g>

        {/* 4. ÉLÉMENTS DE TRANSACTION FLOTTANTS (Ondes & Monnaie) */}
        {/* Bulle Wave / Orange Money */}
        <g id="bubble-om" transform="translate(180, 150)">
          <circle cx="16" cy="16" r="15" fill="#FFF7ED" stroke="#FF8A00" strokeWidth="1.8" filter="url(#shadowLight)" />
          <text x="16" y="20" textAnchor="middle" fill="#FF8A00" fontSize="11" fontWeight="bold" fontFamily="system-ui">
            OM
          </text>
        </g>

        {/* Bulle Wave */}
        <g id="bubble-wave" transform="translate(192, 10)">
          <circle cx="14" cy="14" r="13" fill="#E0F2FE" stroke="#0284C7" strokeWidth="1.8" filter="url(#shadowLight)" />
          <text x="14" y="18" textAnchor="middle" fill="#0284C7" fontSize="10" fontWeight="bold" fontFamily="system-ui">
            Wave
          </text>
        </g>

        {/* Étoiles / Éclats graphiques discrets PAYPER */}
        <circle cx="48" cy="34" r="3" fill="#FF8A00" opacity="0.6" />
        <circle cx="330" cy="24" r="3.5" fill="#00C48C" opacity="0.7" />
        <circle cx="28" cy="190" r="2.5" fill="#00C48C" opacity="0.5" />
      </svg>
    </div>
  );
};
