import React from 'react';

interface PayperLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
  whiteText?: boolean;
}

export const PayperLogo: React.FC<PayperLogoProps> = ({
  size = 'md',
  className = '',
}) => {
  const circleSizes = {
    sm: 'w-5 h-5',
    md: 'w-7 h-7',
    lg: 'w-9 h-9',
    xl: 'w-12 h-12',
  };

  const offset = {
    sm: '-ml-2.5',
    md: '-ml-3.5',
    lg: '-ml-4',
    xl: '-ml-5',
  };

  return (
    <div className={`inline-flex items-center select-none ${className}`}>
      {/* Two overlapping circles: Orange #FF8A00 & Green #00C48C with mix-blend */}
      <div className="isolate relative flex items-center shrink-0">
        <div
          className={`${circleSizes[size]} rounded-full bg-[#FF8A00] opacity-95 shadow-sm ring-1 ring-white/30 transform transition-transform hover:scale-105`}
        />
        <div
          className={`${circleSizes[size]} ${offset[size]} rounded-full bg-[#00C48C] opacity-90 shadow-sm mix-blend-multiply ring-1 ring-white/30 transform transition-transform hover:scale-105`}
        />
      </div>
    </div>
  );
};
