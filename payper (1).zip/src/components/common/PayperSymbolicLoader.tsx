import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Package,        // Commandes / Colis
  ShoppingCart,   // Produits / Panier
  CreditCard,     // Paiements / Carte bancaire
  Coins,          // Transactions / Monnaie
  FileText,       // Factures / Document
  Users2,         // Clients / Groupe
  BarChart3,      // Statistiques & Analytics / Graphique
  BellRing,       // Notifications / Cloche
  Check,
  AlertCircle,
} from 'lucide-react';

export type PayperLoadingContext =
  | 'orders'         // Commandes (Colis animé)
  | 'products'       // Produits (Panier animé)
  | 'payments'       // Paiements (Carte bancaire animée)
  | 'transactions'   // Transactions (Monnaie / Pièces animées)
  | 'invoices'       // Factures (Document animé)
  | 'clients'        // Clients (Groupe animé)
  | 'analytics'      // Statistiques / Graphique animé
  | 'notifications'  // Notifications (Cloche animée)
  | 'general'        // Chargement général (Combinaison harmonieuse de symboles)
  | 'download'       // Téléchargement / export
  | 'whatsapp';      // Envoi WhatsApp

export type PayperSymbolicSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl';

export interface PayperSymbolicLoaderProps {
  /** Contexte d'action / page pour choisir le bon symbole animé */
  context?: PayperLoadingContext;
  /** Taille du loader */
  size?: PayperSymbolicSize;
  /** Affichage en ligne (inline) dans un bouton ou titre */
  inline?: boolean;
  /** Thème d'affichage */
  theme?: 'light' | 'dark' | 'button' | 'white';
  /** État d'erreur éventuel */
  isError?: boolean;
  errorMessage?: string;
  /** Classe Tailwind additionnelle */
  className?: string;
}

/** Configuration des dimensions selon la taille */
const SIZES = {
  xs: { box: 18, icon: 11, glow: 14, stroke: 2.2 },
  sm: { box: 26, icon: 15, glow: 20, stroke: 2.2 },
  md: { box: 44, icon: 24, glow: 34, stroke: 2.1 },
  lg: { box: 68, icon: 36, glow: 52, stroke: 2.0 },
  xl: { box: 96, icon: 52, glow: 76, stroke: 1.9 },
};

export const PayperSymbolicLoader: React.FC<PayperSymbolicLoaderProps> = ({
  context = 'general',
  size = 'md',
  inline = false,
  theme = 'light',
  isError = false,
  errorMessage,
  className = '',
}) => {
  const dim = SIZES[size];
  const isButton = theme === 'button';

  // État d'erreur direct
  if (isError) {
    return (
      <div
        className={`inline-flex items-center justify-center select-none ${className}`}
        style={{ width: inline ? 'auto' : dim.box, height: dim.box }}
      >
        <div className="relative flex items-center justify-center text-red-500">
          <AlertCircle style={{ width: dim.icon, height: dim.icon }} strokeWidth={dim.stroke} />
          {errorMessage && (
            <span className="ml-2 text-xs font-medium text-red-600">{errorMessage}</span>
          )}
        </div>
      </div>
    );
  }

  // Couleurs principales PAYPER : Orange #FF8A00 et Vert #00C48C
  const primaryOrange = '#FF8A00';
  const primaryGreen = '#00C48C';

  // 1. SYMBOLE DE COLIS ANIMÉ (Commandes)
  // Transition douce : léger sautillement élégant et clapet qui respire
  const renderOrdersSymbol = () => (
    <div
      className="relative flex items-center justify-center"
      style={{ width: dim.box, height: dim.box }}
    >
      {/* Halo graphique discret sans scène ni décor */}
      <motion.div
        animate={{ scale: [0.85, 1.15, 0.85], opacity: [0.2, 0.45, 0.2] }}
        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        style={{ width: dim.glow, height: dim.glow }}
        className="absolute rounded-full bg-[#FF8A00] blur-sm pointer-events-none"
      />
      <motion.div
        animate={{
          y: [0, -3.5, 0],
          rotate: [0, -2, 2, 0],
        }}
        transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
        className="relative z-10 text-[#FF8A00]"
      >
        <Package
          style={{ width: dim.icon, height: dim.icon }}
          strokeWidth={dim.stroke}
          className={isButton ? 'text-current' : 'text-[#FF8A00]'}
        />
        {/* Anneau de validation discret en coin */}
        <motion.div
          animate={{ scale: [0.7, 1.1, 0.7], opacity: [0.4, 0.9, 0.4] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-[#00C48C]"
        />
      </motion.div>
    </div>
  );

  // 2. SYMBOLE DE PANIER ANIMÉ (Produits)
  // Mouvement horizontal fluide et chargement d'un élément géométrique
  const renderProductsSymbol = () => (
    <div
      className="relative flex items-center justify-center"
      style={{ width: dim.box, height: dim.box }}
    >
      <motion.div
        animate={{ scale: [0.85, 1.15, 0.85], opacity: [0.2, 0.45, 0.2] }}
        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        style={{ width: dim.glow, height: dim.glow }}
        className="absolute rounded-full bg-[#00C48C] blur-sm pointer-events-none"
      />
      <motion.div
        animate={{
          x: [-2.5, 2.5, -2.5],
        }}
        transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
        className="relative z-10"
      >
        <ShoppingCart
          style={{ width: dim.icon, height: dim.icon }}
          strokeWidth={dim.stroke}
          className={isButton ? 'text-current' : 'text-[#00C48C]'}
        />
        {/* Pastille symbolique qui glisse dans le panier */}
        <motion.div
          animate={{
            y: [-6, 1, -6],
            opacity: [0, 1, 0],
          }}
          transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute top-0 right-1.5 w-1.5 h-1.5 rounded-full bg-[#FF8A00]"
        />
      </motion.div>
    </div>
  );

  // 3. SYMBOLE DE CARTE BANCAIRE ANIMÉ (Paiements)
  // Glissement diagonal fluide de la puce & pulsation de validation
  const renderPaymentsSymbol = () => (
    <div
      className="relative flex items-center justify-center"
      style={{ width: dim.box, height: dim.box }}
    >
      <motion.div
        animate={{ scale: [0.85, 1.15, 0.85], opacity: [0.2, 0.45, 0.2] }}
        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        style={{ width: dim.glow, height: dim.glow }}
        className="absolute rounded-full bg-gradient-to-tr from-[#FF8A00] to-[#00C48C] blur-sm pointer-events-none"
      />
      <motion.div
        animate={{
          rotateY: [0, 15, 0, -15, 0],
          y: [0, -1.5, 0],
        }}
        transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
        className="relative z-10"
      >
        <CreditCard
          style={{ width: dim.icon, height: dim.icon }}
          strokeWidth={dim.stroke}
          className={isButton ? 'text-current' : 'text-[#FF8A00]'}
        />
        {/* Petit trait lumineux symbolique sur la carte */}
        <motion.div
          animate={{
            x: [-6, 10, -6],
            opacity: [0, 1, 0],
          }}
          transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute bottom-1.5 left-1 w-2.5 h-0.5 bg-[#00C48C] rounded-full"
        />
      </motion.div>
    </div>
  );

  // 4. SYMBOLE DE MONNAIE ANIMÉ (Transactions)
  // Deux cercles de monnaie en permutation douce
  const renderTransactionsSymbol = () => (
    <div
      className="relative flex items-center justify-center"
      style={{ width: dim.box, height: dim.box }}
    >
      <motion.div
        animate={{ scale: [0.85, 1.2, 0.85], opacity: [0.2, 0.5, 0.2] }}
        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        style={{ width: dim.glow, height: dim.glow }}
        className="absolute rounded-full bg-[#00C48C] blur-sm pointer-events-none"
      />
      <motion.div
        animate={{
          scale: [0.92, 1.06, 0.92],
          rotate: [0, 10, -10, 0],
        }}
        transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
        className="relative z-10"
      >
        <Coins
          style={{ width: dim.icon, height: dim.icon }}
          strokeWidth={dim.stroke}
          className={isButton ? 'text-current' : 'text-[#00C48C]'}
        />
      </motion.div>
    </div>
  );

  // 5. SYMBOLE DE DOCUMENT ANIMÉ (Factures)
  // Lignes de facture qui se dessinent successivement avec coche de validation
  const renderInvoicesSymbol = () => (
    <div
      className="relative flex items-center justify-center"
      style={{ width: dim.box, height: dim.box }}
    >
      {/* Halos jumeaux orange et vert */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <motion.div
          animate={{ x: [-3, 3, -3], opacity: [0.25, 0.55, 0.25] }}
          transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
          style={{ width: dim.glow * 0.7, height: dim.glow * 0.7 }}
          className="rounded-full bg-[#FF8A00] blur-sm"
        />
        <motion.div
          animate={{ x: [3, -3, 3], opacity: [0.25, 0.55, 0.25] }}
          transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
          style={{ width: dim.glow * 0.7, height: dim.glow * 0.7 }}
          className="rounded-full bg-[#00C48C] blur-sm -ml-2"
        />
      </div>

      <motion.div
        animate={{
          y: [0, -2, 0],
        }}
        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        className="relative z-10"
      >
        <FileText
          style={{ width: dim.icon, height: dim.icon }}
          strokeWidth={dim.stroke}
          className={isButton ? 'text-current' : 'text-[#111827]'}
        />

        {/* Lignes intérieures animées */}
        <div
          className="absolute inset-0 pointer-events-none flex flex-col justify-center items-center"
          style={{ paddingLeft: size === 'xs' ? 2 : size === 'sm' ? 4 : 8 }}
        >
          <motion.div
            animate={{ opacity: [0.2, 1, 0.2], scaleX: [0.4, 1, 0.4] }}
            transition={{ duration: 1.8, repeat: Infinity, delay: 0 }}
            className="h-0.5 bg-[#FF8A00] rounded-full mb-1"
            style={{ width: dim.icon * 0.45 }}
          />
          <motion.div
            animate={{ opacity: [0.2, 1, 0.2], scaleX: [0.4, 1, 0.4] }}
            transition={{ duration: 1.8, repeat: Infinity, delay: 0.3 }}
            className="h-0.5 bg-[#00C48C] rounded-full"
            style={{ width: dim.icon * 0.35 }}
          />
        </div>

        {/* Coche de validation symbolique en coin */}
        <motion.div
          animate={{ scale: [0, 1.15, 1, 0], opacity: [0, 1, 1, 0] }}
          transition={{ duration: 2, repeat: Infinity, times: [0, 0.6, 0.85, 1] }}
          className="absolute -bottom-1 -right-1 rounded-full bg-[#00C48C] text-white flex items-center justify-center p-0.5 shadow-sm"
        >
          <Check style={{ width: dim.icon * 0.35, height: dim.icon * 0.35 }} strokeWidth={3.5} />
        </motion.div>
      </motion.div>
    </div>
  );

  // 6. SYMBOLE DE GROUPE ANIMÉ (Clients)
  // Pulsation harmonieuse de réseau de clients
  const renderClientsSymbol = () => (
    <div
      className="relative flex items-center justify-center"
      style={{ width: dim.box, height: dim.box }}
    >
      <motion.div
        animate={{ scale: [0.85, 1.2, 0.85], opacity: [0.2, 0.45, 0.2] }}
        transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
        style={{ width: dim.glow, height: dim.glow }}
        className="absolute rounded-full bg-[#FF8A00] blur-sm pointer-events-none"
      />
      <motion.div
        animate={{
          scale: [0.94, 1.05, 0.94],
        }}
        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        className="relative z-10"
      >
        <Users2
          style={{ width: dim.icon, height: dim.icon }}
          strokeWidth={dim.stroke}
          className={isButton ? 'text-current' : 'text-[#FF8A00]'}
        />
        {/* Anneau de connexion symbolique */}
        <motion.div
          animate={{ scale: [0.8, 1.3, 0.8], opacity: [0.6, 0, 0.6] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: 'easeOut' }}
          className="absolute inset-0 rounded-full border border-[#00C48C] pointer-events-none"
        />
      </motion.div>
    </div>
  );

  // 7. SYMBOLE DE GRAPHIQUE ANIMÉ (Statistiques / Analytics)
  // Barres qui s'élèvent et s'équilibrent de manière fluide
  const renderAnalyticsSymbol = () => (
    <div
      className="relative flex items-center justify-center"
      style={{ width: dim.box, height: dim.box }}
    >
      <motion.div
        animate={{ scale: [0.85, 1.2, 0.85], opacity: [0.2, 0.5, 0.2] }}
        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        style={{ width: dim.glow, height: dim.glow }}
        className="absolute rounded-full bg-gradient-to-r from-[#FF8A00] to-[#00C48C] blur-sm pointer-events-none"
      />
      <motion.div
        animate={{
          y: [0, -2, 0],
        }}
        transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
        className="relative z-10"
      >
        <BarChart3
          style={{ width: dim.icon, height: dim.icon }}
          strokeWidth={dim.stroke}
          className={isButton ? 'text-current' : 'text-[#00C48C]'}
        />
        {/* Pulsation de point de tendance */}
        <motion.div
          animate={{ scale: [0.8, 1.4, 0.8], opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute -top-1 right-0 w-1.5 h-1.5 rounded-full bg-[#FF8A00]"
        />
      </motion.div>
    </div>
  );

  // 8. SYMBOLE DE CLOCHE ANIMÉE (Notifications)
  // Balancement pendulaire doux et précis (subtil tintement)
  const renderNotificationsSymbol = () => (
    <div
      className="relative flex items-center justify-center"
      style={{ width: dim.box, height: dim.box }}
    >
      <motion.div
        animate={{ scale: [0.85, 1.2, 0.85], opacity: [0.2, 0.45, 0.2] }}
        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        style={{ width: dim.glow, height: dim.glow }}
        className="absolute rounded-full bg-[#FF8A00] blur-sm pointer-events-none"
      />
      <motion.div
        animate={{
          rotate: [0, -12, 10, -8, 6, 0],
        }}
        transition={{
          duration: 1.8,
          repeat: Infinity,
          ease: 'easeInOut',
          repeatDelay: 0.4,
        }}
        style={{ originX: 0.5, originY: 0.1 }}
        className="relative z-10"
      >
        <BellRing
          style={{ width: dim.icon, height: dim.icon }}
          strokeWidth={dim.stroke}
          className={isButton ? 'text-current' : 'text-[#FF8A00]'}
        />
        {/* Point de signalisation vert */}
        <motion.div
          animate={{ scale: [0.8, 1.2, 0.8], opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 1.2, repeat: Infinity }}
          className="absolute -top-0.5 right-0 w-1.5 h-1.5 rounded-full bg-[#00C48C]"
        />
      </motion.div>
    </div>
  );

  // 9. CHARGEMENT GÉNÉRAL : Combinaison harmonieuse de formes géométriques et symboles PAYPER
  // Deux cercles emblématiques (Orange et Vert) en orbite fluide avec un carré pivotant au centre
  const renderGeneralSymbol = () => (
    <div
      className="relative flex items-center justify-center select-none"
      style={{ width: dim.box, height: dim.box }}
    >
      {/* Cercle Orange orbital */}
      <motion.div
        animate={{
          x: [-dim.box * 0.16, dim.box * 0.16, -dim.box * 0.16],
          scale: [0.85, 1.15, 0.85],
          opacity: [0.6, 0.9, 0.6],
        }}
        transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
        style={{ width: dim.box * 0.45, height: dim.box * 0.45 }}
        className="absolute rounded-full bg-[#FF8A00]/80 shadow-sm"
      />

      {/* Cercle Vert orbital entrelacé */}
      <motion.div
        animate={{
          x: [dim.box * 0.16, -dim.box * 0.16, dim.box * 0.16],
          scale: [1.15, 0.85, 1.15],
          opacity: [0.9, 0.6, 0.9],
        }}
        transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
        style={{ width: dim.box * 0.45, height: dim.box * 0.45 }}
        className="absolute rounded-full bg-[#00C48C]/80 shadow-sm mix-blend-multiply"
      />

      {/* Noyau géométrique central minimaliste (losange subtil aux coins arrondis) */}
      <motion.div
        animate={{
          rotate: [0, 90, 180, 270, 360],
          scale: [0.8, 1, 0.8],
        }}
        transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
        style={{
          width: dim.box * 0.22,
          height: dim.box * 0.22,
        }}
        className="relative z-10 rounded-sm bg-white shadow-sm border border-neutral-200"
      />
    </div>
  );

  const getVisualByContext = () => {
    switch (context) {
      case 'orders':
        return renderOrdersSymbol();
      case 'products':
        return renderProductsSymbol();
      case 'payments':
        return renderPaymentsSymbol();
      case 'transactions':
        return renderTransactionsSymbol();
      case 'invoices':
        return renderInvoicesSymbol();
      case 'clients':
        return renderClientsSymbol();
      case 'analytics':
        return renderAnalyticsSymbol();
      case 'notifications':
        return renderNotificationsSymbol();
      case 'download':
      case 'whatsapp':
      case 'general':
      default:
        return renderGeneralSymbol();
    }
  };

  return (
    <div
      className={`inline-flex items-center justify-center select-none ${className}`}
      aria-label={`Chargement PAYPER (${context})`}
    >
      {getVisualByContext()}
    </div>
  );
};
