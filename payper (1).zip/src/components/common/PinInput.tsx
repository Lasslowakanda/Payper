import React, { useRef, useEffect, useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';

interface PinInputProps {
  value: string;
  onChange: (pin: string) => void;
  onComplete?: (pin: string) => void;
  disabled?: boolean;
  hasError?: boolean;
  autoFocus?: boolean;
  idPrefix?: string;
  allowPeek?: boolean;
}

export const PinInput: React.FC<PinInputProps> = ({
  value = '',
  onChange,
  onComplete,
  disabled = false,
  hasError = false,
  autoFocus = false,
  idPrefix = 'pin',
  allowPeek = true,
}) => {
  const [showDigits, setShowDigits] = useState(false);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Array of 6 digits from value
  const digits = Array.from({ length: 6 }, (_, i) => value[i] || '');

  useEffect(() => {
    if (autoFocus && inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
  }, [autoFocus]);

  const handleInputChange = (index: number, e: React.ChangeEvent<HTMLInputElement>) => {
    const rawVal = e.target.value;
    const digit = rawVal.replace(/\D/g, '').slice(-1); // Prendre le dernier chiffre saisi

    const newDigits = [...digits];
    newDigits[index] = digit;
    const newPin = newDigits.join('').slice(0, 6);
    onChange(newPin);

    // Si un chiffre a été tapé, avancer automatiquement à la case suivante
    if (digit && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }

    if (newPin.length === 6 && onComplete) {
      onComplete(newPin);
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      if (!digits[index] && index > 0) {
        // La case actuelle est vide, reculer à la case précédente
        e.preventDefault();
        const newDigits = [...digits];
        newDigits[index - 1] = '';
        onChange(newDigits.join(''));
        inputRefs.current[index - 1]?.focus();
      } else {
        // Efface le chiffre actuel
        const newDigits = [...digits];
        newDigits[index] = '';
        onChange(newDigits.join(''));
      }
    } else if (e.key === 'ArrowLeft' && index > 0) {
      e.preventDefault();
      inputRefs.current[index - 1]?.focus();
    } else if (e.key === 'ArrowRight' && index < 5) {
      e.preventDefault();
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pastedText = e.clipboardData.getData('text');
    const pastedDigits = pastedText.replace(/\D/g, '').slice(0, 6);

    if (pastedDigits.length > 0) {
      onChange(pastedDigits);
      const targetIndex = Math.min(pastedDigits.length, 5);
      inputRefs.current[targetIndex]?.focus();

      if (pastedDigits.length === 6 && onComplete) {
        onComplete(pastedDigits);
      }
    }
  };

  return (
    <div className="w-full">
      <div className="flex items-center justify-center gap-1.5 sm:gap-2.5 max-w-full">
        {digits.map((digit, index) => {
          const isFilled = digit.length > 0;
          return (
            <input
              key={index}
              ref={el => { inputRefs.current[index] = el; }}
              id={`${idPrefix}-${index}`}
              type={showDigits ? 'text' : 'password'}
              inputMode="numeric"
              pattern="[0-9]*"
              maxLength={1}
              value={digit}
              disabled={disabled}
              onChange={e => handleInputChange(index, e)}
              onKeyDown={e => handleKeyDown(index, e)}
              onPaste={handlePaste}
              className={`w-10 h-12 sm:w-12 sm:h-14 min-w-0 text-center text-lg sm:text-2xl font-black rounded-xl sm:rounded-2xl border-2 transition-all outline-none select-none ${
                hasError
                  ? 'border-red-400 bg-red-50/50 text-red-600 focus:border-red-500 focus:ring-4 focus:ring-red-100'
                  : isFilled
                  ? 'border-neutral-300 bg-white text-neutral-900 focus:border-[#FF8A00] focus:ring-4 focus:ring-orange-100'
                  : 'border-neutral-200 bg-neutral-50/60 text-neutral-900 hover:border-neutral-300 focus:border-[#FF8A00] focus:bg-white focus:ring-4 focus:ring-orange-100'
              } ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-text'}`}
              aria-label={`Chiffre ${index + 1} du code`}
              autoComplete="off"
            />
          );
        })}
      </div>

      {allowPeek && (
        <div className="flex items-center justify-end mt-2">
          <button
            type="button"
            onClick={() => setShowDigits(!showDigits)}
            className="flex items-center gap-1.5 text-xs text-neutral-500 hover:text-neutral-800 transition-colors py-1 px-2 rounded-lg hover:bg-neutral-100 cursor-pointer"
          >
            {showDigits ? (
              <>
                <EyeOff className="w-3.5 h-3.5 text-neutral-500" />
                <span>Masquer le code</span>
              </>
            ) : (
              <>
                <Eye className="w-3.5 h-3.5 text-neutral-500" />
                <span>Afficher le code</span>
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
};
