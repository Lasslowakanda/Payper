import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PayperSymbolicLoader, PayperLoadingContext, PayperSymbolicSize } from './PayperSymbolicLoader';

export interface SymbolicLoadingScreenProps {
  /** Contexte d'action de la page */
  context?: PayperLoadingContext;
  size?: PayperSymbolicSize;
  title?: string;
  subtitle?: string;
  fullScreen?: boolean;
  className?: string;
  isError?: boolean;
  errorMessage?: string;
}

export const SymbolicLoadingScreen: React.FC<SymbolicLoadingScreenProps> = ({
  context = 'general',
  size = 'lg',
  title,
  subtitle,
  fullScreen = true,
  className = '',
  isError = false,
  errorMessage,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      className={`${
        fullScreen
          ? 'fixed inset-0 z-50 bg-white/95 backdrop-blur-sm flex flex-col items-center justify-center p-6'
          : 'w-full py-12 flex flex-col items-center justify-center p-6 rounded-2xl'
      } select-none ${className}`}
    >
      <div className="relative">
        <PayperSymbolicLoader
          context={context}
          size={size}
          isError={isError}
          errorMessage={errorMessage}
        />
      </div>

      {(title || subtitle) && (
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.25 }}
          className="mt-5 text-center max-w-xs"
        >
          {title && (
            <p className="text-sm font-semibold text-neutral-800 tracking-tight">
              {title}
            </p>
          )}
          {subtitle && (
            <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
              {subtitle}
            </p>
          )}
        </motion.div>
      )}
    </motion.div>
  );
};
