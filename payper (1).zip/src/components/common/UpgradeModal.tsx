import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Zap, Crown, X, ArrowRight, Lock } from 'lucide-react';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGoToPricing: () => void;
  title?: string;
  description?: string;
  requiredPlan?: 'standard' | 'pro';
  isLimitReached?: boolean;
}

export const UpgradeModal: React.FC<UpgradeModalProps> = ({
  isOpen,
  onClose,
  onGoToPricing,
  title = 'Tu as atteint la limite de ton forfait',
  description = 'Passe à Standard ou Pro pour continuer à créer des factures.',
  requiredPlan = 'standard',
  isLimitReached = true,
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop blur */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 10 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="relative w-full max-w-md bg-white rounded-2xl p-6 sm:p-7 shadow-2xl border border-neutral-100 z-10"
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-1.5 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 rounded-lg transition-colors"
              aria-label="Fermer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex flex-col items-center text-center">
              <div className="w-14 h-14 rounded-2xl bg-orange-50 border border-orange-100 flex items-center justify-center text-[#FF8A00] mb-4">
                {isLimitReached ? (
                  <Crown className="w-7 h-7" />
                ) : (
                  <Lock className="w-7 h-7" />
                )}
              </div>

              <h3 className="text-xl font-bold text-[#111827] mb-2 leading-snug">
                {title}
              </h3>

              <p className="text-sm text-neutral-600 mb-6 leading-relaxed">
                {description}
              </p>

              <div className="w-full bg-[#FAFAFA] rounded-xl p-3.5 mb-6 text-left border border-neutral-100">
                <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#FF8A00] mb-2">
                  <Zap className="w-3.5 h-3.5" />
                  Avantages du plan supérieur :
                </div>
                <ul className="text-xs text-neutral-600 space-y-1.5">
                  <li className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00C48C]" />
                    Factures illimitées chaque mois
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00C48C]" />
                    Clients illimités et suivi complet
                  </li>
                  <li className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00C48C]" />
                    Génération d'images HD ultra nettes
                  </li>
                </ul>
              </div>

              <div className="flex flex-col-reverse sm:flex-row items-center gap-2.5 sm:gap-3 w-full">
                <button
                  type="button"
                  onClick={onClose}
                  className="w-full sm:w-1/2 py-2.5 px-4 rounded-xl text-sm font-medium text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 transition-colors text-center cursor-pointer min-h-[44px]"
                >
                  Plus tard
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onGoToPricing();
                  }}
                  className="w-full sm:w-1/2 py-2.5 px-4 rounded-xl text-sm font-semibold text-white bg-[#FF8A00] hover:bg-[#e67c00] transition-colors flex items-center justify-center gap-1.5 shadow-md shadow-orange-500/20 cursor-pointer min-h-[44px]"
                >
                  <span>Voir les abonnements</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
