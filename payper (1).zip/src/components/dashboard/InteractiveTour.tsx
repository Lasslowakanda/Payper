import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ChevronRight,
  ChevronLeft,
  X,
  Layers,
  CheckCircle2,
  FileText,
  TrendingUp,
  Store,
  Compass,
} from 'lucide-react';

export interface TourStep {
  id: string;
  selector: string;
  mobileSelector?: string;
  title: string;
  description: string;
  icon?: React.ReactNode;
  positionPreference?: 'bottom' | 'top' | 'auto';
}

interface InteractiveTourProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete?: () => void;
}

const TOUR_STEPS: TourStep[] = [
  {
    id: 'new_invoice',
    selector: '#tour-new-invoice-btn',
    mobileSelector: '#tour-mobile-invoice-btn',
    title: 'Créer une facture',
    description:
      'Créez des factures professionnelles en quelques clics avec calcul automatique et partage direct sur WhatsApp.',
    icon: <FileText className="w-5 h-5 text-[#FF8A00]" />,
    positionPreference: 'bottom',
  },
  {
    id: 'stats_cards',
    selector: '#tour-stats-cards',
    title: 'Indicateurs en temps réel',
    description:
      'Suivez instantanément vos encaissements reçus, les paiements en attente de règlement et votre quota mensuel.',
    icon: <TrendingUp className="w-5 h-5 text-[#00C48C]" />,
    positionPreference: 'bottom',
  },
  {
    id: 'invoices_section',
    selector: '#tour-invoices-section',
    title: 'Gestion des factures',
    description:
      'Recherchez par client, filtrez les statuts (payé / en attente) et marquez les paiements comme réglés d’un simple clic.',
    icon: <Layers className="w-5 h-5 text-[#FF8A00]" />,
    positionPreference: 'top',
  },
  {
    id: 'bottom_nav',
    selector: '#tour-bottom-nav',
    mobileSelector: '#tour-bottom-nav',
    title: 'Barre de navigation & Boutiques',
    description:
      'Passez facilement d’une boutique à une autre, gérez vos clients et accédez aux paramètres complets de PAYPER.',
    icon: <Store className="w-5 h-5 text-[#FF8A00]" />,
    positionPreference: 'top',
  },
];

export const InteractiveTour: React.FC<InteractiveTourProps> = ({
  isOpen,
  onClose,
  onComplete,
}) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [targetRect, setTargetRect] = useState<DOMRect | null>(null);

  const currentStep = TOUR_STEPS[currentStepIndex];

  // Helper to locate target element in DOM (fallback between selector and mobileSelector)
  const findTargetElement = useCallback((): HTMLElement | null => {
    if (!currentStep) return null;
    const isMobile = window.innerWidth < 1024;
    let el: HTMLElement | null = null;

    if (isMobile && currentStep.mobileSelector) {
      el = document.querySelector(currentStep.mobileSelector);
    }
    if (!el && currentStep.selector) {
      el = document.querySelector(currentStep.selector);
    }
    return el;
  }, [currentStep]);

  // Update position with scrolling & resize tracking
  const updateTargetPosition = useCallback(() => {
    const el = findTargetElement();
    if (el) {
      const rect = el.getBoundingClientRect();
      setTargetRect(rect);
    } else {
      setTargetRect(null);
    }
  }, [findTargetElement]);

  useEffect(() => {
    if (!isOpen) return;

    const el = findTargetElement();
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'nearest' });
      // Short delay after scroll to calculate exact position
      const timer = setTimeout(() => {
        updateTargetPosition();
      }, 350);
      return () => clearTimeout(timer);
    } else {
      updateTargetPosition();
    }
  }, [isOpen, currentStepIndex, findTargetElement, updateTargetPosition]);

  useEffect(() => {
    if (!isOpen) return;

    window.addEventListener('resize', updateTargetPosition);
    window.addEventListener('scroll', updateTargetPosition, true);

    return () => {
      window.removeEventListener('resize', updateTargetPosition);
      window.removeEventListener('scroll', updateTargetPosition, true);
    };
  }, [isOpen, updateTargetPosition]);

  const handleNext = () => {
    if (currentStepIndex < TOUR_STEPS.length - 1) {
      setCurrentStepIndex(prev => prev + 1);
    } else {
      handleFinish();
    }
  };

  const handlePrev = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(prev => prev - 1);
    }
  };

  const handleFinish = () => {
    localStorage.setItem('payper_tour_completed', 'true');
    onClose();
    if (onComplete) onComplete();
  };

  const handleSkip = () => {
    localStorage.setItem('payper_tour_completed', 'true');
    onClose();
  };

  if (!isOpen) return null;

  // Compute popover positioning relative to targetRect
  const popoverStyle = useMemo(() => {
    const pad = 16;
    const windowWidth = typeof window !== 'undefined' ? window.innerWidth : 380;
    const windowHeight = typeof window !== 'undefined' ? window.innerHeight : 700;
    const cardWidth = Math.min(360, windowWidth - 32);

    if (!targetRect) {
      // Centered fallback
      return {
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: `${cardWidth}px`,
      };
    }

    const spaceBelow = windowHeight - targetRect.bottom;
    const spaceAbove = targetRect.top;

    let preferTop = currentStep.positionPreference === 'top';
    if (currentStep.positionPreference === 'auto' || !currentStep.positionPreference) {
      preferTop = spaceBelow < 240 && spaceAbove > 200;
    }

    let top = 0;
    if (preferTop) {
      top = Math.max(pad, targetRect.top - 230);
    } else {
      top = Math.min(windowHeight - 250, targetRect.bottom + 16);
    }

    // Horizontal centering relative to element, clamped within screen
    let left = targetRect.left + targetRect.width / 2 - cardWidth / 2;
    if (left < pad) left = pad;
    if (left + cardWidth > windowWidth - pad) left = windowWidth - cardWidth - pad;

    return {
      top: `${top}px`,
      left: `${left}px`,
      width: `${cardWidth}px`,
    };
  }, [targetRect, currentStep]);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* 1. Backdrop avec découpe SVG (Spotlight Cutout) */}
      <svg
        className="fixed inset-0 w-full h-full pointer-events-auto transition-all"
        style={{ width: '100vw', height: '100vh' }}
      >
        <defs>
          <mask id="tour-spotlight-mask">
            {/* Arrière-plan complet blanc (opaque) */}
            <rect x="0" y="0" width="100%" height="100%" fill="white" />
            {/* Découpe noire transparente sur l'élément cible */}
            {targetRect && (
              <rect
                x={Math.max(0, targetRect.left - 6)}
                y={Math.max(0, targetRect.top - 6)}
                width={targetRect.width + 12}
                height={targetRect.height + 12}
                rx="16"
                ry="16"
                fill="black"
              />
            )}
          </mask>
        </defs>
        <rect
          x="0"
          y="0"
          width="100%"
          height="100%"
          fill="rgba(0, 0, 0, 0.65)"
          mask="url(#tour-spotlight-mask)"
        />
      </svg>

      {/* 2. Cadre lumineux animé entourant l'élément cible */}
      {targetRect && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.25 }}
          className="fixed pointer-events-none rounded-2xl border-2 border-[#FF8A00] shadow-[0_0_25px_rgba(255,138,0,0.5),inset_0_0_15px_rgba(255,138,0,0.2)] animate-pulse"
          style={{
            left: `${Math.max(0, targetRect.left - 6)}px`,
            top: `${Math.max(0, targetRect.top - 6)}px`,
            width: `${targetRect.width + 12}px`,
            height: `${targetRect.height + 12}px`,
          }}
        />
      )}

      {/* 3. Fenêtre explicative flottante (Popover interactive) */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentStep.id}
          initial={{ opacity: 0, y: 15, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -10, scale: 0.96 }}
          transition={{ duration: 0.25 }}
          style={popoverStyle}
          className="fixed z-50 bg-white rounded-2xl p-5 shadow-[0_20px_50px_rgba(0,0,0,0.25),0_4px_16px_rgba(255,138,0,0.12)] border border-neutral-100 flex flex-col pointer-events-auto"
        >
          {/* Header avec badge et bouton fermer */}
          <div className="flex items-center justify-between gap-3 mb-3">
            <div className="flex items-center gap-2">
              <span className="w-7 h-7 rounded-lg bg-orange-50 flex items-center justify-center">
                {currentStep.icon}
              </span>
              <span className="text-[11px] font-bold text-[#FF8A00] uppercase tracking-wider bg-orange-50/80 px-2.5 py-0.5 rounded-full border border-orange-100/60">
                Étape {currentStepIndex + 1} / {TOUR_STEPS.length}
              </span>
            </div>

            <button
              onClick={handleSkip}
              className="text-neutral-400 hover:text-neutral-600 p-1 rounded-md transition-colors cursor-pointer"
              aria-label="Passer le tutoriel"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Titre */}
          <h3 className="text-base font-bold text-[#111827] leading-snug">
            {currentStep.title}
          </h3>

          {/* Description */}
          <p className="text-xs text-neutral-600 mt-1.5 leading-relaxed">
            {currentStep.description}
          </p>

          {/* Barre d'étapes (Dots) */}
          <div className="flex items-center gap-1.5 mt-4 pt-3 border-t border-neutral-100">
            {TOUR_STEPS.map((step, idx) => (
              <div
                key={step.id}
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  idx === currentStepIndex
                    ? 'w-6 bg-[#FF8A00]'
                    : idx < currentStepIndex
                    ? 'w-2 bg-[#00C48C]'
                    : 'w-2 bg-neutral-200'
                }`}
              />
            ))}
          </div>

          {/* Boutons d'action */}
          <div className="flex items-center justify-between gap-2 mt-4">
            {currentStepIndex > 0 ? (
              <button
                onClick={handlePrev}
                className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
                <span>Précédent</span>
              </button>
            ) : (
              <button
                onClick={handleSkip}
                className="text-xs font-semibold text-neutral-400 hover:text-neutral-600 px-2 py-1 transition-colors cursor-pointer"
              >
                Passer
              </button>
            )}

            <button
              onClick={handleNext}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white bg-[#FF8A00] hover:bg-[#e67c00] active:scale-95 transition-all shadow-sm shadow-orange-500/25 cursor-pointer"
            >
              <span>
                {currentStepIndex === TOUR_STEPS.length - 1 ? 'Terminer' : 'Suivant'}
              </span>
              {currentStepIndex === TOUR_STEPS.length - 1 ? (
                <CheckCircle2 className="w-3.5 h-3.5" />
              ) : (
                <ChevronRight className="w-3.5 h-3.5" />
              )}
            </button>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};
