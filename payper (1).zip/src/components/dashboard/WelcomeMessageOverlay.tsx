import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, ShieldCheck } from 'lucide-react';

interface WelcomeMessageOverlayProps {
  onDismiss: () => void;
  durationMs?: number;
}

/**
 * ÉTAPE 8 — ARRIVÉE SUR LE TABLEAU DE BORD
 * Message temporaire de bienvenue au centre de l'écran :
 * « Bienvenue sur PAYPER »
 * « Votre partenaire financier »
 *
 * Caractéristiques :
 * - Apparition progressive
 * - Léger mouvement subtil
 * - Transition douce
 * - Disparition automatique après 3.5 secondes
 * - Ne bloque pas l'interaction de l'utilisateur (pointer-events-none sur le conteneur)
 * - À sa disparition, lance automatiquement le tutoriel interactif
 */
export const WelcomeMessageOverlay: React.FC<WelcomeMessageOverlayProps> = ({
  onDismiss,
  durationMs = 3600,
}) => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false);
    }, durationMs);

    return () => clearTimeout(timer);
  }, [durationMs]);

  const handleExited = () => {
    onDismiss();
  };

  return (
    <AnimatePresence onExitComplete={handleExited}>
      {isVisible && (
        <div className="fixed inset-0 z-50 pointer-events-none flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 24 }}
            animate={{
              opacity: 1,
              scale: 1,
              y: [0, -6, 0],
            }}
            exit={{ opacity: 0, scale: 0.94, y: -20, transition: { duration: 0.5, ease: 'easeInOut' } }}
            transition={{
              duration: 0.6,
              ease: [0.16, 1, 0.3, 1],
              y: {
                repeat: Infinity,
                duration: 4,
                ease: 'easeInOut',
              },
            }}
            className="pointer-events-auto bg-white/95 backdrop-blur-xl border border-neutral-100/90 shadow-[0_20px_60px_-15px_rgba(255,138,0,0.28),0_10px_30px_-10px_rgba(0,0,0,0.12)] rounded-3xl p-6 sm:p-8 max-w-sm w-full text-center relative overflow-hidden"
          >
            {/* Dégradé lumineux d'arrière-plan */}
            <div className="absolute -top-16 -left-16 w-36 h-36 bg-[#FF8A00]/15 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute -bottom-16 -right-16 w-36 h-36 bg-[#00C48C]/15 rounded-full blur-2xl pointer-events-none" />

            {/* Pastille visuelle iconique */}
            <motion.div
              initial={{ scale: 0, rotate: -20 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.15, type: 'spring', damping: 14 }}
              className="w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-tr from-[#FF8A00] to-[#FFA733] text-white flex items-center justify-center shadow-md shadow-orange-500/25"
            >
              <CheckCircle2 className="w-7 h-7" />
            </motion.div>

            {/* Titre principal */}
            <h2 className="text-xl sm:text-2xl font-black text-[#111827] tracking-tight">
              Bienvenue sur PAYPER
            </h2>

            {/* Sous-titre */}
            <p className="text-sm font-semibold text-[#FF8A00] mt-1.5 flex items-center justify-center gap-1.5">
              <span>Votre partenaire financier</span>
            </p>

            <div className="mt-4 pt-3.5 border-t border-neutral-100 flex items-center justify-center gap-2 text-[11px] text-neutral-400">
              <ShieldCheck className="w-3.5 h-3.5 text-[#00C48C]" />
              <span>Votre espace sécurisé est prêt</span>
            </div>

            {/* Barre de progression subtile */}
            <motion.div
              initial={{ width: '100%' }}
              animate={{ width: '0%' }}
              transition={{ duration: durationMs / 1000, ease: 'linear' }}
              className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-[#FF8A00] to-[#00C48C]"
            />
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
