import React from 'react';
import { Invoice } from '../../types';
import { formatCurrency, formatDate } from '../../lib/invoice';
import { PayperLogo } from '../common/PayperLogo';

interface InvoiceCardA4Props {
  invoice: Invoice;
  showPayperWatermark?: boolean;
}

export const InvoiceCardA4: React.FC<InvoiceCardA4Props> = ({
  invoice,
  showPayperWatermark = true,
}) => {
  const items = invoice.items && invoice.items.length > 0
    ? invoice.items
    : [
        {
          id: '1',
          description: invoice.description,
          quantity: 1,
          price: invoice.amount,
          total: invoice.amount,
        },
      ];
  const custom = invoice.customization;
  const primaryColor = custom?.primaryColor || '#FF8A00';
  const isSignatureBorder = custom?.invoiceTemplate === 'signature_border';
  const isRecuSignature =
    custom?.invoiceTemplate === 'recu_signature' ||
    custom?.receiptTemplate === 'recu_signature';
  const logoPosition = custom?.logoPosition || 'left';

  // MODÈLE REÇU AVEC NUMÉRO DU REÇU, MONTANT, POINTILLÉS ET SIGNATURE
  if (isRecuSignature) {
    return (
      <div
        id="facture-a-capturer"
        className="relative bg-white text-[#111827] rounded-2xl border-2 shadow-md p-6 sm:p-10 max-w-[800px] mx-auto w-full overflow-hidden select-text space-y-6"
        style={{
          fontFamily: "'Poppins', sans-serif",
          borderColor: primaryColor,
        }}
      >
        {/* Paid Stamp Watermark */}
        {invoice.isPaid && (
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 flex items-center justify-center overflow-hidden z-10"
          >
            <div className="transform -rotate-12 border-8 border-[#00C48C] text-[#00C48C] font-black tracking-widest text-6xl sm:text-7xl uppercase px-8 py-3 rounded-2xl opacity-15 select-none">
              PAYÉ
            </div>
          </div>
        )}

        {/* En-tête : Boutique & Titre Reçu */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-6 border-b border-neutral-200">
          <div className="flex items-center gap-4">
            {invoice.boutiqueLogo ? (
              <img
                src={invoice.boutiqueLogo}
                alt={invoice.boutiqueName}
                className="w-16 h-16 rounded-2xl object-cover border border-neutral-100 shadow-sm"
                crossOrigin={invoice.boutiqueLogo.startsWith('http') ? 'anonymous' : undefined}
                onError={(e) => {
                  (e.currentTarget as HTMLElement).style.display = 'none';
                }}
              />
            ) : (
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center font-bold text-2xl text-white shadow-sm"
                style={{ backgroundColor: primaryColor }}
              >
                {invoice.boutiqueName.slice(0, 2).toUpperCase()}
              </div>
            )}
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-[#111827] tracking-tight">
                {invoice.boutiqueName}
              </h2>
              <p className="text-xs text-neutral-500 mt-0.5">
                {invoice.boutiqueCity || 'Dakar'}
              </p>
            </div>
          </div>

          <div className="text-left sm:text-right">
            <div
              className="inline-block px-3.5 py-1 rounded-xl text-xs sm:text-sm font-black uppercase tracking-wider text-white shadow-xs"
              style={{ backgroundColor: primaryColor }}
            >
              REÇU N° {invoice.invoice_number || invoice.id || 'RC-2026-001'}
            </div>
            <div className="text-xs text-neutral-500 mt-1.5 font-medium">
              Date : {formatDate(invoice.date || new Date().toISOString())}
            </div>
          </div>
        </div>

        {/* Bloc Montant du reçu */}
        <div
          className="p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between text-white shadow-sm gap-2"
          style={{ backgroundColor: primaryColor }}
        >
          <div>
            <span className="text-xs font-bold uppercase tracking-wider opacity-90 block">
              MONTANT DU REÇU
            </span>
            <span className="text-xs font-medium opacity-90">Règlement validé et certifié</span>
          </div>
          <div className="text-3xl font-black font-mono tracking-tight">
            {formatCurrency(invoice.amount, invoice.devise)}
          </div>
        </div>

        {/* Lignes en pointillés ................................. */}
        <div className="space-y-4 text-xs sm:text-sm text-neutral-800 pt-2 font-mono">
          <div className="flex items-baseline gap-2">
            <span className="font-sans font-bold text-neutral-900 shrink-0">Reçu de M. / Mme :</span>
            <span className="flex-1 border-b-2 border-dotted border-neutral-400 tracking-widest text-neutral-800 font-bold font-sans">
              {invoice.clientName || '................................................................'}
            </span>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="font-sans font-bold text-neutral-900 shrink-0">La somme de :</span>
            <span className="flex-1 border-b-2 border-dotted border-neutral-400 tracking-widest text-neutral-700 italic font-sans">
              {formatCurrency(invoice.amount, invoice.devise)}
            </span>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="font-sans font-bold text-neutral-900 shrink-0">Pour motif / règlement :</span>
            <span className="flex-1 border-b-2 border-dotted border-neutral-400 tracking-widest text-neutral-700 font-sans">
              {invoice.description || '................................................................'}
            </span>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="font-sans font-bold text-neutral-900 shrink-0">Mode de règlement :</span>
            <span className="flex-1 border-b-2 border-dotted border-neutral-400 tracking-widest text-neutral-700 font-sans">
              Paiement validé · Mobile Money / Espèces / Virement
            </span>
          </div>
        </div>

        {/* Détails des articles si disponibles */}
        {items.length > 0 && (
          <div className="pt-2 border-t border-neutral-100">
            <div className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2">
              Détail des prestations / articles
            </div>
            <div className="space-y-1.5 text-xs text-neutral-700">
              {items.map((it, idx) => (
                <div key={idx} className="flex justify-between py-1 border-b border-neutral-100">
                  <span>{it.description || invoice.description} (x{it.quantity || 1})</span>
                  <span className="font-mono font-semibold">{formatCurrency(it.total || it.price, invoice.devise)}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Section Signature */}
        <div className="pt-8 border-t border-neutral-200 grid grid-cols-2 gap-8">
          <div className="text-center">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-12">
              Signature du client
            </span>
            <div className="border-t border-dashed border-neutral-400 pt-1 text-xs text-neutral-400 italic">
              Bon pour accord & décharge
            </div>
          </div>

          <div className="text-center">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-800 block mb-12">
              Signature & Cachet
            </span>
            <div
              className="border-t-2 pt-1 text-xs font-bold"
              style={{ borderColor: primaryColor, color: primaryColor }}
            >
              {invoice.boutiqueName || 'La Direction'}
            </div>
          </div>
        </div>

        {/* Footer Notes & Branding */}
        <div className="pt-4 border-t border-neutral-100 flex items-center justify-between text-xs text-neutral-400">
          <div>{custom?.receiptFooterMessage || custom?.invoiceFooterMessage || 'Merci pour votre confiance !'}</div>
          {showPayperWatermark && (
            <div className="flex items-center gap-2">
              <span className="text-[10px]">Certifié par</span>
              <PayperLogo size="sm" />
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div
      id="facture-a-capturer"
      className="relative bg-white text-[#111827] rounded-2xl border shadow-md p-4 sm:p-10 max-w-[800px] mx-auto w-full overflow-hidden select-text"
      style={{
        fontFamily: "'Poppins', sans-serif",
        borderColor: isSignatureBorder ? primaryColor : undefined,
        borderWidth: isSignatureBorder ? '3px' : undefined,
      }}
    >
      {/* Paid Stamp / Pending Stamp Watermark */}
      {invoice.isPaid ? (
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 flex items-center justify-center overflow-hidden z-10"
        >
          <div className="transform -rotate-12 border-8 border-[#00C48C] text-[#00C48C] font-black tracking-widest text-6xl sm:text-7xl uppercase px-8 py-3 rounded-2xl opacity-15 select-none">
            PAYÉ
          </div>
        </div>
      ) : (
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 flex items-center justify-center overflow-hidden z-10"
        >
          <div
            className="transform -rotate-12 border-4 border-dashed font-black tracking-wider text-3xl sm:text-4xl uppercase px-6 py-2.5 rounded-xl opacity-20 select-none text-center"
            style={{ borderColor: primaryColor, color: primaryColor }}
          >
            EN ATTENTE DE PAIEMENT
          </div>
        </div>
      )}

      {/* Header section: Boutique details & Invoice Header */}
      <div
        className={`flex flex-col gap-6 border-b border-neutral-100 pb-7 ${
          logoPosition === 'center'
            ? 'items-center text-center sm:text-center'
            : logoPosition === 'right'
            ? 'sm:flex-row-reverse justify-between items-start'
            : 'sm:flex-row justify-between items-start'
        }`}
      >
        <div className="flex items-start gap-4">
          {invoice.boutiqueLogo ? (
            <img
              src={invoice.boutiqueLogo}
              alt={invoice.boutiqueName}
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border border-neutral-100 shadow-sm"
              crossOrigin={invoice.boutiqueLogo.startsWith('http') ? 'anonymous' : undefined}
              onError={(e) => {
                (e.currentTarget as HTMLElement).style.display = 'none';
              }}
            />
          ) : (
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-orange-50 border border-orange-100 flex items-center justify-center font-bold text-xl sm:text-2xl text-[#FF8A00]">
              {invoice.boutiqueName.slice(0, 2).toUpperCase()}
            </div>
          )}

          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-[#111827] tracking-tight">
              {invoice.boutiqueName}
            </h2>
            <p className="text-sm text-neutral-500 mt-0.5">
              {invoice.boutiqueCity || 'Dakar, Sénégal'}
            </p>
            <div className="inline-flex items-center gap-1.5 mt-2 px-2.5 py-0.5 rounded-md text-xs font-semibold bg-emerald-50 text-[#00C48C]">
              Facture certifiée
            </div>
          </div>
        </div>

        <div className="text-left sm:text-right">
          <div className="text-xs uppercase font-extrabold tracking-widest text-[#FF8A00]">
            FACTURE
          </div>
          <div className="text-lg sm:text-xl font-bold text-[#111827] font-mono tabular-nums mt-0.5">
            {invoice.id}
          </div>
          <div className="text-xs text-neutral-500 mt-1">
            Date d'émission : <span className="font-medium text-neutral-700">{formatDate(invoice.date || invoice.issue_date || invoice.createdAt)}</span>
          </div>
          {(invoice.dueDate || invoice.due_date) && (
            <div className="text-xs text-neutral-500 mt-0.5">
              Échéance : <span className="font-semibold text-neutral-800">{formatDate(invoice.dueDate || invoice.due_date || '')}</span>
            </div>
          )}
          {invoice.isPaid ? (
            <div className="inline-flex items-center gap-1.5 mt-2 px-2.5 py-1 rounded-md text-xs font-bold bg-[#00C48C]/10 text-[#00C48C]">
              <span>Statut :</span> Payé ✓
            </div>
          ) : (
            <div className="inline-flex items-center gap-1.5 mt-2 px-2.5 py-1 rounded-md text-xs font-bold bg-[#FF8A00]/10 text-[#FF8A00]">
              <span>Statut :</span> En attente ⏳
            </div>
          )}
        </div>
      </div>

      {/* Client Section */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 my-7 p-4 bg-neutral-50/70 rounded-xl border border-neutral-100">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400">
            Facturé à :
          </span>
          <h3 className="text-base font-bold text-[#111827] mt-1">
            {invoice.clientName}
          </h3>
          <p className="text-xs text-neutral-600 mt-0.5">
            Ville : {invoice.clientCity || 'Dakar'}
          </p>
          {invoice.whatsappNumber && (
            <p className="text-xs text-neutral-600 mt-0.5">
              WhatsApp : <span className="font-mono">{invoice.whatsappNumber}</span>
            </p>
          )}
        </div>

        <div className="sm:text-right flex flex-col justify-end">
          <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400">
            Objet de la facture :
          </span>
          <p className="text-sm font-medium text-neutral-800 mt-1">
            {invoice.description}
          </p>
        </div>
      </div>

      {/* Invoice Items Table */}
      <div className="overflow-x-auto my-6">
        <table className="w-full text-left text-sm border-collapse">
          <thead>
            <tr className="border-b border-neutral-200 text-xs font-bold uppercase tracking-wider text-neutral-500">
              <th className="py-3 px-2">Description</th>
              <th className="py-3 px-2 text-center w-20">Qté</th>
              <th className="py-3 px-2 text-right w-32">Prix Unitaire</th>
              <th className="py-3 px-2 text-right w-36">Total</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100 text-neutral-800">
            {items.map((item, idx) => (
              <tr key={item.id || idx} className="hover:bg-neutral-50/50 transition-colors">
                <td className="py-3.5 px-2 font-medium">
                  {item.description || invoice.description}
                </td>
                <td className="py-3.5 px-2 text-center text-neutral-600 font-mono tabular-nums">
                  {item.quantity || 1}
                </td>
                <td className="py-3.5 px-2 text-right text-neutral-600 font-mono tabular-nums">
                  {formatCurrency(item.price || invoice.amount, invoice.devise)}
                </td>
                <td className="py-3.5 px-2 text-right font-bold text-neutral-900 font-mono tabular-nums">
                  {formatCurrency(item.total || invoice.amount, invoice.devise)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Total Box */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mt-6 pt-4 border-t border-neutral-100">
        <div className="text-xs text-neutral-500 max-w-xs space-y-1.5">
          {invoice.notes && (
            <div>
              <span className="font-semibold text-neutral-700">Notes :</span> {invoice.notes}
            </div>
          )}
          {invoice.payment_link && (
            <div className="p-2 rounded-lg bg-orange-50/60 border border-orange-200/60 text-[11px] text-neutral-700">
              <span className="font-bold text-[#FF8A00] block mb-0.5">Lien de paiement du vendeur :</span>
              <span className="font-mono break-all text-neutral-800">{invoice.payment_link}</span>
            </div>
          )}
          {!invoice.notes && !invoice.payment_link && (
            <div>
              Paiement attendu via Mobile Money (Wave, Orange Money, M-Pesa) ou virement bancaire.
            </div>
          )}
        </div>

        <div
          className="w-full sm:w-72 rounded-xl p-4 text-right shadow-sm border"
          style={{
            backgroundColor: `${primaryColor}15`,
            borderColor: `${primaryColor}40`,
          }}
        >
          <div
            className="text-xs font-bold uppercase tracking-wider"
            style={{ color: primaryColor }}
          >
            MONTANT TOTAL À PAYER
          </div>
          <div className="text-2xl sm:text-3xl font-black text-[#111827] mt-1 font-mono tabular-nums">
            {formatCurrency(invoice.amount, invoice.devise)}
          </div>
        </div>
      </div>

      {/* Footer Notes & Branding */}
      <div className="mt-12 pt-6 border-t border-neutral-100 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-400 gap-3">
        <div className="text-center sm:text-left font-medium">
          {custom?.invoiceFooterMessage || 'Merci pour votre confiance ! 🙏'}
        </div>

        {showPayperWatermark && (
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-neutral-400 font-normal">Généré par</span>
            <PayperLogo size="sm" />
          </div>
        )}
      </div>
    </div>
  );
};
