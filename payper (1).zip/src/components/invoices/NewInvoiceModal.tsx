import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Plus, FileText, AlertCircle, Receipt, Crown, Loader2, Sparkles, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Currency, Invoice } from '../../types';
import { CURRENCIES, createNewInvoice } from '../../lib/invoice';
import { getBoutique, getBoutiqueCustomization, saveBoutiqueCustomization, getSubscription } from '../../lib/storage';
import { canCreateInvoice, checkPlanLimits, canAccessStandardFeatures } from '../../lib/subscription';
import { useToast } from '../common/Toast';

interface NewInvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (invoice: Invoice) => void;
  onShowUpgrade: () => void;
  onNavigate?: (path: string) => void;
}

export const NewInvoiceModal: React.FC<NewInvoiceModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  onShowUpgrade,
  onNavigate,
}) => {
  const { showToast } = useToast();
  const boutique = getBoutique();
  const subscription = getSubscription();
  const isPremiumUser = canAccessStandardFeatures(subscription);

  // Deux phases pour abonnés Standard & Pro : Facture ou Reçu
  const [documentType, setDocumentType] = useState<'facture' | 'recu'>('facture');

  const [clientName, setClientName] = useState('');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState<string>('');
  const [devise, setDevise] = useState<Currency>(boutique?.devise || 'FCFA');
  const [clientCity, setClientCity] = useState(boutique?.city || 'Dakar');
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [dueDate, setDueDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toISOString().split('T')[0];
  });
  const [remindersEnabled, setRemindersEnabled] = useState(true);
  const [paymentLink, setPaymentLink] = useState('');
  const [isPaid, setIsPaid] = useState(false);
  const [notes, setNotes] = useState('');
  const [paymentMethodName, setPaymentMethodName] = useState('Mobile Money validé');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const resetForm = () => {
    setClientName('');
    setDescription('');
    setAmount('');
    setDevise(boutique?.devise || 'FCFA');
    setClientCity(boutique?.city || 'Dakar');
    setWhatsappNumber('');
    const d = new Date();
    d.setDate(d.getDate() + 7);
    setDueDate(d.toISOString().split('T')[0]);
    setRemindersEnabled(true);
    setPaymentLink('');
    setIsPaid(false);
    setNotes('');
    setPaymentMethodName('Mobile Money validé');
    setErrorMsg('');
  };

  const handleDocumentTypeChange = (type: 'facture' | 'recu') => {
    if (!isPremiumUser && type === 'recu') {
      onShowUpgrade();
      return;
    }
    setDocumentType(type);
    if (type === 'recu') {
      setIsPaid(true); // Un reçu atteste toujours d'un paiement effectué
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    // Check plan limits
    if (!canCreateInvoice()) {
      onClose();
      onShowUpgrade();
      return;
    }

    if (!clientName.trim()) {
      setErrorMsg('Veuillez renseigner le nom du client.');
      return;
    }

    if (!description.trim()) {
      setErrorMsg(
        documentType === 'recu'
          ? 'Veuillez renseigner le motif du règlement.'
          : 'Veuillez renseigner une description des produits ou services.'
      );
      return;
    }

    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      setErrorMsg('Veuillez renseigner un montant valide.');
      return;
    }

    setIsLoading(true);

    // Simulate realistic processing with button loading animation
    setTimeout(() => {
      try {
        // Enregistrer la préférence de modèle pour cette boutique si Reçu sélectionné
        if (boutique?.id && documentType === 'recu') {
          const currentCustom = getBoutiqueCustomization(boutique.id);
          saveBoutiqueCustomization(boutique.id, {
            ...currentCustom,
            invoiceTemplate: 'recu_signature',
            receiptTemplate: 'recu_signature',
          });
        }

        const created = createNewInvoice({
          clientName,
          clientCity,
          description: documentType === 'recu' ? description : description,
          amount: numericAmount,
          devise,
          isPaid: documentType === 'recu' ? true : isPaid,
          whatsappNumber,
          dueDate,
          reminders_enabled: remindersEnabled,
          payment_link: paymentLink,
          notes: documentType === 'recu' ? `Règlement : ${paymentMethodName}. ${notes}`.trim() : notes,
        });

        // Trigger celebratory confetti
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#FF8A00', '#00C48C', '#ffffff', '#FFD166'],
        });

        const docLabel = documentType === 'recu' ? 'Reçu officiel généré' : 'Facture générée';
        showToast(`${docLabel} avec succès !`, 'success');

        const status = checkPlanLimits();
        if (status.invoicesLimit !== 'unlimited' && typeof status.remainingInvoices === 'number') {
          if (status.remainingInvoices <= 2 && status.remainingInvoices > 0) {
            setTimeout(() => {
              showToast(`Il te reste ${status.remainingInvoices} document(s) ce mois-ci.`, 'info');
            }, 1200);
          }
        }

        setIsLoading(false);
        resetForm();
        onClose();

        // Si l'utilisateur est abonné Standard ou Pro, rediriger sur la page de personnalisation
        if (isPremiumUser && onNavigate) {
          onNavigate('/customization');
        } else {
          onSuccess(created);
        }
      } catch (err) {
        console.error(err);
        setErrorMsg('Une erreur est survenue lors de la création du document.');
        setIsLoading(false);
      }
    }, 850);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
          {/* Overlay with blur */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm"
          />

          {/* Modal Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 12 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.94, y: 12 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="relative w-full max-w-[620px] bg-white rounded-3xl p-4 sm:p-8 shadow-2xl border border-neutral-100 z-10 my-4 sm:my-8 max-h-[92vh] overflow-y-auto flex flex-col"
          >
            {/* Close button */}
            <button
              onClick={onClose}
              disabled={isLoading}
              className="absolute top-5 right-5 p-1.5 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 rounded-lg transition-colors cursor-pointer"
              aria-label="Fermer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header Title & Subtitle */}
            <div className="flex items-center gap-3 mb-5 shrink-0">
              <div className="w-10 h-10 rounded-xl bg-orange-50 border border-orange-100 flex items-center justify-center text-[#FF8A00]">
                {documentType === 'recu' ? <Receipt className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
              </div>
              <div>
                <h2 className="text-xl font-bold text-[#111827]">
                  {documentType === 'recu' ? 'Nouveau reçu officiel' : 'Nouvelle facture'}
                </h2>
                <p className="text-xs text-neutral-500">
                  {documentType === 'recu'
                    ? 'Reçu avec numéro, montant certifié, pointillés et signature'
                    : 'Remplis les détails pour générer l\'image de facture professionnelle'}
                </p>
              </div>
            </div>

            {/* DEUX PHASES : FACTURE OU REÇU (Pour abonnés Standard & Pro) */}
            <div className="mb-5 shrink-0">
              <div className="p-1 bg-neutral-100 rounded-2xl flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => handleDocumentTypeChange('facture')}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    documentType === 'facture'
                      ? 'bg-white text-[#111827] shadow-xs'
                      : 'text-neutral-500 hover:text-neutral-800'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Phase 1 : Facture</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleDocumentTypeChange('recu')}
                  className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer relative ${
                    documentType === 'recu'
                      ? 'bg-[#00C48C] text-white shadow-xs'
                      : 'text-neutral-500 hover:text-neutral-800'
                  }`}
                >
                  <Receipt className="w-3.5 h-3.5" />
                  <span>Phase 2 : Reçu</span>
                  {!isPremiumUser && (
                    <span className="text-[9px] bg-orange-500 text-white px-1.5 py-0.2 rounded-full uppercase font-black">
                      Standard
                    </span>
                  )}
                </button>
              </div>

              {documentType === 'recu' && (
                <div className="mt-2.5 p-2.5 rounded-xl bg-emerald-50 border border-emerald-200/80 text-[11px] text-emerald-900 flex items-center gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-[#00C48C] shrink-0" />
                  <span>
                    <strong>Modèle Reçu activé :</strong> Numéro officiel, montant mis en valeur, pointillés <code>.......</code> et signature/cachet certifié.
                  </span>
                </div>
              )}
            </div>

            {errorMsg && (
              <div className="flex items-center gap-2 p-3 mb-4 rounded-xl bg-red-50 text-red-600 text-xs border border-red-100 shrink-0">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4 flex-1">
              {/* Client Name & City */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                    {documentType === 'recu' ? 'Reçu de M. / Mme *' : 'Nom du client *'}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Aïssatou Diallo"
                    value={clientName}
                    onChange={e => setClientName(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3.5 py-2.5 text-sm text-neutral-900 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-shadow"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                    Ville ou Localité
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: Dakar, Abidjan, Cotonou..."
                    value={clientCity}
                    onChange={e => setClientCity(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3.5 py-2.5 text-sm text-neutral-900 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-shadow"
                  />
                </div>
              </div>

              {/* Description / Motif */}
              <div>
                <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                  {documentType === 'recu' ? 'Pour motif / règlement de *' : 'Description des produits ou prestations *'}
                </label>
                <textarea
                  required
                  rows={2}
                  placeholder={
                    documentType === 'recu'
                      ? 'Ex: Règlement commande tissus Bazin Riche, confection robe & livraison'
                      : 'Ex: Confection costume traditionnel, 2 robes wax sur mesure et livraison express'
                  }
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3.5 py-2.5 text-sm text-neutral-900 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-shadow resize-none"
                />
              </div>

              {/* Amount & Currency */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                    {documentType === 'recu' ? 'Montant réglé *' : 'Montant total *'}
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    min="1"
                    placeholder="Ex: 50000"
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3.5 py-2.5 text-sm text-neutral-900 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-shadow font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                    Devise
                  </label>
                  <select
                    value={devise}
                    onChange={e => setDevise(e.target.value as Currency)}
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3.5 py-2.5 text-sm text-neutral-900 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-shadow cursor-pointer"
                  >
                    {CURRENCIES.map(curr => (
                      <option key={curr.code} value={curr.code}>
                        {curr.code} - {curr.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Specific fields for Reçu vs Facture */}
              {documentType === 'recu' ? (
                <div>
                  <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                    Mode de règlement validé
                  </label>
                  <select
                    value={paymentMethodName}
                    onChange={e => setPaymentMethodName(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3.5 py-2.5 text-sm text-neutral-900 focus:outline-none focus:ring-2 focus:ring-[#00C48C] transition-shadow cursor-pointer"
                  >
                    <option value="Wave validé">Wave validé</option>
                    <option value="Orange Money validé">Orange Money validé</option>
                    <option value="MTN MoMo validé">MTN MoMo validé</option>
                    <option value="Moov Money validé">Moov Money validé</option>
                    <option value="Règlement Espèces">Règlement en Espèces</option>
                    <option value="Virement Bancaire">Virement Bancaire</option>
                  </select>
                  <p className="text-[11px] text-neutral-400 mt-1">
                    Ce mode sera imprimé sur la ligne pointillée correspondante du reçu.
                  </p>
                </div>
              ) : (
                /* Facture fields: WhatsApp & Due Date */
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                      WhatsApp du client
                    </label>
                    <input
                      type="tel"
                      placeholder="Ex: +221 77 123 45 67"
                      value={whatsappNumber}
                      onChange={e => setWhatsappNumber(e.target.value)}
                      className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3.5 py-2.5 text-sm text-neutral-900 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-shadow"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                      Date d'échéance
                    </label>
                    <input
                      type="date"
                      value={dueDate}
                      onChange={e => setDueDate(e.target.value)}
                      className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3.5 py-2.5 text-sm text-neutral-900 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-shadow cursor-pointer"
                    />
                  </div>
                </div>
              )}

              {/* Payment Status (Hidden or auto-checked for Reçu) */}
              {documentType === 'facture' && (
                <div className="pt-1">
                  <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-2">
                    Statut de règlement
                  </label>
                  <div
                    onClick={() => setIsPaid(!isPaid)}
                    className={`cursor-pointer flex items-center justify-between p-3.5 rounded-xl border transition-all ${
                      isPaid
                        ? 'bg-emerald-50/60 border-emerald-300 text-[#00C48C]'
                        : 'bg-orange-50/60 border-orange-200 text-[#FF8A00]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                          isPaid ? 'bg-[#00C48C] text-white' : 'bg-[#FF8A00] text-white'
                        }`}
                      >
                        {isPaid ? '✓' : '⏳'}
                      </div>
                      <div>
                        <div className="text-sm font-bold text-neutral-900">
                          {isPaid ? 'Payé ✓' : 'En attente ⏳'}
                        </div>
                        <div className="text-xs text-neutral-500">
                          {isPaid ? 'Le client a déjà réglé la facture' : 'Le paiement est en attente'}
                        </div>
                      </div>
                    </div>

                    <div
                      className={`w-12 h-6 flex items-center rounded-full p-1 duration-300 cursor-pointer ${
                        isPaid ? 'bg-[#00C48C]' : 'bg-neutral-300'
                      }`}
                    >
                      <div
                        className={`bg-white w-4 h-4 rounded-full shadow-md transform duration-300 ${
                          isPaid ? 'translate-x-6' : 'translate-x-0'
                        }`}
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* IMMOBILE / STICKY ACTION BUTTON AT THE BOTTOM */}
              <div className="sticky bottom-0 bg-white/95 backdrop-blur-md pt-4 pb-2 border-t border-neutral-100 z-20 flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 sm:gap-3 -mx-4 sm:-mx-8 -mb-4 sm:-mb-8 px-4 sm:px-8 mt-6">
                <button
                  type="button"
                  onClick={onClose}
                  disabled={isLoading}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl text-sm font-medium text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 transition-colors text-center cursor-pointer min-h-[44px]"
                >
                  Annuler
                </button>

                <button
                  type="submit"
                  disabled={isLoading}
                  className={`w-full sm:w-auto px-6 py-3 sm:py-2.5 rounded-xl text-sm font-bold text-white transition-all flex items-center justify-center gap-2 shadow-md active:scale-[0.98] disabled:opacity-75 sm:min-w-[190px] min-h-[44px] cursor-pointer ${
                    documentType === 'recu'
                      ? 'bg-[#00C48C] hover:bg-[#00b07d] shadow-emerald-500/25'
                      : 'bg-[#FF8A00] hover:bg-[#e67c00] shadow-orange-500/25'
                  }`}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin shrink-0 text-white" />
                      <span>{documentType === 'recu' ? 'Génération du reçu...' : 'Génération de la facture...'}</span>
                    </>
                  ) : (
                    <>
                      {documentType === 'recu' ? <Receipt className="w-4 h-4" /> : <FileText className="w-4 h-4" />}
                      <span>{documentType === 'recu' ? 'Générer le reçu' : 'Générer la facture'}</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
