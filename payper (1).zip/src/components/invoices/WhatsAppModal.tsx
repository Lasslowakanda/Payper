import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Send, Download, Phone, CheckCircle2, Share2, Info } from 'lucide-react';
import { Invoice } from '../../types';
import { COUNTRY_CODES, buildWhatsAppUrl, generateWhatsAppMessage } from '../../lib/share';
import { updateInvoice } from '../../lib/storage';
import { useToast } from '../common/Toast';
import { PayperLoader } from '../payper-loader';

interface WhatsAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice;
  onDownloadImage?: () => Promise<void>;
}

export const WhatsAppModal: React.FC<WhatsAppModalProps> = ({
  isOpen,
  onClose,
  invoice,
  onDownloadImage,
}) => {
  const { showToast } = useToast();
  const [selectedCountryCode, setSelectedCountryCode] = useState('+221');
  const [phoneDigits, setPhoneDigits] = useState(() => {
    if (!invoice.whatsappNumber) return '';
    // if number starts with country code like +221, extract rest
    const match = invoice.whatsappNumber.match(/^\+(\d{1,4})(.*)$/);
    if (match) {
      return match[2].trim();
    }
    return invoice.whatsappNumber.replace(/[^0-9]/g, '');
  });

  const [isProcessing, setIsProcessing] = useState(false);
  const [imageDownloaded, setImageDownloaded] = useState(false);

  const previewMessage = generateWhatsAppMessage(invoice);

  const handleSendWhatsApp = async () => {
    setIsProcessing(true);
    const fullPhoneNumber = phoneDigits.trim()
      ? `${selectedCountryCode}${phoneDigits.replace(/\s+/g, '')}`
      : invoice.whatsappNumber || '';

    // Save updated phone to invoice
    if (fullPhoneNumber && fullPhoneNumber !== invoice.whatsappNumber) {
      const updated = { ...invoice, whatsappNumber: fullPhoneNumber };
      updateInvoice(updated);
    }

    try {
      // Step 1: If an image downloader is provided and hasn't run yet, download image
      if (onDownloadImage && !imageDownloaded) {
        await onDownloadImage();
        setImageDownloaded(true);
        showToast('Image de facture générée et téléchargée !', 'success');
      }

      // Step 2: Open WhatsApp
      const waUrl = buildWhatsAppUrl(fullPhoneNumber, previewMessage);
      window.open(waUrl, '_blank', 'noopener,noreferrer');
      showToast('WhatsApp ouvert !', 'success');
      onClose();
    } catch (e) {
      console.error(e);
      const waUrl = buildWhatsAppUrl(fullPhoneNumber, previewMessage);
      window.open(waUrl, '_blank', 'noopener,noreferrer');
      onClose();
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="relative w-full max-w-lg bg-white rounded-2xl p-6 sm:p-7 shadow-2xl border border-neutral-100 z-10"
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-1.5 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-5">
              <div className="w-12 h-12 rounded-xl bg-[#25D366]/10 flex items-center justify-center text-[#25D366]">
                <Send className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-[#111827]">
                  Envoyer la facture à {invoice.clientName}
                </h3>
                <p className="text-xs text-neutral-500">
                  Partage instantané par WhatsApp avec message et image
                </p>
              </div>
            </div>

            {/* Step guidance banner */}
            <div className="bg-emerald-50/70 border border-emerald-200/60 rounded-xl p-3.5 mb-5 text-xs text-emerald-900 flex items-start gap-2.5">
              <Info className="w-4 h-4 text-[#00C48C] shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold">Astuce d'envoi Payper :</span> L'image haute qualité sera téléchargée sur votre appareil pour que vous puissiez l'ajouter dans la discussion WhatsApp en 1 clic !
              </div>
            </div>

            {/* Country and Phone input */}
            <div className="mb-4">
              <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                Numéro WhatsApp du destinataire
              </label>
              <div className="flex gap-2">
                <select
                  value={selectedCountryCode}
                  onChange={e => setSelectedCountryCode(e.target.value)}
                  className="bg-neutral-50 border border-neutral-200 rounded-xl px-3 py-2.5 text-sm font-medium text-neutral-800 focus:outline-none focus:ring-2 focus:ring-[#00C48C] min-h-[44px] cursor-pointer shrink-0"
                >
                  {COUNTRY_CODES.map(c => (
                    <option key={c.country} value={c.code}>
                      {c.flag} {c.code}
                    </option>
                  ))}
                </select>
                <div className="relative flex-1 min-w-0">
                  <Phone className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
                  <input
                    type="tel"
                    inputMode="tel"
                    placeholder="77 123 45 67"
                    value={phoneDigits}
                    onChange={e => setPhoneDigits(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl pl-9 pr-3 py-2.5 text-sm text-neutral-900 focus:outline-none focus:ring-2 focus:ring-[#00C48C] min-h-[44px]"
                  />
                </div>
              </div>
            </div>

            {/* Message Preview */}
            <div className="mb-6">
              <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                Aperçu du message
              </label>
              <div className="bg-[#EFEAE2]/60 p-3.5 rounded-xl border border-neutral-200 text-xs text-neutral-800 font-sans leading-relaxed">
                <div className="bg-white p-3 rounded-lg shadow-xs text-neutral-800 border-l-4 border-[#25D366]">
                  {previewMessage}
                </div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex flex-col-reverse sm:flex-row gap-2.5 sm:gap-3">
              <button
                type="button"
                onClick={onClose}
                className="w-full sm:w-1/3 py-2.5 px-4 rounded-xl text-sm font-medium text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 transition-colors text-center cursor-pointer min-h-[44px]"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={handleSendWhatsApp}
                disabled={isProcessing}
                className="w-full sm:w-2/3 py-2.5 px-4 rounded-xl text-sm font-semibold text-white bg-[#25D366] hover:bg-[#20ba5a] transition-all flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20 active:scale-[0.98] sm:min-w-[170px] min-h-[44px] cursor-pointer"
              >
                {isProcessing ? (
                  <PayperLoader
                    variant="whatsapp"
                    size="sm"
                    theme="button"
                    inline={true}
                    text="Préparation..."
                  />
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Ouvrir WhatsApp</span>
                  </>
                )}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
