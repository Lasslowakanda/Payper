import React, { useState, useEffect, createContext, useContext } from 'react';
import { Menu, Plus, Crown } from 'lucide-react';
import { Sidebar } from './Sidebar';
import { getBoutique, getSubscription } from '../../lib/storage';
import { Boutique, Invoice, Subscription } from '../../types';
import { NewInvoiceModal } from '../invoices/NewInvoiceModal';
import { UpgradeModal } from '../common/UpgradeModal';
import { PayperLogo } from '../common/PayperLogo';
import { NotificationBell } from '../common/NotificationBell';
import { GreenGlowButton } from '../common/GreenGlowButton';
import { BottomNavigation } from './BottomNavigation';

interface LayoutActionContextType {
  openNewInvoice: () => void;
  openUpgradeModal: () => void;
}

const LayoutActionContext = createContext<LayoutActionContextType>({
  openNewInvoice: () => {},
  openUpgradeModal: () => {},
});

export const useLayoutActions = () => useContext(LayoutActionContext);

interface AppLayoutProps {
  children: React.ReactNode;
  currentPath: string;
  onNavigate: (path: string) => void;
  onInvoiceCreated?: (invoice: Invoice) => void;
}

const getPageTitle = (path: string): string => {
  if (path === '/dashboard') return 'Tableau de bord';
  if (path === '/analytics') return 'Analytics';
  if (path === '/clients') return 'Clients';
  if (path === '/factures' || path === '/invoices') return 'Factures';
  if (path === '/boutiques') return 'Boutiques';
  if (path === '/automations') return 'Automatisations';
  if (path === '/settings') return 'Paramètres';
  if (path === '/pricing') return 'Abonnement';
  if (path.startsWith('/invoice/')) return 'Facture';
  return 'Tableau de bord';
};

export const AppLayout: React.FC<AppLayoutProps> = ({
  children,
  currentPath,
  onNavigate,
  onInvoiceCreated,
}) => {
  const [boutique, setBoutique] = useState<Boutique | null>(getBoutique());
  const [subscription, setSubscription] = useState<Subscription>(getSubscription());
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [isNewInvoiceOpen, setIsNewInvoiceOpen] = useState(false);
  const [isUpgradeModalOpen, setIsUpgradeModalOpen] = useState(false);

  useEffect(() => {
    const handleBoutiqueChange = () => setBoutique(getBoutique());
    const handleSubChange = () => setSubscription(getSubscription());

    window.addEventListener('payper_boutique_updated', handleBoutiqueChange);
    window.addEventListener('payper_subscription_updated', handleSubChange);

    return () => {
      window.removeEventListener('payper_boutique_updated', handleBoutiqueChange);
      window.removeEventListener('payper_subscription_updated', handleSubChange);
    };
  }, []);

  const handleCreated = (inv: Invoice) => {
    if (onInvoiceCreated) {
      onInvoiceCreated(inv);
    } else {
      onNavigate(`/invoice/${inv.id}`);
    }
  };

  const contextValue = {
    openNewInvoice: () => setIsNewInvoiceOpen(true),
    openUpgradeModal: () => setIsUpgradeModalOpen(true),
  };

  return (
    <LayoutActionContext.Provider value={contextValue}>
      <div className="min-h-screen bg-[#FAFAFA] flex flex-col antialiased text-[#111827]">
        {/* Mobile Top Header (Fixé en permanence en haut, 100% immobile au défilement) */}
        <header
          className="lg:hidden fixed top-0 inset-x-0 z-40 bg-white/95 backdrop-blur-md border-b border-neutral-200/90 px-4 flex items-center justify-between h-14 select-none shadow-xs"
          style={{
            top: 0,
            paddingTop: 'env(safe-area-inset-top, 0px)',
          }}
        >
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              onClick={() => setIsMobileOpen(true)}
              className="p-1.5 text-neutral-600 hover:text-neutral-900 rounded-lg hover:bg-neutral-100 cursor-pointer"
              aria-label="Ouvrir le menu"
            >
              <Menu className="w-6 h-6" />
            </button>
            <div onClick={() => onNavigate('/dashboard')} className="cursor-pointer">
              <PayperLogo size="sm" />
            </div>
          </div>

          {/* Titre de la page au centre (aucun chevauchement) */}
          <div className="absolute left-1/2 -translate-x-1/2 text-xs sm:text-sm font-bold text-neutral-800 pointer-events-none truncate max-w-[130px] sm:max-w-[180px] text-center">
            {getPageTitle(currentPath)}
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <NotificationBell onNavigate={onNavigate} />
            <GreenGlowButton
              id="tour-mobile-invoice-btn"
              size="sm"
              onClick={() => setIsNewInvoiceOpen(true)}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Facture</span>
            </GreenGlowButton>
          </div>
        </header>

        {/* Sidebar (Desktop fixed & Mobile Drawer) */}
        <Sidebar
          currentPath={currentPath}
          onNavigate={onNavigate}
          boutique={boutique}
          subscription={subscription}
          isOpenMobile={isMobileOpen}
          onCloseMobile={() => setIsMobileOpen(false)}
          onOpenNewInvoice={() => setIsNewInvoiceOpen(true)}
        />

        {/* Main Content Area (commence exactement sous le header fixe sans chevauchement) */}
        <main className="flex-1 lg:pl-[260px] flex flex-col min-h-screen pt-14 lg:pt-0 overflow-x-clip">
          {/* Top desktop fixed/sticky header */}
          <div className="hidden lg:flex items-center justify-between px-8 py-3.5 bg-white/95 backdrop-blur-md border-b border-neutral-200/80 sticky top-0 z-30">
            <div className="flex items-center gap-2 text-xs text-neutral-500 font-medium">
              <button
                onClick={() => onNavigate('/boutiques')}
                className="hover:text-[#FF8A00] transition-colors flex items-center gap-1.5 font-bold text-neutral-800 cursor-pointer py-1 px-2 rounded-lg hover:bg-neutral-100"
                title="Gérer et changer de boutique"
              >
                <span>🏪</span>
                <span>{boutique?.name || 'Ma Boutique'}</span>
              </button>
              <span className="text-neutral-300">/</span>
              <span className="text-neutral-800 capitalize font-semibold">
                {currentPath === '/boutiques'
                  ? 'Boutiques'
                  : currentPath.replace('/', '') || 'Dashboard'}
              </span>
            </div>

            {/* Current page title in the middle of desktop header */}
            <div className="absolute left-1/2 -translate-x-1/2 text-sm font-bold text-neutral-800 pointer-events-none">
              {getPageTitle(currentPath)}
            </div>

            <div className="flex items-center gap-3">
              {(subscription.plan === 'free' || subscription.status !== 'active') && (
                <button
                  onClick={() => onNavigate('/pricing')}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-orange-50 text-[#FF8A00] hover:bg-orange-100 transition-colors cursor-pointer"
                >
                  <Crown className="w-3.5 h-3.5" />
                  <span>Passer en Standard ou Pro</span>
                </button>
              )}
              <NotificationBell onNavigate={onNavigate} />
              <GreenGlowButton
                id="tour-new-invoice-btn"
                size="md"
                onClick={() => setIsNewInvoiceOpen(true)}
              >
                <Plus className="w-4 h-4" />
                <span>+ Nouvelle facture</span>
              </GreenGlowButton>
            </div>
          </div>

          <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto pb-28 lg:pb-8">
            {children}
          </div>
        </main>

        {/* Fixed Mobile Bottom Navigation (Hidden on desktop) */}
        <BottomNavigation
          currentPath={currentPath}
          onNavigate={onNavigate}
          onOpenNewInvoice={() => setIsNewInvoiceOpen(true)}
        />

        {/* Modals */}
        <NewInvoiceModal
          isOpen={isNewInvoiceOpen}
          onClose={() => setIsNewInvoiceOpen(false)}
          onSuccess={handleCreated}
          onShowUpgrade={() => setIsUpgradeModalOpen(true)}
          onNavigate={onNavigate}
        />

        <UpgradeModal
          isOpen={isUpgradeModalOpen}
          onClose={() => setIsUpgradeModalOpen(false)}
          onGoToPricing={() => onNavigate('/pricing')}
        />
      </div>
    </LayoutActionContext.Provider>
  );
};

