import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  LayoutDashboard,
  FileText,
  Plus,
  Users,
  Menu,
  Crown,
  Settings,
  HelpCircle,
  X,
  ExternalLink,
  ChevronRight,
  Store,
  Zap,
  BarChart3,
  Palette,
} from 'lucide-react';

export interface BottomNavigationProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  onOpenNewInvoice: () => void;
}

/**
 * BottomNavigation Component
 * Barre de navigation inférieure flottante en forme de capsule allongée (pill shape).
 * Fond ORANGE vif (#FF8A00) permanent, icônes et textes blancs,
 * indicateur d'onglet actif arrondi légèrement plus foncé avec animation fluide.
 */
export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  currentPath,
  onNavigate,
  onOpenNewInvoice,
}) => {
  const [isMoreMenuOpen, setIsMoreMenuOpen] = useState(false);

  const isMoreActive =
    isMoreMenuOpen ||
    currentPath === '/pricing' ||
    currentPath === '/settings' ||
    currentPath === '/clients' ||
    currentPath === '/automations' ||
    currentPath === '/analytics';

  const navItems = [
    {
      id: 'dashboard',
      label: 'Accueil',
      path: '/dashboard',
      icon: LayoutDashboard,
      isActive: currentPath === '/dashboard',
      onClick: () => {
        setIsMoreMenuOpen(false);
        onNavigate('/dashboard');
      },
    },
    {
      id: 'invoices',
      label: 'Factures',
      path: '/invoices',
      icon: FileText,
      isActive: currentPath === '/invoices' || currentPath.startsWith('/invoice/'),
      onClick: () => {
        setIsMoreMenuOpen(false);
        onNavigate('/invoices');
      },
    },
    {
      id: 'create',
      label: 'Créer',
      path: '',
      icon: Plus,
      isActive: false,
      onClick: () => {
        setIsMoreMenuOpen(false);
        onOpenNewInvoice();
      },
    },
    {
      id: 'boutiques',
      label: 'Boutiques',
      path: '/boutiques',
      icon: Store,
      isActive: currentPath === '/boutiques',
      onClick: () => {
        setIsMoreMenuOpen(false);
        onNavigate('/boutiques');
      },
    },
    {
      id: 'more',
      label: 'Plus',
      path: '',
      icon: Menu,
      isActive: isMoreActive,
      onClick: () => {
        setIsMoreMenuOpen((prev) => !prev);
      },
    },
  ];

  const handleContactSupport = () => {
    const waUrl =
      'https://wa.me/221770000000?text=' +
      encodeURIComponent('Bonjour support Payper, j’ai une question.');
    window.open(waUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <>
      {/* 1. Bottom Sheet for "Plus" */}
      <AnimatePresence>
        {isMoreMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex flex-col justify-end">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMoreMenuOpen(false)}
              className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            />

            {/* Bottom Sheet Menu */}
            <motion.div
              initial={{ opacity: 0, y: 120 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 120 }}
              transition={{ type: 'spring', damping: 26, stiffness: 320 }}
              className="relative z-10 bg-white rounded-t-3xl p-5 pb-8 shadow-2xl border-t border-neutral-100 max-h-[85vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between pb-3 border-b border-neutral-100 mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-[#FF8A00]" />
                  <div className="w-2.5 h-2.5 rounded-full bg-[#00C48C] -ml-1" />
                  <span className="font-bold text-sm text-[#111827]">Menu</span>
                </div>
                <button
                  onClick={() => setIsMoreMenuOpen(false)}
                  className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg cursor-pointer"
                  aria-label="Fermer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-1.5">
                <button
                  onClick={() => {
                    setIsMoreMenuOpen(false);
                    onNavigate('/analytics');
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-neutral-50 transition-colors text-left cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-50 text-[#00C48C] flex items-center justify-center">
                      <BarChart3 className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[#111827]">📊 Analytics</div>
                      <div className="text-[11px] text-neutral-400">
                        Statistiques, CA, impayés & graphiques
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-neutral-400" />
                </button>

                <button
                  onClick={() => {
                    setIsMoreMenuOpen(false);
                    onNavigate('/clients');
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-neutral-50 transition-colors text-left cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                      <Users className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[#111827]">Clients</div>
                      <div className="text-[11px] text-neutral-400">
                        Répertoire & historique des clients
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-neutral-400" />
                </button>

                <button
                  onClick={() => {
                    setIsMoreMenuOpen(false);
                    onNavigate('/automations');
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-neutral-50 transition-colors text-left cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-amber-50 text-[#FF8A00] flex items-center justify-center">
                      <Zap className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[#111827]">Automatisations</div>
                      <div className="text-[11px] text-neutral-400">
                        Relances J+1/3/7 & Factures récurrentes
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-neutral-400" />
                </button>

                <button
                  onClick={() => {
                    setIsMoreMenuOpen(false);
                    onNavigate('/boutiques');
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-neutral-50 transition-colors text-left cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-orange-50 text-[#FF8A00] flex items-center justify-center">
                      <Store className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[#111827]">Boutiques</div>
                      <div className="text-[11px] text-neutral-400">
                        Changer de boutique, ouvrir & gérer
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-neutral-400" />
                </button>

                <button
                  onClick={() => {
                    setIsMoreMenuOpen(false);
                    onNavigate('/invoices');
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-neutral-50 transition-colors text-left cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-orange-50 text-[#FF8A00] flex items-center justify-center">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[#111827]">Factures</div>
                      <div className="text-[11px] text-neutral-400">
                        Historique, téléchargements & statuts
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-neutral-400" />
                </button>

                <button
                  onClick={() => {
                    setIsMoreMenuOpen(false);
                    onNavigate('/customization');
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-neutral-50 transition-colors text-left cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-50 text-[#00C48C] flex items-center justify-center">
                      <Palette className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[#111827]">Personnalisation</div>
                      <div className="text-[11px] text-neutral-400">
                        Modèles, couleurs, logos des reçus & factures
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-neutral-400" />
                </button>

                <button
                  onClick={() => {
                    setIsMoreMenuOpen(false);
                    onNavigate('/pricing');
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-neutral-50 transition-colors text-left cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
                      <Crown className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[#111827]">Abonnement</div>
                      <div className="text-[11px] text-neutral-400">
                        Forfaits Gratuit, Standard & Pro
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-neutral-400" />
                </button>

                <button
                  onClick={() => {
                    setIsMoreMenuOpen(false);
                    onNavigate('/settings');
                  }}
                  className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-neutral-50 transition-colors text-left cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-neutral-100 text-neutral-700 flex items-center justify-center">
                      <Settings className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[#111827]">Paramètres</div>
                      <div className="text-[11px] text-neutral-400">
                        Boutique, devise, logo & sauvegarde
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-neutral-400" />
                </button>

                <button
                  onClick={handleContactSupport}
                  className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-emerald-50/60 transition-colors text-left cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-50 text-[#00C48C] flex items-center justify-center">
                      <HelpCircle className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-[#111827]">Aide & Support</div>
                      <div className="text-[11px] text-neutral-400">
                        Assistance rapide par WhatsApp
                      </div>
                    </div>
                  </div>
                  <ExternalLink className="w-4 h-4 text-neutral-400" />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 2. Floating Orange Capsule Bottom Navigation Bar (Mobile / Tablet only, hidden on lg screens) */}
      <nav
        id="tour-bottom-nav"
        role="navigation"
        aria-label="Navigation principale mobile"
        className="fixed inset-x-0 z-40 lg:hidden flex justify-center pointer-events-none select-none px-3 sm:px-4"
        style={{
          bottom: 'calc(0.75rem + env(safe-area-inset-bottom, 0px))',
        }}
      >
        <div className="pointer-events-auto w-full max-w-md bg-[#FF8A00] rounded-full shadow-[0_10px_28px_rgba(255,138,0,0.42),0_4px_14px_rgba(0,0,0,0.14)] px-2 py-1.5 flex items-center justify-between transition-all">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isTabActive = item.isActive;

            return (
              <motion.button
                key={item.id}
                whileTap={{ scale: 0.92 }}
                onClick={item.onClick}
                className="relative flex-1 flex flex-col items-center justify-center py-1 px-0.5 rounded-full cursor-pointer focus:outline-hidden"
                aria-label={item.label}
              >
                {/* Icône avec forme arrondie plus foncée pour l'onglet actif */}
                <div className="relative w-9 h-9 flex items-center justify-center">
                  {isTabActive && (
                    <motion.div
                      layoutId="activePillTabIndicator"
                      className="absolute inset-0 rounded-full bg-black/20"
                      transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                    />
                  )}
                  <Icon
                    className={`relative z-10 w-5 h-5 transition-all ${
                      isTabActive
                        ? 'scale-110 text-[#00FF87] drop-shadow-[0_2px_8px_rgba(0,255,135,0.55)]'
                        : 'text-[#00E676] opacity-95 hover:opacity-100'
                    }`}
                    strokeWidth={isTabActive ? 2.6 : 2.2}
                  />
                </div>

                {/* Libellé blanc toujours bien lisible */}
                <span
                  className={`text-[10px] tracking-tight leading-tight mt-0.5 text-white transition-opacity ${
                    isTabActive ? 'font-bold opacity-100' : 'font-medium opacity-90'
                  }`}
                >
                  {item.label}
                </span>
              </motion.button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
