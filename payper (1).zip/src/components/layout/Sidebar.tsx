import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  FileText,
  Users,
  Settings,
  Crown,
  PlusCircle,
  X,
  ExternalLink,
  Store,
  LogOut,
  ChevronRight,
  Zap,
  BarChart3,
  Palette,
} from 'lucide-react';
import { PayperLogo } from '../common/PayperLogo';
import { GreenGlowButton } from '../common/GreenGlowButton';
import { Boutique, Subscription } from '../../types';
import { getBoutiques, getUserAccount } from '../../lib/storage';
import { LogoutModal } from '../common/LogoutModal';

interface SidebarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  boutique: Boutique | null;
  subscription: Subscription;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
  onOpenNewInvoice: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPath,
  onNavigate,
  boutique,
  subscription,
  isOpenMobile,
  onCloseMobile,
  onOpenNewInvoice,
}) => {
  const [boutiquesCount, setBoutiquesCount] = useState<number>(() => getBoutiques().length);
  const [isLogoutOpen, setIsLogoutOpen] = useState(false);
  const user = getUserAccount();

  useEffect(() => {
    const handleUpdate = () => {
      setBoutiquesCount(getBoutiques().length);
    };
    window.addEventListener('payper_boutiques_updated', handleUpdate);
    return () => window.removeEventListener('payper_boutiques_updated', handleUpdate);
  }, []);

  const navItems = [
    {
      name: 'Dashboard',
      path: '/dashboard',
      icon: LayoutDashboard,
    },
    {
      name: 'Factures',
      path: '/invoices',
      icon: FileText,
    },
    {
      name: 'Analytics',
      path: '/analytics',
      icon: BarChart3,
    },
    {
      name: 'Clients',
      path: '/clients',
      icon: Users,
    },
    {
      name: 'Automatisations',
      path: '/automations',
      icon: Zap,
    },
    {
      name: 'Boutiques',
      path: '/boutiques',
      icon: Store,
      badge: boutiquesCount > 1 ? `${boutiquesCount}` : undefined,
    },
    {
      name: 'Personnalisation',
      path: '/customization',
      icon: Palette,
      highlight: (subscription.plan === 'standard' || subscription.plan === 'pro') && subscription.status === 'active',
    },
    {
      name: 'Mon abonnement',
      path: '/pricing',
      icon: Crown,
      highlight: true,
    },
    {
      name: 'Paramètres',
      path: '/settings',
      icon: Settings,
    },
  ];

  const handleLinkClick = (path: string) => {
    onNavigate(path);
    onCloseMobile();
  };

  const getPlanBadgeColor = (plan: string) => {
    switch (plan) {
      case 'pro':
        return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'standard':
        return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      default:
        return 'bg-neutral-100 text-neutral-600 border-neutral-200';
    }
  };

  const sidebarContent = (
    <div className="flex flex-col h-full bg-[#FAFAFA] border-r border-neutral-200/80 w-[260px] select-none">
      {/* Top Brand Logo */}
      <div className="p-5 flex items-center justify-between border-b border-neutral-100">
        <button
          onClick={() => handleLinkClick('/dashboard')}
          className="cursor-pointer text-left focus:outline-none"
        >
          <PayperLogo size="md" />
        </button>
        {isOpenMobile && (
          <button
            onClick={onCloseMobile}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg lg:hidden cursor-pointer"
            aria-label="Fermer le menu"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Action CTA: Nouvelle facture (Bouton vert avec lumière tournante) */}
      <div className="p-4">
        <GreenGlowButton
          fullWidth
          size="md"
          onClick={() => {
            onCloseMobile();
            onOpenNewInvoice();
          }}
        >
          <PlusCircle className="w-4 h-4" />
          <span>+ Nouvelle facture</span>
        </GreenGlowButton>
      </div>

      {/* Navigation links */}
      <nav className="flex-1 px-3 space-y-1 overflow-y-auto">
        {navItems.map(item => {
          const isActive =
            currentPath === item.path ||
            (item.path === '/invoices' && currentPath.startsWith('/invoice/'));
          const Icon = item.icon;

          return (
            <button
              key={item.path}
              onClick={() => handleLinkClick(item.path)}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-colors text-left cursor-pointer ${
                isActive
                  ? 'bg-orange-50 text-[#FF8A00] border-l-4 border-[#FF8A00] font-semibold'
                  : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100/70'
              }`}
            >
              {(item as any).emoji ? (
                <span className="text-base shrink-0 leading-none">{(item as any).emoji}</span>
              ) : (
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isActive
                      ? 'text-[#FF8A00]'
                      : item.highlight
                      ? 'text-[#FF8A00]'
                      : 'text-neutral-400'
                  }`}
                />
              )}
              <span className="truncate">{item.name}</span>
              {item.badge && (
                <span className="ml-auto text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-neutral-200 text-neutral-700">
                  {item.badge}
                </span>
              )}
              {item.highlight && subscription.plan === 'free' && (
                <span className="ml-auto text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-orange-100 text-[#FF8A00]">
                  PRO
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom Profile / Boutique Card */}
      <div className="p-3 border-t border-neutral-200/70 bg-white m-3 rounded-2xl shadow-xs space-y-2">
        <button
          onClick={() => handleLinkClick('/boutiques')}
          className="w-full flex items-center gap-2.5 p-1 rounded-xl hover:bg-neutral-50 transition-colors text-left cursor-pointer group"
          title="Gérer ou changer de boutique"
        >
          {boutique?.logo ? (
            <img
              src={boutique.logo}
              alt={boutique.name}
              className="w-9 h-9 rounded-xl object-cover border border-neutral-100 shadow-2xs shrink-0"
            />
          ) : (
            <div className="w-9 h-9 rounded-xl bg-orange-50 border border-orange-100 flex items-center justify-center font-bold text-xs text-[#FF8A00] shrink-0">
              {boutique?.name ? boutique.name.slice(0, 2).toUpperCase() : '🏪'}
            </div>
          )}

          <div className="min-w-0 flex-1">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-[#111827] truncate group-hover:text-[#FF8A00] transition-colors">
                {boutique?.name || 'Ma Boutique'}
              </h4>
              <ChevronRight className="w-3.5 h-3.5 text-neutral-400 group-hover:text-[#FF8A00] shrink-0" />
            </div>
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="text-[10px] text-neutral-400 truncate">
                {boutiquesCount > 1 ? `${boutiquesCount} boutiques` : 'Boutique active'}
              </span>
            </div>
          </div>
        </button>

        {/* Déconnexion Account Independent Action */}
        <div className="pt-2 border-t border-neutral-100 flex items-center justify-between px-1">
          <div className="text-[10px] text-neutral-400 truncate max-w-[130px]">
            {user.name || 'Compte Payper'}
          </div>
          <button
            onClick={() => setIsLogoutOpen(true)}
            className="flex items-center gap-1 text-[11px] font-semibold text-neutral-500 hover:text-red-600 transition-colors p-1 rounded hover:bg-red-50 cursor-pointer"
            title="Se déconnecter du compte PAYPER"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Déconnexion</span>
          </button>
        </div>
      </div>

      <LogoutModal
        isOpen={isLogoutOpen}
        onClose={() => setIsLogoutOpen(false)}
        onLogoutConfirmed={() => {
          onCloseMobile();
          window.location.hash = '#/welcome';
        }}
      />
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar (Permanent) */}
      <aside className="hidden lg:block fixed inset-y-0 left-0 z-30">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer (Collapsible) */}
      {isOpenMobile && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            onClick={onCloseMobile}
            className="fixed inset-0 bg-black/50 backdrop-blur-xs transition-opacity"
          />
          <div className="relative z-10 w-[260px] h-full shadow-2xl animate-in slide-in-from-left duration-200">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};
