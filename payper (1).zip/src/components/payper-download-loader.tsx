import React from 'react';
import { motion } from 'motion/react';
import { ArrowDown, Check, Image as ImageIcon } from 'lucide-react';

interface PayperDownloadLoaderProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  theme?: 'light' | 'dark' | 'button';
}

export const PayperDownloadLoader: React.FC<PayperDownloadLoaderProps> = ({
  size = 'md',
  className = '',
  theme = 'light',
}) => {
  const dimensions = {
    sm: { container: 26, icon: 14, badge: 12 },
    md: { container: 48, icon: 24, badge: 18 },
    lg: { container: 72, icon: 36, badge: 24 },
  };

  const dim = dimensions[size];
  const isButton = theme === 'button';

  return (
    <div
      className={`relative inline-flex items-center justify-center select-none ${className}`}
      style={{ width: dim.container, height: dim.container }}
      aria-label="Chargement téléchargement"
    >
      {/* Background soft glow / circles */}
      <motion.div
        animate={{
          scale: [0.85, 1.15, 0.9, 0.85],
          opacity: [0.25, 0.55, 0.3, 0.25],
        }}
        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        className="absolute inset-0 rounded-2xl bg-gradient-to-tr from-[#FF8A00] to-[#00C48C] blur-[2px]"
      />

      {/* Main Picture Frame */}
      <motion.div
        animate={{
          y: [0, -2, 0],
          scale: [0.95, 1, 0.95],
        }}
        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        className={`relative z-10 rounded-xl flex items-center justify-center shadow-xs border ${
          isButton
            ? 'bg-white/10 border-white/30 text-white'
            : 'bg-white border-neutral-200 text-neutral-800'
        }`}
        style={{ width: dim.container * 0.78, height: dim.container * 0.78 }}
      >
        <ImageIcon style={{ width: dim.icon, height: dim.icon }} className="text-[#FF8A00]" />

        {/* Download Arrow gliding down */}
        <motion.div
          animate={{
            y: [-6, 6, -6],
            opacity: [0, 1, 0],
          }}
          transition={{
            duration: 1.6,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="absolute inset-0 flex items-center justify-center text-[#FF8A00]"
        >
          <ArrowDown style={{ width: dim.icon * 0.75, height: dim.icon * 0.75 }} strokeWidth={3} />
        </motion.div>
      </motion.div>

      {/* Green Check Pop */}
      <motion.div
        animate={{
          scale: [0, 0, 1.25, 1, 0],
          opacity: [0, 0, 1, 1, 0],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          times: [0, 0.55, 0.7, 0.85, 1],
          ease: 'easeOut',
        }}
        style={{
          width: dim.badge,
          height: dim.badge,
          right: -2,
          bottom: -2,
        }}
        className="absolute rounded-full bg-[#00C48C] text-white flex items-center justify-center shadow-md z-20 border-2 border-white"
      >
        <Check style={{ width: dim.badge * 0.65, height: dim.badge * 0.65 }} strokeWidth={3.5} />
      </motion.div>
    </div>
  );
};
