import React from 'react';
import { motion } from 'motion/react';
import { Check } from 'lucide-react';

interface PayperInvoiceLoaderProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  theme?: 'light' | 'dark' | 'button';
}

export const PayperInvoiceLoader: React.FC<PayperInvoiceLoaderProps> = ({
  size = 'md',
  className = '',
  theme = 'light',
}) => {
  // Sizing definitions
  const dimensions = {
    sm: { width: 22, height: 26, stroke: 1.8, circleSize: 12, checkSize: 10 },
    md: { width: 38, height: 46, stroke: 2, circleSize: 22, checkSize: 16 },
    lg: { width: 62, height: 76, stroke: 2.2, circleSize: 34, checkSize: 24 },
  };

  const dim = dimensions[size];
  const isButton = theme === 'button';

  return (
    <div
      className={`relative inline-flex items-center justify-center select-none ${className}`}
      style={{ width: dim.width + dim.circleSize, height: dim.height + 10 }}
      aria-label="Chargement Payper Flow"
    >
      {/* 1. Signature Payper: Overlapping Orange & Green circles */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        {/* Orange circle */}
        <motion.div
          animate={{
            x: [-6, 3, 0, -6],
            scale: [0.85, 1.1, 0.95, 0.85],
            opacity: [0.35, 0.65, 0.45, 0.35],
          }}
          transition={{
            duration: 2.2,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          style={{ width: dim.circleSize, height: dim.circleSize }}
          className="rounded-full bg-[#FF8A00] blur-[1px]"
        />

        {/* Green circle */}
        <motion.div
          animate={{
            x: [6, -3, 0, 6],
            scale: [0.85, 1.15, 0.9, 0.85],
            opacity: [0.35, 0.7, 0.4, 0.35],
          }}
          transition={{
            duration: 2.2,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          style={{ width: dim.circleSize, height: dim.circleSize }}
          className="rounded-full bg-[#00C48C] blur-[1px] -ml-2 mix-blend-multiply"
        />
      </div>

      {/* 2. Main Invoice Sheet */}
      <motion.div
        animate={{
          scale: [0.88, 1, 1, 0.88],
          y: [3, 0, 0, 3],
          opacity: [0.8, 1, 1, 0.8],
        }}
        transition={{
          duration: 2.2,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="relative z-10 flex items-center justify-center"
      >
        <svg
          width={dim.width}
          height={dim.height}
          viewBox="0 0 40 48"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="overflow-visible"
        >
          {/* Invoice Page Outline with folded corner */}
          <motion.path
            d="M 6 3 H 26 L 34 11 V 43 C 34 44.5 32.5 46 30 46 H 6 C 4.5 46 3 44.5 3 43 V 6 C 3 4.5 4.5 3 6 3 Z"
            stroke={isButton ? 'currentColor' : '#111827'}
            strokeWidth={dim.stroke * 1.2}
            strokeLinecap="round"
            strokeLinejoin="round"
            fill={isButton ? 'rgba(255,255,255,0.1)' : '#FFFFFF'}
            animate={{
              stroke: isButton
                ? ['currentColor', 'currentColor', 'currentColor']
                : ['#111827', '#FF8A00', '#00C48C', '#111827'],
            }}
            transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
          />

          {/* Folded corner flap */}
          <path
            d="M 26 3 V 11 H 34"
            stroke={isButton ? 'currentColor' : '#111827'}
            strokeWidth={dim.stroke}
            strokeLinecap="round"
            strokeLinejoin="round"
            fill="none"
            opacity={0.7}
          />

          {/* Header line */}
          <motion.line
            x1="9"
            y1="13"
            x2="21"
            y2="13"
            stroke="#FF8A00"
            strokeWidth={dim.stroke * 1.1}
            strokeLinecap="round"
            animate={{
              opacity: [0.2, 1, 1, 0.2],
              scaleX: [0.4, 1, 1, 0.4],
            }}
            transition={{ duration: 2.2, repeat: Infinity, times: [0, 0.3, 0.8, 1] }}
          />

          {/* Line 1: Item description */}
          <motion.line
            x1="9"
            y1="21"
            x2="29"
            y2="21"
            stroke={isButton ? 'currentColor' : '#6B7280'}
            strokeWidth={dim.stroke}
            strokeLinecap="round"
            animate={{
              opacity: [0, 0, 1, 1, 0],
              scaleX: [0, 0.2, 1, 1, 0],
            }}
            transition={{ duration: 2.2, repeat: Infinity, times: [0, 0.2, 0.45, 0.85, 1] }}
          />

          {/* Line 2: Price / Quantity */}
          <motion.line
            x1="9"
            y1="28"
            x2="25"
            y2="28"
            stroke={isButton ? 'currentColor' : '#9CA3AF'}
            strokeWidth={dim.stroke}
            strokeLinecap="round"
            animate={{
              opacity: [0, 0, 1, 1, 0],
              scaleX: [0, 0.2, 1, 1, 0],
            }}
            transition={{ duration: 2.2, repeat: Infinity, times: [0, 0.35, 0.6, 0.85, 1] }}
          />

          {/* Line 3: Total amount */}
          <motion.line
            x1="9"
            y1="35"
            x2="20"
            y2="35"
            stroke="#00C48C"
            strokeWidth={dim.stroke * 1.3}
            strokeLinecap="round"
            animate={{
              opacity: [0, 0, 1, 1, 0],
              scaleX: [0, 0.2, 1, 1, 0],
            }}
            transition={{ duration: 2.2, repeat: Infinity, times: [0, 0.5, 0.75, 0.85, 1] }}
          />
        </svg>

        {/* 3. Pop-up Green Validation Badge */}
        <motion.div
          animate={{
            scale: [0, 0, 1.2, 1, 1, 0],
            opacity: [0, 0, 1, 1, 1, 0],
          }}
          transition={{
            duration: 2.2,
            repeat: Infinity,
            times: [0, 0.58, 0.72, 0.78, 0.9, 1],
            ease: 'easeOut',
          }}
          style={{
            width: dim.checkSize + 4,
            height: dim.checkSize + 4,
            right: -dim.checkSize / 3,
            bottom: -dim.checkSize / 4,
          }}
          className="absolute rounded-full bg-[#00C48C] text-white flex items-center justify-center shadow-md z-20 border-2 border-white"
        >
          <Check style={{ width: dim.checkSize - 2, height: dim.checkSize - 2 }} strokeWidth={3.5} />
        </motion.div>
      </motion.div>
    </div>
  );
};
