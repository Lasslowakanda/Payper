import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  PayperSymbolicLoader,
  PayperLoadingContext,
  PayperSymbolicSize,
} from './common/PayperSymbolicLoader';

export type PayperLoaderVariant =
  | 'default'
  | 'invoice'
  | 'download'
  | 'whatsapp'
  | 'payment'
  | 'sync'
  | 'orders'
  | 'products'
  | 'transactions'
  | 'clients'
  | 'analytics'
  | 'notifications';

export type PayperLoaderSize = 'sm' | 'md' | 'lg';

export interface PayperLoaderProps {
  variant?: PayperLoaderVariant;
  size?: PayperLoaderSize;
  text?: string;
  theme?: 'light' | 'dark' | 'button';
  inline?: boolean;
  className?: string;
  isError?: boolean;
  errorMessage?: string;
}

/**
 * Mapping des variantes existantes vers les nouveaux contextes symboliques
 */
const mapVariantToContext = (variant: PayperLoaderVariant = 'default'): PayperLoadingContext => {
  switch (variant) {
    case 'orders':
      return 'orders';
    case 'products':
      return 'products';
    case 'payment':
      return 'payments';
    case 'transactions':
      return 'transactions';
    case 'invoice':
      return 'invoices';
    case 'clients':
      return 'clients';
    case 'analytics':
      return 'analytics';
    case 'notifications':
      return 'notifications';
    case 'download':
      return 'download';
    case 'whatsapp':
      return 'whatsapp';
    case 'sync':
    case 'default':
    default:
      return 'general';
  }
};

export const PayperCoreInvoiceAnimation: React.FC<{
  size: PayperLoaderSize;
  theme: 'light' | 'dark' | 'button';
}> = ({ size, theme }) => {
  return (
    <PayperSymbolicLoader
      context="invoices"
      size={size}
      theme={theme}
    />
  );
};

export const PayperLoader: React.FC<PayperLoaderProps> = ({
  variant = 'default',
  size = 'md',
  text,
  theme = 'light',
  inline = false,
  className = '',
  isError = false,
  errorMessage,
}) => {
  const isButton = theme === 'button';
  const context = mapVariantToContext(variant);

  const displayText =
    text !== undefined
      ? text
      : !inline && size !== 'sm'
      ? variant === 'download'
        ? "Génération de l'image..."
        : variant === 'whatsapp'
        ? 'Préparation de WhatsApp...'
        : variant === 'payment'
        ? 'Paiement en cours...'
        : variant === 'invoice'
        ? 'Traitement de la facture...'
        : variant === 'orders'
        ? 'Chargement des commandes...'
        : variant === 'products'
        ? 'Mise à jour du catalogue...'
        : variant === 'transactions'
        ? 'Actualisation des flux...'
        : variant === 'clients'
        ? 'Gestion des clients...'
        : variant === 'analytics'
        ? 'Calcul des statistiques...'
        : variant === 'notifications'
        ? 'Actualisation des alertes...'
        : undefined
      : undefined;

  const textSizeClasses = {
    sm: 'text-xs',
    md: 'text-sm font-medium',
    lg: 'text-base font-semibold',
  };

  const renderVisual = () => (
    <PayperSymbolicLoader
      context={context}
      size={size}
      theme={theme}
      isError={isError}
      errorMessage={errorMessage}
    />
  );

  if (inline) {
    return (
      <div className={`inline-flex items-center gap-2 ${className}`}>
        {renderVisual()}
        {displayText && (
          <span className={`${textSizeClasses[size]} truncate tracking-tight`}>
            {displayText}
          </span>
        )}
      </div>
    );
  }

  return (
    <div className={`flex flex-col items-center justify-center text-center p-2 ${className}`}>
      {renderVisual()}
      <AnimatePresence mode="wait">
        {displayText && (
          <motion.p
            key={displayText}
            initial={{ opacity: 0, y: 3 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -3 }}
            transition={{ duration: 0.2 }}
            className={`mt-2.5 ${textSizeClasses[size]} ${
              isButton ? 'text-white' : 'text-neutral-700'
            }`}
          >
            {displayText}
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
};
