import React from 'react';
import { motion } from 'motion/react';
import { PayperLogo } from './common/PayperLogo';
import { PayperSymbolicLoader, PayperLoadingContext } from './common/PayperSymbolicLoader';

interface PayperLoadingScreenProps {
  context?: PayperLoadingContext;
  title?: string;
  subtitle?: string;
  className?: string;
  fullScreen?: boolean;
}

export const PayperLoadingScreen: React.FC<PayperLoadingScreenProps> = ({
  context = 'general',
  title = 'Chargement de Payper...',
  subtitle = 'Préparation de ton espace de facturation...',
  className = '',
  fullScreen = true,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      className={`${
        fullScreen
          ? 'fixed inset-0 z-50 bg-white flex flex-col items-center justify-center p-6'
          : 'w-full py-16 bg-white flex flex-col items-center justify-center p-6 rounded-2xl'
      } select-none ${className}`}
    >
      {/* Top Logo */}
      <motion.div
        initial={{ y: -6, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.05, duration: 0.25 }}
        className="mb-8"
      >
        <PayperLogo size="md" />
      </motion.div>

      {/* Proprietary Symbolic Animation */}
      <div className="my-2">
        <PayperSymbolicLoader context={context} size="lg" />
      </div>

      {/* Titles */}
      {(title || subtitle) && (
        <motion.div
          initial={{ y: 6, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.15, duration: 0.25 }}
          className="mt-6 text-center max-w-sm"
        >
          {title && (
            <h3 className="text-base font-bold text-[#111827]">
              {title}
            </h3>
          )}
          {subtitle && (
            <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
              {subtitle}
            </p>
          )}
        </motion.div>
      )}
    </motion.div>
  );
};
