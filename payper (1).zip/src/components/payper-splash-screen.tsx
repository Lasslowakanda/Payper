import React, { useEffect } from 'react';
import { motion } from 'motion/react';
import { PayperLogo } from './common/PayperLogo';

interface PayperSplashScreenProps {
  onComplete: () => void;
  durationMs?: number;
}

/**
 * ÉTAPE 1 — ÉCRAN DE DÉMARRAGE
 *
 * Plein écran, moderne et élégant.
 * Arrière-plan :
 * - Dégradé professionnel orange et vert (#FF8A00 et #00C48C).
 * - Transition douce entre les couleurs.
 * - Animations subtiles et fluides.
 * - Design minimaliste et premium.
 *
 * Affichage :
 * - Uniquement le logo officiel de PAYPER au centre de l'écran.
 * - Respect strict de sa forme, de ses proportions et de son identité visuelle.
 * - Légère animation à son apparition avec effet de fondu et mouvement subtil.
 * - Aucun texte superflu à côté du logo.
 * - Passage automatique à la suite après une courte animation (3s par défaut).
 */
export const PayperSplashScreen: React.FC<PayperSplashScreenProps> = ({
  onComplete,
  durationMs = 3000,
}) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, durationMs);

    return () => clearTimeout(timer);
  }, [durationMs, onComplete]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.02 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="fixed inset-0 z-[100] flex items-center justify-center select-none overflow-hidden"
      style={{
        background: 'linear-gradient(135deg, #FF8A00 0%, #FF9500 30%, #059669 70%, #00C48C 100%)',
      }}
    >
      {/* Subtle organic light glow in background */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: [0.25, 0.45, 0.3], scale: [0.95, 1.15, 1] }}
        transition={{ duration: 3.5, repeat: Infinity, repeatType: 'reverse', ease: 'easeInOut' }}
        className="absolute w-[500px] h-[500px] rounded-full bg-gradient-to-br from-white/20 via-emerald-300/15 to-transparent blur-3xl pointer-events-none"
      />

      {/* Official PAYPER Logo directly on the gradient (no white background) */}
      <motion.div
        initial={{ scale: 0.85, opacity: 0, y: 10 }}
        animate={{
          scale: [0.85, 1.04, 1],
          opacity: [0, 1, 1],
          y: [10, -2, 0],
        }}
        transition={{
          duration: 1.1,
          ease: [0.16, 1, 0.3, 1],
        }}
        className="relative z-10 flex items-center justify-center drop-shadow-2xl"
      >
        <PayperLogo size="xl" />
      </motion.div>
    </motion.div>
  );
};
