import React from 'react';
import { motion } from 'motion/react';
import { FileText, MessageCircle, Check } from 'lucide-react';

interface PayperWhatsAppLoaderProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  theme?: 'light' | 'dark' | 'button';
}

export const PayperWhatsAppLoader: React.FC<PayperWhatsAppLoaderProps> = ({
  size = 'md',
  className = '',
  theme = 'light',
}) => {
  const dimensions = {
    sm: { container: 30, invoice: 14, chat: 16, check: 11 },
    md: { container: 52, invoice: 22, chat: 26, check: 16 },
    lg: { container: 76, invoice: 32, chat: 38, check: 22 },
  };

  const dim = dimensions[size];
  const isButton = theme === 'button';

  return (
    <div
      className={`relative inline-flex items-center justify-center select-none ${className}`}
      style={{ width: dim.container, height: dim.container }}
      aria-label="Chargement WhatsApp"
    >
      {/* Background Payper circles pulsing */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <motion.div
          animate={{
            scale: [0.8, 1.1, 0.8],
            opacity: [0.2, 0.5, 0.2],
          }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          className="w-3/4 h-3/4 rounded-full bg-[#25D366]/20 blur-[2px]"
        />
      </div>

      <div className="relative flex items-center justify-center">
        {/* Invoice moving toward chat bubble */}
        <motion.div
          animate={{
            x: [-6, 3, 3, -6],
            opacity: [1, 1, 0.3, 1],
            scale: [1, 0.85, 0.6, 1],
          }}
          transition={{
            duration: 2.2,
            repeat: Infinity,
            times: [0, 0.5, 0.75, 1],
            ease: 'easeInOut',
          }}
          className="z-10 text-[#FF8A00]"
        >
          <FileText style={{ width: dim.invoice, height: dim.invoice }} strokeWidth={2.2} />
        </motion.div>

        {/* WhatsApp Chat Bubble */}
        <motion.div
          animate={{
            scale: [0.95, 1.12, 1, 0.95],
            color: ['#00C48C', '#25D366', '#25D366', '#00C48C'],
          }}
          transition={{
            duration: 2.2,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="z-20 text-[#25D366] -ml-1"
        >
          <MessageCircle style={{ width: dim.chat, height: dim.chat }} strokeWidth={2.2} />
        </motion.div>
      </div>

      {/* Check badge pop */}
      <motion.div
        animate={{
          scale: [0, 0, 1.25, 1, 0],
          opacity: [0, 0, 1, 1, 0],
        }}
        transition={{
          duration: 2.2,
          repeat: Infinity,
          times: [0, 0.6, 0.75, 0.9, 1],
          ease: 'easeOut',
        }}
        style={{
          width: dim.check,
          height: dim.check,
          right: 0,
          bottom: 0,
        }}
        className="absolute rounded-full bg-[#00C48C] text-white flex items-center justify-center shadow-md z-30 border-2 border-white"
      >
        <Check style={{ width: dim.check * 0.65, height: dim.check * 0.65 }} strokeWidth={3.5} />
      </motion.div>
    </div>
  );
};
