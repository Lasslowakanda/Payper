import { Boutique, Currency, Invoice } from '../types';
import { formatCurrency, formatDate } from './invoice';

export type AnalyticsPeriod =
  | 'today'
  | '7days'
  | '28days'
  | '30days'
  | '90days'
  | 'thisWeek'
  | 'thisMonth'
  | 'prevMonth'
  | 'custom';

export interface PeriodOption {
  id: AnalyticsPeriod;
  label: string;
  shortLabel: string;
}

export const PERIOD_OPTIONS: PeriodOption[] = [
  { id: 'today', label: "Aujourd'hui", shortLabel: "Auj." },
  { id: '7days', label: '7 derniers jours', shortLabel: '7j' },
  { id: '28days', label: '28 derniers jours', shortLabel: '28j' },
  { id: '30days', label: '30 derniers jours', shortLabel: '30j' },
  { id: '90days', label: '90 derniers jours', shortLabel: '90j' },
  { id: 'thisWeek', label: 'Cette semaine', shortLabel: 'Semaine' },
  { id: 'thisMonth', label: 'Ce mois-ci', shortLabel: 'Mois' },
  { id: 'prevMonth', label: 'Mois précédent', shortLabel: 'Mois préc.' },
  { id: 'custom', label: 'Personnalisé', shortLabel: 'Perso' },
];

export interface DateRange {
  start: Date;
  end: Date;
  label: string;
  daysCount: number;
}

export interface DayDataPoint {
  dateKey: string; // YYYY-MM-DD
  displayDate: string; // "9 oct." or "Ven 9"
  revenue: number; // Encaissements (factures payées)
  pending: number; // En attente
  invoicesCount: number;
  paidCount: number;
  pendingCount: number;
  invoices: Invoice[];
  clients: string[];
}

export interface MetricComparison {
  current: number;
  previous: number;
  percentChange: number | null; // e.g. +25.4, -10.2, or null if no comparison
  trend: 'up' | 'down' | 'neutral';
}

export interface AnalyticsStats {
  periodLabel: string;
  currentRange: DateRange;
  previousRange: DateRange;
  currency: Currency;
  // Core cards
  revenue: MetricComparison; // Chiffre d'affaires
  invoicesCount: MetricComparison; // Factures créées
  paidInvoicesCount: MetricComparison; // Factures réglées
  pendingAmount: MetricComparison; // Montant restant à encaisser
  clientsCount: MetricComparison; // Clients enregistrés / actifs
  // List of filtered invoices in current period
  currentInvoices: Invoice[];
  paidInvoices: Invoice[];
  pendingInvoices: Invoice[];
  // Time-series breakdown
  dailySeries: DayDataPoint[];
  // Top clients during period
  topClients: {
    name: string;
    city?: string;
    phone?: string;
    invoicesCount: number;
    totalAmount: number;
    paidAmount: number;
  }[];
  // Breakdown percentages
  collectionRate: number; // % of total billed that was paid
}

/**
 * Format a Date to local YYYY-MM-DD
 */
export function toDateKey(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Parse an invoice date safely into a Date object
 */
export function parseInvoiceDate(inv: Invoice): Date {
  const dateStr = inv.date || inv.createdAt;
  const parsed = new Date(dateStr);
  if (isNaN(parsed.getTime())) {
    return new Date();
  }
  return parsed;
}

/**
 * Calculates current and comparison date ranges
 */
export function calculateDateRanges(
  period: AnalyticsPeriod,
  customStart?: string,
  customEnd?: string
): { current: DateRange; previous: DateRange } {
  const now = new Date();
  const todayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);

  let currentStart: Date;
  let currentEnd: Date = todayEnd;
  let prevStart: Date;
  let prevEnd: Date;
  let label = '';
  let prevLabel = '';

  switch (period) {
    case 'today': {
      currentStart = todayStart;
      currentEnd = todayEnd;
      prevStart = new Date(todayStart);
      prevStart.setDate(prevStart.getDate() - 1);
      prevEnd = new Date(todayEnd);
      prevEnd.setDate(prevEnd.getDate() - 1);
      label = "Aujourd'hui";
      prevLabel = 'Hier';
      break;
    }
    case '7days': {
      currentStart = new Date(todayStart);
      currentStart.setDate(currentStart.getDate() - 6);
      prevStart = new Date(currentStart);
      prevStart.setDate(prevStart.getDate() - 7);
      prevEnd = new Date(currentStart);
      prevEnd.setMilliseconds(prevEnd.getMilliseconds() - 1);
      label = '7 derniers jours';
      prevLabel = '7 jours précédents';
      break;
    }
    case '28days': {
      currentStart = new Date(todayStart);
      currentStart.setDate(currentStart.getDate() - 27);
      prevStart = new Date(currentStart);
      prevStart.setDate(prevStart.getDate() - 28);
      prevEnd = new Date(currentStart);
      prevEnd.setMilliseconds(prevEnd.getMilliseconds() - 1);
      label = '28 derniers jours';
      prevLabel = '28 jours précédents';
      break;
    }
    case '30days': {
      currentStart = new Date(todayStart);
      currentStart.setDate(currentStart.getDate() - 29);
      prevStart = new Date(currentStart);
      prevStart.setDate(prevStart.getDate() - 30);
      prevEnd = new Date(currentStart);
      prevEnd.setMilliseconds(prevEnd.getMilliseconds() - 1);
      label = '30 derniers jours';
      prevLabel = '30 jours précédents';
      break;
    }
    case '90days': {
      currentStart = new Date(todayStart);
      currentStart.setDate(currentStart.getDate() - 89);
      prevStart = new Date(currentStart);
      prevStart.setDate(prevStart.getDate() - 90);
      prevEnd = new Date(currentStart);
      prevEnd.setMilliseconds(prevEnd.getMilliseconds() - 1);
      label = '90 derniers jours';
      prevLabel = '90 jours précédents';
      break;
    }
    case 'thisWeek': {
      // Monday of this week
      const day = now.getDay();
      const diffToMonday = (day === 0 ? -6 : 1) - day;
      currentStart = new Date(todayStart);
      currentStart.setDate(currentStart.getDate() + diffToMonday);

      // Previous week (Monday to Sunday)
      prevStart = new Date(currentStart);
      prevStart.setDate(prevStart.getDate() - 7);
      prevEnd = new Date(currentStart);
      prevEnd.setMilliseconds(prevEnd.getMilliseconds() - 1);

      label = 'Cette semaine';
      prevLabel = 'Semaine précédente';
      break;
    }
    case 'thisMonth': {
      currentStart = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
      // Previous month
      prevStart = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
      // End of previous month
      prevEnd = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
      label = 'Ce mois-ci';
      prevLabel = 'Mois dernier';
      break;
    }
    case 'prevMonth': {
      currentStart = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
      currentEnd = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
      prevStart = new Date(now.getFullYear(), now.getMonth() - 2, 1, 0, 0, 0, 0);
      prevEnd = new Date(now.getFullYear(), now.getMonth() - 1, 0, 23, 59, 59, 999);
      label = 'Mois précédent';
      prevLabel = '2 mois auparavant';
      break;
    }
    case 'custom':
    default: {
      if (customStart && customEnd) {
        const s = new Date(customStart + 'T00:00:00');
        const e = new Date(customEnd + 'T23:59:59');
        if (!isNaN(s.getTime()) && !isNaN(e.getTime()) && s <= e) {
          currentStart = s;
          currentEnd = e;
        } else {
          currentStart = new Date(todayStart);
          currentStart.setDate(currentStart.getDate() - 27);
        }
      } else {
        currentStart = new Date(todayStart);
        currentStart.setDate(currentStart.getDate() - 27);
      }

      const durationMs = currentEnd.getTime() - currentStart.getTime();
      prevEnd = new Date(currentStart.getTime() - 1);
      prevStart = new Date(prevEnd.getTime() - durationMs);
      label = `Du ${formatDate(currentStart.toISOString())} au ${formatDate(currentEnd.toISOString())}`;
      prevLabel = 'Période précédente';
      break;
    }
  }

  const daysCount = Math.max(
    1,
    Math.round((currentEnd.getTime() - currentStart.getTime()) / (1000 * 60 * 60 * 24))
  );
  const prevDaysCount = Math.max(
    1,
    Math.round((prevEnd.getTime() - prevStart.getTime()) / (1000 * 60 * 60 * 24))
  );

  return {
    current: {
      start: currentStart,
      end: currentEnd,
      label,
      daysCount,
    },
    previous: {
      start: prevStart,
      end: prevEnd,
      label: prevLabel,
      daysCount: prevDaysCount,
    },
  };
}

/**
 * Calculates percentage variation and trend
 */
export function calculateComparison(curr: number, prev: number): MetricComparison {
  if (prev === 0 && curr === 0) {
    return { current: curr, previous: prev, percentChange: 0, trend: 'neutral' };
  }
  if (prev === 0 && curr > 0) {
    return { current: curr, previous: prev, percentChange: 100, trend: 'up' };
  }
  if (prev === 0 && curr < 0) {
    return { current: curr, previous: prev, percentChange: -100, trend: 'down' };
  }
  const diff = curr - prev;
  const pct = Math.round((diff / prev) * 1000) / 10;
  return {
    current: curr,
    previous: prev,
    percentChange: pct,
    trend: pct > 0 ? 'up' : pct < 0 ? 'down' : 'neutral',
  };
}

/**
 * Compute all analytics stats for the given invoices and period
 */
export function computeAnalytics(
  allInvoices: Invoice[],
  period: AnalyticsPeriod,
  currency: Currency = 'FCFA',
  customStart?: string,
  customEnd?: string
): AnalyticsStats {
  const { current: currentRange, previous: previousRange } = calculateDateRanges(
    period,
    customStart,
    customEnd
  );

  const curStartMs = currentRange.start.getTime();
  const curEndMs = currentRange.end.getTime();
  const prevStartMs = previousRange.start.getTime();
  const prevEndMs = previousRange.end.getTime();

  // Split invoices into current and previous ranges
  const currentInvoices: Invoice[] = [];
  const previousInvoices: Invoice[] = [];

  for (const inv of allInvoices) {
    const invDate = parseInvoiceDate(inv);
    const ms = invDate.getTime();
    if (ms >= curStartMs && ms <= curEndMs) {
      currentInvoices.push(inv);
    } else if (ms >= prevStartMs && ms <= prevEndMs) {
      previousInvoices.push(inv);
    }
  }

  // Sort current descending by date
  currentInvoices.sort((a, b) => parseInvoiceDate(b).getTime() - parseInvoiceDate(a).getTime());

  // Metrics for Current Period
  const paidInvoices = currentInvoices.filter(i => i.isPaid);
  const pendingInvoices = currentInvoices.filter(i => !i.isPaid);

  const currentRevenue = paidInvoices.reduce((sum, i) => sum + (Number(i.amount) || 0), 0);
  const currentTotalBilled = currentInvoices.reduce((sum, i) => sum + (Number(i.amount) || 0), 0);
  const currentPendingAmount = pendingInvoices.reduce((sum, i) => sum + (Number(i.amount) || 0), 0);
  const currentInvoicesCount = currentInvoices.length;
  const currentPaidCount = paidInvoices.length;

  const currentClientsSet = new Set(
    currentInvoices.map(i => i.clientName.trim().toLowerCase()).filter(Boolean)
  );
  const currentClientsCount = currentClientsSet.size;

  // Metrics for Previous Period
  const prevPaidInvoices = previousInvoices.filter(i => i.isPaid);
  const prevPendingInvoices = previousInvoices.filter(i => !i.isPaid);

  const prevRevenue = prevPaidInvoices.reduce((sum, i) => sum + (Number(i.amount) || 0), 0);
  const prevPendingAmount = prevPendingInvoices.reduce((sum, i) => sum + (Number(i.amount) || 0), 0);
  const prevInvoicesCount = previousInvoices.length;
  const prevPaidCount = prevPaidInvoices.length;

  const prevClientsSet = new Set(
    previousInvoices.map(i => i.clientName.trim().toLowerCase()).filter(Boolean)
  );
  const prevClientsCount = prevClientsSet.size;

  // Collection rate
  const collectionRate =
    currentTotalBilled > 0 ? Math.round((currentRevenue / currentTotalBilled) * 100) : 100;

  // Build daily series
  const dailySeries: DayDataPoint[] = [];
  const daysDiff = Math.max(
    1,
    Math.round((curEndMs - curStartMs) / (1000 * 60 * 60 * 24))
  );

  // Group invoices by day
  const mapByDay = new Map<string, Invoice[]>();
  for (const inv of currentInvoices) {
    const key = toDateKey(parseInvoiceDate(inv));
    const list = mapByDay.get(key) || [];
    list.push(inv);
    mapByDay.set(key, list);
  }

  // Iterate day by day from start to end (or maximum 90 days for chart readability)
  const cursor = new Date(currentRange.start);
  cursor.setHours(0, 0, 0, 0);

  const stop = new Date(currentRange.end);
  stop.setHours(23, 59, 59, 999);

  while (cursor <= stop) {
    const key = toDateKey(cursor);
    const dayInvoices = mapByDay.get(key) || [];
    const dayPaid = dayInvoices.filter(i => i.isPaid);
    const dayPending = dayInvoices.filter(i => !i.isPaid);

    const dayRevenue = dayPaid.reduce((s, i) => s + (Number(i.amount) || 0), 0);
    const dayPendingAmount = dayPending.reduce((s, i) => s + (Number(i.amount) || 0), 0);

    const dayClients = Array.from(
      new Set(dayInvoices.map(i => i.clientName.trim()).filter(Boolean))
    );

    const dayFormatter = new Intl.DateTimeFormat('fr-FR', {
      day: 'numeric',
      month: 'short',
    });

    dailySeries.push({
      dateKey: key,
      displayDate: dayFormatter.format(cursor),
      revenue: dayRevenue,
      pending: dayPendingAmount,
      invoicesCount: dayInvoices.length,
      paidCount: dayPaid.length,
      pendingCount: dayPending.length,
      invoices: dayInvoices,
      clients: dayClients,
    });

    cursor.setDate(cursor.getDate() + 1);
  }

  // Build Top Clients for the period
  const clientMap = new Map<
    string,
    {
      name: string;
      city?: string;
      phone?: string;
      invoicesCount: number;
      totalAmount: number;
      paidAmount: number;
    }
  >();

  for (const inv of currentInvoices) {
    const norm = inv.clientName.trim().toLowerCase();
    if (!norm) continue;
    const existing = clientMap.get(norm) || {
      name: inv.clientName.trim(),
      city: inv.clientCity,
      phone: inv.whatsappNumber,
      invoicesCount: 0,
      totalAmount: 0,
      paidAmount: 0,
    };

    existing.invoicesCount += 1;
    existing.totalAmount += Number(inv.amount) || 0;
    if (inv.isPaid) {
      existing.paidAmount += Number(inv.amount) || 0;
    }
    if (!existing.phone && inv.whatsappNumber) {
      existing.phone = inv.whatsappNumber;
    }
    clientMap.set(norm, existing);
  }

  const topClients = Array.from(clientMap.values()).sort(
    (a, b) => b.totalAmount - a.totalAmount
  );

  return {
    periodLabel: currentRange.label,
    currentRange,
    previousRange,
    currency,
    revenue: calculateComparison(currentRevenue, prevRevenue),
    invoicesCount: calculateComparison(currentInvoicesCount, prevInvoicesCount),
    paidInvoicesCount: calculateComparison(currentPaidCount, prevPaidCount),
    pendingAmount: calculateComparison(currentPendingAmount, prevPendingAmount),
    clientsCount: calculateComparison(currentClientsCount, prevClientsCount),
    currentInvoices,
    paidInvoices,
    pendingInvoices,
    dailySeries,
    topClients,
    collectionRate,
  };
}

/**
 * CSV Export for Analytics
 * Outputs UTF-8 with BOM for perfect opening in Microsoft Excel and Google Sheets
 */
export function exportAnalyticsCSV(
  boutique: Boutique | null,
  stats: AnalyticsStats
): void {
  const currency = stats.currency;
  const boutiqueName = boutique?.name || 'Ma Boutique';

  let csvContent = '\uFEFF'; // UTF-8 BOM
  csvContent += `RAPPORT ANALYTICS PAYPER - ${boutiqueName.toUpperCase()}\n`;
  csvContent += `Période;${stats.periodLabel}\n`;
  csvContent += `Date d'exportation;${new Date().toLocaleString('fr-FR')}\n`;
  csvContent += `Devise;${currency}\n\n`;

  // Summary Metrics Section
  csvContent += 'RÉSUMÉ DES INDICATEURS CLÉS\n';
  csvContent += 'Indicateur;Valeur actuelle;Période précédente;Évolution (%)\n';
  csvContent += `Chiffre d'affaires;${stats.revenue.current};${stats.revenue.previous};${stats.revenue.percentChange !== null ? stats.revenue.percentChange + '%' : 'N/A'}\n`;
  csvContent += `Factures créées;${stats.invoicesCount.current};${stats.invoicesCount.previous};${stats.invoicesCount.percentChange !== null ? stats.invoicesCount.percentChange + '%' : 'N/A'}\n`;
  csvContent += `Factures payées;${stats.paidInvoicesCount.current};${stats.paidInvoicesCount.previous};${stats.paidInvoicesCount.percentChange !== null ? stats.paidInvoicesCount.percentChange + '%' : 'N/A'}\n`;
  csvContent += `Impayés (Montant restant);${stats.pendingAmount.current};${stats.pendingAmount.previous};${stats.pendingAmount.percentChange !== null ? stats.pendingAmount.percentChange + '%' : 'N/A'}\n`;
  csvContent += `Clients enregistrés;${stats.clientsCount.current};${stats.clientsCount.previous};${stats.clientsCount.percentChange !== null ? stats.clientsCount.percentChange + '%' : 'N/A'}\n`;
  csvContent += `Taux d'encaissement;${stats.collectionRate}%;-\n\n`;

  // Detailed Invoices Section
  csvContent += 'DÉTAIL DES FACTURES DE LA PÉRIODE\n';
  csvContent += 'Numéro;Date;Client;Ville;Téléphone;Description;Montant;Statut\n';

  stats.currentInvoices.forEach(inv => {
    const cleanDesc = (inv.description || '').replace(/;/g, ' - ').replace(/\n/g, ' ');
    const cleanClient = (inv.clientName || '').replace(/;/g, ' ');
    const status = inv.isPaid ? 'PAYÉE' : 'EN ATTENTE';
    csvContent += `${inv.id};${inv.date};"${cleanClient}";"${inv.clientCity || ''}";"${inv.whatsappNumber || ''}";"${cleanDesc}";${inv.amount};${status}\n`;
  });

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  const filename = `payper_analytics_${boutiqueName.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${stats.currentRange.start.toISOString().slice(0, 10)}.csv`;
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
