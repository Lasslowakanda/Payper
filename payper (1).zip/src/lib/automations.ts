import {
  Invoice,
  ReminderLog,
  ReminderType,
  RecurringSchedule,
  AutomationSettings,
  RecurrenceFrequency,
} from '../types';
import {
  getBoutique,
  getActiveBoutique,
  getInvoices,
  saveInvoice,
  updateInvoice,
  getUserAccount,
} from './storage';
import { generatePublicInvoiceUrl, buildWhatsAppUrl } from './share';
import { formatCurrency, formatDate } from './invoice';

const STORAGE_KEYS = {
  REMINDER_LOGS_PREFIX: 'payper_reminder_logs_',
  RECURRING_PREFIX: 'payper_recurring_schedules_',
  AUTOMATION_SETTINGS_PREFIX: 'payper_automation_settings_',
  LAST_CRON_RUN_PREFIX: 'payper_last_cron_date_',
};

/**
 * Get the effective business timezone for a boutique (defaulting to Africa/Dakar or Africa/Abidjan / Paris)
 */
export function getBoutiqueTimezone(boutiqueId?: string): string {
  const settings = getAutomationSettings(boutiqueId);
  return settings.timezone || 'Africa/Dakar';
}

/**
 * Get formatted current date string YYYY-MM-DD in the given timezone
 */
export function getTodayDateString(timezone: string = 'Africa/Dakar'): string {
  try {
    const formatter = new Intl.DateTimeFormat('en-CA', {
      timeZone: timezone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
    return formatter.format(new Date()); // Returns "YYYY-MM-DD"
  } catch {
    const now = new Date();
    return now.toISOString().split('T')[0];
  }
}

/**
 * Compute the date difference in integer days: (today - targetDate)
 * All comparisons are done strictly in calendar dates (YYYY-MM-DD)
 */
export function getDaysDifference(targetDateStr: string, timezone: string = 'Africa/Dakar'): number {
  try {
    const todayStr = getTodayDateString(timezone);
    const [tYear, tMonth, tDay] = todayStr.split('-').map(Number);
    const cleanTarget = targetDateStr.split('T')[0];
    const [dYear, dMonth, dDay] = cleanTarget.split('-').map(Number);

    const todayUtc = Date.UTC(tYear, tMonth - 1, tDay);
    const targetUtc = Date.UTC(dYear, dMonth - 1, dDay);

    const msPerDay = 1000 * 60 * 60 * 24;
    return Math.floor((todayUtc - targetUtc) / msPerDay);
  } catch {
    return 0;
  }
}

/**
 * Add days to a YYYY-MM-DD date string and return YYYY-MM-DD
 */
export function addDaysToDate(dateStr: string, days: number): string {
  try {
    const clean = dateStr.split('T')[0];
    const [year, month, day] = clean.split('-').map(Number);
    const date = new Date(Date.UTC(year, month - 1, day));
    date.setUTCDate(date.getUTCDate() + days);
    return date.toISOString().split('T')[0];
  } catch {
    const d = new Date();
    d.setDate(d.getDate() + days);
    return d.toISOString().split('T')[0];
  }
}

/**
 * Calculate next recurrence date based on frequency
 */
export function calculateNextRecurrenceDate(fromDateStr: string, frequency: RecurrenceFrequency): string {
  try {
    const clean = fromDateStr.split('T')[0];
    const [year, month, day] = clean.split('-').map(Number);
    const date = new Date(Date.UTC(year, month - 1, day));

    if (frequency === 'WEEKLY') {
      date.setUTCDate(date.getUTCDate() + 7);
    } else if (frequency === 'MONTHLY') {
      date.setUTCMonth(date.getUTCMonth() + 1);
    } else if (frequency === 'QUARTERLY') {
      date.setUTCMonth(date.getUTCMonth() + 3);
    }
    return date.toISOString().split('T')[0];
  } catch {
    return addDaysToDate(fromDateStr, 30);
  }
}

// ============================================================================
// 1. SETTINGS & CONFIGURATION
// ============================================================================

export function getAutomationSettings(boutiqueId?: string): AutomationSettings {
  const bId = boutiqueId || getActiveBoutique()?.id || 'btq_primary';
  const raw = localStorage.getItem(STORAGE_KEYS.AUTOMATION_SETTINGS_PREFIX + bId);
  if (raw) {
    try {
      return JSON.parse(raw);
    } catch {
      // fallback
    }
  }

  return {
    auto_reminders_enabled: true,
    timezone: 'Africa/Dakar',
    send_hour: '09:00',
    custom_payment_link: '',
  };
}

export function saveAutomationSettings(settings: AutomationSettings, boutiqueId?: string): void {
  const bId = boutiqueId || getActiveBoutique()?.id || 'btq_primary';
  localStorage.setItem(STORAGE_KEYS.AUTOMATION_SETTINGS_PREFIX + bId, JSON.stringify(settings));
  window.dispatchEvent(new Event('payper_automations_updated'));
}

// ============================================================================
// 2. REMINDER LOGS (IDEMPOTENCY & HISTORY)
// ============================================================================

export function getReminderLogs(boutiqueId?: string): ReminderLog[] {
  const bId = boutiqueId || getActiveBoutique()?.id || 'btq_primary';
  const raw = localStorage.getItem(STORAGE_KEYS.REMINDER_LOGS_PREFIX + bId);
  if (raw) {
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  }
  return [];
}

export function hasReminderBeenSent(invoiceId: string, type: ReminderType, boutiqueId?: string): boolean {
  const logs = getReminderLogs(boutiqueId);
  return logs.some(log => log.invoice_id === invoiceId && log.reminder_type === type);
}

export function recordReminderLog(log: Omit<ReminderLog, 'id' | 'sent_at'>): ReminderLog {
  const bId = log.boutique_id || getActiveBoutique()?.id || 'btq_primary';
  const logs = getReminderLogs(bId);

  const fullLog: ReminderLog = {
    ...log,
    id: `rem_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    sent_at: new Date().toISOString(),
  };

  const updated = [fullLog, ...logs];
  localStorage.setItem(STORAGE_KEYS.REMINDER_LOGS_PREFIX + bId, JSON.stringify(updated));
  window.dispatchEvent(new Event('payper_reminders_updated'));
  return fullLog;
}

// ============================================================================
// 3. REMINDER MESSAGE TEMPLATES (PROFESSIONAL & COURTEOUS)
// ============================================================================

export function generateReminderMessage(
  invoice: Invoice,
  type: ReminderType,
  paymentLink?: string
): string {
  const boutique = getActiveBoutique();
  const boutiqueName = invoice.boutiqueName || boutique?.name || 'Notre boutique';
  const amountStr = formatCurrency(invoice.amount, invoice.devise);
  const invoiceUrl = generatePublicInvoiceUrl(invoice);
  const sellerPaymentLink = paymentLink || invoice.payment_link;

  let reminderHeader = '';
  let reminderBody = '';

  if (type === 'J+1') {
    reminderHeader = `Bonjour ${invoice.clientName},`;
    reminderBody = `Sauf erreur de notre part, la facture n° ${invoice.id} d'un montant de ${amountStr} pour « ${invoice.description} » est arrivée à échéance hier.`;
  } else if (type === 'J+3') {
    reminderHeader = `Rappel : Facture ${invoice.id}`;
    reminderBody = `Nous vous rappelons que la facture n° ${invoice.id} (${amountStr}) est en attente de règlement depuis 3 jours.`;
  } else {
    reminderHeader = `Dernière relance : Facture ${invoice.id}`;
    reminderBody = `Votre facture n° ${invoice.id} d'un montant de ${amountStr} auprès de ${boutiqueName} reste en attente de règlement depuis 7 jours.`;
  }

  let paymentInstructions = '';
  if (sellerPaymentLink) {
    paymentInstructions = `\n💳 Lien de paiement direct du vendeur :\n${sellerPaymentLink}\n`;
  } else if (invoice.notes) {
    paymentInstructions = `\n💡 Instructions de paiement : ${invoice.notes}\n`;
  }

  return `${reminderHeader}

${reminderBody}

📄 Consultez ou téléchargez votre facture :
${invoiceUrl}
${paymentInstructions}
*Important : PAYPER est un outil d'émission de factures. Les règlements s'effectuent directement selon les coordonnées transmises par ${boutiqueName}.*

Merci de nous tenir informés dès votre paiement effectué.
Cordialement,
${boutiqueName}`;
}

export function buildReminderWhatsAppUrl(invoice: Invoice, type: ReminderType, paymentLink?: string): string {
  const message = generateReminderMessage(invoice, type, paymentLink);
  const phone = invoice.whatsappNumber || '';
  return buildWhatsAppUrl(phone, message);
}

// ============================================================================
// 4. CRON ENGINE — EVALUATE & PROCESS AUTOMATED REMINDERS
// ============================================================================

export interface ReminderProcessResult {
  date: string;
  processedCount: number;
  triggeredCount: number;
  reminders: {
    invoiceId: string;
    clientName: string;
    type: ReminderType;
    status: 'TRIGGERED' | 'ALREADY_SENT' | 'SKIPPED';
    whatsappUrl?: string;
  }[];
}

/**
 * Execute automated reminders check.
 * Idempotent: checks hasReminderBeenSent for every reminder type.
 * Evaluates invoices where status === 'PENDING' (or !isPaid) and reminders_enabled !== false.
 */
export function runAutomatedRemindersCheck(boutiqueId?: string): ReminderProcessResult {
  const bId = boutiqueId || getActiveBoutique()?.id || 'btq_primary';
  const settings = getAutomationSettings(bId);
  const timezone = settings.timezone || 'Africa/Dakar';
  const todayStr = getTodayDateString(timezone);

  const invoices = getInvoices(bId);
  let triggeredCount = 0;
  const detailedResults: ReminderProcessResult['reminders'] = [];

  // Filter pending eligible invoices
  for (const inv of invoices) {
    const isPending = !inv.isPaid && (inv.status !== 'PAID');
    const isRemindersEnabled = inv.reminders_enabled !== false && settings.auto_reminders_enabled;

    if (!isPending || !isRemindersEnabled) {
      continue;
    }

    // Determine due date (fallback to date + 7 days if dueDate is missing)
    const dueDateStr = inv.dueDate || inv.due_date || inv.date || inv.createdAt;
    if (!dueDateStr) continue;

    const daysPastDue = getDaysDifference(dueDateStr, timezone);

    // Determine if eligible for J+1, J+3, or J+7
    let targetType: ReminderType | null = null;
    if (daysPastDue === 1) {
      targetType = 'J+1';
    } else if (daysPastDue === 3) {
      targetType = 'J+3';
    } else if (daysPastDue === 7) {
      targetType = 'J+7';
    }

    if (!targetType) {
      continue;
    }

    // Idempotency check: has this specific reminder already been recorded/sent?
    const alreadySent = hasReminderBeenSent(inv.id, targetType, bId);
    if (alreadySent) {
      detailedResults.push({
        invoiceId: inv.id,
        clientName: inv.clientName,
        type: targetType,
        status: 'ALREADY_SENT',
      });
      continue;
    }

    // Trigger reminder
    const message = generateReminderMessage(inv, targetType, settings.custom_payment_link);
    const whatsappUrl = buildReminderWhatsAppUrl(inv, targetType, settings.custom_payment_link);

    recordReminderLog({
      invoice_id: inv.id,
      boutique_id: bId,
      client_name: inv.clientName,
      whatsapp_number: inv.whatsappNumber,
      reminder_type: targetType,
      channel: 'WHATSAPP',
      status: 'SENT',
      message_content: message,
      public_url: generatePublicInvoiceUrl(inv),
    });

    triggeredCount++;
    detailedResults.push({
      invoiceId: inv.id,
      clientName: inv.clientName,
      type: targetType,
      status: 'TRIGGERED',
      whatsappUrl,
    });
  }

  // Save last cron execution stamp
  try {
    localStorage.setItem(STORAGE_KEYS.LAST_CRON_RUN_PREFIX + bId, todayStr);
  } catch {
    // silent
  }

  return {
    date: todayStr,
    processedCount: invoices.length,
    triggeredCount,
    reminders: detailedResults,
  };
}

// ============================================================================
// 5. RECURRING INVOICING SCHEDULES (CREATION, CRON, IDEMPOTENCY)
// ============================================================================

export function getRecurringSchedules(boutiqueId?: string): RecurringSchedule[] {
  const bId = boutiqueId || getActiveBoutique()?.id || 'btq_primary';
  const raw = localStorage.getItem(STORAGE_KEYS.RECURRING_PREFIX + bId);
  if (raw) {
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  }
  return [];
}

export function saveRecurringSchedule(schedule: RecurringSchedule): void {
  const bId = schedule.boutique_id || getActiveBoutique()?.id || 'btq_primary';
  const list = getRecurringSchedules(bId);
  const existingIdx = list.findIndex(s => s.id === schedule.id);

  let updated: RecurringSchedule[];
  if (existingIdx >= 0) {
    updated = [...list];
    updated[existingIdx] = schedule;
  } else {
    updated = [schedule, ...list];
  }

  localStorage.setItem(STORAGE_KEYS.RECURRING_PREFIX + bId, JSON.stringify(updated));
  window.dispatchEvent(new Event('payper_recurring_updated'));
}

export function createRecurringSchedule(params: {
  client_name: string;
  client_city?: string;
  whatsapp_number?: string;
  description: string;
  amount: number;
  currency: any;
  frequency: RecurrenceFrequency;
  start_date: string; // YYYY-MM-DD
  due_date_offset_days?: number;
  reminders_enabled?: boolean;
  payment_link?: string;
  notes?: string;
}): RecurringSchedule {
  const boutique = getActiveBoutique();
  const bId = boutique?.id || 'btq_primary';

  const newSchedule: RecurringSchedule = {
    id: `rec_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    boutique_id: bId,
    client_name: params.client_name.trim(),
    client_city: params.client_city?.trim() || boutique?.city || 'Dakar',
    whatsapp_number: params.whatsapp_number?.trim() || '',
    description: params.description.trim(),
    amount: Number(params.amount) || 0,
    currency: params.currency || boutique?.devise || 'FCFA',
    frequency: params.frequency,
    next_run_date: params.start_date.split('T')[0],
    due_date_offset_days: params.due_date_offset_days || 7,
    reminders_enabled: params.reminders_enabled !== false,
    status: 'ACTIVE',
    created_at: new Date().toISOString(),
    generated_invoices_count: 0,
    payment_link: params.payment_link?.trim(),
    notes: params.notes?.trim(),
  };

  saveRecurringSchedule(newSchedule);
  return newSchedule;
}

export function updateRecurringScheduleStatus(id: string, status: 'ACTIVE' | 'PAUSED' | 'CANCELLED'): void {
  const bId = getActiveBoutique()?.id || 'btq_primary';
  const list = getRecurringSchedules(bId);
  const target = list.find(s => s.id === id);
  if (target) {
    target.status = status;
    saveRecurringSchedule(target);
  }
}

export function deleteRecurringSchedule(id: string): void {
  const bId = getActiveBoutique()?.id || 'btq_primary';
  const list = getRecurringSchedules(bId);
  const updated = list.filter(s => s.id !== id);
  localStorage.setItem(STORAGE_KEYS.RECURRING_PREFIX + bId, JSON.stringify(updated));
  window.dispatchEvent(new Event('payper_recurring_updated'));
}

/**
 * Process active recurring schedules whose next_run_date <= today.
 * Generates regular invoices with due date and auto-reminder enabled.
 * Advances schedule next_run_date.
 */
export function processRecurringInvoices(boutiqueId?: string): {
  processedCount: number;
  generatedInvoices: Invoice[];
} {
  const bId = boutiqueId || getActiveBoutique()?.id || 'btq_primary';
  const timezone = getBoutiqueTimezone(bId);
  const todayStr = getTodayDateString(timezone);

  const schedules = getRecurringSchedules(bId);
  const generatedInvoices: Invoice[] = [];

  for (const schedule of schedules) {
    if (schedule.status !== 'ACTIVE') continue;

    // Check if scheduled date has arrived
    if (schedule.next_run_date <= todayStr) {
      // Calculate due date (next_run_date + due_date_offset_days)
      const calculatedDueDate = addDaysToDate(schedule.next_run_date, schedule.due_date_offset_days || 7);

      const boutique = getActiveBoutique();
      const user = getUserAccount();

      // Create new official Invoice
      const year = new Date().getFullYear();
      const randomSuffix = Math.floor(1000 + Math.random() * 9000);
      const invoiceId = `INV-${year}-${randomSuffix}`;

      const newInvoice: Invoice = {
        id: invoiceId,
        invoice_number: invoiceId,
        user_id: user.id,
        store_id: bId,
        client_id: `cli_${schedule.client_name.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
        clientName: schedule.client_name,
        clientCity: schedule.client_city || boutique?.city || 'Dakar',
        whatsappNumber: schedule.whatsapp_number,
        description: schedule.description,
        amount: schedule.amount,
        devise: schedule.currency,
        date: new Date().toISOString(),
        issue_date: schedule.next_run_date,
        dueDate: calculatedDueDate,
        due_date: calculatedDueDate,
        boutiqueName: boutique?.name || 'Ma Boutique',
        boutiqueLogo: boutique?.logo,
        boutiqueCity: boutique?.city || 'Dakar, Sénégal',
        isPaid: false,
        status: 'PENDING',
        reminders_enabled: schedule.reminders_enabled,
        payment_link: schedule.payment_link,
        notes: schedule.notes || (schedule.payment_link ? `Lien de paiement : ${schedule.payment_link}` : ''),
        is_recurring: true,
        recurring_schedule_id: schedule.id,
        createdAt: new Date().toISOString(),
        items: [
          {
            id: '1',
            description: schedule.description,
            quantity: 1,
            price: schedule.amount,
            total: schedule.amount,
          },
        ],
      };

      saveInvoice(newInvoice);
      generatedInvoices.push(newInvoice);

      // Advance schedule next run date
      const nextDate = calculateNextRecurrenceDate(schedule.next_run_date, schedule.frequency);
      schedule.next_run_date = nextDate;
      schedule.last_generated_at = new Date().toISOString();
      schedule.generated_invoices_count = (schedule.generated_invoices_count || 0) + 1;
      saveRecurringSchedule(schedule);
    }
  }

  return {
    processedCount: generatedInvoices.length,
    generatedInvoices,
  };
}

/**
 * MASTER SCHEDULER TICK
 * Runs both recurring generation and automated reminders.
 * Can be called automatically once per day or on demand via button.
 */
export function executeDailyAutomationCycle(boutiqueId?: string) {
  const recurringResult = processRecurringInvoices(boutiqueId);
  const remindersResult = runAutomatedRemindersCheck(boutiqueId);

  return {
    recurringResult,
    remindersResult,
  };
}
