import { ClientSummary, Currency, Invoice } from '../types';
import { getInvoices } from './storage';

export function getClientsSummaries(): ClientSummary[] {
  const invoices = getInvoices();
  const clientsMap = new Map<string, Invoice[]>();

  // Group invoices by trimmed lowercase client name for aggregation
  for (const inv of invoices) {
    const key = inv.clientName.trim().toLowerCase();
    if (!key) continue;
    const existing = clientsMap.get(key) || [];
    existing.push(inv);
    clientsMap.set(key, existing);
  }

  const summaries: ClientSummary[] = [];

  clientsMap.forEach((invs) => {
    // Sort descending by date
    invs.sort((a, b) => new Date(b.date || b.createdAt).getTime() - new Date(a.date || a.createdAt).getTime());

    const latest = invs[0];
    const totalBilled = invs.reduce((sum, inv) => sum + (Number(inv.amount) || 0), 0);
    const totalPaid = invs.filter(inv => inv.isPaid).reduce((sum, inv) => sum + (Number(inv.amount) || 0), 0);
    const totalPending = invs.filter(inv => !inv.isPaid).reduce((sum, inv) => sum + (Number(inv.amount) || 0), 0);

    // Get phone if any invoice had it
    const phone = invs.find(inv => inv.whatsappNumber?.trim())?.whatsappNumber || '';

    summaries.push({
      name: latest.clientName,
      city: latest.clientCity || 'Dakar',
      whatsappNumber: phone,
      invoicesCount: invs.length,
      totalBilled,
      totalPaid,
      totalPending,
      currency: (latest.devise as Currency) || 'FCFA',
      lastInvoiceDate: latest.date || latest.createdAt,
      lastInvoiceId: latest.id,
    });
  });

  return summaries;
}

export function getClientInitials(name: string): string {
  if (!name) return 'CL';
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) {
    return parts[0].slice(0, 2).toUpperCase();
  }
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}
