import { Currency } from '../types';

export interface SupportedCountry {
  country: string;
  flag: string;
  code: string;
  currency: Currency;
  defaultCity: string;
  expectedDigits: string;
  placeholder: string;
  example: string;
  validator: (rawDigits: string) => boolean;
}

export const SUPPORTED_COUNTRIES: SupportedCountry[] = [
  {
    country: 'Sénégal',
    flag: '🇸🇳',
    code: '+221',
    currency: 'FCFA',
    defaultCity: 'Dakar',
    expectedDigits: '9 chiffres',
    placeholder: '77 123 45 67',
    example: '77 123 45 67 ou 78 987 65 43',
    validator: (raw: string) => {
      const d = raw.replace(/\D/g, '');
      return d.length === 9 && /^(7[05-8]|3[3])\d{7}$/.test(d);
    },
  },
  {
    country: "Côte d'Ivoire",
    flag: '🇨🇮',
    code: '+225',
    currency: 'FCFA',
    defaultCity: 'Abidjan',
    expectedDigits: '10 chiffres',
    placeholder: '07 01 23 45 67',
    example: '07 01 23 45 67 ou 05 12 34 56 78',
    validator: (raw: string) => {
      const d = raw.replace(/\D/g, '');
      return d.length === 10;
    },
  },
  {
    country: 'Bénin',
    flag: '🇧🇯',
    code: '+229',
    currency: 'FCFA',
    defaultCity: 'Cotonou',
    expectedDigits: '8 ou 10 chiffres',
    placeholder: '97 12 34 56',
    example: '97 12 34 56 ou 01 97 12 34 56',
    validator: (raw: string) => {
      const d = raw.replace(/\D/g, '');
      return d.length === 8 || d.length === 10;
    },
  },
  {
    country: 'Guinée',
    flag: '🇬🇳',
    code: '+224',
    currency: 'GNF',
    defaultCity: 'Conakry',
    expectedDigits: '9 chiffres',
    placeholder: '620 12 34 56',
    example: '620 12 34 56 ou 664 12 34 56',
    validator: (raw: string) => {
      const d = raw.replace(/\D/g, '');
      return d.length === 9 && /^6/.test(d);
    },
  },
  {
    country: 'Congo-Brazzaville',
    flag: '🇨🇬',
    code: '+242',
    currency: 'FCFA',
    defaultCity: 'Brazzaville',
    expectedDigits: '9 chiffres',
    placeholder: '06 123 45 67',
    example: '06 123 45 67 ou 05 987 65 43',
    validator: (raw: string) => {
      const d = raw.replace(/\D/g, '');
      return d.length === 9;
    },
  },
  {
    country: 'Cameroun',
    flag: '🇨🇲',
    code: '+237',
    currency: 'FCFA',
    defaultCity: 'Douala',
    expectedDigits: '9 chiffres',
    placeholder: '6 90 12 34 56',
    example: '6 90 12 34 56 ou 6 75 12 34 56',
    validator: (raw: string) => {
      const d = raw.replace(/\D/g, '');
      return d.length === 9 && /^[26]/.test(d);
    },
  },
  {
    country: 'Rép. Dém. du Congo (RDC)',
    flag: '🇨🇩',
    code: '+243',
    currency: 'CDF',
    defaultCity: 'Kinshasa',
    expectedDigits: '9 chiffres',
    placeholder: '81 123 45 67',
    example: '81 123 45 67',
    validator: (raw: string) => {
      const d = raw.replace(/\D/g, '');
      return d.length === 9;
    },
  },
  {
    country: 'Mali',
    flag: '🇲🇱',
    code: '+223',
    currency: 'FCFA',
    defaultCity: 'Bamako',
    expectedDigits: '8 chiffres',
    placeholder: '70 12 34 56',
    example: '70 12 34 56',
    validator: (raw: string) => {
      const d = raw.replace(/\D/g, '');
      return d.length === 8;
    },
  },
  {
    country: 'Togo',
    flag: '🇹🇬',
    code: '+228',
    currency: 'FCFA',
    defaultCity: 'Lomé',
    expectedDigits: '8 chiffres',
    placeholder: '90 12 34 56',
    example: '90 12 34 56',
    validator: (raw: string) => {
      const d = raw.replace(/\D/g, '');
      return d.length === 8;
    },
  },
  {
    country: 'Burkina Faso',
    flag: '🇧🇫',
    code: '+226',
    currency: 'FCFA',
    defaultCity: 'Ouagadougou',
    expectedDigits: '8 chiffres',
    placeholder: '70 12 34 56',
    example: '70 12 34 56',
    validator: (raw: string) => {
      const d = raw.replace(/\D/g, '');
      return d.length === 8;
    },
  },
  {
    country: 'Gabon',
    flag: '🇬🇦',
    code: '+241',
    currency: 'FCFA',
    defaultCity: 'Libreville',
    expectedDigits: '7 à 9 chiffres',
    placeholder: '65 12 34 56',
    example: '65 12 34 56',
    validator: (raw: string) => {
      const d = raw.replace(/\D/g, '');
      return d.length >= 7 && d.length <= 9;
    },
  },
  {
    country: 'France / Diaspora',
    flag: '🇫🇷',
    code: '+33',
    currency: 'USD',
    defaultCity: 'Paris',
    expectedDigits: '9 ou 10 chiffres',
    placeholder: '6 12 34 56 78',
    example: '6 12 34 56 78',
    validator: (raw: string) => {
      const d = raw.replace(/\D/g, '');
      return d.length === 9 || d.length === 10;
    },
  },
];

export function getCountryByCode(code: string): SupportedCountry {
  return SUPPORTED_COUNTRIES.find(c => c.code === code) || SUPPORTED_COUNTRIES[0];
}

export function getCountryByName(name: string): SupportedCountry {
  return SUPPORTED_COUNTRIES.find(c => c.country.toLowerCase() === name.toLowerCase()) || SUPPORTED_COUNTRIES[0];
}

export function validatePhoneNumber(code: string, rawDigits: string): { isValid: boolean; message?: string } {
  const cleanDigits = rawDigits.replace(/\D/g, '');
  if (!cleanDigits) {
    return { isValid: false, message: 'Le numéro de téléphone est obligatoire.' };
  }

  const country = getCountryByCode(code);
  const isValid = country.validator(cleanDigits);

  if (!isValid) {
    return {
      isValid: false,
      message: `Numéro incomplet ou invalide pour ${country.country}. Format attendu : ${country.expectedDigits} (ex : ${country.example})`,
    };
  }

  return { isValid: true };
}
