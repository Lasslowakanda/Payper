export type IntegrationStatus = 'CONNECTED' | 'REQUIRES_SETUP' | 'AVAILABLE' | 'COMING_SOON';

export interface IntegrationTrigger {
  id: string;
  name: string;
  description: string;
  isSupported: boolean;
}

export interface IntegrationAction {
  id: string;
  name: string;
  description: string;
  isSupported: boolean;
}

export interface IntegrationApp {
  id: string;
  name: string;
  category: 'automation' | 'marketing' | 'messaging' | 'social' | 'productivity' | 'core';
  shortDescription: string;
  fullDescription: string;
  status: IntegrationStatus;
  statusLabel: string;
  brandColor: string;
  badgeColor: string;
  badgeTextColor: string;
  requiresConfig: boolean;
  configPlaceholder?: string;
  configLabel?: string;
  prerequisites: string[];
  possibleAutomations: {
    title: string;
    description: string;
  }[];
  triggers: IntegrationTrigger[];
  actions: IntegrationAction[];
  docsNote?: string;
  webhookUrl?: string;
}

export interface AutomationWorkflow {
  id: string;
  name: string;
  triggerAppId: string;
  triggerId: string;
  actionAppId: string;
  actionId: string;
  isEnabled: boolean;
  createdAt: string;
}

const STORAGE_KEYS = {
  INTEGRATIONS: 'payper_integrations_settings_v1',
  WORKFLOWS: 'payper_active_workflows_v1',
};

export const INTEGRATIONS_LIST: IntegrationApp[] = [
  {
    id: 'zapier',
    name: 'Zapier',
    category: 'automation',
    shortDescription: 'Connectez PAYPER à plus de 6 000 applications pour synchroniser vos factures et paiements sans code.',
    fullDescription: 'Zapier orchestre les flux de données entre PAYPER et l\'ensemble de votre écosystème SaaS (CRM, comptabilité, messagerie). Grâce aux Webhooks PAYPER, chaque nouvelle facture ou encaissement peut instantanément déclencher des automatisations externes.',
    status: 'REQUIRES_SETUP',
    statusLabel: 'Configuration requise',
    brandColor: '#FF4A00',
    badgeColor: 'bg-orange-50 border-orange-200',
    badgeTextColor: 'text-[#FF4A00]',
    requiresConfig: true,
    configLabel: 'URL de Webhook Zapier (Catch Hook)',
    configPlaceholder: 'https://hooks.zapier.com/hooks/catch/...',
    prerequisites: [
      'Un compte Zapier (formule gratuite ou payante)',
      'Créer un Zap avec le déclencheur « Webhooks by Zapier (Catch Hook) »',
      'Coller l\'URL du webhook généré dans la configuration PAYPER'
    ],
    possibleAutomations: [
      {
        title: 'Synchronisation CRM / Airtable',
        description: 'Dès qu\'une facture est émise dans PAYPER, ajoutez automatiquement une ligne dans Airtable, Notion ou votre CRM.'
      },
      {
        title: 'Notification d\'encaissement d\'équipe',
        description: 'Lorsqu\'une facture est marquée payée, notifiez instantanément votre équipe dans Slack ou Microsoft Teams.'
      },
      {
        title: 'Création de facture depuis un paiement externe',
        description: 'Générez une facture dans PAYPER dès qu\'un paiement Stripe ou PayPal est validé sur votre site.'
      }
    ],
    triggers: [
      { id: 'zap_invoice_created', name: 'Facture émise', description: 'Déclenché dès qu\'une facture est validée dans PAYPER', isSupported: true },
      { id: 'zap_invoice_paid', name: 'Facture payée', description: 'Déclenché quand le statut passe à Payé', isSupported: true },
      { id: 'zap_reminder_sent', name: 'Relance effectuée', description: 'Déclenché après chaque relance J+1, J+3 ou J+7', isSupported: true }
    ],
    actions: [
      { id: 'zap_create_invoice', name: 'Créer une facture', description: 'Génère un nouveau brouillon ou une facture officielle dans PAYPER', isSupported: true },
      { id: 'zap_mark_paid', name: 'Marquer comme payée', description: 'Met à jour le règlement d\'une facture existante', isSupported: true }
    ],
    docsNote: 'Intégration par Webhook standardisé JSON. Aucune clé secrète n\'est requise dans le navigateur.'
  },
  {
    id: 'systeme_io',
    name: 'Systeme.io',
    category: 'marketing',
    shortDescription: 'Générez automatiquement des factures PAYPER conformes pour chaque achat sur vos tunnels de vente.',
    fullDescription: 'Systeme.io est la plateforme marketing tout-en-un pour vos tunnels de vente, cours en ligne et formations. Connectez vos règles d\'automatisation Systeme.io à PAYPER pour fournir instantanément une facture officielle à vos apprenants et clients.',
    status: 'REQUIRES_SETUP',
    statusLabel: 'Configuration requise',
    brandColor: '#0066FF',
    badgeColor: 'bg-blue-50 border-blue-200',
    badgeTextColor: 'text-[#0066FF]',
    requiresConfig: true,
    configLabel: 'URL Webhook de notification Systeme.io',
    configPlaceholder: 'https://api.systeme.io/webhook/notify/...',
    prerequisites: [
      'Un compte Systeme.io avec au moins un tunnel de vente actif',
      'Dans Systeme.io > Automatisations > Règles > Déclencheur « Vente effectuée »',
      'Action « Envoyer un Webhook » avec les coordonnées de l\'acheteur'
    ],
    possibleAutomations: [
      {
        title: 'Facture automatique pour vente de formation',
        description: 'Dès qu\'un client règle une offre sur votre tunnel Systeme.io, PAYPER génère la facture officielle correspondante.'
      },
      {
        title: 'Synchronisation des clients de tunnels',
        description: 'Chaque nouvel acheteur sur Systeme.io est automatiquement ajouté dans votre carnet de clients PAYPER.'
      },
      {
        title: 'Reçu d\'abonnement récurrent',
        description: 'Générez un reçu PAYPER chaque mois pour les abonnements souscrits via Systeme.io.'
      }
    ],
    triggers: [
      { id: 'sio_purchase_completed', name: 'Achat sur tunnel de vente', description: 'Nouvelle commande validée sur Systeme.io', isSupported: true },
      { id: 'sio_contact_subscribed', name: 'Nouveau contact / prospect', description: 'Capture de coordonnées via page de capture', isSupported: true }
    ],
    actions: [
      { id: 'sio_create_invoice', name: 'Générer facture acquittée', description: 'Émet une facture avec le montant exact et la devise de l\'offre', isSupported: true },
      { id: 'sio_sync_client', name: 'Enregistrer client', description: 'Ajoute le client dans le répertoire de la boutique', isSupported: true }
    ],
    docsNote: 'PAYPER traite les webhooks entrants de vente au format JSON de Systeme.io.'
  },
  {
    id: 'whatsapp_business',
    name: 'WhatsApp Business',
    category: 'messaging',
    shortDescription: 'Envoyez les factures, reçus officiels et relances d\'impayés directement dans WhatsApp avec lien de paiement direct.',
    fullDescription: 'WhatsApp est le canal de communication numéro 1 des commerçants et clients en Afrique et dans le monde. PAYPER génère des liens de factures interactifs, des messages professionnels pré-remplis et gère les relances automatiques J+1, J+3 et J+7 sans friction.',
    status: 'CONNECTED',
    statusLabel: 'Prêt & Actif',
    brandColor: '#25D366',
    badgeColor: 'bg-emerald-50 border-emerald-200',
    badgeTextColor: 'text-emerald-700',
    requiresConfig: false,
    prerequisites: [
      'Application WhatsApp ou WhatsApp Business installée sur votre smartphone ou ordinateur',
      'Numéro de téléphone de la boutique renseigné dans les Paramètres',
      'Numéro de téléphone valide pour chaque client'
    ],
    possibleAutomations: [
      {
        title: 'Relances automatiques J+1 / J+3 / J+7',
        description: 'Dès qu\'une facture dépasse sa date d\'échéance, PAYPER prépare le message courtois avec lien de règlement Wave/OM.'
      },
      {
        title: 'Transmission instantanée de facture PDF',
        description: 'Envoyez en 1 clic le lien de téléchargement PDF sécurisé et la vue A4 de la facture.'
      },
      {
        title: 'Reçu de paiement confirmé',
        description: 'Confirmez la bonne réception de l\'argent dès que vous marquez une facture comme payée.'
      }
    ],
    triggers: [
      { id: 'wa_invoice_created', name: 'Facture émise', description: 'Prépare le lien de partage WhatsApp de la facture', isSupported: true },
      { id: 'wa_due_date_passed', name: 'Échéance dépassée', description: 'Prépare la relance J+1, J+3 ou J+7 selon le calendrier', isSupported: true }
    ],
    actions: [
      { id: 'wa_send_invoice_link', name: 'Envoyer lien de facture', description: 'Ouvre la discussion WhatsApp avec le message structuré', isSupported: true },
      { id: 'wa_send_reminder', name: 'Envoyer relance d\'impayé', description: 'Génère le message de rappel avec lien de paiement direct', isSupported: true }
    ],
    docsNote: 'Totalement fonctionnel via l\'API Web et universelle WhatsApp (wa.me / WhatsApp Cloud).'
  },
  {
    id: 'instagram',
    name: 'Instagram',
    category: 'social',
    shortDescription: 'Transmettez vos factures et liens de paiement sécurisés directement en messages privés (DM) à vos acheteurs.',
    fullDescription: 'Idéal pour le Social Commerce et les boutiques qui vendent via posts, reels et stories. Permet de générer des factures instantanées pour vos clients Instagram et d\'envoyer le lien directement dans leur boîte de réception.',
    status: 'COMING_SOON',
    statusLabel: 'Bientôt disponible',
    brandColor: '#E1306C',
    badgeColor: 'bg-neutral-100 border-neutral-200',
    badgeTextColor: 'text-neutral-600',
    requiresConfig: true,
    prerequisites: [
      'Compte Instagram Professionnel ou Créateur',
      'Liaison avec une Page Meta Business vérifiée',
      'Autorisation de l\'API Instagram Messaging'
    ],
    possibleAutomations: [
      {
        title: 'Facture automatique par DM suite à commande en Story',
        description: 'Envoyez un lien de commande et une facture PAYPER dès qu\'un client valide son achat en DM.'
      },
      {
        title: 'Relance discrète par DM pour paniers en attente',
        description: 'Rappelez à un client Instagram sa facture non réglée avant annulation de la réservation.'
      }
    ],
    triggers: [
      { id: 'ig_dm_received', name: 'Message DM de commande', description: 'Détecte une intention d\'achat en DM', isSupported: false }
    ],
    actions: [
      { id: 'ig_send_invoice_dm', name: 'Envoyer facture en DM', description: 'Transmet le lien interactif dans le fil de discussion', isSupported: false }
    ],
    docsNote: 'Actuellement en phase d\'intégration via Meta Graph API v20.'
  },
  {
    id: 'facebook_messenger',
    name: 'Facebook Messenger',
    category: 'messaging',
    shortDescription: 'Envoyez vos factures PAYPER et confirmations de règlement dans les discussions de votre Page Facebook.',
    fullDescription: 'Permet aux vendeurs opérant sur Facebook d\'interagir avec leurs acheteurs Messenger pour transformer une conversation de vente en facture officielle enregistrée dans PAYPER.',
    status: 'COMING_SOON',
    statusLabel: 'Bientôt disponible',
    brandColor: '#0084FF',
    badgeColor: 'bg-neutral-100 border-neutral-200',
    badgeTextColor: 'text-neutral-600',
    requiresConfig: true,
    prerequisites: [
      'Page Facebook gérée par votre compte',
      'Accès administrateur aux paramètres de messagerie Meta'
    ],
    possibleAutomations: [
      {
        title: 'Envoi de facture dans la conversation Messenger',
        description: 'Transmettez le lien public PAYPER dès la confirmation du devis en discussion.'
      },
      {
        title: 'Rappel d\'échéance automatisé',
        description: 'Notifiez le client sur Messenger 24h avant la date limite de paiement convenue.'
      }
    ],
    triggers: [
      { id: 'fbm_order_message', name: 'Discussion de commande initiée', description: 'Message clé de commande dans Messenger', isSupported: false }
    ],
    actions: [
      { id: 'fbm_send_card', name: 'Envoyer fiche de facture', description: 'Affiche la carte de paiement dans Messenger', isSupported: false }
    ],
    docsNote: 'Intégration programmée avec Meta Messenger Platform.'
  },
  {
    id: 'facebook',
    name: 'Facebook',
    category: 'social',
    shortDescription: 'Synchronisez les commandes de votre Boutique Facebook / Marketplace pour éditer les factures associées.',
    fullDescription: 'Connectez votre vitrine Facebook Commerce Manager pour que chaque commande passée par vos abonnés génère automatiquement sa facture de vente dans PAYPER.',
    status: 'COMING_SOON',
    statusLabel: 'Bientôt disponible',
    brandColor: '#1877F2',
    badgeColor: 'bg-neutral-100 border-neutral-200',
    badgeTextColor: 'text-neutral-600',
    requiresConfig: true,
    prerequisites: [
      'Boutique Facebook configurée dans Meta Commerce Manager',
      'Catalogue de produits actif'
    ],
    possibleAutomations: [
      {
        title: 'Facturation automatique des ventes Boutique Facebook',
        description: 'Générez la facture officielle au nom de l\'acheteur dès validation sur Facebook.'
      }
    ],
    triggers: [
      { id: 'fb_order_placed', name: 'Commande validée sur Facebook Shop', description: 'Nouvel achat dans la vitrine Facebook', isSupported: false }
    ],
    actions: [
      { id: 'fb_create_receipt', name: 'Générer facture acquittée', description: 'Émet la facture correspondante dans PAYPER', isSupported: false }
    ],
    docsNote: 'Nécessite la validation des autorisations Meta Business App.'
  },
  {
    id: 'google_sheets',
    name: 'Google Sheets',
    category: 'productivity',
    shortDescription: 'Exportez et synchronisez en temps réel chaque facture émise et chaque paiement encaissé dans un tableur.',
    fullDescription: 'Gardez une vue consolidée de votre comptabilité. Chaque facture créée ou réglée sur PAYPER ajoute instantanément une ligne dans votre feuille de calcul Google Sheets, avec les colonnes client, montant, devise, date et statut.',
    status: 'REQUIRES_SETUP',
    statusLabel: 'Configuration requise',
    brandColor: '#0F9D58',
    badgeColor: 'bg-emerald-50 border-emerald-200',
    badgeTextColor: 'text-[#0F9D58]',
    requiresConfig: true,
    configLabel: 'URL du Webhook Google Sheets (Apps Script)',
    configPlaceholder: 'https://script.google.com/macros/s/.../exec',
    prerequisites: [
      'Un compte Google (Google Drive / Sheets)',
      'Une feuille de calcul avec colonnes (Date, Numéro, Client, Montant, Devise, Statut)',
      'Déployer le script Webhook Google Apps Script en tant qu\'application Web'
    ],
    possibleAutomations: [
      {
        title: 'Livre de recettes en direct',
        description: 'Ajoutez une ligne dans votre tableur comptable dès qu\'une facture est émise.'
      },
      {
        title: 'Mise à jour du statut lors de l\'encaissement',
        description: 'Passez le statut de la ligne de « En attente » à « Payé » dès que vous confirmez le paiement dans PAYPER.'
      }
    ],
    triggers: [
      { id: 'gs_invoice_saved', name: 'Facture enregistrée', description: 'Lorsque la facture est sauvegardée', isSupported: true },
      { id: 'gs_status_changed', name: 'Changement de statut de paiement', description: 'Lors d\'une mise à jour de facture', isSupported: true }
    ],
    actions: [
      { id: 'gs_append_row', name: 'Ajouter une ligne au tableau', description: 'Insère les détails de la facture dans la feuille active', isSupported: true },
      { id: 'gs_update_row', name: 'Mettre à jour le statut', description: 'Actualise la ligne correspondante au numéro de facture', isSupported: true }
    ],
    docsNote: 'Connexion directe sans exposer vos identifiants Google grâce à l\'URL Webhook Apps Script.'
  },
  {
    id: 'google_calendar',
    name: 'Google Calendar',
    category: 'productivity',
    shortDescription: 'Inscrivez automatiquement les dates d\'échéance de factures et rappels de paiement dans votre agenda Google.',
    fullDescription: 'Ne ratez aucun encaissement important. PAYPER crée un événement ou un rappel discret dans votre calendrier Google pour chaque facture client arrivant à échéance.',
    status: 'COMING_SOON',
    statusLabel: 'Bientôt disponible',
    brandColor: '#4285F4',
    badgeColor: 'bg-neutral-100 border-neutral-200',
    badgeTextColor: 'text-neutral-600',
    requiresConfig: true,
    prerequisites: [
      'Compte Google Agenda personnel ou Workspace',
      'Autorisation d\'accès à l\'agenda de suivi commercial'
    ],
    possibleAutomations: [
      {
        title: 'Rappel d\'échéance dans l\'agenda',
        description: 'Création d\'un événement à la date d\'échéance avec le nom du client et le montant à encaisser.'
      },
      {
        title: 'Blocage des relances le week-end',
        description: 'Décale automatiquement les relances automatiques au lundi suivant.'
      }
    ],
    triggers: [
      { id: 'gc_due_date_set', name: 'Date d\'échéance définie', description: 'Lors de la création de la facture', isSupported: false }
    ],
    actions: [
      { id: 'gc_create_event', name: 'Créer événement d\'échéance', description: 'Ajoute le rappel dans l\'agenda sélectionné', isSupported: false }
    ],
    docsNote: 'Intégration via Google Calendar API en cours de finalisation.'
  },
  {
    id: 'email',
    name: 'E-mail',
    category: 'messaging',
    shortDescription: 'Transmettez vos factures professionnelles en PDF et vos reçus par courrier électronique sécurisé.',
    fullDescription: 'L\'envoi par e-mail reste indispensable pour les clients institutionnels, les grandes entreprises et les commandes B2B nécessitant une trace comptable formelle. PAYPER permet d\'envoyer le récapitulatif avec lien sécurisé et attachement.',
    status: 'CONNECTED',
    statusLabel: 'Prêt & Actif',
    brandColor: '#4F46E5',
    badgeColor: 'bg-indigo-50 border-indigo-200',
    badgeTextColor: 'text-indigo-700',
    requiresConfig: false,
    prerequisites: [
      'Adresse e-mail valide du client',
      'Client de messagerie configuré ou passerelle d\'envoi'
    ],
    possibleAutomations: [
      {
        title: 'Envoi automatique de facture PDF',
        description: 'Prépare le courrier avec objet structuré (Facture #PAY-xxx - Boutique) et lien de paiement direct.'
      },
      {
        title: 'Reçu de paiement par e-mail',
        description: 'Envoi d\'une confirmation écrite dès que la facture est marquée payée.'
      }
    ],
    triggers: [
      { id: 'mail_invoice_created', name: 'Nouvelle facture émise', description: 'Génère le corps de message prêt à l\'envoi', isSupported: true },
      { id: 'mail_paid_confirmed', name: 'Paiement reçu', description: 'Génère le reçu d\'encaissement officiel', isSupported: true }
    ],
    actions: [
      { id: 'mail_send_link', name: 'Transmettre par e-mail', description: 'Ouvre le modèle d\'envoi avec coordonnées pré-remplies', isSupported: true }
    ],
    docsNote: 'Pris en charge nativement via les passerelles e-mail standard et mailto.'
  },
  {
    id: 'payper',
    name: 'PAYPER',
    category: 'core',
    shortDescription: 'Moteur d\'automatisation interne : calendrier d\'impayés, calcul d\'échéances et facturation récurrente.',
    fullDescription: 'Le cœur natif de PAYPER fonctionne en continu pour votre boutique. Il calcule quotidiennement les retards de paiement, planifie les relances J+1, J+3 et J+7 selon le fuseau horaire de votre boutique et déclenche les abonnements récurrents.',
    status: 'CONNECTED',
    statusLabel: 'Connecté (Natif)',
    brandColor: '#FF8A00',
    badgeColor: 'bg-orange-50 border-orange-200',
    badgeTextColor: 'text-[#FF8A00]',
    requiresConfig: false,
    prerequisites: [
      'Boutique PAYPER active',
      'Règles d\'automatisation activées dans l\'onglet Règles & Cron'
    ],
    possibleAutomations: [
      {
        title: 'Calcul quotidien des relances à 09:00',
        description: 'Exécution quotidienne selon le fuseau horaire de la boutique pour repérer les factures échues.'
      },
      {
        title: 'Émission automatique des abonnements récurrents',
        description: 'Génération automatique des factures hebdomadaires, mensuelles ou trimestrielles à la date prévue.'
      },
      {
        title: 'Journal d\'audit et détection des doublons',
        description: 'Garantie d\'idempotence stricte pour ne jamais relancer deux fois le même client pour la même échéance.'
      }
    ],
    triggers: [
      { id: 'pp_cron_daily', name: 'Cycle quotidien automatique', description: 'Exécuté chaque matin à l\'heure planifiée', isSupported: true },
      { id: 'pp_recurring_due', name: 'Échéance d\'abonnement atteinte', description: 'Date de récurrence arrivée à échéance', isSupported: true },
      { id: 'pp_invoice_overdue', name: 'Retard de paiement constaté', description: 'Facture impayée après dépassement d\'échéance', isSupported: true }
    ],
    actions: [
      { id: 'pp_generate_recurring_invoice', name: 'Émettre la facture d\'abonnement', description: 'Crée la facture et met à jour le calendrier', isSupported: true },
      { id: 'pp_log_reminder', name: 'Enregistrer la relance dans le journal', description: 'Consigne l\'action pour traçabilité', isSupported: true }
    ],
    docsNote: 'Intégré au moteur local de l\'application. Actif par défaut sans configuration supplémentaire.'
  }
];

export interface IntegrationsConfig {
  [appId: string]: {
    webhookUrl?: string;
    isConnected?: boolean;
    lastUpdated?: string;
  };
}

export function getIntegrationsConfig(): IntegrationsConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.INTEGRATIONS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Error reading integrations config', e);
  }
  return {
    payper: { isConnected: true },
    whatsapp_business: { isConnected: true },
    email: { isConnected: true },
  };
}

export function saveIntegrationConfig(appId: string, webhookUrl: string, isConnected: boolean): void {
  try {
    const current = getIntegrationsConfig();
    current[appId] = {
      webhookUrl: webhookUrl.trim(),
      isConnected,
      lastUpdated: new Date().toISOString(),
    };
    localStorage.setItem(STORAGE_KEYS.INTEGRATIONS, JSON.stringify(current));
    window.dispatchEvent(new Event('payper_integrations_updated'));
  } catch (e) {
    console.error('Error saving integration config', e);
  }
}

export function getEffectiveIntegrations(): IntegrationApp[] {
  const configs = getIntegrationsConfig();
  return INTEGRATIONS_LIST.map(app => {
    const userCfg = configs[app.id];
    if (app.id === 'payper' || app.id === 'whatsapp_business' || app.id === 'email') {
      return { ...app, status: 'CONNECTED', statusLabel: 'Connecté' };
    }
    if (app.requiresConfig && userCfg?.webhookUrl && userCfg?.isConnected) {
      return {
        ...app,
        status: 'CONNECTED',
        statusLabel: 'Connecté',
        webhookUrl: userCfg.webhookUrl,
      };
    }
    return app;
  });
}

// Workflows Store
export function getSavedWorkflows(): AutomationWorkflow[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.WORKFLOWS);
    if (raw) {
      const list = JSON.parse(raw);
      if (Array.isArray(list)) return list;
    }
  } catch (e) {
    console.error('Error reading saved workflows', e);
  }

  // Default initial workflows
  return [
    {
      id: 'wf_default_1',
      name: 'Relances automatiques WhatsApp (J+1 / J+3 / J+7)',
      triggerAppId: 'payper',
      triggerId: 'pp_invoice_overdue',
      actionAppId: 'whatsapp_business',
      actionId: 'wa_send_reminder',
      isEnabled: true,
      createdAt: '2026-01-01T00:00:00Z',
    },
    {
      id: 'wf_default_2',
      name: 'Facturation automatique des abonnements récurrents',
      triggerAppId: 'payper',
      triggerId: 'pp_recurring_due',
      actionAppId: 'payper',
      actionId: 'pp_generate_recurring_invoice',
      isEnabled: true,
      createdAt: '2026-01-01T00:00:00Z',
    },
    {
      id: 'wf_default_3',
      name: 'Envoi du lien de facture par WhatsApp après émission',
      triggerAppId: 'payper',
      triggerId: 'zap_invoice_created',
      actionAppId: 'whatsapp_business',
      actionId: 'wa_send_invoice_link',
      isEnabled: true,
      createdAt: '2026-01-01T00:00:00Z',
    },
  ];
}

export function saveWorkflow(workflow: AutomationWorkflow): void {
  try {
    const list = getSavedWorkflows();
    const existingIdx = list.findIndex(w => w.id === workflow.id);
    if (existingIdx >= 0) {
      list[existingIdx] = workflow;
    } else {
      list.unshift(workflow);
    }
    localStorage.setItem(STORAGE_KEYS.WORKFLOWS, JSON.stringify(list));
    window.dispatchEvent(new Event('payper_workflows_updated'));
  } catch (e) {
    console.error('Error saving workflow', e);
  }
}

export function toggleWorkflowStatus(id: string): void {
  try {
    const list = getSavedWorkflows();
    const item = list.find(w => w.id === id);
    if (item) {
      item.isEnabled = !item.isEnabled;
      localStorage.setItem(STORAGE_KEYS.WORKFLOWS, JSON.stringify(list));
      window.dispatchEvent(new Event('payper_workflows_updated'));
    }
  } catch (e) {
    console.error('Error toggling workflow', e);
  }
}

export function deleteWorkflow(id: string): void {
  try {
    const list = getSavedWorkflows().filter(w => w.id !== id);
    localStorage.setItem(STORAGE_KEYS.WORKFLOWS, JSON.stringify(list));
    window.dispatchEvent(new Event('payper_workflows_updated'));
  } catch (e) {
    console.error('Error deleting workflow', e);
  }
}
