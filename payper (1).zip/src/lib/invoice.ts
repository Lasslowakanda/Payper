import html2canvas from 'html2canvas';
import { Currency, Invoice, InvoiceItem } from '../types';
import { getBoutique, getInvoices, saveInvoice } from './storage';

export const CURRENCIES: { code: Currency; label: string; flag: string; symbol: string }[] = [
  { code: 'FCFA', label: 'FCFA (Franc CFA)', flag: '🇸🇳', symbol: 'FCFA' },
  { code: 'CDF', label: 'CDF (Franc Congolais)', flag: '🇨🇩', symbol: 'CDF' },
  { code: 'GNF', label: 'GNF (Franc Guinéen)', flag: '🇬🇳', symbol: 'GNF' },
  { code: 'USD', label: 'USD (Dollar US)', flag: '🇺🇸', symbol: '$' },
];

/**
 * Generates a truly unique invoice ID in format INV-YYYY-XXXX
 * Never relies solely on invoices.length to prevent collision on deletion
 */
export function generateInvoiceId(): string {
  const year = new Date().getFullYear();
  const existing = getInvoices();
  const existingIds = new Set(existing.map(i => i.id));

  // Generate a random 4-digit or letter code, or sequential safe number
  for (let attempt = 0; attempt < 50; attempt++) {
    // 1000 to 9999 or random alphanumeric
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const candidate = `INV-${year}-${randomSuffix}`;
    if (!existingIds.has(candidate)) {
      return candidate;
    }
  }

  // Fallback with timestamp slice
  const uniqueStamp = Date.now().toString().slice(-4);
  return `INV-${year}-${uniqueStamp}`;
}

export function formatCurrency(amount: number, currency: Currency = 'FCFA'): string {
  if (isNaN(amount) || amount === null || amount === undefined) {
    amount = 0;
  }

  // Format with space thousands separator
  const formattedNumber = new Intl.NumberFormat('fr-FR', {
    maximumFractionDigits: currency === 'USD' ? 2 : 0,
    minimumFractionDigits: currency === 'USD' ? 2 : 0,
  }).format(amount);

  if (currency === 'USD') {
    return `$${formattedNumber}`;
  }

  return `${formattedNumber} ${currency}`;
}

export function formatDate(dateString: string): string {
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return new Intl.DateTimeFormat('fr-FR', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    }).format(d);
  } catch {
    return dateString;
  }
}

export function createNewInvoice(params: {
  clientName: string;
  clientCity: string;
  description: string;
  amount: number;
  devise?: Currency;
  isPaid: boolean;
  whatsappNumber?: string;
  dueDate?: string;
  reminders_enabled?: boolean;
  payment_link?: string;
  notes?: string;
  items?: InvoiceItem[];
}): Invoice {
  const boutique = getBoutique();
  const currency: Currency = params.devise || boutique?.devise || 'FCFA';

  const issueDate = new Date().toISOString();
  // Default dueDate to 7 days from now if not specified
  const defaultDueDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  const finalDueDate = params.dueDate || defaultDueDate;

  const newInvoice: Invoice = {
    id: generateInvoiceId(),
    clientName: params.clientName.trim(),
    clientCity: params.clientCity.trim() || 'Dakar',
    whatsappNumber: params.whatsappNumber?.trim() || '',
    description: params.description.trim(),
    amount: Number(params.amount) || 0,
    devise: currency,
    date: issueDate,
    dueDate: finalDueDate,
    issue_date: issueDate.split('T')[0],
    due_date: finalDueDate,
    boutiqueName: boutique?.name || 'Ma Boutique',
    boutiqueLogo: boutique?.logo,
    boutiqueCity: boutique?.city || 'Dakar, Sénégal',
    isPaid: Boolean(params.isPaid),
    status: params.isPaid ? 'PAID' : 'PENDING',
    reminders_enabled: params.reminders_enabled !== undefined ? params.reminders_enabled : true,
    payment_link: params.payment_link?.trim() || undefined,
    notes: params.notes?.trim() || '',
    items: params.items && params.items.length > 0 ? params.items : [
      {
        id: '1',
        description: params.description.trim(),
        quantity: 1,
        price: Number(params.amount) || 0,
        total: Number(params.amount) || 0,
      }
    ],
    createdAt: issueDate,
  };

  saveInvoice(newInvoice);
  return newInvoice;
}

/**
 * Wait helper for browser animation frames and fonts
 */
async function prepareInvoiceForCapture(element: HTMLElement): Promise<void> {
  // 1. Wait at least 2 animation frames and short settle delay (150ms) to ensure DOM layout & paint
  await new Promise<void>((resolve) => {
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        setTimeout(resolve, 150);
      });
    });
  });

  // 2. Wait for web fonts if document.fonts is supported
  if (typeof document !== 'undefined' && 'fonts' in document && (document as any).fonts?.ready) {
    try {
      await (document as any).fonts.ready;
    } catch {
      // Non-blocking fallback
    }
  }

  // 3. Wait for all <img> tags inside the invoice to be loaded
  const imgElements = Array.from(element.querySelectorAll('img'));
  if (imgElements.length > 0) {
    await Promise.all(
      imgElements.map((img) => {
        if (img.complete && img.naturalWidth > 0) {
          return Promise.resolve(true);
        }
        return new Promise<boolean>((resolve) => {
          const done = () => resolve(true);
          img.addEventListener('load', done, { once: true });
          img.addEventListener('error', done, { once: true });
          setTimeout(done, 3500); // 3.5s timeout so broken images never block invoice generation
        });
      })
    );
  }
}

/**
 * Helper to render SVG string onto a canvas in widescreen format (1600x960)
 */
async function renderSvgToCanvas(
  svgString: string,
  width = 1600,
  height = 960
): Promise<HTMLCanvasElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);

    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          URL.revokeObjectURL(url);
          return reject(new Error('Canvas 2D context unavailable'));
        }
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
        URL.revokeObjectURL(url);
        resolve(canvas);
      } catch (e) {
        URL.revokeObjectURL(url);
        reject(e);
      }
    };
    img.onerror = (e) => {
      URL.revokeObjectURL(url);
      reject(e);
    };
    img.src = url;
  });
}

/**
 * DIRECT CANVAS RENDERER: Renders an ultra-clean, high-definition (1600x960)
 * Payper invoice in horizontal landscape rectangle format (largeur longue, longueur/hauteur compacte).
 * Toutes les polices et logos sont agrandis pour une lisibilité maximale et un remplissage intégral du rectangle.
 */
export async function renderInvoiceDirectToCanvas(
  invoice: Invoice
): Promise<HTMLCanvasElement> {
  const width = 1600;
  const height = 960;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas 2D context unavailable');

  // 1. Fond blanc immaculé
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, width, height);

  // 2. Double bordure extérieure raffinée
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.roundRect(14, 14, width - 28, height - 28, 22);
  ctx.stroke();

  ctx.strokeStyle = '#F1F5F9';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.roundRect(18, 18, width - 36, height - 36, 18);
  ctx.stroke();

  // 3. Barre d'accent supérieure dégradée élégante (Orange vers Vert émeraude)
  const grad = ctx.createLinearGradient(40, 0, width - 40, 0);
  grad.addColorStop(0, '#FF8A00');
  grad.addColorStop(0.5, '#FFAA33');
  grad.addColorStop(1, '#00C48C');
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.roundRect(40, 22, width - 80, 7, 4);
  ctx.fill();

  const padX = 42;
  const rightX = width - padX;

  // 4. Charger le logo boutique si présent
  let logoImg: HTMLImageElement | null = null;
  if (invoice.boutiqueLogo) {
    try {
      logoImg = await new Promise<HTMLImageElement | null>((res) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        const timer = setTimeout(() => res(null), 1200);
        img.onload = () => { clearTimeout(timer); res(img); };
        img.onerror = () => { clearTimeout(timer); res(null); };
        img.src = invoice.boutiqueLogo!;
      });
    } catch {
      logoImg = null;
    }
  }

  // 5. Filigrane / Tampon arrière-plan au centre
  ctx.save();
  ctx.translate(width / 2 + 140, height / 2 - 10);
  ctx.rotate((-11 * Math.PI) / 180);
  if (invoice.isPaid) {
    ctx.strokeStyle = 'rgba(0, 196, 140, 0.18)';
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.roundRect(-180, -50, 360, 100, 20);
    ctx.stroke();
    ctx.fillStyle = 'rgba(0, 196, 140, 0.22)';
    ctx.font = '900 62px Poppins, -apple-system, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('PAYÉ', 0, 0);
  } else {
    ctx.strokeStyle = 'rgba(255, 138, 0, 0.20)';
    ctx.lineWidth = 6;
    ctx.setLineDash([14, 10]);
    ctx.beginPath();
    ctx.roundRect(-270, -42, 540, 84, 18);
    ctx.stroke();
    ctx.fillStyle = 'rgba(255, 138, 0, 0.24)';
    ctx.font = '900 32px Poppins, -apple-system, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('EN ATTENTE DE RÈGLEMENT', 0, 0);
  }
  ctx.restore();

  // 6. EN-TÊTE SUPÉRIEUR (Y: 44 à 168)
  const headerY = 46;
  const logoBoxSize = 96; // Logo grand et imposant

  if (logoImg) {
    ctx.save();
    ctx.beginPath();
    ctx.roundRect(padX, headerY, logoBoxSize, logoBoxSize, 20);
    ctx.clip();
    ctx.drawImage(logoImg, padX, headerY, logoBoxSize, logoBoxSize);
    ctx.restore();
    ctx.strokeStyle = '#E2E8F0';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.roundRect(padX, headerY, logoBoxSize, logoBoxSize, 20);
    ctx.stroke();
  } else {
    // Squircle stylisé dégradé avec lettre capitale imposante
    const logoGrad = ctx.createLinearGradient(padX, headerY, padX + logoBoxSize, headerY + logoBoxSize);
    logoGrad.addColorStop(0, '#FF8A00');
    logoGrad.addColorStop(1, '#FF5500');
    ctx.fillStyle = logoGrad;
    ctx.beginPath();
    ctx.roundRect(padX, headerY, logoBoxSize, logoBoxSize, 22);
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 50px Poppins, -apple-system, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const initial = (invoice.boutiqueName || 'B').charAt(0).toUpperCase();
    ctx.fillText(initial, padX + logoBoxSize / 2, headerY + logoBoxSize / 2);
  }

  // Nom et détails boutique (Grandes polices)
  const boutiqueTextX = padX + logoBoxSize + 22;
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';

  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 34px Poppins, -apple-system, sans-serif';
  ctx.fillText(invoice.boutiqueName || 'Ma Boutique', boutiqueTextX, headerY + 6);

  ctx.fillStyle = '#64748B';
  ctx.font = '600 18px Poppins, sans-serif';
  ctx.fillText(invoice.boutiqueCity || 'Dakar, Sénégal', boutiqueTextX, headerY + 48);

  ctx.fillStyle = '#059669';
  ctx.font = '500 16px Poppins, sans-serif';
  ctx.fillText('✓ Commerce vérifié & certifié', boutiqueTextX, headerY + 74);

  // Droite de l'en-tête : Badge FACTURE, Numéro et Dates
  ctx.textAlign = 'right';
  ctx.textBaseline = 'top';

  ctx.fillStyle = '#94A3B8';
  ctx.font = 'bold 15px Poppins, sans-serif';
  ctx.fillText('FACTURE OFFICIELLE', rightX, headerY + 4);

  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 36px Poppins, monospace';
  ctx.fillText(invoice.id, rightX, headerY + 24);

  ctx.fillStyle = '#475569';
  ctx.font = '600 18px Poppins, sans-serif';
  const formattedDate = formatDate(invoice.date || invoice.createdAt || '');
  ctx.fillText(`Date d'émission : ${formattedDate}`, rightX, headerY + 68);

  // Ligne de séparation sous l'en-tête
  const sepY = headerY + 118;
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(padX, sepY);
  ctx.lineTo(rightX, sepY);
  ctx.stroke();

  // 7. CORPS PRINCIPAL : DISPOSITION 2 COLONNES REMPLISSANT TOUT LE RECTANGLE
  // Left Column (Largeur: 490px)
  // Right Column (Largeur: 986px)
  const colLeftX = padX;
  const colLeftW = 490;
  const colRightX = colLeftX + colLeftW + 42;
  const colRightW = rightX - colRightX;

  // Hauteur totale utile : de sepY + 18 (182) à footerY - 26 (860) = 678px !
  const bodyTopY = sepY + 18;
  const bodyBottomY = 860;

  // --- COLONNE GAUCHE ---
  // Card 1 : CLIENT / FACTURÉ À (h = 175)
  const clientCardH = 175;
  ctx.fillStyle = '#F8FAFC';
  ctx.beginPath();
  ctx.roundRect(colLeftX, bodyTopY, colLeftW, clientCardH, 18);
  ctx.fill();
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  ctx.fillStyle = '#64748B';
  ctx.font = 'bold 13px Poppins, sans-serif';
  ctx.fillText('FACTURÉ À (CLIENT) :', colLeftX + 22, bodyTopY + 18);

  ctx.fillStyle = '#0F172A';
  ctx.font = 'bold 26px Poppins, sans-serif';
  let clientDisplay = invoice.clientName;
  if (clientDisplay.length > 28) clientDisplay = clientDisplay.slice(0, 26) + '...';
  ctx.fillText(clientDisplay, colLeftX + 22, bodyTopY + 44);

  ctx.fillStyle = '#475569';
  ctx.font = '600 18px Poppins, sans-serif';
  ctx.fillText(`📍 ${invoice.clientCity || 'Dakar'}`, colLeftX + 22, bodyTopY + 84);

  if (invoice.whatsappNumber) {
    ctx.fillStyle = '#059669';
    ctx.font = '600 17px Poppins, sans-serif';
    ctx.fillText(`📞 WhatsApp : ${invoice.whatsappNumber}`, colLeftX + 22, bodyTopY + 118);
  } else {
    ctx.fillStyle = '#64748B';
    ctx.font = '500 16px Poppins, sans-serif';
    ctx.fillText('Client enregistré au répertoire', colLeftX + 22, bodyTopY + 118);
  }

  // Card 2 : STATUT DU PAIEMENT (h = 160)
  const statusCardY = bodyTopY + clientCardH + 16;
  const statusCardH = 160;

  if (invoice.isPaid) {
    ctx.fillStyle = '#ECFDF5';
    ctx.strokeStyle = '#A7F3D0';
  } else {
    ctx.fillStyle = '#FFFBEB';
    ctx.strokeStyle = '#FDE68A';
  }
  ctx.beginPath();
  ctx.roundRect(colLeftX, statusCardY, colLeftW, statusCardH, 18);
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.fillStyle = invoice.isPaid ? '#059669' : '#D97706';
  ctx.font = 'bold 13px Poppins, sans-serif';
  ctx.fillText('STATUT DU RÈGLEMENT :', colLeftX + 22, statusCardY + 18);

  ctx.fillStyle = invoice.isPaid ? '#047857' : '#B45309';
  ctx.font = '900 24px Poppins, sans-serif';
  ctx.fillText(
    invoice.isPaid ? '✓ FACTURE PAYÉE INTÉGRALEMENT' : '⏳ EN ATTENTE DE RÈGLEMENT',
    colLeftX + 22,
    statusCardY + 48
  );

  ctx.fillStyle = invoice.isPaid ? '#065F46' : '#92400E';
  ctx.font = '600 17px Poppins, sans-serif';
  if (invoice.isPaid) {
    ctx.fillText('Paiement acquitté avec succès', colLeftX + 22, statusCardY + 88);
  } else if (invoice.dueDate) {
    ctx.fillText(`Échéance limite : ${formatDate(invoice.dueDate)}`, colLeftX + 22, statusCardY + 88);
  } else {
    ctx.fillText('Règlement exigible à réception', colLeftX + 22, statusCardY + 88);
  }

  // Card 3 : MODALITÉS DE RÈGLEMENT & NOTES (s'étire jusqu'à bodyBottomY pour remplir 100% de la colonne !)
  const notesCardY = statusCardY + statusCardH + 16;
  const notesCardH = bodyBottomY - notesCardY;

  ctx.fillStyle = '#F8FAFC';
  ctx.beginPath();
  ctx.roundRect(colLeftX, notesCardY, colLeftW, notesCardH, 18);
  ctx.fill();
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 2;
  ctx.stroke();

  let noteInsideY = notesCardY + 20;
  ctx.fillStyle = '#334155';
  ctx.font = 'bold 14px Poppins, sans-serif';
  ctx.fillText('MODALITÉS DE PAIEMENT :', colLeftX + 22, noteInsideY);
  noteInsideY += 28;

  ctx.fillStyle = '#1E293B';
  ctx.font = '600 17px Poppins, sans-serif';
  ctx.fillText('• Wave, Orange Money, M-Pesa acceptés', colLeftX + 22, noteInsideY);
  noteInsideY += 26;

  ctx.fillStyle = '#475569';
  ctx.font = '500 16px Poppins, sans-serif';
  ctx.fillText('• Virement bancaire & règlement direct', colLeftX + 22, noteInsideY);
  noteInsideY += 34;

  if (invoice.notes) {
    ctx.fillStyle = '#334155';
    ctx.font = 'bold 14px Poppins, sans-serif';
    ctx.fillText('Notes & Instructions :', colLeftX + 22, noteInsideY);
    noteInsideY += 22;

    ctx.fillStyle = '#475569';
    ctx.font = '500 15px Poppins, sans-serif';
    let cleanNotes = invoice.notes;
    if (cleanNotes.length > 52) cleanNotes = cleanNotes.slice(0, 50) + '...';
    ctx.fillText(cleanNotes, colLeftX + 22, noteInsideY);
    noteInsideY += 30;
  }

  if (invoice.payment_link) {
    ctx.fillStyle = '#EA580C';
    ctx.font = 'bold 13px Poppins, sans-serif';
    ctx.fillText('Lien de règlement direct :', colLeftX + 22, noteInsideY);
    noteInsideY += 20;

    ctx.fillStyle = '#C2410C';
    ctx.font = '600 14px Poppins, monospace';
    ctx.fillText(invoice.payment_link.slice(0, 44), colLeftX + 22, noteInsideY);
  }

  // --- COLONNE DROITE ---
  // Tableau complet des articles + Encart Total Orange géant occupant tout l'espace
  const tableHeaderH = 52;
  ctx.fillStyle = '#F1F5F9';
  ctx.beginPath();
  ctx.roundRect(colRightX, bodyTopY, colRightW, tableHeaderH, 14);
  ctx.fill();
  ctx.strokeStyle = '#CBD5E1';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  const colDescX = colRightX + 24;
  const colQtyX = colRightX + colRightW * 0.54;
  const colPriceX = colRightX + colRightW * 0.76;
  const colTotalX = rightX - 24;

  ctx.fillStyle = '#334155';
  ctx.font = 'bold 15px Poppins, sans-serif';
  ctx.textBaseline = 'middle';

  ctx.textAlign = 'left';
  ctx.fillText('DESCRIPTION DES PRESTATIONS', colDescX, bodyTopY + tableHeaderH / 2);
  ctx.textAlign = 'center';
  ctx.fillText('QTÉ', colQtyX, bodyTopY + tableHeaderH / 2);
  ctx.textAlign = 'right';
  ctx.fillText('PRIX UNITAIRE', colPriceX, bodyTopY + tableHeaderH / 2);
  ctx.fillText('TOTAL', colTotalX, bodyTopY + tableHeaderH / 2);

  const items = invoice.items && invoice.items.length > 0
    ? invoice.items
    : [
        {
          id: '1',
          description: invoice.description || 'Prestation de services',
          quantity: 1,
          price: invoice.amount,
          total: invoice.amount,
        },
      ];

  const displayItems = items.slice(0, 5);
  let rightCurY = bodyTopY + tableHeaderH + 12;

  // Calcul dynamique de la hauteur des lignes pour bien remplir le tableau
  const availableTableH = 380;
  const rowH = Math.max(68, Math.floor(availableTableH / Math.max(displayItems.length, 2)));

  for (let idx = 0; idx < displayItems.length; idx++) {
    const item = displayItems[idx];

    // Alternance de fond subtile pour professionnalisme accru
    if (idx % 2 === 1) {
      ctx.fillStyle = '#F8FAFC';
      ctx.beginPath();
      ctx.roundRect(colRightX, rightCurY, colRightW, rowH - 6, 10);
      ctx.fill();
    }

    ctx.textAlign = 'left';
    ctx.fillStyle = '#0F172A';
    ctx.font = 'bold 20px Poppins, sans-serif';
    let desc = item.description || invoice.description;
    if (desc.length > 42) desc = desc.slice(0, 39) + '...';
    ctx.fillText(desc, colDescX, rightCurY + rowH / 2);

    ctx.textAlign = 'center';
    ctx.fillStyle = '#475569';
    ctx.font = '600 18px Poppins, sans-serif';
    ctx.fillText(String(item.quantity || 1), colQtyX, rightCurY + rowH / 2);

    ctx.textAlign = 'right';
    ctx.fillStyle = '#475569';
    ctx.font = '600 18px Poppins, sans-serif';
    ctx.fillText(formatCurrency(item.price, invoice.devise), colPriceX, rightCurY + rowH / 2);

    ctx.fillStyle = '#0F172A';
    ctx.font = 'bold 21px Poppins, sans-serif';
    ctx.fillText(formatCurrency(item.total, invoice.devise), colTotalX, rightCurY + rowH / 2);

    rightCurY += rowH;

    // Ligne de séparation
    ctx.strokeStyle = '#E2E8F0';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(colRightX, rightCurY - 4);
    ctx.lineTo(rightX, rightCurY - 4);
    ctx.stroke();
  }

  // ENCADRÉ GÉANT TOTAL À PAYER (s'aligne exactement sur le bas à bodyBottomY)
  const totalBoxH = 150;
  const totalBoxY = bodyBottomY - totalBoxH;

  ctx.fillStyle = '#FFF7ED';
  ctx.beginPath();
  ctx.roundRect(colRightX, totalBoxY, colRightW, totalBoxH, 20);
  ctx.fill();

  ctx.strokeStyle = '#FB923C';
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // Gauche de l'encadré Total
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';

  ctx.fillStyle = '#C2410C';
  ctx.font = 'bold 18px Poppins, sans-serif';
  ctx.fillText('MONTANT TOTAL NET À PAYER', colRightX + 28, totalBoxY + 30);

  ctx.fillStyle = '#EA580C';
  ctx.font = '600 16px Poppins, sans-serif';
  ctx.fillText(`Facturation officielle en ${invoice.devise} • TTC`, colRightX + 28, totalBoxY + 62);

  ctx.fillStyle = '#9A3412';
  ctx.font = '500 14px Poppins, sans-serif';
  ctx.fillText(
    invoice.isPaid ? '✓ Règlement acquitté' : 'Net à payer sans escompte',
    colRightX + 28,
    totalBoxY + 92
  );

  // Droite de l'encadré Total (Montant en police géante et très visible)
  ctx.textAlign = 'right';
  ctx.textBaseline = 'middle';

  ctx.fillStyle = '#0F172A';
  ctx.font = '900 52px Poppins, -apple-system, sans-serif';
  ctx.fillText(formatCurrency(invoice.amount, invoice.devise), rightX - 28, totalBoxY + totalBoxH / 2);

  // 8. PIED DE PAGE COMPLET (Y: 884 à 940)
  const footerY = height - 42;

  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(padX, footerY - 24);
  ctx.lineTo(rightX, footerY - 24);
  ctx.stroke();

  ctx.textAlign = 'left';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#475569';
  ctx.font = 'bold 19px Poppins, sans-serif';
  ctx.fillText('Merci pour votre confiance ! 🙏', padX, footerY);

  // Signature de marque officielle PAYPER imposante et lisible (aucun lien d'URL)
  const logoCircleX = rightX - 160;
  ctx.save();
  ctx.fillStyle = '#FF8A00';
  ctx.beginPath();
  ctx.arc(logoCircleX, footerY, 14, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = '#00C48C';
  ctx.beginPath();
  ctx.arc(logoCircleX + 16, footerY, 14, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  ctx.textAlign = 'left';
  ctx.fillStyle = '#0F172A';
  ctx.font = '900 24px Poppins, sans-serif';
  ctx.fillText('PAY', logoCircleX + 38, footerY);
  ctx.fillStyle = '#FF8A00';
  ctx.fillText('PER', logoCircleX + 88, footerY);

  return canvas;
}

/**
 * Tente de résoudre l'objet Invoice depuis l'argument ou le stockage
 */
function resolveInvoice(
  target: HTMLElement | string | Invoice,
  providedInvoice?: Invoice
): Invoice | null {
  if (providedInvoice) return providedInvoice;
  if (target && typeof target === 'object' && 'id' in target && 'clientName' in target) {
    return target as Invoice;
  }
  if (typeof target === 'string') {
    const invoices = getInvoices();
    const found = invoices.find((inv) => inv.id === target || target.includes(inv.id));
    if (found) return found;
  }
  if (typeof document !== 'undefined') {
    const el = typeof target === 'string'
      ? document.getElementById(target) || document.querySelector(target)
      : target;
    if (el) {
      const text = el.textContent || '';
      const invoices = getInvoices();
      const found = invoices.find((inv) => text.includes(inv.id));
      if (found) return found;
    }
  }
  return null;
}

/**
 * FONCTION CENTRALISÉE : generateInvoiceImage(invoiceElement, filename, invoiceData)
 * Génération haute fidélité HD de la facture via moteur vectoriel et Canvas natif.
 * Totalement infaillible, sans erreur et conforme à l'identité PAYPER.
 */
export async function generateInvoiceImage(
  invoiceElement: HTMLElement | string | Invoice,
  filename: string = 'Facture-Payper.png',
  invoiceData?: Invoice
): Promise<boolean> {
  let objectUrl: string | null = null;

  try {
    const invoice = resolveInvoice(invoiceElement, invoiceData);

    let canvas: HTMLCanvasElement | null = null;

    if (invoice) {
      // 1. Tenter la génération du visuel vectoriel côté serveur
      try {
        const res = await fetch('/api/invoice/generate-graphic', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ invoice }),
          signal: AbortSignal.timeout(3500),
        });

        if (res.ok) {
          const data = await res.json();
          if (data.success && data.svg) {
            canvas = await renderSvgToCanvas(data.svg, 1600, 960);
          }
        }
      } catch {
        // En cas de délai réseau ou indisponibilité, bascule instantanée sur le Canvas natif
      }

      // 2. Si non généré par SVG, utiliser le rendu haute définition direct Canvas
      if (!canvas) {
        canvas = await renderInvoiceDirectToCanvas(invoice);
      }
    } else {
      // 3. Fallback si aucun objet Invoice n'est résolu directement
      let element: HTMLElement | null = null;
      if (typeof invoiceElement === 'string') {
        element = document.getElementById(invoiceElement) || document.querySelector(invoiceElement);
      } else if (invoiceElement instanceof HTMLElement) {
        element = invoiceElement;
      }

      if (element) {
        await prepareInvoiceForCapture(element);
        const scrollY = typeof window !== 'undefined' ? window.scrollY : 0;
        canvas = await html2canvas(element, {
          scale: 2,
          useCORS: true,
          allowTaint: false,
          backgroundColor: '#FFFFFF',
          logging: false,
          imageTimeout: 10000,
          removeContainer: true,
          scrollX: 0,
          scrollY: -scrollY,
        });
      }
    }

    if (!canvas || canvas.width === 0 || canvas.height === 0) {
      throw new Error('Canvas invalide');
    }

    // 4. Convertir en PNG Blob
    const blob: Blob | null = await new Promise((resolve) => {
      try {
        canvas!.toBlob((b) => resolve(b), 'image/png', 1.0);
      } catch {
        resolve(null);
      }
    });

    if (blob) {
      objectUrl = URL.createObjectURL(blob);
      triggerDownload(objectUrl, filename);
    } else {
      const dataUrl = canvas.toDataURL('image/png');
      triggerDownload(dataUrl, filename);
    }

    return true;
  } catch (error) {
    console.error('Erreur lors de la génération de l\'image de facture:', error);
    // Dernier recours : créer une facture minimale sur canvas pour ne jamais bloquer l'utilisateur
    try {
      const invoice = resolveInvoice(invoiceElement, invoiceData) || {
        id: 'INV-PAYPER',
        clientName: 'Client',
        clientCity: 'Dakar',
        description: 'Prestation',
        amount: 0,
        devise: 'FCFA',
        date: new Date().toISOString(),
        boutiqueName: 'Ma Boutique',
        isPaid: false,
        createdAt: new Date().toISOString(),
      };
      const canvas = await renderInvoiceDirectToCanvas(invoice);
      const dataUrl = canvas.toDataURL('image/png');
      triggerDownload(dataUrl, filename);
      return true;
    } catch (finalErr) {
      throw finalErr;
    }
  } finally {
    if (objectUrl) {
      const urlToRevoke = objectUrl;
      setTimeout(() => {
        try {
          URL.revokeObjectURL(urlToRevoke);
        } catch {
          // ignore
        }
      }, 4000);
    }
  }
}

/**
 * Trigger download of image via hidden <a> link
 */
function triggerDownload(url: string, filename: string, onDone?: () => void) {
  const link = document.createElement('a');
  link.download = filename;
  link.href = url;
  link.rel = 'noopener';
  link.target = '_blank';
  link.style.display = 'none';

  document.body.appendChild(link);
  link.click();

  setTimeout(() => {
    try {
      if (link.parentNode) {
        document.body.removeChild(link);
      }
    } catch {
      // silent
    }
    if (onDone) onDone();
  }, 350);
}

/**
 * Compatibility alias for existing callers
 */
export async function downloadInvoiceImage(
  elementId: string,
  filename: string,
  invoiceData?: Invoice
): Promise<boolean> {
  return generateInvoiceImage(elementId, filename, invoiceData);
}

/**
 * Capture Blob directly for Native Web Share API
 */
export async function captureInvoiceBlob(
  elementOrId: string | HTMLElement | Invoice,
  invoiceData?: Invoice
): Promise<{ blob: Blob; dataUrl: string } | null> {
  try {
    const invoice = resolveInvoice(elementOrId, invoiceData);
    let canvas: HTMLCanvasElement | null = null;

    if (invoice) {
      canvas = await renderInvoiceDirectToCanvas(invoice);
    } else {
      let element: HTMLElement | null = null;
      if (typeof elementOrId === 'string') {
        element = document.getElementById(elementOrId);
      } else if (elementOrId instanceof HTMLElement) {
        element = elementOrId;
      }
      if (element) {
        await prepareInvoiceForCapture(element);
        canvas = await html2canvas(element, { scale: 2, useCORS: true, backgroundColor: '#FFFFFF' });
      }
    }

    if (!canvas) return null;

    const dataUrl = canvas.toDataURL('image/png');
    const blob: Blob | null = await new Promise((resolve) => {
      canvas!.toBlob((b) => resolve(b), 'image/png', 1.0);
    });

    if (!blob) return null;
    return { blob, dataUrl };
  } catch (err) {
    console.error('Erreur captureInvoiceBlob:', err);
    return null;
  }
}

