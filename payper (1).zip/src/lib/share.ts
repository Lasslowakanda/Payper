import { Currency, Invoice } from '../types';
import { formatCurrency } from './invoice';

export interface PublicInvoicePayload {
  i: string; // id
  c: string; // clientName
  cc: string; // clientCity
  d: string; // description
  a: number; // amount
  v: Currency; // devise
  dt: string; // date
  b: string; // boutiqueName
  bl?: string; // boutiqueLogo
  bc?: string; // boutiqueCity
  p: boolean; // isPaid
  n?: string; // notes
}

/**
 * Encodes invoice essential data into a safe URL query string for device-independent viewing
 */
export function generatePublicInvoiceUrl(invoice: Invoice): string {
  const payload: PublicInvoicePayload = {
    i: invoice.id,
    c: invoice.clientName,
    cc: invoice.clientCity,
    d: invoice.description,
    a: invoice.amount,
    v: invoice.devise,
    dt: invoice.date,
    b: invoice.boutiqueName,
    bl: invoice.boutiqueLogo ? invoice.boutiqueLogo.slice(0, 300) : undefined, // keep logo reasonable if short URL, or omit huge data URI to prevent URL overflow
    bc: invoice.boutiqueCity,
    p: invoice.isPaid,
    n: invoice.notes,
  };

  try {
    const jsonStr = JSON.stringify(payload);
    // Safe base64 encoding for Unicode
    const base64 = btoa(encodeURIComponent(jsonStr).replace(/%([0-9A-F]{2})/g, (_, p1) => {
      return String.fromCharCode(parseInt(p1, 16));
    }));

    const urlSafe = encodeURIComponent(base64);
    const origin = window.location.origin;
    const pathname = window.location.pathname;

    return `${origin}${pathname}#/public-invoice?data=${urlSafe}`;
  } catch (err) {
    console.error('Failed to encode public invoice URL', err);
    return `${window.location.origin}#/public-invoice?id=${invoice.id}`;
  }
}

/**
 * Decodes the public invoice data from current window URL hash or search params
 */
export function decodePublicInvoiceUrl(): Invoice | null {
  try {
    // Check hash first e.g. #/public-invoice?data=...
    const fullHash = window.location.hash;
    const queryIndex = fullHash.indexOf('?');
    let queryString = '';

    if (queryIndex !== -1) {
      queryString = fullHash.substring(queryIndex + 1);
    } else {
      queryString = window.location.search.replace(/^\?/, '');
    }

    const params = new URLSearchParams(queryString);
    const encodedData = params.get('data');

    if (!encodedData) return null;

    const base64 = decodeURIComponent(encodedData);
    const decodedStr = decodeURIComponent(
      Array.prototype.map
        .call(atob(base64), (c: string) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );

    const data: PublicInvoicePayload = JSON.parse(decodedStr);

    const invoice: Invoice = {
      id: data.i,
      clientName: data.c,
      clientCity: data.cc || 'Dakar',
      description: data.d,
      amount: data.a,
      devise: data.v || 'FCFA',
      date: data.dt,
      boutiqueName: data.b,
      boutiqueLogo: data.bl,
      boutiqueCity: data.bc || 'Dakar, Sénégal',
      isPaid: data.p,
      notes: data.n,
      createdAt: data.dt,
      items: [
        {
          id: '1',
          description: data.d,
          quantity: 1,
          price: data.a,
          total: data.a,
        },
      ],
    };

    return invoice;
  } catch (e) {
    console.error('Failed to decode invoice URL', e);
    return null;
  }
}

export function generateWhatsAppMessage(invoice: Invoice): string {
  const formattedAmount = formatCurrency(invoice.amount, invoice.devise);
  return `Salut ${invoice.clientName} ! Voici ta facture ${invoice.id} de ${formattedAmount} pour ${invoice.description} de la part de ${invoice.boutiqueName}. Merci ! 🙏`;
}

export function buildWhatsAppUrl(phoneNumber: string, message: string): string {
  // Strip non-numeric characters except +
  let cleanNumber = phoneNumber.replace(/[^0-9]/g, '');
  // If no phone number provided, wa.me can open with text directly
  const encodedText = encodeURIComponent(message);
  if (!cleanNumber) {
    return `https://wa.me/?text=${encodedText}`;
  }
  return `https://wa.me/${cleanNumber}?text=${encodedText}`;
}

export const COUNTRY_CODES = [
  { country: 'Sénégal', flag: '🇸🇳', code: '+221' },
  { country: "Côte d'Ivoire", flag: '🇨🇮', code: '+225' },
  { country: 'Bénin', flag: '🇧🇯', code: '+229' },
  { country: 'Guinée', flag: '🇬🇳', code: '+224' },
  { country: 'Congo-Brazzaville', flag: '🇨🇬', code: '+242' },
  { country: 'Cameroun', flag: '🇨🇲', code: '+237' },
  { country: 'Rép. Dém. du Congo', flag: '🇨🇩', code: '+243' },
  { country: 'Mali', flag: '🇲🇱', code: '+223' },
  { country: 'Togo', flag: '🇹🇬', code: '+228' },
  { country: 'Burkina Faso', flag: '🇧🇫', code: '+226' },
  { country: 'Gabon', flag: '🇬🇦', code: '+241' },
  { country: 'France / Diaspora', flag: '🇫🇷', code: '+33' },
];
