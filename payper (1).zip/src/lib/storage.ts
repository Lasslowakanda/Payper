import { Boutique, Invoice, Subscription, SubscriptionPlan, UserAccount, DocumentCustomization } from '../types';
import {
  syncBoutiqueToSupabase,
  syncBoutiqueDeleteToSupabase,
  syncInvoiceToSupabase,
  syncInvoiceDeleteToSupabase,
  syncUserProfileToSupabase,
} from './supabase';

const STORAGE_KEYS = {
  USER: 'payper_user',
  BOUTIQUE: 'payper_boutique', // Current active boutique cache for fast reading
  BOUTIQUES_LIST: 'payper_boutiques_list', // List of all user's boutiques
  ACTIVE_BOUTIQUE_ID: 'payper_active_boutique_id',
  INVOICES: 'payper_invoices', // Current active boutique invoices cache
  INVOICES_PREFIX: 'payper_boutique_invoices_', // Invoices keyed by boutique ID
  SUBSCRIPTION: 'payper_subscription',
  USAGE: 'payper_usage',
} as const;

// ==========================================
// 1. USER ACCOUNT & AUTHENTICATION
// ==========================================

export function getUserAccount(): UserAccount {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USER);
    if (raw) {
      const parsed: UserAccount = JSON.parse(raw);
      if (parsed && typeof parsed.isLoggedIn === 'boolean') {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Error reading user account', e);
  }

  return {
    id: '',
    name: '',
    phone: '',
    email: '',
    isLoggedIn: false,
    createdAt: new Date().toISOString(),
  };
}

export const getCurrentUser = getUserAccount;

export function saveUserAccount(user: UserAccount): void {
  try {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
    window.dispatchEvent(new Event('payper_user_updated'));
    if (user.id) {
      syncUserProfileToSupabase(user).catch(() => {});
    }
  } catch (e) {
    console.error('Error saving user account', e);
  }
}

export function cleanPhoneDigits(phone?: string): string {
  if (!phone) return '';
  return phone.replace(/\D/g, '');
}

/**
 * Détermine si une boutique appartient strictement au compte utilisateur connecté.
 * Isolation garantie même sur un même appareil ou navigateur partagé :
 * - Un numéro de téléphone possède ses propres boutiques.
 * - Aucune boutique d'un autre compte n'apparaît.
 */
export function isBoutiqueOwnedByUser(boutique: Boutique, user: UserAccount): boolean {
  if (!user || !user.isLoggedIn) return false;
  if (!boutique || !boutique.id) return false;

  const currentUserId = (user.id || '').trim();
  const currentUserPhoneDigits = cleanPhoneDigits(user.phone);

  const bUserId = (boutique.userId || '').trim();
  const bOwnerDigits = cleanPhoneDigits(boutique.ownerPhone);
  const bPhoneDigits = cleanPhoneDigits(boutique.phone);

  // 1. Isolation prioritaire par numéro de téléphone (E.164 / chiffres)
  if (currentUserPhoneDigits && currentUserPhoneDigits.length >= 6) {
    if (bOwnerDigits && bOwnerDigits.length >= 6) {
      return bOwnerDigits === currentUserPhoneDigits;
    }
    // Si ownerPhone n'est pas encore écrit (données existantes), tester le numéro direct de la boutique
    if (bPhoneDigits && bPhoneDigits.length >= 6 && bPhoneDigits === currentUserPhoneDigits) {
      return true;
    }
  }

  // 2. Vérification par identifiant unique d'utilisateur Supabase / local
  if (currentUserId && bUserId) {
    if (bUserId === currentUserId) {
      // Si un ownerPhone explicite est présent et différent du numéro connecté, ce n'est pas ce compte
      if (currentUserPhoneDigits && bOwnerDigits && bOwnerDigits !== currentUserPhoneDigits) {
        return false;
      }
      return true;
    }
    return false;
  }

  // 3. Cas de repli : le numéro direct correspond au compte connecté
  if (currentUserPhoneDigits && bPhoneDigits && currentUserPhoneDigits === bPhoneDigits) {
    return true;
  }

  return false;
}

export function loginUser(phoneOrEmail: string, name?: string): UserAccount {
  const cleanDigits = phoneOrEmail.replace(/\D/g, '');
  const updated: UserAccount = {
    id: `user_${cleanDigits || Date.now()}`,
    name: name || `Compte ${phoneOrEmail}`,
    phone: phoneOrEmail.includes('@') ? '' : phoneOrEmail,
    email: phoneOrEmail.includes('@') ? phoneOrEmail : '',
    isLoggedIn: true,
    createdAt: new Date().toISOString(),
  };
  setCurrentUser(updated);
  return updated;
}

export function setCurrentUser(user: UserAccount): void {
  const cleanUser: UserAccount = {
    ...user,
    isLoggedIn: true,
  };
  saveUserAccount(cleanUser);

  // Vérifier et activer immédiatement la boutique appartenant à ce compte
  const userBoutiques = getBoutiques();
  if (userBoutiques.length > 0) {
    const activeId = localStorage.getItem(STORAGE_KEYS.ACTIVE_BOUTIQUE_ID);
    const existingActive = userBoutiques.find(b => b.id === activeId);
    const target = existingActive || userBoutiques[0];
    if (target.id) {
      setActiveBoutique(target.id);
    }
  } else {
    // Si ce nouveau compte n'a pas encore de boutique, effacer le cache d'une session précédente
    localStorage.removeItem(STORAGE_KEYS.ACTIVE_BOUTIQUE_ID);
    localStorage.removeItem(STORAGE_KEYS.BOUTIQUE);
    localStorage.removeItem(STORAGE_KEYS.INVOICES);
    window.dispatchEvent(new Event('payper_boutique_updated'));
    window.dispatchEvent(new Event('payper_boutiques_updated'));
    window.dispatchEvent(new Event('payper_invoices_updated'));
  }

  window.dispatchEvent(new Event('payper_auth_updated'));
}

export function logoutUser(): void {
  // Effacer complètement l'utilisateur actif et les caches de boutique active
  localStorage.removeItem(STORAGE_KEYS.USER);
  localStorage.removeItem(STORAGE_KEYS.ACTIVE_BOUTIQUE_ID);
  localStorage.removeItem(STORAGE_KEYS.BOUTIQUE);
  localStorage.removeItem(STORAGE_KEYS.INVOICES);
  sessionStorage.clear();
  window.dispatchEvent(new Event('payper_auth_updated'));
  window.dispatchEvent(new Event('payper_boutique_updated'));
  window.dispatchEvent(new Event('payper_boutiques_updated'));
  window.dispatchEvent(new Event('payper_invoices_updated'));
}

export function isUserLoggedIn(): boolean {
  const user = getUserAccount();
  return !!(user && user.isLoggedIn && (user.phone || user.id));
}

// ==========================================
// 2. MULTI-BOUTIQUE MANAGEMENT (ISOLATION PAR NUMÉRO / COMPTE)
// ==========================================

/**
 * Récupère toutes les boutiques enregistrées pour le compte utilisateur actuellement connecté.
 * Filtre strictement selon le numéro de téléphone et l'ID du compte.
 * Même sur un même téléphone / navigateur, sépare hermétiquement les boutiques selon le compte.
 */
export function getBoutiques(): Boutique[] {
  try {
    const currentUser = getUserAccount();
    if (!currentUser.isLoggedIn) {
      return [];
    }

    const rawList = localStorage.getItem(STORAGE_KEYS.BOUTIQUES_LIST);
    if (rawList) {
      const parsed: Boutique[] = JSON.parse(rawList);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Filtrer strictement les boutiques appartenant à CE compte utilisateur (ce numéro)
        const userSpecific = parsed.filter(b => isBoutiqueOwnedByUser(b, currentUser));

        // Déduplication par ID unique
        const unique = Array.from(new Map(userSpecific.map(b => [b.id!, b])).values());
        return unique;
      }
    }

    // Migration d'une ancienne clé unique si elle appartient à cet utilisateur
    const legacyRaw = localStorage.getItem(STORAGE_KEYS.BOUTIQUE);
    if (legacyRaw) {
      const legacy: Boutique = JSON.parse(legacyRaw);
      if (legacy && legacy.name && isBoutiqueOwnedByUser(legacy, currentUser)) {
        const migratedId = legacy.id || 'btq_primary';
        const migratedBoutique: Boutique = {
          ...legacy,
          id: migratedId,
          userId: currentUser.id,
          ownerPhone: currentUser.phone,
          isActive: true,
        };

        const list = [migratedBoutique];
        localStorage.setItem(STORAGE_KEYS.BOUTIQUES_LIST, JSON.stringify(list));
        localStorage.setItem(STORAGE_KEYS.ACTIVE_BOUTIQUE_ID, migratedId);
        return list;
      }
    }
  } catch (e) {
    console.error('Error reading boutiques list', e);
  }

  return [];
}

/**
 * Récupère la boutique active de l'utilisateur connecté.
 * Garantit que la boutique active appartient exclusivement à cet utilisateur.
 */
export function getActiveBoutique(): Boutique | null {
  const currentUser = getUserAccount();
  if (!currentUser || !currentUser.isLoggedIn) {
    return null;
  }

  const list = getBoutiques();
  if (list.length === 0) {
    // Si l'utilisateur n'a aucune boutique, effacer le cache actif
    localStorage.removeItem(STORAGE_KEYS.ACTIVE_BOUTIQUE_ID);
    localStorage.removeItem(STORAGE_KEYS.BOUTIQUE);
    return null;
  }

  // 1. Vérifier si l'identifiant actif stocké correspond bien à une boutique de cet utilisateur
  const activeId = localStorage.getItem(STORAGE_KEYS.ACTIVE_BOUTIQUE_ID);
  if (activeId) {
    const found = list.find(b => b.id === activeId);
    if (found) {
      return found;
    }
  }

  // 2. Sinon, activer la première boutique appartenant à cet utilisateur
  const first = list[0];
  try {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_BOUTIQUE_ID, first.id || 'btq_1');
    localStorage.setItem(STORAGE_KEYS.BOUTIQUE, JSON.stringify(first));
  } catch {
    // silent
  }
  return first;
}

/**
 * Alias pour getActiveBoutique
 */
export function getBoutique(): Boutique | null {
  return getActiveBoutique();
}

/**
 * Enregistre ou met à jour une boutique, en la liant au numéro et compte propriétaire.
 */
export function saveBoutique(boutique: Boutique): void {
  try {
    const currentUser = getUserAccount();
    const bId = boutique.id || ('btq_' + Date.now());
    const finalUserId = boutique.userId || currentUser.id || undefined;
    const finalOwnerPhone = boutique.ownerPhone || currentUser.phone || undefined;

    const enrichedBoutique: Boutique = {
      ...boutique,
      id: bId,
      userId: finalUserId,
      ownerPhone: finalOwnerPhone,
    };

    let list: Boutique[] = [];
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.BOUTIQUES_LIST);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) list = parsed;
      }
    } catch {
      // silent
    }

    const existingIndex = list.findIndex(b => b.id === bId);
    let updatedList: Boutique[];

    if (existingIndex >= 0) {
      updatedList = [...list];
      updatedList[existingIndex] = enrichedBoutique;
    } else {
      updatedList = [...list, enrichedBoutique];
    }

    localStorage.setItem(STORAGE_KEYS.BOUTIQUES_LIST, JSON.stringify(updatedList));

    // Si cette boutique appartient à l'utilisateur actuellement connecté, la marquer comme active
    if (currentUser.isLoggedIn && isBoutiqueOwnedByUser(enrichedBoutique, currentUser)) {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_BOUTIQUE_ID, bId);
      localStorage.setItem(STORAGE_KEYS.BOUTIQUE, JSON.stringify(enrichedBoutique));
    }

    window.dispatchEvent(new Event('payper_boutique_updated'));
    window.dispatchEvent(new Event('payper_boutiques_updated'));

    // Synchronisation asynchrone transparente avec Supabase
    if (finalUserId) {
      syncBoutiqueToSupabase(enrichedBoutique, finalUserId).catch(() => {});
    }
  } catch (e) {
    console.error('Error saving boutique to localStorage', e);
  }
}

/**
 * Change la boutique active parmi celles du compte connecté.
 */
export function setActiveBoutique(boutiqueId: string): boolean {
  try {
    const list = getBoutiques();
    const target = list.find(b => b.id === boutiqueId);
    if (!target) return false;

    // 1. Définir l'identifiant actif
    localStorage.setItem(STORAGE_KEYS.ACTIVE_BOUTIQUE_ID, boutiqueId);

    // 2. Synchroniser le cache de la boutique active
    localStorage.setItem(STORAGE_KEYS.BOUTIQUE, JSON.stringify(target));

    // 3. Charger les factures isolées de cette boutique
    const targetInvoicesRaw = localStorage.getItem(STORAGE_KEYS.INVOICES_PREFIX + boutiqueId);
    const targetInvoices = targetInvoicesRaw ? targetInvoicesRaw : '[]';
    localStorage.setItem(STORAGE_KEYS.INVOICES, targetInvoices);

    // 4. Déclencher les événements de mise à jour pour tous les composants
    window.dispatchEvent(new Event('payper_boutique_updated'));
    window.dispatchEvent(new Event('payper_invoices_updated'));
    window.dispatchEvent(new Event('payper_boutiques_updated'));

    return true;
  } catch (e) {
    console.error('Error setting active boutique', e);
    return false;
  }
}

/**
 * Crée une nouvelle boutique liée au numéro de téléphone et compte de l'utilisateur connecté
 */
export function createBoutique(data: Omit<Boutique, 'id'>): Boutique {
  const currentUser = getUserAccount();
  const newId = 'btq_' + Date.now();
  const ownerUserId = data.userId || currentUser.id || undefined;
  const ownerPhone = data.ownerPhone || currentUser.phone || undefined;

  const newBoutique: Boutique = {
    ...data,
    id: newId,
    userId: ownerUserId,
    ownerPhone: ownerPhone,
    createdAt: data.createdAt || new Date().toISOString(),
    isActive: true,
  };

  // 1. Initialiser le conteneur de factures isolé pour cette boutique
  localStorage.setItem(STORAGE_KEYS.INVOICES_PREFIX + newId, '[]');

  // 2. Ajouter à la liste globale dans localStorage (sans écraser les boutiques d'autres comptes)
  let allBoutiques: Boutique[] = [];
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.BOUTIQUES_LIST);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) allBoutiques = parsed;
    }
  } catch {
    // silent
  }

  const updatedList = [...allBoutiques, newBoutique];
  localStorage.setItem(STORAGE_KEYS.BOUTIQUES_LIST, JSON.stringify(updatedList));

  // 3. Définir comme boutique active pour cet utilisateur
  localStorage.setItem(STORAGE_KEYS.ACTIVE_BOUTIQUE_ID, newId);
  localStorage.setItem(STORAGE_KEYS.BOUTIQUE, JSON.stringify(newBoutique));
  localStorage.setItem(STORAGE_KEYS.INVOICES, '[]');

  window.dispatchEvent(new Event('payper_boutique_updated'));
  window.dispatchEvent(new Event('payper_invoices_updated'));
  window.dispatchEvent(new Event('payper_boutiques_updated'));

  // Synchronisation asynchrone avec Supabase
  if (ownerUserId) {
    syncBoutiqueToSupabase(newBoutique, ownerUserId).catch(() => {});
  }

  return newBoutique;
}

/**
 * Delete a boutique and its isolated invoices.
 */
export function deleteBoutique(boutiqueId: string): void {
  try {
    let allBoutiques: Boutique[] = [];
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.BOUTIQUES_LIST);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) allBoutiques = parsed;
      }
    } catch {
      // silent
    }

    const updatedGlobalList = allBoutiques.filter(b => b.id !== boutiqueId);
    localStorage.setItem(STORAGE_KEYS.BOUTIQUES_LIST, JSON.stringify(updatedGlobalList));

    // Clean up isolated invoices for this boutique
    localStorage.removeItem(STORAGE_KEYS.INVOICES_PREFIX + boutiqueId);

    // If deleted boutique was active, switch to another boutique of this user or clear
    const activeId = localStorage.getItem(STORAGE_KEYS.ACTIVE_BOUTIQUE_ID);
    if (activeId === boutiqueId) {
      const remainingUserBoutiques = getBoutiques();
      if (remainingUserBoutiques.length > 0) {
        setActiveBoutique(remainingUserBoutiques[0].id || 'btq_1');
      } else {
        localStorage.removeItem(STORAGE_KEYS.ACTIVE_BOUTIQUE_ID);
        localStorage.removeItem(STORAGE_KEYS.BOUTIQUE);
        localStorage.setItem(STORAGE_KEYS.INVOICES, '[]');
        window.dispatchEvent(new Event('payper_boutique_updated'));
        window.dispatchEvent(new Event('payper_invoices_updated'));
      }
    }

    window.dispatchEvent(new Event('payper_boutiques_updated'));

    // Synchronisation suppression avec Supabase
    syncBoutiqueDeleteToSupabase(boutiqueId).catch(() => {});
  } catch (e) {
    console.error('Error deleting boutique', e);
  }
}

// ==========================================
// 3. ISOLATED INVOICES PER BOUTIQUE
// ==========================================

/**
 * Get invoices for a specific boutique, or for the active boutique by default
 */
export function getInvoices(boutiqueId?: string): Invoice[] {
  try {
    const bId = boutiqueId || localStorage.getItem(STORAGE_KEYS.ACTIVE_BOUTIQUE_ID) || getActiveBoutique()?.id;

    if (bId) {
      const raw = localStorage.getItem(STORAGE_KEYS.INVOICES_PREFIX + bId);
      if (raw) {
        const list: Invoice[] = JSON.parse(raw);
        return Array.isArray(list) ? list : [];
      }
    }

    // Fallback to active cache
    const activeRaw = localStorage.getItem(STORAGE_KEYS.INVOICES);
    if (activeRaw) {
      const list: Invoice[] = JSON.parse(activeRaw);
      return Array.isArray(list) ? list : [];
    }
  } catch (e) {
    console.error('Error reading invoices from localStorage', e);
  }
  return [];
}

/**
 * Get statistics summary for a specific boutique
 */
export function getBoutiqueStats(boutiqueId: string) {
  const invoices = getInvoices(boutiqueId);
  const totalBilled = invoices.reduce((sum, inv) => sum + (Number(inv.amount) || 0), 0);
  const totalPaid = invoices.filter(inv => inv.isPaid).reduce((sum, inv) => sum + (Number(inv.amount) || 0), 0);
  const totalPending = invoices.filter(inv => !inv.isPaid).reduce((sum, inv) => sum + (Number(inv.amount) || 0), 0);

  // Find the latest generated invoice (by date or createdAt)
  let lastInvoice: Invoice | null = null;
  let lastInvoiceDate: string | null = null;

  if (invoices.length > 0) {
    // Sort descending by date / createdAt
    const sorted = [...invoices].sort((a, b) => {
      const dateA = new Date(a.date || a.createdAt || 0).getTime();
      const dateB = new Date(b.date || b.createdAt || 0).getTime();
      return dateB - dateA;
    });
    lastInvoice = sorted[0];
    lastInvoiceDate = sorted[0]?.date || sorted[0]?.createdAt || null;
  }

  return {
    invoicesCount: invoices.length,
    totalBilled,
    totalPaid,
    totalPending,
    lastInvoice,
    lastInvoiceDate,
  };
}

export function saveInvoice(invoice: Invoice): void {
  try {
    const active = getActiveBoutique();
    const bId = active?.id || 'btq_primary';

    // Enrich invoice with active boutique metadata and snapshot customization for future invoices
    const boutiqueCustomization = getBoutiqueCustomization(bId);
    const enrichedInvoice: Invoice = {
      ...invoice,
      boutiqueName: invoice.boutiqueName || active?.name || 'Ma Boutique',
      boutiqueLogo: invoice.boutiqueLogo || active?.logo,
      boutiqueCity: invoice.boutiqueCity || active?.city,
      customization: invoice.customization || boutiqueCustomization,
    };

    const existing = getInvoices(bId);
    const index = existing.findIndex(inv => inv.id === enrichedInvoice.id);
    let updated: Invoice[];
    if (index >= 0) {
      updated = [...existing];
      updated[index] = enrichedInvoice;
    } else {
      updated = [enrichedInvoice, ...existing];
    }

    // Save in isolated store AND active cache
    localStorage.setItem(STORAGE_KEYS.INVOICES_PREFIX + bId, JSON.stringify(updated));
    localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(updated));

    // Update usage and subscription counter
    incrementMonthlyInvoiceCount();
    window.dispatchEvent(new Event('payper_invoices_updated'));

    // Synchronisation asynchrone avec Supabase
    syncInvoiceToSupabase(enrichedInvoice, bId).catch(() => {});
  } catch (e) {
    console.error('Error saving invoice to localStorage', e);
  }
}

export function updateInvoice(invoice: Invoice): void {
  try {
    const active = getActiveBoutique();
    const bId = active?.id || 'btq_primary';

    const existing = getInvoices(bId);
    const updated = existing.map(item => (item.id === invoice.id ? invoice : item));

    localStorage.setItem(STORAGE_KEYS.INVOICES_PREFIX + bId, JSON.stringify(updated));
    localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(updated));
    window.dispatchEvent(new Event('payper_invoices_updated'));

    // Synchronisation asynchrone avec Supabase
    syncInvoiceToSupabase(invoice, bId).catch(() => {});
  } catch (e) {
    console.error('Error updating invoice', e);
  }
}

export function deleteInvoice(id: string): void {
  try {
    const active = getActiveBoutique();
    const bId = active?.id || 'btq_primary';

    const existing = getInvoices(bId);
    const updated = existing.filter(item => item.id !== id);

    localStorage.setItem(STORAGE_KEYS.INVOICES_PREFIX + bId, JSON.stringify(updated));
    localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(updated));
    window.dispatchEvent(new Event('payper_invoices_updated'));

    // Synchronisation suppression avec Supabase
    syncInvoiceDeleteToSupabase(id).catch(() => {});
  } catch (e) {
    console.error('Error deleting invoice', e);
  }
}

export function getInvoiceById(id: string): Invoice | null {
  const list = getInvoices();
  return list.find(inv => inv.id === id) || null;
}

// ==========================================
// 4. SUBSCRIPTION & USAGE
// ==========================================

export function getSubscription(): Subscription {
  try {
    const user = getCurrentUser();
    const subKey = user?.id ? `${STORAGE_KEYS.SUBSCRIPTION}_${user.id}` : STORAGE_KEYS.SUBSCRIPTION;
    const raw = localStorage.getItem(subKey) || localStorage.getItem(STORAGE_KEYS.SUBSCRIPTION);
    if (raw) {
      const parsed: Subscription = JSON.parse(raw);
      // Auto-evaluate expiration date
      if (parsed.status === 'active' && parsed.endDate) {
        if (Date.now() > new Date(parsed.endDate).getTime()) {
          parsed.status = 'expired';
          saveSubscription(parsed);
        }
      }
      return {
        ...parsed,
        userId: user?.id || parsed.userId,
        status: parsed.status || (parsed.plan === 'free' ? 'inactive' : 'inactive'),
      };
    }
  } catch (e) {
    console.error('Error reading subscription from localStorage', e);
  }

  // Default fallback if not initialized yet
  const user = getCurrentUser();
  const defaultSub: Subscription = {
    userId: user?.id,
    plan: 'free',
    status: 'inactive',
    startDate: new Date().toISOString(),
    invoicesThisMonth: 0,
    amountUSD: 0,
  };
  saveSubscription(defaultSub);
  return defaultSub;
}

export function saveSubscription(sub: Subscription): void {
  try {
    const user = getCurrentUser();
    const subKey = user?.id ? `${STORAGE_KEYS.SUBSCRIPTION}_${user.id}` : STORAGE_KEYS.SUBSCRIPTION;
    localStorage.setItem(subKey, JSON.stringify(sub));
    // Also mirror to global key for current session
    localStorage.setItem(STORAGE_KEYS.SUBSCRIPTION, JSON.stringify(sub));
    window.dispatchEvent(new Event('payper_subscription_updated'));
  } catch (e) {
    console.error('Error saving subscription to localStorage', e);
  }
}

/**
 * Revert to free plan (can be triggered by user).
 * Upgrading to paid plans MUST go through backend payment confirmation!
 */
export function resetToFreePlan(): Subscription {
  const current = getSubscription();
  const updated: Subscription = {
    ...current,
    plan: 'free',
    status: 'inactive',
    endDate: undefined,
    signature: undefined,
  };
  saveSubscription(updated);
  return updated;
}

export function incrementMonthlyInvoiceCount(): void {
  const sub = getSubscription();
  const updated: Subscription = {
    ...sub,
    invoicesThisMonth: (sub.invoicesThisMonth || 0) + 1,
  };
  saveSubscription(updated);

  // Track global usage
  try {
    const rawUsage = localStorage.getItem(STORAGE_KEYS.USAGE);
    const count = rawUsage ? parseInt(rawUsage, 10) || 0 : 0;
    localStorage.setItem(STORAGE_KEYS.USAGE, String(count + 1));
  } catch {
    // silent
  }
}

export function getMonthlyInvoiceCount(): number {
  const invoices = getInvoices();
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();

  const count = invoices.filter(inv => {
    try {
      const d = new Date(inv.createdAt || inv.date);
      return d.getFullYear() === currentYear && d.getMonth() === currentMonth;
    } catch {
      return false;
    }
  }).length;

  return count;
}

// ==========================================
// 8. DOCUMENT CUSTOMIZATION (OFFRE STANDARD & PRO)
// ==========================================

export const DEFAULT_CUSTOMIZATION: DocumentCustomization = {
  invoiceTemplate: 'classic_a4',
  receiptTemplate: 'modern_slip',
  primaryColor: '#00C48C',
  secondaryColor: '#111827',
  accentColor: '#FF8A00',
  logoPosition: 'left',
  iconStyle: 'filled',
  infoAlignment: 'split',
  showWatermark: false,
  receiptFooterMessage: 'Merci pour votre confiance ! À très bientôt.',
  invoiceFooterMessage: 'Modalités de règlement : Paiement par Mobile Money ou Virement bancaire.',
};

export function getBoutiqueCustomization(boutiqueId?: string): DocumentCustomization {
  try {
    const targetBoutique = boutiqueId ? getBoutiques().find(b => b.id === boutiqueId) : getActiveBoutique();
    if (targetBoutique && targetBoutique.customization) {
      return { ...DEFAULT_CUSTOMIZATION, ...targetBoutique.customization };
    }
    const bId = boutiqueId || targetBoutique?.id;
    if (bId) {
      const stored = localStorage.getItem(`payper_customization_${bId}`);
      if (stored) {
        return { ...DEFAULT_CUSTOMIZATION, ...JSON.parse(stored) };
      }
    }
  } catch (e) {
    console.error('Error reading boutique customization', e);
  }
  return DEFAULT_CUSTOMIZATION;
}

export function saveBoutiqueCustomization(boutiqueId: string, customization: DocumentCustomization): void {
  try {
    const allBoutiques = getBoutiques();
    const boutique = allBoutiques.find(b => b.id === boutiqueId) || getActiveBoutique();
    if (boutique && boutique.id) {
      const updated: Boutique = {
        ...boutique,
        customization: {
          ...customization,
          updatedAt: new Date().toISOString(),
        },
      };
      saveBoutique(updated);
      localStorage.setItem(`payper_customization_${boutique.id}`, JSON.stringify(customization));
      window.dispatchEvent(new Event('payper_customization_updated'));
      window.dispatchEvent(new Event('payper_boutique_updated'));
    }
  } catch (e) {
    console.error('Error saving boutique customization', e);
  }
}

