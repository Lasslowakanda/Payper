import { SubscriptionPlan, PlanLimits, Subscription } from '../types';
import { getSubscription, getMonthlyInvoiceCount, getInvoices } from './storage';

export interface PlanPricingDetails {
  id: SubscriptionPlan;
  name: string;
  tagline: string;
  priceFCFA: string;
  priceUSD: string;
  period: string;
  isPopular?: boolean;
  limits: PlanLimits;
  features: {
    text: string;
    included: boolean;
    lockNote?: string;
  }[];
}

export const PLAN_LIMITS: Record<SubscriptionPlan, PlanLimits> = {
  free: {
    invoicesPerMonth: 'unlimited',
    clientsLimit: 'unlimited',
    hdImages: false,
    customColors: false,
    removePayperBranding: false,
    advancedStats: false,
    invoiceTemplates: false,
    customization: false,
  },
  standard: {
    invoicesPerMonth: 'unlimited',
    clientsLimit: 'unlimited',
    hdImages: true,
    customColors: true,
    removePayperBranding: false,
    advancedStats: true,
    invoiceTemplates: true,
    customization: true,
  },
  pro: {
    invoicesPerMonth: 'unlimited',
    clientsLimit: 'unlimited',
    hdImages: true,
    customColors: true,
    removePayperBranding: true,
    advancedStats: true,
    invoiceTemplates: true,
    customization: true,
  },
};

export const PLANS_DATA: PlanPricingDetails[] = [
  {
    id: 'free',
    name: 'Gratuit',
    tagline: 'Pour démarrer et tester Payper sans engagement',
    priceFCFA: '0 FCFA',
    priceUSD: '0 $',
    period: '/mois',
    limits: PLAN_LIMITS.free,
    features: [
      { text: 'Factures 100% illimitées chaque mois', included: true },
      { text: 'Clients illimités sans restriction', included: true },
      { text: 'Génération de facture en image PNG', included: true },
      { text: 'Téléchargement PNG instantané', included: true },
      { text: 'Partage WhatsApp & lien public', included: true },
      { text: 'Logo de votre boutique', included: true },
      { text: 'Statistiques basiques de vente', included: true },
      { text: 'Personnalisation des reçus & factures', included: false, lockNote: 'Disponible dès l\'offre Standard (5 USD)' },
      { text: 'Factures HD haute résolution', included: false, lockNote: 'Disponible avec Standard' },
      { text: 'Suppression du logo Payper', included: false, lockNote: 'Disponible avec Pro' },
    ],
  },
  {
    id: 'standard',
    name: 'Standard',
    tagline: 'Pour les commerçants réguliers et indépendants actifs',
    priceFCFA: '3 000 FCFA',
    priceUSD: '5 USD',
    period: '/mois',
    isPopular: true,
    limits: PLAN_LIMITS.standard,
    features: [
      { text: 'Factures illimitées chaque mois', included: true },
      { text: 'Clients illimités', included: true },
      { text: 'Personnalisation complète des reçus & factures', included: true },
      { text: 'Choix des modèles de reçus et factures', included: true },
      { text: 'Palette de couleurs primaires & secondaires', included: true },
      { text: 'Positionnement du logo (gauche, centre, droite)', included: true },
      { text: 'Styles d\'icônes & disposition des informations', included: true },
      { text: 'Factures HD (Capture haute définition)', included: true },
      { text: 'Téléchargement image & partage WhatsApp', included: true },
      { text: 'Suppression du logo Payper', included: false, lockNote: 'Disponible avec Pro' },
    ],
  },
  {
    id: 'pro',
    name: 'Pro',
    tagline: 'Pour les professionnels, boutiques établies et PME',
    priceFCFA: '7 500 FCFA',
    priceUSD: '12 USD',
    period: '/mois',
    limits: PLAN_LIMITS.pro,
    features: [
      { text: 'Factures illimitées chaque mois', included: true },
      { text: 'Clients illimités sans restriction', included: true },
      { text: 'Toutes les fonctionnalités de personnalisation Standard', included: true },
      { text: 'Module Transfert d\'argent intégré (sous réserve de disponibilité)', included: true },
      { text: 'Images HD 4K ultra nettes sans filigrane', included: true },
      { text: 'Suppression totale du branding Payper', included: true },
      { text: 'Statistiques avancées & graphiques détaillés', included: true },
      { text: 'Support prioritaire direct sur WhatsApp', included: true },
    ],
  },
];

export interface UsageStatus {
  plan: SubscriptionPlan;
  invoicesThisMonth: number;
  invoicesLimit: number | 'unlimited';
  isLimitReached: boolean;
  remainingInvoices: number | 'unlimited';
  clientsCount: number;
  clientsLimit: number | 'unlimited';
}

/**
 * Évalue si un abonnement est actif et encore valide dans le temps (non expiré)
 */
export function isSubscriptionActive(sub?: Subscription): boolean {
  if (!sub) return false;
  if (sub.plan === 'free') return true; // Gratuit est toujours accessible sur son périmètre

  // Pour Standard et Pro : le statut doit être 'active'
  if (sub.status !== 'active') return false;

  // Vérifier la date d'expiration
  if (sub.endDate) {
    const expiry = new Date(sub.endDate).getTime();
    if (Date.now() > expiry) {
      return false; // Expiré !
    }
  }

  return true;
}

/**
 * Détermine si l'utilisateur a accès aux fonctionnalités Standard (Personnalisation avancée)
 */
export function canAccessStandardFeatures(sub?: Subscription): boolean {
  const current = sub || getSubscription();
  if (current.plan === 'free') return false;
  if (current.plan === 'standard' || current.plan === 'pro') {
    return isSubscriptionActive(current);
  }
  return false;
}

/**
 * Détermine si l'utilisateur a accès aux fonctionnalités Pro (Transferts, etc.)
 */
export function canAccessProFeatures(sub?: Subscription): boolean {
  const current = sub || getSubscription();
  if (current.plan === 'pro') {
    return isSubscriptionActive(current);
  }
  return false;
}

/**
 * Récupère le statut vérifié de l'abonnement auprès du serveur backend
 */
export async function fetchServerSubscriptionStatus(userId: string): Promise<Subscription> {
  try {
    const res = await fetch(`/api/subscription/status?userId=${encodeURIComponent(userId)}`);
    if (res.ok) {
      const data = await res.json();
      return data.subscription;
    }
  } catch (err) {
    console.warn('Erreur lors de la synchronisation serveur de l\'abonnement:', err);
  }
  return getSubscription();
}

/**
 * Initie un paiement d'abonnement sécurisé côté serveur
 */
export async function initiateSubscriptionCheckout(
  userId: string,
  plan: 'standard' | 'pro',
  paymentProvider: string = 'wave'
): Promise<any> {
  const res = await fetch('/api/subscription/checkout', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId, plan, paymentProvider }),
  });
  return res.json();
}

/**
 * Confirme un paiement d'abonnement côté serveur (transition vers 'active')
 */
export async function confirmSubscriptionPayment(
  userId: string,
  transactionId: string,
  simulatedOutcome?: 'confirmed' | 'failed' | 'expired'
): Promise<any> {
  const res = await fetch('/api/subscription/confirm', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId, transactionId, simulatedOutcome }),
  });
  return res.json();
}

/**
 * Vérifie côté serveur l'authenticité d'un objet d'abonnement (anti-falsification)
 */
export async function verifySubscriptionWithServer(sub: Subscription): Promise<{ valid: boolean; reason?: string }> {
  try {
    const res = await fetch('/api/subscription/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(sub),
    });
    return res.json();
  } catch {
    return { valid: false, reason: 'Erreur réseau de validation' };
  }
}

/**
 * Annule un abonnement auprès du serveur
 */
export async function cancelSubscriptionOnServer(userId: string): Promise<any> {
  const res = await fetch('/api/subscription/cancel', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId }),
  });
  return res.json();
}

export function checkPlanLimits(): UsageStatus {
  const sub = getSubscription();
  const isActive = isSubscriptionActive(sub);
  const plan = isActive ? sub.plan : 'free';
  const limits = PLAN_LIMITS[plan];
  const countThisMonth = getMonthlyInvoiceCount();

  const invoicesLimit = limits.invoicesPerMonth;
  const isLimitReached =
    invoicesLimit === 'unlimited' ? false : countThisMonth >= invoicesLimit;

  const remainingInvoices =
    invoicesLimit === 'unlimited'
      ? 'unlimited'
      : Math.max(0, invoicesLimit - countThisMonth);

  // Clients count calculation
  const invoices = getInvoices();
  const uniqueClients = new Set(invoices.map(i => i.clientName.trim().toLowerCase())).size;

  return {
    plan,
    invoicesThisMonth: countThisMonth,
    invoicesLimit,
    isLimitReached,
    remainingInvoices,
    clientsCount: uniqueClients,
    clientsLimit: limits.clientsLimit,
  };
}

export function canCreateInvoice(): boolean {
  const status = checkPlanLimits();
  return !status.isLimitReached;
}
