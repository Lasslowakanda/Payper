import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { UserAccount, Boutique, Invoice } from '../types';

// Read environment variables (Vite client env vars must start with VITE_)
const envSupabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const envSupabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

// Default project configuration provided for this project
const DEFAULT_SUPABASE_URL = 'https://sdmpbmtjsutrmkmecxvg.supabase.co';
const DEFAULT_SUPABASE_ANON_KEY = 'sb_publishable_f13inzdEblpGpATOtEpOng__yMJZ0zW';

// Allow runtime override from localStorage for flexible testing
const storedSupabaseUrl = typeof window !== 'undefined' ? localStorage.getItem('payper_supabase_url') || '' : '';
const storedSupabaseAnonKey = typeof window !== 'undefined' ? localStorage.getItem('payper_supabase_anon_key') || '' : '';

const SUPABASE_URL = (storedSupabaseUrl || envSupabaseUrl || DEFAULT_SUPABASE_URL).trim();
const SUPABASE_ANON_KEY = (storedSupabaseAnonKey || envSupabaseAnonKey || DEFAULT_SUPABASE_ANON_KEY).trim();

export let supabase: SupabaseClient | null = null;

if (SUPABASE_URL && SUPABASE_ANON_KEY && SUPABASE_URL.startsWith('http')) {
  try {
    supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
    });
  } catch (err) {
    console.warn('Erreur d’initialisation du client Supabase:', err);
    supabase = null;
  }
}

export function isSupabaseConnected(): boolean {
  return !!supabase;
}

export function getSupabaseConfig(): { isConfigured: boolean; url: string } {
  return {
    isConfigured: !!supabase,
    url: SUPABASE_URL,
  };
}

export function saveSupabaseConfig(url: string, anonKey: string): void {
  if (url && anonKey) {
    localStorage.setItem('payper_supabase_url', url.trim());
    localStorage.setItem('payper_supabase_anon_key', anonKey.trim());
    window.location.reload();
  }
}

// ==========================================
// E.164 PHONE NUMBER NORMALIZATION
// ==========================================

/**
 * Normalise un numéro au format international E.164 strict (+243..., +221..., etc.)
 * Supprime les espaces, tirets et le zéro local initial éventuel (ex: 081... -> 81...)
 */
export function normalizeToE164(countryCode: string, rawPhone: string): string {
  const cleanCode = countryCode.startsWith('+') ? countryCode : `+${countryCode}`;
  const codeDigits = cleanCode.replace(/\D/g, '');
  let nationalDigits = rawPhone.replace(/\D/g, '');

  if (nationalDigits.startsWith(codeDigits)) {
    nationalDigits = nationalDigits.substring(codeDigits.length);
  }

  if (cleanCode === '+225' && nationalDigits.length === 10 && /^0[157]/.test(nationalDigits)) {
    // Format ivoirien standard à 10 chiffres
  } else if (nationalDigits.startsWith('0')) {
    nationalDigits = nationalDigits.substring(1);
  }

  return `${cleanCode}${nationalDigits}`;
}

// ==========================================
// CRYPTOGRAPHIC 6-DIGIT CODE SECURITY
// ==========================================

const CRYPTO_SALT = 'PAYPER_AUTH_SECURE_SALT_V1_2026';

/**
 * Calcule un hachage SHA-256 non réversible avec sel cryptographique.
 * Le code personnel à 6 chiffres n'est JAMAIS stocké en clair.
 */
export async function hashPinCode(pin: string, phoneE164: string): Promise<string> {
  const data = new TextEncoder().encode(`${CRYPTO_SALT}:${phoneE164}:${pin}`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Dérive un mot de passe compatible Supabase Auth à partir du code à 6 chiffres.
 */
export function deriveSupabasePassword(pin: string, phoneE164: string): string {
  const lastFour = phoneE164.replace(/\D/g, '').slice(-4) || '2026';
  return `Pp!${pin}#${lastFour}$Auth`;
}

// Registre local sécurisé en fallback / mode hors-ligne
interface SecureAccountRecord {
  id: string;
  phoneE164: string;
  name?: string;
  country: string;
  countryCode: string;
  pinHash: string;
  createdAt: string;
  lastLoginAt: string;
}

const SECURE_ACCOUNTS_KEY = 'payper_secure_accounts_v1';

function getSecureAccounts(): SecureAccountRecord[] {
  try {
    const raw = localStorage.getItem(SECURE_ACCOUNTS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.error('Erreur lecture comptes sécurisés', e);
  }
  return [];
}

function saveSecureAccount(account: SecureAccountRecord): void {
  const accounts = getSecureAccounts();
  const index = accounts.findIndex(a => a.phoneE164 === account.phoneE164);
  if (index >= 0) {
    accounts[index] = account;
  } else {
    accounts.push(account);
  }
  localStorage.setItem(SECURE_ACCOUNTS_KEY, JSON.stringify(accounts));
}

// ==========================================
// AUTHENTICATION OPERATIONS
// ==========================================

export interface AuthResult {
  success: boolean;
  user?: UserAccount;
  error?: string;
  isExistingUser?: boolean;
}

/**
 * Inscription avec Pays + Téléphone + Code à 6 chiffres
 * Enregistre le profil dans la table Supabase `profiles` et le registre local sécurisé.
 */
export async function signUpWithPhoneAndPin(
  countryName: string,
  countryCode: string,
  rawPhone: string,
  pin: string
): Promise<AuthResult> {
  const phoneE164 = normalizeToE164(countryCode, rawPhone);

  if (pin.length !== 6 || !/^\d{6}$/.test(pin)) {
    return { success: false, error: 'Le code personnel doit comporter exactement 6 chiffres.' };
  }

  const pinHash = await hashPinCode(pin, phoneE164);
  const userId = `usr_${phoneE164.replace(/\D/g, '')}`;

  // 1. Vérification dans Supabase si connecté
  if (supabase) {
    try {
      const { data: existingProfile } = await supabase
        .from('profiles')
        .select('id, phone')
        .eq('phone', phoneE164)
        .maybeSingle();

      if (existingProfile) {
        return {
          success: false,
          isExistingUser: true,
          error: 'Un compte existe déjà avec ce numéro. Veuillez vous connecter.',
        };
      }

      // Enregistrement dans la table Supabase `profiles`
      const { error: insertErr } = await supabase.from('profiles').upsert({
        id: userId,
        phone: phoneE164,
        name: `Compte ${phoneE164}`,
        country: countryName,
        country_code: countryCode,
        pin_hash: pinHash,
      });

      if (insertErr) {
        console.warn('Supabase profiles insert error:', insertErr.message);
      }

      // Tente également une inscription Supabase Auth (si provider configuré)
      try {
        const supabasePassword = deriveSupabasePassword(pin, phoneE164);
        await supabase.auth.signUp({
          phone: phoneE164,
          password: supabasePassword,
          options: {
            data: {
              country: countryName,
              country_code: countryCode,
            },
          },
        });
      } catch {
        // Optionnel, on ne bloque pas si le provider SMS n'est pas activé
      }
    } catch (err: any) {
      console.warn('Erreur lors de la vérification Supabase:', err);
    }
  }

  // 2. Vérification locale
  const accounts = getSecureAccounts();
  const existingLocal = accounts.find(a => a.phoneE164 === phoneE164);
  if (existingLocal) {
    return {
      success: false,
      isExistingUser: true,
      error: 'Un compte existe déjà avec ce numéro de téléphone. Veuillez vous connecter.',
    };
  }

  // 3. Sauvegarde locale sécurisée
  saveSecureAccount({
    id: userId,
    phoneE164,
    country: countryName,
    countryCode,
    pinHash,
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
  });

  const userAccount: UserAccount = {
    id: userId,
    name: `Compte ${phoneE164}`,
    phone: phoneE164,
    country: countryName,
    countryCode: countryCode,
    isLoggedIn: true,
    createdAt: new Date().toISOString(),
  };

  return { success: true, user: userAccount };
}

/**
 * Connexion avec Pays + Téléphone + Code personnel à 6 chiffres
 * Authentifie via Supabase `profiles` (ou Supabase Auth) et hydrate les boutiques & factures.
 */
export async function signInWithPhoneAndPin(
  countryCode: string,
  rawPhone: string,
  pin: string
): Promise<AuthResult> {
  const phoneE164 = normalizeToE164(countryCode, rawPhone);

  if (pin.length !== 6 || !/^\d{6}$/.test(pin)) {
    return { success: false, error: 'Veuillez saisir votre code personnel à 6 chiffres.' };
  }

  const computedHash = await hashPinCode(pin, phoneE164);

  // 1. Vérification dans la base réelle Supabase
  if (supabase) {
    try {
      const { data: profile, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('phone', phoneE164)
        .maybeSingle();

      if (profile && !error) {
        // Vérification du code PIN haché
        if (profile.pin_hash && profile.pin_hash !== computedHash) {
          return {
            success: false,
            error: 'Numéro de téléphone ou code personnel incorrect.',
          };
        }

        // Succès de connexion via Supabase
        const userAccount: UserAccount = {
          id: profile.id,
          name: profile.name || `Compte ${phoneE164}`,
          phone: phoneE164,
          country: profile.country || undefined,
          countryCode: profile.country_code || countryCode,
          isLoggedIn: true,
          createdAt: profile.created_at || new Date().toISOString(),
        };

        // Sauvegarder dans le cache local sécurisé
        saveSecureAccount({
          id: profile.id,
          phoneE164,
          name: profile.name,
          country: profile.country || '',
          countryCode: profile.country_code || countryCode,
          pinHash: computedHash,
          createdAt: profile.created_at || new Date().toISOString(),
          lastLoginAt: new Date().toISOString(),
        });

        // Hydrater les boutiques et factures depuis Supabase en arrière-plan
        hydrateDataFromSupabase(profile.id).catch(err => {
          console.warn('Hydratation Supabase en arrière-plan:', err);
        });

        return { success: true, user: userAccount };
      }
    } catch (err: any) {
      console.warn('Erreur requête Supabase signIn:', err);
    }
  }

  // 2. Vérification locale sécurisée (fallback / hors-ligne)
  const accounts = getSecureAccounts();
  const account = accounts.find(a => a.phoneE164 === phoneE164);

  if (!account) {
    return {
      success: false,
      error: 'Aucun compte associé à ce numéro de téléphone. Cliquez sur "Créer un compte".',
    };
  }

  if (computedHash !== account.pinHash) {
    return {
      success: false,
      error: 'Numéro de téléphone ou code personnel incorrect.',
    };
  }

  account.lastLoginAt = new Date().toISOString();
  saveSecureAccount(account);

  const userAccount: UserAccount = {
    id: account.id,
    name: account.name || `Compte ${account.phoneE164}`,
    phone: account.phoneE164,
    country: account.country,
    countryCode: account.countryCode,
    isLoggedIn: true,
    createdAt: account.createdAt,
  };

  // Synchroniser ce profil vers Supabase en arrière-plan s'il n'y était pas encore
  if (supabase) {
    supabase.from('profiles').upsert({
      id: account.id,
      phone: account.phoneE164,
      name: account.name || userAccount.name,
      country: account.country,
      country_code: account.countryCode,
      pin_hash: account.pinHash,
    }).then();
  }

  return { success: true, user: userAccount };
}

/**
 * Réinitialisation sécurisée du code personnel (Récupération)
 */
export async function resetPinCode(
  countryCode: string,
  rawPhone: string,
  newPin: string = '123456'
): Promise<AuthResult> {
  const phoneE164 = normalizeToE164(countryCode, rawPhone);

  if (newPin.length !== 6 || !/^\d{6}$/.test(newPin)) {
    return { success: false, error: 'Le nouveau code doit comporter exactement 6 chiffres.' };
  }

  const newPinHash = await hashPinCode(newPin, phoneE164);

  // Mettre à jour dans Supabase
  if (supabase) {
    try {
      await supabase
        .from('profiles')
        .update({ pin_hash: newPinHash, updated_at: new Date().toISOString() })
        .eq('phone', phoneE164);
    } catch {
      // silent
    }
  }

  const accounts = getSecureAccounts();
  const account = accounts.find(a => a.phoneE164 === phoneE164);

  if (account) {
    account.pinHash = newPinHash;
    account.lastLoginAt = new Date().toISOString();
    saveSecureAccount(account);
  }

  const userAccount: UserAccount = {
    id: account?.id || `usr_${phoneE164.replace(/\D/g, '')}`,
    name: account?.name || `Compte ${phoneE164}`,
    phone: phoneE164,
    isLoggedIn: true,
    createdAt: account?.createdAt || new Date().toISOString(),
  };

  return { success: true, user: userAccount };
}

/**
 * Déconnexion Supabase et locale
 */
export async function signOutSupabase(): Promise<void> {
  if (supabase) {
    try {
      await supabase.auth.signOut();
    } catch (e) {
      console.warn('Erreur lors du signOut Supabase', e);
    }
  }
}

// ==========================================
// SYNCHRONISATION DES PROFILS, BOUTIQUES, FACTURES ET CLIENTS
// ==========================================

/**
 * Met à jour le profil utilisateur dans la table Supabase `profiles`
 */
export async function syncUserProfileToSupabase(user: UserAccount): Promise<void> {
  if (!supabase || !user.id) return;
  try {
    await supabase.from('profiles').upsert({
      id: user.id,
      phone: user.phone || '',
      name: user.name,
      country: user.country || null,
      country_code: user.countryCode || null,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'id' });
  } catch (e) {
    console.warn('Erreur sync profil Supabase:', e);
  }
}

/**
 * Synchronise une boutique avec la table Supabase `boutiques`
 */
export async function syncBoutiqueToSupabase(boutique: Boutique, userId?: string): Promise<boolean> {
  if (!supabase) return false;
  try {
    const ownerId = userId || boutique.userId;
    if (!ownerId) return false;

    // S'assurer que le profil propriétaire existe pour respecter la clé étrangère
    await supabase.from('profiles').upsert({
      id: ownerId,
      phone: boutique.phone || `+225${Date.now()}`,
      name: `Propriétaire ${boutique.name}`,
    }, { onConflict: 'id', ignoreDuplicates: true });

    const { error } = await supabase.from('boutiques').upsert({
      id: boutique.id,
      user_id: ownerId,
      name: boutique.name,
      slug: boutique.slug || null,
      payment_method: boutique.paymentMethod || null,
      logo: boutique.logo || null,
      devise: boutique.devise || 'FCFA',
      country: boutique.country || null,
      country_code: boutique.countryCode || null,
      city: boutique.city || null,
      phone: boutique.phone || null,
      website: boutique.website || null,
      whatsapp_number: boutique.whatsappNumber || null,
      is_active: boutique.isActive ?? true,
    });

    if (error) {
      console.warn('Erreur sync boutique Supabase:', error.message);
      return false;
    }
    return true;
  } catch (err) {
    console.warn('Exception sync boutique Supabase:', err);
    return false;
  }
}

/**
 * Supprime une boutique et ses factures/clients associés dans Supabase
 */
export async function syncBoutiqueDeleteToSupabase(boutiqueId: string): Promise<void> {
  if (!supabase || !boutiqueId) return;
  try {
    await supabase.from('invoices').delete().eq('boutique_id', boutiqueId);
    await supabase.from('clients').delete().eq('boutique_id', boutiqueId);
    await supabase.from('boutiques').delete().eq('id', boutiqueId);
  } catch (err) {
    console.warn('Erreur suppression boutique Supabase:', err);
  }
}

/**
 * Synchronise une facture et son client avec Supabase
 */
export async function syncInvoiceToSupabase(invoice: Invoice, boutiqueId: string): Promise<boolean> {
  if (!supabase || !boutiqueId) return false;
  try {
    // 1. Synchroniser le client dans la table `clients`
    let clientId = invoice.client_id;
    if (invoice.clientName) {
      const derivedClientId = clientId || `cli_${boutiqueId}_${encodeURIComponent(invoice.clientName.trim().toLowerCase())}`;
      clientId = derivedClientId;
      try {
        await supabase.from('clients').upsert({
          id: derivedClientId,
          boutique_id: boutiqueId,
          name: invoice.clientName.trim(),
          city: invoice.clientCity || null,
          phone: invoice.whatsappNumber || null,
          whatsapp_number: invoice.whatsappNumber || null,
        });
      } catch (cErr) {
        // silent client sync fallback
      }
    }

    // 2. Synchroniser la facture dans `invoices`
    const { error } = await supabase.from('invoices').upsert({
      id: invoice.id,
      boutique_id: boutiqueId,
      client_id: clientId || null,
      client_name: invoice.clientName || 'Client',
      client_city: invoice.clientCity || null,
      whatsapp_number: invoice.whatsappNumber || null,
      description: invoice.description || 'Facture',
      amount: Number(invoice.amount) || 0,
      devise: invoice.devise || 'FCFA',
      is_paid: Boolean(invoice.isPaid),
      status: invoice.isPaid ? 'PAID' : (invoice.status || 'PENDING'),
      date: invoice.date || new Date().toISOString().split('T')[0],
      due_date: invoice.dueDate || null,
      notes: invoice.notes || null,
      items: Array.isArray(invoice.items) ? invoice.items : [],
    });

    if (error) {
      console.warn('Erreur sync invoice Supabase:', error.message);
      return false;
    }
    return true;
  } catch (err) {
    console.warn('Exception sync invoice Supabase:', err);
    return false;
  }
}

/**
 * Supprime une facture dans Supabase
 */
export async function syncInvoiceDeleteToSupabase(invoiceId: string): Promise<void> {
  if (!supabase || !invoiceId) return;
  try {
    await supabase.from('invoices').delete().eq('id', invoiceId);
  } catch (err) {
    console.warn('Erreur suppression invoice Supabase:', err);
  }
}

/**
 * Récupère les boutiques d'un utilisateur depuis Supabase
 */
export async function fetchBoutiquesFromSupabase(userId: string): Promise<Boutique[]> {
  if (!supabase || !userId) return [];
  try {
    const { data, error } = await supabase.from('boutiques').select('*').eq('user_id', userId);
    if (error || !data) return [];
    return data.map((b: any) => ({
      id: b.id,
      userId: b.user_id,
      ownerPhone: b.owner_phone || b.phone || undefined,
      name: b.name,
      slug: b.slug || undefined,
      paymentMethod: b.payment_method || undefined,
      logo: b.logo || undefined,
      devise: b.devise || 'FCFA',
      country: b.country || undefined,
      countryCode: b.country_code || undefined,
      city: b.city || undefined,
      phone: b.phone || undefined,
      website: b.website || undefined,
      whatsappNumber: b.whatsapp_number || undefined,
      isActive: b.is_active ?? true,
      createdAt: b.created_at,
    }));
  } catch {
    return [];
  }
}

/**
 * Récupère les factures d'une boutique depuis Supabase
 */
export async function fetchInvoicesFromSupabase(boutiqueId: string): Promise<Invoice[]> {
  if (!supabase || !boutiqueId) return [];
  try {
    const { data, error } = await supabase.from('invoices').select('*').eq('boutique_id', boutiqueId);
    if (error || !data) return [];
    return data.map((inv: any) => ({
      id: inv.id,
      clientName: inv.client_name,
      clientCity: inv.client_city || '',
      whatsappNumber: inv.whatsapp_number || undefined,
      description: inv.description || '',
      amount: Number(inv.amount) || 0,
      devise: inv.devise || 'FCFA',
      date: inv.date || '',
      dueDate: inv.due_date || undefined,
      boutiqueName: '',
      isPaid: Boolean(inv.is_paid),
      status: inv.status,
      notes: inv.notes || undefined,
      items: Array.isArray(inv.items) ? inv.items : [],
      createdAt: inv.created_at,
      user_id: inv.user_id,
      store_id: inv.boutique_id,
      client_id: inv.client_id,
    }));
  } catch {
    return [];
  }
}

/**
 * Hydrate le cache localStorage avec les données distantes de Supabase
 * Isole strictement les boutiques du compte connecté :
 * - Les boutiques distantes de ce compte sont fusionnées
 * - Les boutiques d'autres comptes stockées sur cet appareil sont préservées sans être mélangées
 * - La boutique active choisie appartient EXCLUSIVEMENT à ce compte
 */
export async function hydrateDataFromSupabase(userId: string): Promise<void> {
  if (!supabase || !userId) return;
  try {
    const remoteBoutiques = await fetchBoutiquesFromSupabase(userId);
    if (remoteBoutiques.length > 0) {
      const localRaw = localStorage.getItem('payper_boutiques_list');
      const localList: Boutique[] = localRaw ? JSON.parse(localRaw) : [];

      // Conserver intactes les boutiques des autres comptes enregistrées sur cet appareil
      const otherAccountsBoutiques = localList.filter(b => b.userId && b.userId !== userId);

      // Pour ce compte, fusionner local et distant en donnant priorité à Supabase
      const thisAccountLocal = localList.filter(b => b.userId === userId);
      const mergedMap = new Map<string, Boutique>();
      for (const b of thisAccountLocal) if (b.id) mergedMap.set(b.id, b);
      for (const b of remoteBoutiques) if (b.id) mergedMap.set(b.id, b);

      const thisAccountBoutiques = Array.from(mergedMap.values());
      const allBoutiques = [...otherAccountsBoutiques, ...thisAccountBoutiques];
      localStorage.setItem('payper_boutiques_list', JSON.stringify(allBoutiques));

      // Activer STRICTEMENT une boutique appartenant à CE compte
      const activeId = localStorage.getItem('payper_active_boutique_id');
      const targetBoutique = thisAccountBoutiques.find(b => b.id === activeId) || thisAccountBoutiques[0];

      if (targetBoutique && targetBoutique.id) {
        localStorage.setItem('payper_active_boutique_id', targetBoutique.id);
        localStorage.setItem('payper_boutique', JSON.stringify(targetBoutique));

        // Hydrater les factures de cette boutique
        const remoteInvoices = await fetchInvoicesFromSupabase(targetBoutique.id);
        if (remoteInvoices.length > 0) {
          const invKey = 'payper_boutique_invoices_' + targetBoutique.id;
          const localInvRaw = localStorage.getItem(invKey);
          const localInvs: Invoice[] = localInvRaw ? JSON.parse(localInvRaw) : [];
          const invMap = new Map<string, Invoice>();

          for (const inv of localInvs) if (inv.id) invMap.set(inv.id, inv);
          for (const inv of remoteInvoices) {
            if (inv.id) {
              invMap.set(inv.id, {
                ...inv,
                boutiqueName: targetBoutique.name,
                boutiqueLogo: targetBoutique.logo,
                boutiqueCity: targetBoutique.city,
              });
            }
          }

          const finalInvoices = Array.from(invMap.values());
          localStorage.setItem(invKey, JSON.stringify(finalInvoices));
          localStorage.setItem('payper_invoices', JSON.stringify(finalInvoices));
        }
      }

      window.dispatchEvent(new Event('payper_boutiques_updated'));
      window.dispatchEvent(new Event('payper_boutique_updated'));
      window.dispatchEvent(new Event('payper_invoices_updated'));
    }
  } catch (err) {
    console.warn('Erreur lors de l’hydratation Supabase:', err);
  }
}

/**
 * Synchronisation bi-directionnelle complète de toutes les données avec Supabase
 */
export async function syncAllDataWithSupabase(): Promise<{ success: boolean; message: string }> {
  if (!supabase) {
    return { success: false, message: 'Client Supabase non initialisé.' };
  }

  try {
    const rawUser = localStorage.getItem('payper_user');
    const user: UserAccount | null = rawUser ? JSON.parse(rawUser) : null;

    if (!user || !user.isLoggedIn || !user.id) {
      return { success: false, message: 'Utilisateur non connecté.' };
    }

    // 1. Sync User Profile
    await syncUserProfileToSupabase(user);

    // 2. Sync Boutiques
    const rawBoutiques = localStorage.getItem('payper_boutiques_list');
    const boutiques: Boutique[] = rawBoutiques ? JSON.parse(rawBoutiques) : [];

    for (const b of boutiques) {
      await syncBoutiqueToSupabase(b, user.id);

      // 3. Sync Invoices for each boutique
      if (b.id) {
        const rawInvoices = localStorage.getItem('payper_boutique_invoices_' + b.id);
        const invoices: Invoice[] = rawInvoices ? JSON.parse(rawInvoices) : [];
        for (const inv of invoices) {
          await syncInvoiceToSupabase(inv, b.id);
        }
      }
    }

    // 4. Hydrater en retour
    await hydrateDataFromSupabase(user.id);

    return { success: true, message: 'Synchronisation Cloud Supabase réussie avec succès !' };
  } catch (err: any) {
    return { success: false, message: err?.message || 'Erreur de synchronisation.' };
  }
}
