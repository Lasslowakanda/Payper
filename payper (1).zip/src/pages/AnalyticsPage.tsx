import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  TrendingUp,
  DollarSign,
  FileCheck2,
  Users,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Download,
  Printer,
  Search,
  Filter,
  CheckCircle2,
  ChevronRight,
  Plus,
  RefreshCw,
  Store,
  Share2,
  Eye,
  AlertCircle,
  FileSpreadsheet,
} from 'lucide-react';
import {
  AnalyticsPeriod,
  PERIOD_OPTIONS,
  computeAnalytics,
  exportAnalyticsCSV,
  DayDataPoint,
} from '../lib/analytics';
import { getInvoices, getActiveBoutique, updateInvoice } from '../lib/storage';
import { formatCurrency, formatDate } from '../lib/invoice';
import { Boutique, Currency, Invoice } from '../types';
import { AnalyticsCharts } from '../components/analytics/AnalyticsCharts';
import { DayDetailModal } from '../components/analytics/DayDetailModal';
import { PrintReportModal } from '../components/analytics/PrintReportModal';
import { useToast } from '../components/common/Toast';
import { useLayoutActions } from '../components/layout/AppLayout';

interface AnalyticsPageProps {
  onNavigate: (path: string) => void;
}

export const AnalyticsPage: React.FC<AnalyticsPageProps> = ({ onNavigate }) => {
  const { showToast } = useToast();
  const { openNewInvoice } = useLayoutActions();

  // Active Store & Invoices state
  const [boutique, setBoutique] = useState<Boutique | null>(() => getActiveBoutique());
  const [invoices, setInvoices] = useState<Invoice[]>(() => getInvoices());

  // Period Selector State (Default: 28 days as highlighted in user prompt)
  const [selectedPeriod, setSelectedPeriod] = useState<AnalyticsPeriod>('28days');
  const [customStartDate, setCustomStartDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() - 27);
    return d.toISOString().slice(0, 10);
  });
  const [customEndDate, setCustomEndDate] = useState<string>(() => {
    return new Date().toISOString().slice(0, 10);
  });

  // Table filters & interaction states
  const [tableFilter, setTableFilter] = useState<'all' | 'paid' | 'pending'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDayPoint, setSelectedDayPoint] = useState<DayDataPoint | null>(null);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Sync with live store events (when invoice added, edited or store switched)
  const reloadData = () => {
    setBoutique(getActiveBoutique());
    setInvoices(getInvoices());
  };

  useEffect(() => {
    const handleUpdate = () => reloadData();
    window.addEventListener('payper_invoices_updated', handleUpdate);
    window.addEventListener('payper_boutique_updated', handleUpdate);
    window.addEventListener('payper_boutiques_updated', handleUpdate);

    return () => {
      window.removeEventListener('payper_invoices_updated', handleUpdate);
      window.removeEventListener('payper_boutique_updated', handleUpdate);
      window.removeEventListener('payper_boutiques_updated', handleUpdate);
    };
  }, []);

  const currency: Currency = boutique?.devise || 'FCFA';

  // Compute all analytics metrics and series using real data
  const stats = useMemo(() => {
    return computeAnalytics(
      invoices,
      selectedPeriod,
      currency,
      customStartDate,
      customEndDate
    );
  }, [invoices, selectedPeriod, currency, customStartDate, customEndDate]);

  // Filtered invoices in the bottom detail table
  const tableInvoices = useMemo(() => {
    return stats.currentInvoices.filter(inv => {
      // Status filter
      if (tableFilter === 'paid' && !inv.isPaid) return false;
      if (tableFilter === 'pending' && inv.isPaid) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const mClient = (inv.clientName || '').toLowerCase().includes(q);
        const mDesc = (inv.description || '').toLowerCase().includes(q);
        const mId = (inv.id || '').toLowerCase().includes(q);
        if (!mClient && !mDesc && !mId) return false;
      }

      return true;
    });
  }, [stats.currentInvoices, tableFilter, searchQuery]);

  const handleMarkAsPaid = (inv: Invoice, e?: React.MouseEvent) => {
    e?.stopPropagation();
    const updated = { ...inv, isPaid: true };
    updateInvoice(updated);
    reloadData();
    showToast(`Facture ${inv.id} marquée comme payée !`, 'success');
  };

  const handleExportCSV = () => {
    exportAnalyticsCSV(boutique, stats);
    showToast('Export CSV téléchargé avec succès !', 'success');
  };

  return (
    <div className="space-y-7 animate-in fade-in duration-300 pb-12">
      {/* =========================================================================
          TOP BANNER: TITRE & ACTIONS
          ========================================================================= */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5 mb-1">
            <span className="text-2xl sm:text-3xl">📊</span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#111827] tracking-tight">
              Analytics & Statistiques
            </h1>
          </div>
          <p className="text-sm text-neutral-500">
            Performances réelles de la boutique{' '}
            <strong className="text-neutral-800 font-bold">
              {boutique?.name || 'Ma Boutique'}
            </strong>{' '}
            avec analyse comparative en direct.
          </p>
        </div>

        {/* Action Buttons: Exporter CSV & Imprimer / PDF */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 py-2.5 px-3.5 rounded-xl text-xs font-bold bg-white hover:bg-neutral-50 text-neutral-700 border border-neutral-200/90 shadow-2xs hover:border-neutral-300 transition-all cursor-pointer"
            title="Télécharger le fichier CSV pour Excel"
          >
            <FileSpreadsheet className="w-4 h-4 text-[#00C48C]" />
            <span>Exporter CSV</span>
          </button>

          <button
            onClick={() => setIsPrintModalOpen(true)}
            className="flex items-center gap-1.5 py-2.5 px-3.5 rounded-xl text-xs font-bold bg-white hover:bg-neutral-50 text-neutral-700 border border-neutral-200/90 shadow-2xs hover:border-neutral-300 transition-all cursor-pointer"
            title="Imprimer ou enregistrer le rapport en PDF"
          >
            <Printer className="w-4 h-4 text-[#FF8A00]" />
            <span>Rapport PDF</span>
          </button>

          <button
            onClick={openNewInvoice}
            className="flex items-center gap-1.5 py-2.5 px-4 rounded-xl text-xs font-bold bg-[#FF8A00] hover:bg-[#e67c00] text-white shadow-xs shadow-orange-500/20 active:scale-95 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Nouvelle facture</span>
          </button>
        </div>
      </div>

      {/* =========================================================================
          2. SÉLECTEUR DE PÉRIODES INTERACTIF
          ========================================================================= */}
      <div className="bg-white rounded-3xl p-4 sm:p-5 shadow-xs border border-neutral-200/80">
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2 text-xs font-bold text-neutral-700">
              <Calendar className="w-4 h-4 text-[#FF8A00]" />
              <span>Période d'analyse :</span>
              <span className="text-neutral-500 font-medium">
                {stats.periodLabel}
              </span>
            </div>

            <div className="text-xs text-neutral-400 font-medium">
              Comparé automatiquement à :{' '}
              <span className="font-semibold text-neutral-600">
                {stats.previousRange.label}
              </span>
            </div>
          </div>

          {/* Interactive Horizontal Period Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-1 no-scrollbar">
            {PERIOD_OPTIONS.map(opt => {
              const isActive = selectedPeriod === opt.id;
              return (
                <button
                  key={opt.id}
                  onClick={() => setSelectedPeriod(opt.id)}
                  className={`py-2 px-3.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer shrink-0 ${
                    isActive
                      ? 'bg-[#111827] text-white shadow-sm'
                      : 'bg-neutral-100 hover:bg-neutral-200/80 text-neutral-700'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>

          {/* Custom Date Pickers (Shown only when 'custom' is selected) */}
          <AnimatePresence>
            {selectedPeriod === 'custom' && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="pt-3 border-t border-neutral-100 flex flex-wrap items-center gap-3 overflow-hidden"
              >
                <div className="flex items-center gap-2">
                  <label className="text-xs font-medium text-neutral-500">Du :</label>
                  <input
                    type="date"
                    value={customStartDate}
                    onChange={e => setCustomStartDate(e.target.value)}
                    className="py-1.5 px-3 rounded-xl border border-neutral-200 text-xs font-semibold text-neutral-800 bg-neutral-50 focus:bg-white focus:outline-none focus:border-[#FF8A00]"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <label className="text-xs font-medium text-neutral-500">Au :</label>
                  <input
                    type="date"
                    value={customEndDate}
                    onChange={e => setCustomEndDate(e.target.value)}
                    className="py-1.5 px-3 rounded-xl border border-neutral-200 text-xs font-semibold text-neutral-800 bg-neutral-50 focus:bg-white focus:outline-none focus:border-[#FF8A00]"
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* =========================================================================
          3. CARTES DE STATISTIQUES INTERACTIVES AVEC COMPARAISON INTELLIGENTE
          ========================================================================= */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3.5 sm:gap-4">
        {/* CARTE 1 : 💰 Chiffre d'affaires */}
        <div
          onClick={() => setTableFilter('paid')}
          className="bg-white rounded-3xl p-5 shadow-xs border border-neutral-200/80 hover:border-emerald-300 transition-all cursor-pointer group flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-neutral-500">
                💰 Chiffre d'affaires
              </span>
              <div className="w-8 h-8 rounded-xl bg-emerald-50 text-[#00C48C] flex items-center justify-center">
                <DollarSign className="w-4 h-4 stroke-[2.5]" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-black text-[#111827] tracking-tight">
              {formatCurrency(stats.revenue.current, currency)}
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-neutral-100 flex items-center justify-between">
            {stats.revenue.percentChange !== null ? (
              <span
                className={`inline-flex items-center gap-0.5 text-xs font-bold ${
                  stats.revenue.trend === 'up'
                    ? 'text-emerald-700'
                    : stats.revenue.trend === 'down'
                    ? 'text-rose-600'
                    : 'text-neutral-500'
                }`}
              >
                {stats.revenue.trend === 'up' && <ArrowUpRight className="w-3.5 h-3.5 stroke-[3]" />}
                {stats.revenue.trend === 'down' && <ArrowDownRight className="w-3.5 h-3.5 stroke-[3]" />}
                <span>
                  {stats.revenue.percentChange > 0 ? '+' : ''}
                  {stats.revenue.percentChange}%
                </span>
              </span>
            ) : (
              <span className="text-[10px] text-neutral-400">Période initiale</span>
            )}
            <span className="text-[10px] text-neutral-400 font-medium truncate">
              Préc: {formatCurrency(stats.revenue.previous, currency)}
            </span>
          </div>
        </div>

        {/* CARTE 2 : 🧾 Factures créées */}
        <div
          onClick={() => setTableFilter('all')}
          className="bg-white rounded-3xl p-5 shadow-xs border border-neutral-200/80 hover:border-blue-300 transition-all cursor-pointer group flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-neutral-500">
                🧾 Factures
              </span>
              <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                <FileCheck2 className="w-4 h-4 stroke-[2.5]" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-black text-[#111827] tracking-tight">
              {stats.invoicesCount.current}
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-neutral-100 flex items-center justify-between">
            {stats.invoicesCount.percentChange !== null ? (
              <span
                className={`inline-flex items-center gap-0.5 text-xs font-bold ${
                  stats.invoicesCount.trend === 'up'
                    ? 'text-emerald-700'
                    : stats.invoicesCount.trend === 'down'
                    ? 'text-rose-600'
                    : 'text-neutral-500'
                }`}
              >
                {stats.invoicesCount.trend === 'up' && <ArrowUpRight className="w-3.5 h-3.5 stroke-[3]" />}
                {stats.invoicesCount.trend === 'down' && <ArrowDownRight className="w-3.5 h-3.5 stroke-[3]" />}
                <span>
                  {stats.invoicesCount.percentChange > 0 ? '+' : ''}
                  {stats.invoicesCount.percentChange}%
                </span>
              </span>
            ) : (
              <span className="text-[10px] text-neutral-400">Période initiale</span>
            )}
            <span className="text-[10px] text-neutral-400 font-medium">
              Préc: {stats.invoicesCount.previous}
            </span>
          </div>
        </div>

        {/* CARTE 3 : ✅ Factures payées */}
        <div
          onClick={() => setTableFilter('paid')}
          className="bg-white rounded-3xl p-5 shadow-xs border border-neutral-200/80 hover:border-emerald-300 transition-all cursor-pointer group flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-neutral-500">
                ✅ Factures payées
              </span>
              <div className="w-8 h-8 rounded-xl bg-emerald-50 text-[#00C48C] flex items-center justify-center">
                <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-black text-[#00C48C] tracking-tight">
              {stats.paidInvoicesCount.current}
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-neutral-100 flex items-center justify-between">
            {stats.paidInvoicesCount.percentChange !== null ? (
              <span
                className={`inline-flex items-center gap-0.5 text-xs font-bold ${
                  stats.paidInvoicesCount.trend === 'up'
                    ? 'text-emerald-700'
                    : stats.paidInvoicesCount.trend === 'down'
                    ? 'text-rose-600'
                    : 'text-neutral-500'
                }`}
              >
                {stats.paidInvoicesCount.trend === 'up' && <ArrowUpRight className="w-3.5 h-3.5 stroke-[3]" />}
                {stats.paidInvoicesCount.trend === 'down' && <ArrowDownRight className="w-3.5 h-3.5 stroke-[3]" />}
                <span>
                  {stats.paidInvoicesCount.percentChange > 0 ? '+' : ''}
                  {stats.paidInvoicesCount.percentChange}%
                </span>
              </span>
            ) : (
              <span className="text-[10px] text-neutral-400">Période initiale</span>
            )}
            <span className="text-[10px] text-neutral-400 font-medium">
              Préc: {stats.paidInvoicesCount.previous}
            </span>
          </div>
        </div>

        {/* CARTE 4 : ⏳ Impayés (Montant restant à encaisser) */}
        <div
          onClick={() => setTableFilter('pending')}
          className="bg-white rounded-3xl p-5 shadow-xs border border-neutral-200/80 hover:border-orange-300 transition-all cursor-pointer group flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-neutral-500">
                ⏳ Impayés
              </span>
              <div className="w-8 h-8 rounded-xl bg-orange-50 text-[#FF8A00] flex items-center justify-center">
                <Clock className="w-4 h-4 stroke-[2.5]" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-black text-[#FF8A00] tracking-tight">
              {formatCurrency(stats.pendingAmount.current, currency)}
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-neutral-100 flex items-center justify-between">
            <span className="text-[10px] font-bold text-neutral-600">
              {stats.pendingInvoices.length} à relancer
            </span>
            <span className="text-[10px] text-neutral-400 font-medium truncate">
              Préc: {formatCurrency(stats.pendingAmount.previous, currency)}
            </span>
          </div>
        </div>

        {/* CARTE 5 : 👥 Clients enregistrés */}
        <div
          onClick={() => onNavigate('/clients')}
          className="bg-white rounded-3xl p-5 shadow-xs border border-neutral-200/80 hover:border-purple-300 transition-all cursor-pointer group flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-neutral-500">
                👥 Clients
              </span>
              <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
                <Users className="w-4 h-4 stroke-[2.5]" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-black text-[#111827] tracking-tight">
              {stats.clientsCount.current}
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-neutral-100 flex items-center justify-between">
            {stats.clientsCount.percentChange !== null ? (
              <span
                className={`inline-flex items-center gap-0.5 text-xs font-bold ${
                  stats.clientsCount.trend === 'up'
                    ? 'text-emerald-700'
                    : stats.clientsCount.trend === 'down'
                    ? 'text-rose-600'
                    : 'text-neutral-500'
                }`}
              >
                {stats.clientsCount.trend === 'up' && <ArrowUpRight className="w-3.5 h-3.5 stroke-[3]" />}
                {stats.clientsCount.trend === 'down' && <ArrowDownRight className="w-3.5 h-3.5 stroke-[3]" />}
                <span>
                  {stats.clientsCount.percentChange > 0 ? '+' : ''}
                  {stats.clientsCount.percentChange}%
                </span>
              </span>
            ) : (
              <span className="text-[10px] text-neutral-400">Période initiale</span>
            )}
            <span className="text-[10px] text-neutral-400 font-medium">
              Préc: {stats.clientsCount.previous}
            </span>
          </div>
        </div>

        {/* CARTE 6 : 📈 Évolution générale */}
        <div className="bg-gradient-to-br from-neutral-900 to-[#111827] text-white rounded-3xl p-5 shadow-md flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-neutral-300">
                📈 Évolution
              </span>
              <div className="w-8 h-8 rounded-xl bg-white/10 text-white flex items-center justify-center">
                <TrendingUp className="w-4 h-4 stroke-[2.5]" />
              </div>
            </div>
            <div className="text-xl sm:text-2xl font-black tracking-tight text-white">
              {stats.revenue.percentChange !== null ? (
                <span className={stats.revenue.percentChange >= 0 ? 'text-[#00C48C]' : 'text-rose-400'}>
                  {stats.revenue.percentChange > 0 ? '+' : ''}
                  {stats.revenue.percentChange}%
                </span>
              ) : (
                'Stable'
              )}
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between text-[10px] text-neutral-300">
            <span>Taux recouvrement</span>
            <span className="font-extrabold text-[#00C48C]">{stats.collectionRate}%</span>
          </div>
        </div>
      </div>

      {/* =========================================================================
          4. GRAPHIQUES PROFESSIONNELS (1, 2, 3, 4)
          ========================================================================= */}
      <AnalyticsCharts
        stats={stats}
        currency={currency}
        onSelectDay={day => setSelectedDayPoint(day)}
        onFilterByStatus={status => setTableFilter(status)}
        onSelectClient={name => {
          setSearchQuery(name);
          const el = document.getElementById('analytics-invoices-table');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {/* =========================================================================
          5. DÉTAIL DES FACTURES DE LA PÉRIODE (Tableau interactif)
          ========================================================================= */}
      <div id="analytics-invoices-table" className="bg-white rounded-3xl p-5 sm:p-7 shadow-xs border border-neutral-200/80">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-[#111827]">
              Factures de la période ({tableInvoices.length})
            </h2>
            <p className="text-xs text-neutral-500">
              Liste détaillée des factures générées pendant {stats.periodLabel.toLowerCase()}.
            </p>
          </div>

          {/* Filter Pills & Search */}
          <div className="flex flex-col sm:flex-row sm:items-center gap-2.5">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Rechercher client, numéro..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="py-1.5 pl-8 pr-3 rounded-xl border border-neutral-200 text-xs font-medium text-neutral-800 bg-neutral-50 focus:bg-white focus:outline-none focus:border-[#FF8A00] w-full sm:w-[200px]"
              />
            </div>

            {/* Status pills */}
            <div className="flex items-center gap-1 bg-neutral-100 p-1 rounded-xl">
              <button
                onClick={() => setTableFilter('all')}
                className={`py-1 px-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  tableFilter === 'all'
                    ? 'bg-white text-neutral-900 shadow-2xs'
                    : 'text-neutral-500 hover:text-neutral-800'
                }`}
              >
                Toutes ({stats.currentInvoices.length})
              </button>
              <button
                onClick={() => setTableFilter('paid')}
                className={`py-1 px-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  tableFilter === 'paid'
                    ? 'bg-emerald-50 text-emerald-800 shadow-2xs'
                    : 'text-neutral-500 hover:text-neutral-800'
                }`}
              >
                Payées ({stats.paidInvoicesCount.current})
              </button>
              <button
                onClick={() => setTableFilter('pending')}
                className={`py-1 px-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  tableFilter === 'pending'
                    ? 'bg-orange-50 text-orange-800 shadow-2xs'
                    : 'text-neutral-500 hover:text-neutral-800'
                }`}
              >
                Impayés ({stats.pendingInvoices.length})
              </button>
            </div>
          </div>
        </div>

        {/* Invoices List / Table */}
        {tableInvoices.length === 0 ? (
          <div className="py-14 text-center text-sm text-neutral-400 bg-neutral-50 rounded-2xl border border-neutral-100">
            Aucune facture ne correspond à ces critères sur cette période.
          </div>
        ) : (
          <div className="border border-neutral-200/80 rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-50/80 border-b border-neutral-200 text-neutral-600 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="py-3 px-4">Facture</th>
                    <th className="py-3 px-4">Date</th>
                    <th className="py-3 px-4">Client</th>
                    <th className="py-3 px-4">Montant</th>
                    <th className="py-3 px-4">Statut</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {tableInvoices.map(inv => (
                    <tr
                      key={inv.id}
                      onClick={() => onNavigate(`/invoice/${inv.id}`)}
                      className="hover:bg-orange-50/30 transition-colors cursor-pointer group"
                    >
                      <td className="py-3 px-4 font-bold text-neutral-900 group-hover:text-[#FF8A00] transition-colors">
                        {inv.id}
                      </td>
                      <td className="py-3 px-4 text-neutral-500 font-medium whitespace-nowrap">
                        {formatDate(inv.date)}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-bold text-neutral-800">{inv.clientName}</div>
                        {inv.clientCity && (
                          <div className="text-[10px] text-neutral-400">{inv.clientCity}</div>
                        )}
                      </td>
                      <td className="py-3 px-4 font-black text-sm text-[#111827] whitespace-nowrap">
                        {formatCurrency(inv.amount, inv.devise || currency)}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold ${
                            inv.isPaid
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {inv.isPaid ? 'PAYÉE' : 'EN ATTENTE'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5" onClick={e => e.stopPropagation()}>
                          {!inv.isPaid && (
                            <button
                              onClick={e => handleMarkAsPaid(inv, e)}
                              className="py-1 px-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white text-[11px] font-bold shadow-2xs transition-all cursor-pointer"
                              title="Encaisser"
                            >
                              Encaisser
                            </button>
                          )}
                          <button
                            onClick={() => onNavigate(`/invoice/${inv.id}`)}
                            className="p-1 text-neutral-400 hover:text-neutral-700 transition-colors cursor-pointer"
                            title="Voir la facture"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* =========================================================================
          MODALS : DETAIL D'UNE JOURNÉE & RAPPORT D'IMPRESSION
          ========================================================================= */}
      <DayDetailModal
        dayPoint={selectedDayPoint}
        currency={currency}
        onClose={() => setSelectedDayPoint(null)}
        onNavigateToInvoice={id => onNavigate(`/invoice/${id}`)}
        onInvoiceUpdated={() => reloadData()}
      />

      <PrintReportModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        stats={stats}
        boutique={boutique}
        currency={currency}
      />
    </div>
  );
};
