import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Zap,
  Repeat,
  Bell,
  Calendar,
  Clock,
  Play,
  Plus,
  CheckCircle2,
  AlertCircle,
  Trash2,
  Pause,
  ExternalLink,
  ShieldCheck,
  Send,
  MessageCircle,
  HelpCircle,
  ArrowRight,
  Layers,
  LayoutGrid,
} from 'lucide-react';
import {
  getAutomationSettings,
  saveAutomationSettings,
  getReminderLogs,
  getRecurringSchedules,
  createRecurringSchedule,
  updateRecurringScheduleStatus,
  deleteRecurringSchedule,
  executeDailyAutomationCycle,
  getTodayDateString,
  getBoutiqueTimezone,
  buildReminderWhatsAppUrl,
  addDaysToDate,
} from '../lib/automations';
import { getInvoices, getActiveBoutique } from '../lib/storage';
import { CURRENCIES, formatCurrency, formatDate } from '../lib/invoice';
import {
  AutomationSettings,
  RecurringSchedule,
  ReminderLog,
  Invoice,
  RecurrenceFrequency,
  Currency,
} from '../types';
import { useToast } from '../components/common/Toast';
import { PayperLoader } from '../components/payper-loader';
import { IntegrationsGallery } from '../components/automations/IntegrationsGallery';
import { WorkflowBuilder } from '../components/automations/WorkflowBuilder';

interface AutomationsPageProps {
  onNavigate: (path: string) => void;
}

export const AutomationsPage: React.FC<AutomationsPageProps> = ({ onNavigate }) => {
  const { showToast } = useToast();
  const boutique = getActiveBoutique();
  const timezone = getBoutiqueTimezone(boutique?.id);
  const todayStr = getTodayDateString(timezone);

  const [settings, setSettings] = useState<AutomationSettings>(() => getAutomationSettings());
  const [schedules, setSchedules] = useState<RecurringSchedule[]>(() => getRecurringSchedules());
  const [reminderLogs, setReminderLogs] = useState<ReminderLog[]>(() => getReminderLogs());
  const [invoices, setInvoices] = useState<Invoice[]>(() => getInvoices());

  const [activeTab, setActiveTab] = useState<'apps' | 'workflows' | 'reminders' | 'recurring' | 'settings'>('apps');
  const [preselectedWorkflowApp, setPreselectedWorkflowApp] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isNewScheduleModalOpen, setIsNewScheduleModalOpen] = useState(false);

  // New recurring form state
  const [clientName, setClientName] = useState('');
  const [clientCity, setClientCity] = useState(boutique?.city || 'Dakar');
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState<Currency>(boutique?.devise || 'FCFA');
  const [frequency, setFrequency] = useState<RecurrenceFrequency>('MONTHLY');
  const [startDate, setStartDate] = useState(todayStr);
  const [dueDateOffset, setDueDateOffset] = useState(7);
  const [scheduleRemindersEnabled, setScheduleRemindersEnabled] = useState(true);
  const [schedulePaymentLink, setSchedulePaymentLink] = useState('');
  const [scheduleNotes, setScheduleNotes] = useState('');

  const reloadData = () => {
    setSettings(getAutomationSettings());
    setSchedules(getRecurringSchedules());
    setReminderLogs(getReminderLogs());
    setInvoices(getInvoices());
  };

  useEffect(() => {
    const handleUpdate = () => reloadData();
    window.addEventListener('payper_automations_updated', handleUpdate);
    window.addEventListener('payper_reminders_updated', handleUpdate);
    window.addEventListener('payper_recurring_updated', handleUpdate);
    window.addEventListener('payper_invoices_updated', handleUpdate);

    return () => {
      window.removeEventListener('payper_automations_updated', handleUpdate);
      window.removeEventListener('payper_reminders_updated', handleUpdate);
      window.removeEventListener('payper_recurring_updated', handleUpdate);
      window.removeEventListener('payper_invoices_updated', handleUpdate);
    };
  }, []);

  const handleRunManualCycle = () => {
    setIsProcessing(true);
    setTimeout(() => {
      const result = executeDailyAutomationCycle();
      reloadData();
      setIsProcessing(false);
      showToast(
        `Cycle exécuté : ${result.recurringResult.processedCount} facture(s) récurrente(s) générée(s), ${result.remindersResult.triggeredCount} relance(s) traitée(s).`,
        'success'
      );
    }, 600);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    saveAutomationSettings(settings);
    showToast('Paramètres d’automatisation enregistrés ✓', 'success');
  };

  const handleCreateSchedule = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (!clientName.trim() || isNaN(numAmount) || numAmount <= 0 || !description.trim()) {
      showToast('Veuillez remplir correctement tous les champs obligatoires.', 'error');
      return;
    }

    createRecurringSchedule({
      client_name: clientName,
      client_city: clientCity,
      whatsapp_number: whatsappNumber,
      description,
      amount: numAmount,
      currency,
      frequency,
      start_date: startDate,
      due_date_offset_days: dueDateOffset,
      reminders_enabled: scheduleRemindersEnabled,
      payment_link: schedulePaymentLink,
      notes: scheduleNotes,
    });

    showToast('Abonnement de facturation récurrente créé !', 'success');
    setIsNewScheduleModalOpen(false);
    // Reset form
    setClientName('');
    setDescription('');
    setAmount('');
    setWhatsappNumber('');
    reloadData();
  };

  // Pending invoices calculation
  const pendingInvoices = invoices.filter(i => !i.isPaid && i.status !== 'PAID');

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-300 pb-12">
      {/* Navigation Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-neutral-100 rounded-2xl overflow-x-auto [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden w-full max-w-full">
        <button
          onClick={() => setActiveTab('apps')}
          className={`flex items-center justify-center gap-2 py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'apps'
              ? 'bg-white text-neutral-900 shadow-xs'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          <Layers className="w-4 h-4 text-[#FF8A00]" />
          <span>Applications (10)</span>
        </button>

        <button
          onClick={() => setActiveTab('workflows')}
          className={`flex items-center justify-center gap-2 py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'workflows'
              ? 'bg-white text-neutral-900 shadow-xs'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          <Zap className="w-4 h-4 text-[#00C48C]" />
          <span>Workflows</span>
        </button>

        <button
          onClick={() => setActiveTab('reminders')}
          className={`flex items-center justify-center gap-2 py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'reminders'
              ? 'bg-white text-neutral-900 shadow-xs'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          <Bell className="w-4 h-4 text-[#FF8A00]" />
          <span>Relances J+1/J+3/J+7</span>
        </button>

        <button
          onClick={() => setActiveTab('recurring')}
          className={`flex items-center justify-center gap-2 py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'recurring'
              ? 'bg-white text-neutral-900 shadow-xs'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          <Repeat className="w-4 h-4 text-[#00C48C]" />
          <span>Facturation Récurrente</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`flex items-center justify-center gap-2 py-2 px-3.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
            activeTab === 'settings'
              ? 'bg-white text-neutral-900 shadow-xs'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          <Clock className="w-4 h-4 text-neutral-600" />
          <span>Règles & Cron</span>
        </button>
      </div>

      {/* ==================================================================== */}
      {/* TAB 0: GALERIE D'APPLICATIONS & INTÉGRATIONS                        */}
      {/* ==================================================================== */}
      {activeTab === 'apps' && (
        <IntegrationsGallery
          onCreateWorkflow={(appId) => {
            setPreselectedWorkflowApp(appId);
            setActiveTab('workflows');
          }}
        />
      )}

      {/* ==================================================================== */}
      {/* TAB: CONSTRUCTEUR DE WORKFLOWS                                      */}
      {/* ==================================================================== */}
      {activeTab === 'workflows' && (
        <WorkflowBuilder
          initialAppId={preselectedWorkflowApp}
          onNavigateToGallery={() => setActiveTab('apps')}
        />
      )}

      {/* ==================================================================== */}
      {/* TAB 1: RELANCES AUTOMATIQUES */}
      {/* ==================================================================== */}
      {activeTab === 'reminders' && (
        <div className="space-y-6">
          {/* Status summary grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-neutral-100 shadow-xs space-y-1">
              <span className="text-xs text-neutral-500 font-medium">Factures en attente</span>
              <div className="text-2xl font-black text-[#111827]">{pendingInvoices.length}</div>
              <p className="text-[11px] text-neutral-400">Éligibles aux calculs d'échéances</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-neutral-100 shadow-xs space-y-1">
              <span className="text-xs text-neutral-500 font-medium">Relances automatiques</span>
              <div className="text-2xl font-black text-[#FF8A00]">
                {settings.auto_reminders_enabled ? 'Activées' : 'En pause'}
              </div>
              <p className="text-[11px] text-neutral-400">Exécution quotidienne à 09:00 ({timezone})</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-neutral-100 shadow-xs space-y-1">
              <span className="text-xs text-neutral-500 font-medium">Total relances envoyées</span>
              <div className="text-2xl font-black text-[#00C48C]">{reminderLogs.length}</div>
              <p className="text-[11px] text-neutral-400">Idempotence stricte (aucun doublon)</p>
            </div>
          </div>

          {/* Pending Invoices Table with Reminder Triggers */}
          <div className="bg-white rounded-3xl border border-neutral-100 shadow-xs overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-neutral-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-[#111827]">
                  Factures impayées & Relances programmées
                </h2>
                <p className="text-xs text-neutral-500">
                  Calculées selon l'heure locale ({timezone})
                </p>
              </div>

              <button
                onClick={handleRunManualCycle}
                disabled={isProcessing}
                className="inline-flex items-center justify-center gap-2 py-2 px-4 rounded-xl text-xs font-bold text-white bg-[#FF8A00] hover:bg-[#e67c00] active:scale-95 transition-all cursor-pointer disabled:opacity-80 shrink-0 self-start sm:self-auto shadow-xs"
              >
                {isProcessing ? (
                  <PayperLoader variant="sync" size="sm" inline={true} text="Vérification..." />
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Exécuter le cycle maintenant</span>
                  </>
                )}
              </button>
            </div>

            {pendingInvoices.length === 0 ? (
              <div className="p-12 text-center text-neutral-500 space-y-2">
                <CheckCircle2 className="w-10 h-10 text-[#00C48C] mx-auto opacity-70" />
                <h3 className="text-base font-bold text-neutral-800">Toutes les factures sont réglées !</h3>
                <p className="text-xs text-neutral-400 max-w-sm mx-auto">
                  Aucun impayé en cours. Les relances se déclencheront automatiquement dès qu'une facture dépassera son échéance.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-neutral-50 text-neutral-500 uppercase font-bold tracking-wider border-b border-neutral-100">
                    <tr>
                      <th className="py-3 px-4">Facture & Client</th>
                      <th className="py-3 px-4">Échéance</th>
                      <th className="py-3 px-4">Montant</th>
                      <th className="py-3 px-4">Relances auto</th>
                      <th className="py-3 px-4 text-right">Relancer via WhatsApp</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100 text-neutral-700">
                    {pendingInvoices.map(inv => {
                      const due = inv.dueDate || inv.due_date || inv.date;
                      const linkJ1 = buildReminderWhatsAppUrl(inv, 'J+1', settings.custom_payment_link);
                      const linkJ3 = buildReminderWhatsAppUrl(inv, 'J+3', settings.custom_payment_link);
                      const linkJ7 = buildReminderWhatsAppUrl(inv, 'J+7', settings.custom_payment_link);

                      return (
                        <tr key={inv.id} className="hover:bg-neutral-50/50 transition-colors">
                          <td className="py-3.5 px-4">
                            <span className="font-bold text-[#111827] block">{inv.clientName}</span>
                            <span className="text-[11px] font-mono text-neutral-400">{inv.id}</span>
                          </td>
                          <td className="py-3.5 px-4 font-medium text-neutral-800">
                            {formatDate(due)}
                          </td>
                          <td className="py-3.5 px-4 font-bold text-[#111827]">
                            {formatCurrency(inv.amount, inv.devise)}
                          </td>
                          <td className="py-3.5 px-4">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                inv.reminders_enabled !== false
                                  ? 'bg-emerald-50 text-[#00C48C]'
                                  : 'bg-neutral-100 text-neutral-500'
                              }`}
                            >
                              {inv.reminders_enabled !== false ? 'Actives (J+1/3/7)' : 'Désactivées'}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <a
                                href={linkJ1}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="px-2.5 py-1 rounded-lg bg-orange-50 hover:bg-orange-100 text-[#FF8A00] font-bold text-[11px] transition-colors"
                                title="Envoyer le rappel J+1"
                              >
                                J+1
                              </a>
                              <a
                                href={linkJ3}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="px-2.5 py-1 rounded-lg bg-orange-50 hover:bg-orange-100 text-[#FF8A00] font-bold text-[11px] transition-colors"
                                title="Envoyer le rappel J+3"
                              >
                                J+3
                              </a>
                              <a
                                href={linkJ7}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="px-2.5 py-1 rounded-lg bg-red-50 hover:bg-red-100 text-red-600 font-bold text-[11px] transition-colors"
                                title="Envoyer la dernière relance J+7"
                              >
                                J+7
                              </a>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Reminder Logs History */}
          <div className="bg-white rounded-3xl border border-neutral-100 shadow-xs p-5 space-y-4">
            <h3 className="text-sm font-bold text-[#111827]">
              Historique des relances générées ({reminderLogs.length})
            </h3>
            {reminderLogs.length === 0 ? (
              <p className="text-xs text-neutral-400">Aucune relance enregistrée pour le moment.</p>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {reminderLogs.map(log => (
                  <div
                    key={log.id}
                    className="p-3 rounded-xl bg-neutral-50 border border-neutral-100 flex items-center justify-between text-xs"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-[#111827]">{log.client_name}</span>
                        <span className="px-1.5 py-0.5 rounded bg-orange-100 text-[#FF8A00] text-[10px] font-bold">
                          {log.reminder_type}
                        </span>
                        <span className="text-neutral-400 text-[10px] font-mono">{log.invoice_id}</span>
                      </div>
                      <p className="text-[11px] text-neutral-500 line-clamp-1">{log.message_content}</p>
                    </div>
                    <span className="text-[11px] text-neutral-400 shrink-0 font-medium ml-3">
                      {formatDate(log.sent_at)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ==================================================================== */}
      {/* TAB 2: FACTURATION RÉCURRENTE */}
      {/* ==================================================================== */}
      {activeTab === 'recurring' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-black text-[#111827]">
                Abonnements & Échéances récurrentes
              </h2>
              <p className="text-xs text-neutral-500 mt-0.5">
                PAYPER génère automatiquement la facture à chaque cycle et calcule la date d'échéance.
              </p>
            </div>

            <button
              onClick={() => setIsNewScheduleModalOpen(true)}
              className="flex items-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-[#00C48C] hover:bg-[#00ad7a] transition-all shadow-sm active:scale-95 cursor-pointer self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>+ Nouvel abonnement récurrent</span>
            </button>
          </div>

          {schedules.length === 0 ? (
            <div className="bg-white rounded-3xl border border-neutral-100 p-12 text-center space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-[#00C48C] flex items-center justify-center mx-auto">
                <Repeat className="w-7 h-7" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-[#111827]">Aucune facturation récurrente configurée</h3>
                <p className="text-xs text-neutral-500 max-w-md mx-auto">
                  Idéal pour les abonnements mensuels, contrats de maintenance, forfaits réguliers ou loyers.
                </p>
              </div>
              <button
                onClick={() => setIsNewScheduleModalOpen(true)}
                className="py-2.5 px-5 rounded-xl text-xs font-bold text-white bg-[#00C48C] hover:bg-[#00ad7a] transition-all cursor-pointer"
              >
                Créer un abonnement
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {schedules.map(sch => (
                <div
                  key={sch.id}
                  className="bg-white rounded-3xl border border-neutral-200/80 p-5 shadow-xs flex flex-col justify-between space-y-4"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-emerald-50 text-[#00C48C]">
                          {sch.frequency === 'WEEKLY'
                            ? 'Hebdomadaire'
                            : sch.frequency === 'MONTHLY'
                            ? 'Mensuel'
                            : 'Trimestriel'}
                        </span>
                        <h3 className="text-base font-bold text-[#111827] mt-1.5">{sch.client_name}</h3>
                        <p className="text-xs text-neutral-500 line-clamp-1">{sch.description}</p>
                      </div>

                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          sch.status === 'ACTIVE'
                            ? 'bg-emerald-100 text-[#00C48C]'
                            : 'bg-neutral-100 text-neutral-500'
                        }`}
                      >
                        {sch.status === 'ACTIVE' ? 'Actif' : 'En pause'}
                      </span>
                    </div>

                    <div className="bg-neutral-50 p-3 rounded-2xl space-y-1 text-xs">
                      <div className="flex justify-between">
                        <span className="text-neutral-500">Montant par cycle :</span>
                        <span className="font-bold text-[#111827]">
                          {formatCurrency(sch.amount, sch.currency)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-500">Prochaine génération :</span>
                        <span className="font-semibold text-neutral-800">{formatDate(sch.next_run_date)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-neutral-500">Délai de règlement :</span>
                        <span className="font-medium text-neutral-700">{sch.due_date_offset_days} jours</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-neutral-100 flex items-center justify-between">
                    <button
                      onClick={() =>
                        updateRecurringScheduleStatus(
                          sch.id,
                          sch.status === 'ACTIVE' ? 'PAUSED' : 'ACTIVE'
                        )
                      }
                      className="text-xs font-semibold text-neutral-600 hover:text-neutral-900 cursor-pointer"
                    >
                      {sch.status === 'ACTIVE' ? 'Mettre en pause' : 'Réactiver'}
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm('Supprimer cet échéancier récurrent ?')) {
                          deleteRecurringSchedule(sch.id);
                          reloadData();
                        }
                      }}
                      className="p-1.5 text-neutral-400 hover:text-red-500 rounded-lg hover:bg-red-50 transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ==================================================================== */}
      {/* TAB 3: CONFIGURATION & CRON RULES */}
      {/* ==================================================================== */}
      {activeTab === 'settings' && (
        <div className="bg-white rounded-3xl border border-neutral-100 p-6 sm:p-8 max-w-2xl space-y-6">
          <div className="space-y-1">
            <h2 className="text-lg font-bold text-[#111827]">Règles d'automatisation métier</h2>
            <p className="text-xs text-neutral-500">
              Configurez le fuseau horaire de votre boutique et vos liens de paiement directs.
            </p>
          </div>

          <form onSubmit={handleSaveSettings} className="space-y-5">
            <div>
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.auto_reminders_enabled}
                  onChange={e =>
                    setSettings({ ...settings, auto_reminders_enabled: e.target.checked })
                  }
                  className="w-4 h-4 text-[#FF8A00] accent-[#FF8A00] rounded"
                />
                <div>
                  <span className="text-xs font-bold text-neutral-900 block">
                    Activer globalement les relances automatiques
                  </span>
                  <span className="text-[11px] text-neutral-500">
                    Déclenche les relances J+1, J+3 et J+7 pour toutes les factures impayées éligibles.
                  </span>
                </div>
              </label>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                Fuseau horaire de calcul *
              </label>
              <select
                value={settings.timezone}
                onChange={e => setSettings({ ...settings, timezone: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-sm font-medium text-neutral-900 bg-white"
              >
                <option value="Africa/Dakar">Afrique de l'Ouest / Dakar (GMT+0)</option>
                <option value="Africa/Abidjan">Côte d'Ivoire / Abidjan (GMT+0)</option>
                <option value="Africa/Douala">Afrique Centrale / Douala (GMT+1)</option>
                <option value="Africa/Kinshasa">Rép. Dém. Congo / Kinshasa (GMT+1)</option>
                <option value="Europe/Paris">Europe / Paris (GMT+1 / GMT+2)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                Heure d'exécution planifiée
              </label>
              <input
                type="time"
                value={settings.send_hour}
                onChange={e => setSettings({ ...settings, send_hour: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-sm font-medium text-neutral-900"
              />
              <p className="text-[11px] text-neutral-400 mt-1">
                Exécuté automatiquement chaque jour à l'heure indiquée (défaut : 09:00).
              </p>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                Lien de paiement par défaut du vendeur (Wave, Orange Money...)
              </label>
              <input
                type="url"
                placeholder="https://wave.com/pay/... ou lien marchand personnel"
                value={settings.custom_payment_link || ''}
                onChange={e =>
                  setSettings({ ...settings, custom_payment_link: e.target.value })
                }
                className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-sm font-medium text-neutral-900"
              />
              <p className="text-[11px] text-neutral-400 mt-1">
                Ce lien sera directement inséré dans le corps des messages de relance envoyés au client.
              </p>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="py-2.5 px-6 rounded-xl text-xs font-bold text-white bg-[#FF8A00] hover:bg-[#e67c00] transition-colors cursor-pointer"
              >
                Enregistrer la configuration
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Modal: New Recurring Schedule */}
      <AnimatePresence>
        {isNewScheduleModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsNewScheduleModalOpen(false)}
              className="fixed inset-0 bg-black/50 backdrop-blur-xs"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="relative z-10 bg-white rounded-3xl shadow-2xl max-w-lg w-full p-6 sm:p-8 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between pb-3 border-b border-neutral-100 mb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-emerald-50 text-[#00C48C] flex items-center justify-center">
                    <Repeat className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-[#111827]">
                      Nouvel abonnement récurrent
                    </h3>
                    <p className="text-xs text-neutral-400">Génération automatique de factures</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsNewScheduleModalOpen(false)}
                  className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg cursor-pointer"
                >
                  ✕
                </button>
              </div>

              <form onSubmit={handleCreateSchedule} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                      Nom du client *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: Client Entreprise SARL"
                      value={clientName}
                      onChange={e => setClientName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-sm text-neutral-900"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                      WhatsApp client
                    </label>
                    <input
                      type="tel"
                      placeholder="Ex: +221 77 123 45 67"
                      value={whatsappNumber}
                      onChange={e => setWhatsappNumber(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-sm text-neutral-900"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                    Description du service récurrent *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Abonnement mensuel maintenance web"
                    value={description}
                    onChange={e => setDescription(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-sm text-neutral-900"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                      Montant *
                    </label>
                    <input
                      type="number"
                      min="1"
                      required
                      placeholder="Ex: 50000"
                      value={amount}
                      onChange={e => setAmount(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-sm font-bold text-neutral-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                      Devise
                    </label>
                    <select
                      value={currency}
                      onChange={e => setCurrency(e.target.value as Currency)}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-sm text-neutral-900 bg-white"
                    >
                      {CURRENCIES.map(c => (
                        <option key={c.code} value={c.code}>
                          {c.flag} {c.code}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                      Fréquence *
                    </label>
                    <select
                      value={frequency}
                      onChange={e => setFrequency(e.target.value as RecurrenceFrequency)}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-sm font-semibold text-neutral-900 bg-white"
                    >
                      <option value="MONTHLY">Mensuelle (tous les mois)</option>
                      <option value="WEEKLY">Hebdomadaire (toutes les semaines)</option>
                      <option value="QUARTERLY">Trimestrielle (tous les 3 mois)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                      Première date d'émission *
                    </label>
                    <input
                      type="date"
                      required
                      value={startDate}
                      onChange={e => setStartDate(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-sm text-neutral-900"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                      Délai d'échéance (jours)
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={dueDateOffset}
                      onChange={e => setDueDateOffset(Number(e.target.value) || 7)}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-sm text-neutral-900"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1">
                      Lien de paiement (optionnel)
                    </label>
                    <input
                      type="url"
                      placeholder="https://wave.com/pay/..."
                      value={schedulePaymentLink}
                      onChange={e => setSchedulePaymentLink(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-sm text-neutral-900"
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={scheduleRemindersEnabled}
                      onChange={e => setScheduleRemindersEnabled(e.target.checked)}
                      className="w-4 h-4 text-[#FF8A00] accent-[#FF8A00] rounded"
                    />
                    <span className="text-xs text-neutral-700">
                      Activer les relances automatiques J+1 / J+3 / J+7 pour les factures de cet abonnement
                    </span>
                  </label>
                </div>

                <div className="pt-3 border-t border-neutral-100 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsNewScheduleModalOpen(false)}
                    className="py-2.5 px-4 rounded-xl text-xs font-semibold text-neutral-600 hover:bg-neutral-100"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="py-2.5 px-5 rounded-xl text-xs font-bold text-white bg-[#00C48C] hover:bg-[#00ad7a] transition-all shadow-sm"
                  >
                    Enregistrer l'abonnement
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
