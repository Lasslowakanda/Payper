import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Store,
  Plus,
  CheckCircle2,
  Settings,
  Trash2,
  ArrowRight,
  MapPin,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';
import {
  getBoutiques,
  getActiveBoutique,
  setActiveBoutique,
  deleteBoutique,
  getUserAccount,
  isBoutiqueOwnedByUser,
} from '../lib/storage';
import { hydrateDataFromSupabase, fetchBoutiquesFromSupabase } from '../lib/supabase';
import { Boutique } from '../types';
import { useToast } from '../components/common/Toast';
import { NewBoutiqueModal } from '../components/boutiques/NewBoutiqueModal';
import { GreenGlowButton } from '../components/common/GreenGlowButton';

interface BoutiquesPageProps {
  onNavigate: (path: string) => void;
}

export const BoutiquesPage: React.FC<BoutiquesPageProps> = ({ onNavigate }) => {
  const { showToast } = useToast();
  const [boutiques, setBoutiques] = useState<Boutique[]>([]);
  const [activeBoutique, setActiveBoutiqueState] = useState<Boutique | null>(null);
  const [isNewBoutiqueOpen, setIsNewBoutiqueOpen] = useState(false);
  const [deletingBoutique, setDeletingBoutique] = useState<Boutique | null>(null);

  // Charger et dédupliquer strictement les vraies boutiques associées au compte utilisateur connecté
  const reloadBoutiques = () => {
    const currentUser = getUserAccount();
    if (!currentUser.isLoggedIn) {
      setBoutiques([]);
      setActiveBoutiqueState(null);
      return;
    }

    // 1. Récupérer les boutiques filtrées pour CE compte / CE numéro
    const rawList = getBoutiques();

    // 2. Dédupliquer par ID unique de boutique et valider l'appartenance stricte
    const uniqueMap = new Map<string, Boutique>();
    rawList.forEach((b) => {
      if (b && b.id && b.name && b.name.trim().length > 0 && isBoutiqueOwnedByUser(b, currentUser)) {
        if (!uniqueMap.has(b.id)) {
          uniqueMap.set(b.id, b);
        }
      }
    });

    const cleanList = Array.from(uniqueMap.values());
    const active = getActiveBoutique();

    setBoutiques(cleanList);
    setActiveBoutiqueState(active);
  };

  useEffect(() => {
    // Premier chargement local immédiat
    reloadBoutiques();

    // Synchronisation en temps réel avec Supabase pour charger les vraies boutiques du propriétaire
    const currentUser = getUserAccount();
    if (currentUser?.id) {
      hydrateDataFromSupabase(currentUser.id)
        .then(() => {
          reloadBoutiques();
        })
        .catch(() => {});

      // Vérification directe auprès de la table boutiques Supabase
      fetchBoutiquesFromSupabase(currentUser.id)
        .then((remoteBoutiques) => {
          if (remoteBoutiques && remoteBoutiques.length > 0) {
            reloadBoutiques();
          }
        })
        .catch(() => {});
    }

    const handleUpdate = () => reloadBoutiques();
    window.addEventListener('payper_boutique_updated', handleUpdate);
    window.addEventListener('payper_boutiques_updated', handleUpdate);

    return () => {
      window.removeEventListener('payper_boutique_updated', handleUpdate);
      window.removeEventListener('payper_boutiques_updated', handleUpdate);
    };
  }, []);

  // Changement automatique et instantané de boutique au clic
  const handleCardClick = (boutique: Boutique) => {
    if (!boutique.id) return;

    if (activeBoutique?.id === boutique.id) {
      // Déjà active : redirection rapide vers le tableau de bord
      showToast(`Boutique « ${boutique.name} » déjà active`, 'info');
      return;
    }

    const success = setActiveBoutique(boutique.id);
    if (success) {
      setActiveBoutiqueState(boutique);
      showToast(`Boutique active : « ${boutique.name} »`, 'success');
      reloadBoutiques();
    }
  };

  const handleConfirmDelete = () => {
    if (!deletingBoutique?.id) return;
    deleteBoutique(deletingBoutique.id);
    showToast(`Boutique « ${deletingBoutique.name} » supprimée.`, 'info');
    setDeletingBoutique(null);
    reloadBoutiques();
  };

  return (
    <div className="max-w-3xl mx-auto w-full space-y-6 sm:space-y-8 animate-in fade-in duration-200 pb-16 px-1 sm:px-0">
      {/* =================================================================== */}
      {/* EN-TÊTE DE LA SECTION BOUTIQUES                                     */}
      {/* =================================================================== */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-neutral-100">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-[#00C48C] border border-emerald-100 flex items-center justify-center shrink-0">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-[#111827] tracking-tight">
                  Mes Boutiques
                </h1>
                {boutiques.length > 0 && (
                  <span className="px-2.5 py-0.5 rounded-full bg-neutral-100 text-neutral-600 text-xs font-bold">
                    {boutiques.length}
                  </span>
                )}
              </div>
              <p className="text-xs sm:text-sm text-neutral-500 mt-0.5">
                Cliquez sur une boutique pour l'activer sur l'ensemble de l'application.
              </p>
            </div>
          </div>
        </div>

        <div className="shrink-0">
          <GreenGlowButton
            size="sm"
            onClick={() => setIsNewBoutiqueOpen(true)}
            className="w-full sm:w-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Nouvelle boutique</span>
          </GreenGlowButton>
        </div>
      </div>

      {/* =================================================================== */}
      {/* CAS 1 : AUCUNE BOUTIQUE ENREGISTRÉE                                 */}
      {/* =================================================================== */}
      {boutiques.length === 0 ? (
        <div className="bg-white rounded-3xl border border-neutral-200/90 shadow-sm p-8 sm:p-12 text-center">
          <div className="w-16 h-16 rounded-2xl bg-neutral-50 border border-neutral-200/80 flex items-center justify-center text-neutral-400 mx-auto mb-4">
            <Store className="w-8 h-8" />
          </div>
          <h2 className="text-lg sm:text-xl font-bold text-[#111827] mb-2">
            Aucune boutique configurée
          </h2>
          <p className="text-xs sm:text-sm text-neutral-500 max-w-md mx-auto mb-6 leading-relaxed">
            Créez votre première boutique pour commencer à émettre des factures et gérer vos activités avec PAYPER.
          </p>
          <GreenGlowButton
            size="md"
            onClick={() => setIsNewBoutiqueOpen(true)}
            className="mx-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Créer ma première boutique</span>
          </GreenGlowButton>
        </div>
      ) : (
        /* =================================================================== */
        /* CAS 2 : LISTE VERTICALE DE CARTES HORIZONTALES ALLONGÉES            */
        /* =================================================================== */
        <div className="flex flex-col gap-3 sm:gap-3.5">
          {boutiques.map((boutique) => {
            const isActive = activeBoutique?.id === boutique.id;

            return (
              <motion.div
                key={boutique.id}
                whileHover={{ scale: 1.006, y: -1 }}
                whileTap={{ scale: 0.985 }}
                transition={{ duration: 0.15 }}
                onClick={() => handleCardClick(boutique)}
                className={`group relative w-full rounded-2xl border transition-all cursor-pointer overflow-hidden select-none ${
                  isActive
                    ? 'bg-white border-[#00C48C] shadow-sm ring-2 ring-[#00C48C]/15'
                    : 'bg-white border-neutral-200/90 hover:border-neutral-300 hover:shadow-xs'
                }`}
              >
                <div className="flex items-center justify-between p-4 sm:p-5 gap-3 sm:gap-4">
                  {/* CÔTÉ GAUCHE : LOGO DANS CADRE CARRÉ + NOM RÉEL DE LA BOUTIQUE */}
                  <div className="flex items-center gap-3.5 sm:gap-4 min-w-0 flex-1">
                    {/* Cadre carré aux coins arrondis pour le logo réel ou icône neutre */}
                    <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl overflow-hidden shrink-0 border border-neutral-200/80 bg-neutral-50 flex items-center justify-center shadow-2xs">
                      {boutique.logo ? (
                        <img
                          src={boutique.logo}
                          alt={boutique.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-neutral-400 bg-neutral-100/70">
                          <Store className="w-6 h-6 sm:w-7 sm:h-7" />
                        </div>
                      )}
                    </div>

                    {/* Informations textuelles bien alignées */}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        {/* Le véritable nom de la boutique */}
                        <h3 className="text-base sm:text-lg font-bold text-neutral-900 truncate tracking-tight">
                          {boutique.name}
                        </h3>
                      </div>

                      {/* Courte information discrète (ville, devise) sans aucune statistique */}
                      <div className="flex items-center gap-2.5 text-xs text-neutral-500 mt-1 flex-wrap">
                        {boutique.city && (
                          <span className="flex items-center gap-1 truncate">
                            <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
                            <span className="truncate">{boutique.city}</span>
                          </span>
                        )}
                        {boutique.devise && (
                          <span className="px-2 py-0.5 rounded-md bg-neutral-100 text-neutral-600 font-semibold text-[11px]">
                            {boutique.devise}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* CÔTÉ DROIT : INDICATEUR DISCRET BOUTIQUE ACTIVE & ACTIONS */}
                  <div className="flex items-center gap-2 shrink-0">
                    {isActive ? (
                      <div className="flex items-center gap-2">
                        <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-50 border border-emerald-200/90 text-[#00C48C] text-xs font-bold shadow-2xs">
                          <CheckCircle2 className="w-4 h-4 text-[#00C48C]" />
                          <span>Active</span>
                        </span>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onNavigate('/dashboard');
                          }}
                          className="p-2 text-neutral-400 hover:text-neutral-800 hover:bg-neutral-100 rounded-xl transition-colors cursor-pointer hidden sm:flex items-center justify-center"
                          title="Accéder au tableau de bord"
                          aria-label="Tableau de bord"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5">
                        <span className="hidden sm:inline-flex text-xs font-medium text-neutral-400 group-hover:text-neutral-700 transition-colors">
                          Cliquer pour activer
                        </span>
                        <div className="w-8 h-8 rounded-xl bg-neutral-50 group-hover:bg-[#00C48C]/10 text-neutral-400 group-hover:text-[#00C48C] flex items-center justify-center transition-all">
                          <ArrowRight className="w-4 h-4" />
                        </div>
                      </div>
                    )}

                    {/* Bouton de configuration ou suppression pour les boutiques secondaires */}
                    <div className="flex items-center">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (!isActive) {
                            setActiveBoutique(boutique.id!);
                          }
                          onNavigate('/settings');
                        }}
                        className="p-2 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 rounded-xl transition-colors cursor-pointer"
                        title="Paramètres de cette boutique"
                        aria-label="Paramètres de cette boutique"
                      >
                        <Settings className="w-4 h-4" />
                      </button>

                      {boutiques.length > 1 && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setDeletingBoutique(boutique);
                          }}
                          className="p-2 text-neutral-300 hover:text-red-600 hover:bg-red-50 rounded-xl transition-colors cursor-pointer"
                          title="Supprimer cette boutique"
                          aria-label="Supprimer cette boutique"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* =================================================================== */}
      {/* MODAL : CRÉATION D'UNE NOUVELLE BOUTIQUE                            */}
      {/* =================================================================== */}
      <NewBoutiqueModal
        isOpen={isNewBoutiqueOpen}
        onClose={() => setIsNewBoutiqueOpen(false)}
        onSuccess={() => {
          reloadBoutiques();
        }}
      />

      {/* =================================================================== */}
      {/* MODAL : CONFIRMATION DE SUPPRESSION                                 */}
      {/* =================================================================== */}
      <AnimatePresence>
        {deletingBoutique && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setDeletingBoutique(null)}
              className="fixed inset-0 bg-black/40 backdrop-blur-xs"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative z-10 bg-white rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-2xl border border-neutral-100"
            >
              <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mb-4">
                <AlertCircle className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-[#111827] mb-2">
                Supprimer la boutique « {deletingBoutique.name} » ?
              </h3>
              <p className="text-xs text-neutral-500 mb-6 leading-relaxed">
                Cette action supprimera définitivement cette boutique ainsi que ses données associées. Vos autres boutiques restent inchangées.
              </p>
              <div className="flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setDeletingBoutique(null)}
                  className="py-2.5 px-4 rounded-xl text-xs font-semibold text-neutral-600 hover:bg-neutral-100 transition-colors cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDelete}
                  className="py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-red-600 hover:bg-red-700 transition-colors cursor-pointer shadow-sm shadow-red-600/20"
                >
                  Confirmer la suppression
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
