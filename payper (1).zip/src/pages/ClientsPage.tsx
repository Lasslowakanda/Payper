import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Users,
  Search,
  Plus,
  Send,
  FileText,
  Calendar,
  CheckCircle2,
  Clock,
  MapPin,
  ExternalLink,
} from 'lucide-react';
import { getClientsSummaries, getClientInitials } from '../lib/clients';
import { formatCurrency, formatDate } from '../lib/invoice';
import { buildWhatsAppUrl } from '../lib/share';
import { ClientSummary } from '../types';
import { useLayoutActions } from '../components/layout/AppLayout';

interface ClientsPageProps {
  onNavigate: (path: string) => void;
  onOpenNewInvoice?: () => void;
}

export const ClientsPage: React.FC<ClientsPageProps> = ({
  onNavigate,
  onOpenNewInvoice,
}) => {
  const { openNewInvoice } = useLayoutActions();

  const handleOpenNewInvoice = () => {
    if (onOpenNewInvoice) onOpenNewInvoice();
    else openNewInvoice();
  };

  const [searchQuery, setSearchQuery] = useState('');
  const [clients, setClients] = useState<ClientSummary[]>(() => getClientsSummaries());

  useEffect(() => {
    const handleUpdate = () => {
      setClients(getClientsSummaries());
    };
    window.addEventListener('payper_invoices_updated', handleUpdate);
    window.addEventListener('payper_boutique_updated', handleUpdate);
    return () => {
      window.removeEventListener('payper_invoices_updated', handleUpdate);
      window.removeEventListener('payper_boutique_updated', handleUpdate);
    };
  }, []);

  const filteredClients = useMemo(() => {
    if (!searchQuery.trim()) return clients;
    const q = searchQuery.toLowerCase().trim();
    return clients.filter(
      c =>
        c.name.toLowerCase().includes(q) ||
        c.city.toLowerCase().includes(q) ||
        (c.whatsappNumber && c.whatsappNumber.includes(q))
    );
  }, [clients, searchQuery]);

  const handleOpenWhatsApp = (client: ClientSummary) => {
    const message = `Bonjour ${client.name} ! C'est un plaisir d'échanger avec vous.`;
    const url = buildWhatsAppUrl(client.whatsappNumber || '', message);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#111827] tracking-tight">
            Clients ({clients.length})
          </h1>
          <p className="text-sm text-neutral-500 mt-1">
            Répertoire automatique de vos clients et historique des montants facturés.
          </p>
        </div>

        <button
          onClick={handleOpenNewInvoice}
          className="flex items-center gap-2 py-2.5 px-4 rounded-xl text-sm font-semibold text-white bg-[#FF8A00] hover:bg-[#e67c00] shadow-sm shadow-orange-500/20 active:scale-95 transition-all cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>+ Nouveau client</span>
        </button>
      </div>

      {/* Search Input Bar */}
      <div className="bg-white p-4 rounded-2xl border border-neutral-100 shadow-sm flex items-center justify-between">
        <div className="relative w-full max-w-md">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder="Rechercher par nom, ville, téléphone..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-neutral-50 border border-neutral-200/80 rounded-xl pl-9 pr-3.5 py-2.5 text-sm sm:text-xs text-neutral-900 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-all min-h-[42px]"
          />
        </div>
      </div>

      {/* Clients Cards Grid */}
      {filteredClients.length === 0 ? (
        <div className="bg-white rounded-2xl p-12 text-center border border-neutral-100 shadow-sm">
          <Users className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-neutral-800">
            {clients.length === 0 ? 'Aucun client enregistré' : 'Aucun client trouvé'}
          </h3>
          <p className="text-xs text-neutral-500 max-w-sm mx-auto mt-1 mb-5">
            {clients.length === 0
              ? 'Vos clients apparaîtront automatiquement dès que vous créerez votre première facture.'
              : 'Aucun client ne correspond à votre recherche.'}
          </p>
          <button
            onClick={handleOpenNewInvoice}
            className="inline-flex items-center gap-2 py-2.5 px-5 rounded-xl text-xs font-semibold text-white bg-[#FF8A00] hover:bg-[#e67c00]"
          >
            <Plus className="w-4 h-4" />
            <span>Créer une facture client</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredClients.map(client => (
            <motion.div
              key={client.name}
              whileHover={{ scale: 1.02 }}
              transition={{ type: 'spring', damping: 20, stiffness: 300 }}
              className="bg-white rounded-2xl p-5 border border-neutral-100 shadow-sm hover:shadow-lg transition-shadow flex flex-col justify-between"
            >
              <div>
                {/* Header Card: Avatar initiales, Nom, Ville, Badge devise */}
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-orange-50 border border-orange-100 flex items-center justify-center font-bold text-sm text-[#FF8A00]">
                      {getClientInitials(client.name)}
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-[#111827] leading-snug">
                        {client.name}
                      </h3>
                      <div className="flex items-center gap-1 text-[11px] text-neutral-500 mt-0.5">
                        <MapPin className="w-3 h-3 text-neutral-400" />
                        <span>{client.city}</span>
                      </div>
                    </div>
                  </div>

                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-neutral-100 text-neutral-600 uppercase">
                    {client.currency}
                  </span>
                </div>

                {/* Metrics Breakdown */}
                <div className="bg-neutral-50/70 rounded-xl p-3 space-y-2 border border-neutral-100 mb-4 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="text-neutral-500">Volume :</span>
                    <span className="font-bold text-neutral-900 font-mono tabular-nums">
                      {client.invoicesCount} facture{client.invoicesCount > 1 ? 's' : ''}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-neutral-500">Total facturé :</span>
                    <span className="font-black text-neutral-900 font-mono tabular-nums">
                      {formatCurrency(client.totalBilled, client.currency)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-[11px]">
                    <span className="text-[#00C48C] font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Payé :
                    </span>
                    <span className="font-semibold text-neutral-800 font-mono tabular-nums">
                      {formatCurrency(client.totalPaid, client.currency)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-[11px]">
                    <span className="text-[#FF8A00] font-semibold flex items-center gap-1">
                      <Clock className="w-3 h-3" /> En attente :
                    </span>
                    <span className="font-semibold text-neutral-800 font-mono tabular-nums">
                      {formatCurrency(client.totalPending, client.currency)}
                    </span>
                  </div>
                </div>

                {/* Dernière facture */}
                <div className="flex items-center gap-1.5 text-[11px] text-neutral-400 mb-4">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Dernière : {formatDate(client.lastInvoiceDate)}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-2 border-t border-neutral-100">
                <button
                  onClick={() => onNavigate(`/invoice/${client.lastInvoiceId}`)}
                  className="flex-1 py-2 px-3 rounded-xl text-xs font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5 text-neutral-500" />
                  <span>Voir factures</span>
                </button>

                <button
                  onClick={() => handleOpenWhatsApp(client)}
                  className="py-2 px-3.5 rounded-xl text-xs font-semibold text-white bg-[#25D366] hover:bg-[#20ba5a] transition-colors flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                  title="Contacter sur WhatsApp"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};
