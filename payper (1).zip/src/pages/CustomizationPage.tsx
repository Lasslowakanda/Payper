import React, { useState, useEffect } from 'react';
import {
  Palette,
  Layout,
  Sliders,
  Check,
  Crown,
  Store,
  FileText,
  Receipt,
  AlignLeft,
  AlignCenter,
  AlignRight,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  Save,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import {
  Boutique,
  DocumentCustomization,
  InvoiceTemplateId,
  ReceiptTemplateId,
  LogoPosition,
  IconStyle,
  InfoAlignment,
  Subscription,
} from '../types';
import {
  getBoutiques,
  getActiveBoutique,
  getBoutiqueCustomization,
  saveBoutiqueCustomization,
  getSubscription,
} from '../lib/storage';
import { canAccessStandardFeatures } from '../lib/subscription';
import { useToast } from '../components/common/Toast';
import { GreenGlowButton } from '../components/common/GreenGlowButton';
import { PayperLogo } from '../components/common/PayperLogo';

interface CustomizationPageProps {
  onNavigate: (path: string) => void;
}

const PRIMARY_COLOR_PRESETS = [
  { name: 'Émeraude Vif', value: '#00C48C' },
  { name: 'Orange Solaire', value: '#FF8A00' },
  { name: 'Bleu Royal', value: '#2563EB' },
  { name: 'Indigo Profond', value: '#4F46E5' },
  { name: 'Violet Impérial', value: '#7C3AED' },
  { name: 'Noir Ébène', value: '#111827' },
  { name: 'Rubis Carmin', value: '#DC2626' },
  { name: 'Teal Océan', value: '#0D9488' },
];

const SECONDARY_COLOR_PRESETS = [
  { name: 'Gris Anthracite', value: '#111827' },
  { name: 'Ardoise Sombre', value: '#0F172A' },
  { name: 'Gris Neutre', value: '#374151' },
  { name: 'Bleu Minuit', value: '#1E293B' },
];

export const CustomizationPage: React.FC<CustomizationPageProps> = ({ onNavigate }) => {
  const { showToast } = useToast();
  const [subscription, setSubscription] = useState<Subscription>(() => getSubscription());
  const [boutiques, setBoutiques] = useState<Boutique[]>(() => getBoutiques());
  const [selectedBoutiqueId, setSelectedBoutiqueId] = useState<string>(() => {
    const active = getActiveBoutique();
    return active?.id || (getBoutiques()[0]?.id || '');
  });

  const currentBoutique = boutiques.find(b => b.id === selectedBoutiqueId) || getActiveBoutique() || boutiques[0];

  const [formState, setFormState] = useState<DocumentCustomization>(() =>
    getBoutiqueCustomization(selectedBoutiqueId)
  );
  const [isSaving, setIsSaving] = useState(false);
  const [hasSaved, setHasSaved] = useState(false);
  const [previewMode, setPreviewMode] = useState<'invoice' | 'receipt'>('invoice');

  const isAllowed = canAccessStandardFeatures(subscription);

  useEffect(() => {
    if (selectedBoutiqueId) {
      setFormState(getBoutiqueCustomization(selectedBoutiqueId));
      setHasSaved(false);
    }
  }, [selectedBoutiqueId]);

  const handleBoutiqueChange = (bId: string) => {
    setSelectedBoutiqueId(bId);
  };

  const handleSave = async () => {
    if (!currentBoutique?.id) {
      showToast('Veuillez sélectionner une boutique valide.', 'error');
      return;
    }

    if (!isAllowed) {
      showToast('Action non autorisée. Votre abonnement doit être actif et payé.', 'error');
      return;
    }

    setIsSaving(true);
    try {
      // Backend authorization check
      const res = await fetch('/api/premium/verify-access', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: subscription.userId || 'default_user',
          feature: 'customization',
        }),
      });

      if (!res.ok) {
        const errData = await res.json();
        showToast(errData.error || 'Accès refusé par le serveur de facturation.', 'error');
        setIsSaving(false);
        return;
      }

      saveBoutiqueCustomization(currentBoutique.id, formState);
      setIsSaving(false);
      setHasSaved(true);
      showToast(
        `Personnalisation enregistrée pour « ${currentBoutique.name} » ! Appliquée aux futurs documents.`,
        'success'
      );
    } catch {
      // Non-blocking offline fallback if backend transiently unreachable
      saveBoutiqueCustomization(currentBoutique.id, formState);
      setIsSaving(false);
      setHasSaved(true);
      showToast(`Personnalisation sauvegardée localement.`, 'success');
    }
  };

  // Paywall for non-active or non-paid users
  if (!isAllowed) {
    const isExpired = subscription.status === 'expired';
    const isPending = subscription.status === 'pending';
    const isFailed = subscription.status === 'payment_failed';

    return (
      <div className="max-w-4xl mx-auto py-10 px-4">
        <div className="bg-white rounded-3xl p-8 sm:p-12 border border-neutral-200/90 shadow-xl text-center relative overflow-hidden">
          {/* Subtle decorative glow */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-gradient-to-b from-emerald-100/60 to-transparent rounded-full blur-3xl pointer-events-none -z-10" />

          <div className="w-16 h-16 rounded-3xl bg-emerald-50 text-[#00C48C] border border-emerald-100 flex items-center justify-center mx-auto mb-6 shadow-xs">
            <Palette className="w-8 h-8" />
          </div>

          <span className="text-xs font-bold uppercase tracking-wider text-[#00C48C] bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">
            {isExpired
              ? 'Abonnement Expiré'
              : isPending
              ? 'Paiement en attente'
              : isFailed
              ? 'Paiement échoué'
              : 'Fonctionnalité Standard & Pro'}
          </span>

          <h1 className="text-2xl sm:text-4xl font-black text-[#111827] mt-4 tracking-tight">
            {isExpired
              ? 'Votre abonnement a expiré'
              : isPending
              ? 'Validation du paiement en cours'
              : isFailed
              ? 'Échec du paiement'
              : 'Personnalisation pro des reçus & factures'}
          </h1>

          <p className="text-sm sm:text-base text-neutral-600 mt-3 max-w-lg mx-auto leading-relaxed">
            {isExpired
              ? 'Votre période de validité de 30 jours est terminée. Veuillez renouveler votre forfait Standard ou Pro pour continuer à personnaliser vos documents.'
              : isPending
              ? 'Votre paiement est en cours de traitement par le serveur. Les fonctionnalités s\'activeront dès confirmation du règlement.'
              : isFailed
              ? 'Le paiement de votre abonnement a été refusé par l\'émetteur. Veuillez renouveler l\'opération.'
              : 'L\'accès au studio de personnalisation des reçus & factures nécessite l\'offre Standard (5 USD/mois) ou Pro (12 USD/mois) dûment confirmée par le serveur.'}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl mx-auto my-8 text-left">
            <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-100">
              <div className="font-bold text-xs text-neutral-800 mb-1 flex items-center gap-1.5">
                <Layout className="w-4 h-4 text-[#00C48C]" />
                <span>Multi-Modèles</span>
              </div>
              <p className="text-[11px] text-neutral-500">
                Choix entre formats A4, modèle Reçu officiel avec pointillés et signatures.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-100">
              <div className="font-bold text-xs text-neutral-800 mb-1 flex items-center gap-1.5">
                <Palette className="w-4 h-4 text-[#00C48C]" />
                <span>Palette de couleurs</span>
              </div>
              <p className="text-[11px] text-neutral-500">
                Couleurs primaires et secondaires assorties à l'identité de votre boutique.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-100">
              <div className="font-bold text-xs text-neutral-800 mb-1 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#00C48C]" />
                <span>Paiement certifié</span>
              </div>
              <p className="text-[11px] text-neutral-500">
                Tarifs officiels : 5 USD pour Standard et 12 USD pour Pro, validés par backend.
              </p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <GreenGlowButton
              size="lg"
              onClick={() => onNavigate('/pricing')}
              className="w-full sm:w-auto"
            >
              <Crown className="w-4 h-4" />
              <span>{isExpired ? 'Renouveler mon abonnement' : 'Souscrire à l\'offre Standard · 5 USD/mois'}</span>
            </GreenGlowButton>

            <button
              onClick={() => onNavigate('/pricing')}
              className="py-3 px-5 rounded-xl text-xs font-bold text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100 transition-colors cursor-pointer w-full sm:w-auto"
            >
              Consulter les forfaits & statuts
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Sample data for preview rendering
  const previewAmount = 75000;
  const previewCurrency = currentBoutique?.devise || 'FCFA';

  return (
    <div className="space-y-6 max-w-7xl mx-auto py-2">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-neutral-200/80">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#00C48C] bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-100">
              Offre Standard (5 USD) & Pro
            </span>
            {hasSaved && (
              <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Paramètres enregistrés</span>
              </span>
            )}
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-[#111827] mt-1 tracking-tight">
            Personnalisation des reçus & factures
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 mt-0.5">
            Configurez l'apparence officielle des documents émis pour cette boutique.
          </p>
        </div>

        {/* Boutique Selector & Save Button */}
        <div className="flex items-center gap-3">
          {boutiques.length > 1 && (
            <div className="flex items-center gap-1.5 bg-white border border-neutral-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-neutral-700 shadow-2xs">
              <Store className="w-3.5 h-3.5 text-neutral-500" />
              <select
                value={selectedBoutiqueId}
                onChange={e => handleBoutiqueChange(e.target.value)}
                className="bg-transparent border-none outline-none font-bold text-[#111827] cursor-pointer"
              >
                {boutiques.map(b => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          <GreenGlowButton
            onClick={handleSave}
            disabled={isSaving}
            size="md"
          >
            <Save className="w-4 h-4" />
            <span>{isSaving ? 'Enregistrement...' : 'Enregistrer pour cette boutique'}</span>
          </GreenGlowButton>
        </div>
      </div>

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Customization Controls (Tabs & Sections) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Section A: MODÈLES */}
          <div className="bg-white rounded-2xl p-5 border border-neutral-200/80 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-100">
              <div className="flex items-center gap-2">
                <Layout className="w-4 h-4 text-[#00C48C]" />
                <h2 className="text-sm font-bold text-[#111827]">A. Modèles de documents</h2>
              </div>
            </div>

            {/* Modèle de Facture */}
            <div>
              <label className="block text-xs font-bold text-neutral-700 mb-2">
                Modèle de Facture
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'classic_a4', name: 'Classique A4', desc: 'Standard officiel et équilibré' },
                  { id: 'modern_clean', name: 'Moderne Épuré', desc: 'Lignes aérées et minimales' },
                  { id: 'signature_border', name: 'Bordure Signature', desc: 'Cadre accentué et professionnel' },
                  { id: 'minimal_ticket', name: 'Facture Express', desc: 'Format compact et direct' },
                  { id: 'recu_signature', name: 'Modèle Reçu', desc: 'Reçu officiel, montant, pointillés & signature' },
                ].map(item => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setFormState(prev => ({ ...prev, invoiceTemplate: item.id as InvoiceTemplateId }));
                      setHasSaved(false);
                    }}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      formState.invoiceTemplate === item.id
                        ? 'border-[#00C48C] bg-emerald-50/40 ring-2 ring-[#00C48C]/20'
                        : 'border-neutral-200 hover:border-neutral-300 bg-white'
                    }`}
                  >
                    <div className="text-xs font-bold text-[#111827]">{item.name}</div>
                    <div className="text-[10px] text-neutral-500 mt-0.5">{item.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Modèle de Reçu */}
            <div className="pt-2">
              <label className="block text-xs font-bold text-neutral-700 mb-2">
                Modèle de Reçu de Paiement
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'recu_signature', name: 'Reçu & Signature', desc: 'Numéro, montant, pointillés et signature' },
                  { id: 'modern_slip', name: 'Reçu Numérique Pro', desc: 'Reçu pleine page optimisé mobile' },
                  { id: 'thermal_ticket', name: 'Ticket de Caisse', desc: 'Format ticket thermique compact' },
                  { id: 'executive_receipt', name: 'Bordereau Exécutif', desc: 'Reçu officiel d\'encaissement' },
                  { id: 'compact_badge', name: 'Carte d\'Encaissement', desc: 'Format badge ultra lisible' },
                ].map(item => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setFormState(prev => ({ ...prev, receiptTemplate: item.id as ReceiptTemplateId }));
                      setHasSaved(false);
                    }}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      formState.receiptTemplate === item.id
                        ? 'border-[#00C48C] bg-emerald-50/40 ring-2 ring-[#00C48C]/20'
                        : 'border-neutral-200 hover:border-neutral-300 bg-white'
                    }`}
                  >
                    <div className="text-xs font-bold text-[#111827]">{item.name}</div>
                    <div className="text-[10px] text-neutral-500 mt-0.5">{item.desc}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Section B: COULEURS */}
          <div className="bg-white rounded-2xl p-5 border border-neutral-200/80 shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-neutral-100">
              <Palette className="w-4 h-4 text-[#00C48C]" />
              <h2 className="text-sm font-bold text-[#111827]">B. Palette de Couleurs</h2>
            </div>

            {/* Couleur Principale */}
            <div>
              <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                Couleur Principale (En-têtes, montants & totaux)
              </label>
              <div className="flex flex-wrap gap-2.5 items-center mb-3">
                {PRIMARY_COLOR_PRESETS.map(preset => (
                  <button
                    key={preset.value}
                    onClick={() => {
                      setFormState(prev => ({ ...prev, primaryColor: preset.value }));
                      setHasSaved(false);
                    }}
                    className={`w-7 h-7 rounded-full transition-transform cursor-pointer relative flex items-center justify-center ${
                      formState.primaryColor.toLowerCase() === preset.value.toLowerCase()
                        ? 'scale-110 ring-2 ring-offset-2 ring-[#111827]'
                        : 'hover:scale-105'
                    }`}
                    style={{ backgroundColor: preset.value }}
                    title={preset.name}
                  >
                    {formState.primaryColor.toLowerCase() === preset.value.toLowerCase() && (
                      <Check className="w-3.5 h-3.5 text-white stroke-[3]" />
                    )}
                  </button>
                ))}
                <div className="flex items-center gap-1.5 ml-2">
                  <input
                    type="color"
                    value={formState.primaryColor}
                    onChange={e => {
                      setFormState(prev => ({ ...prev, primaryColor: e.target.value }));
                      setHasSaved(false);
                    }}
                    className="w-7 h-7 rounded-lg border border-neutral-200 cursor-pointer p-0.5 bg-white"
                  />
                  <span className="text-[11px] font-mono text-neutral-500">
                    {formState.primaryColor}
                  </span>
                </div>
              </div>
            </div>

            {/* Couleur Secondaire */}
            <div className="pt-2">
              <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                Couleur Secondaire (Texte, bordures & badges)
              </label>
              <div className="flex flex-wrap gap-2.5 items-center">
                {SECONDARY_COLOR_PRESETS.map(preset => (
                  <button
                    key={preset.value}
                    onClick={() => {
                      setFormState(prev => ({ ...prev, secondaryColor: preset.value }));
                      setHasSaved(false);
                    }}
                    className={`w-7 h-7 rounded-full transition-transform cursor-pointer relative flex items-center justify-center ${
                      formState.secondaryColor.toLowerCase() === preset.value.toLowerCase()
                        ? 'scale-110 ring-2 ring-offset-2 ring-[#00C48C]'
                        : 'hover:scale-105'
                    }`}
                    style={{ backgroundColor: preset.value }}
                    title={preset.name}
                  >
                    {formState.secondaryColor.toLowerCase() === preset.value.toLowerCase() && (
                      <Check className="w-3.5 h-3.5 text-white stroke-[3]" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Section C: LOGO & POSITION */}
          <div className="bg-white rounded-2xl p-5 border border-neutral-200/80 shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-neutral-100">
              <Store className="w-4 h-4 text-[#00C48C]" />
              <h2 className="text-sm font-bold text-[#111827]">C. Logo & Emplacement</h2>
            </div>

            <div className="flex items-center gap-3 p-3 rounded-xl bg-neutral-50 border border-neutral-100">
              {currentBoutique?.logo ? (
                <img
                  src={currentBoutique.logo}
                  alt={currentBoutique.name}
                  className="w-12 h-12 rounded-lg object-contain bg-white border border-neutral-200 p-1"
                />
              ) : (
                <div className="w-12 h-12 rounded-lg bg-neutral-200 flex items-center justify-center text-xs font-bold text-neutral-600">
                  {currentBoutique?.name?.substring(0, 2).toUpperCase() || 'BT'}
                </div>
              )}
              <div className="text-xs">
                <div className="font-bold text-[#111827]">{currentBoutique?.name || 'Ma Boutique'}</div>
                <div className="text-neutral-500 text-[11px]">Proportions originales conservées</div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-700 mb-2">
                Position du logo sur l'en-tête
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { pos: 'left' as LogoPosition, label: 'Gauche', icon: AlignLeft },
                  { pos: 'center' as LogoPosition, label: 'Centré', icon: AlignCenter },
                  { pos: 'right' as LogoPosition, label: 'Droite', icon: AlignRight },
                ].map(item => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.pos}
                      onClick={() => {
                        setFormState(prev => ({ ...prev, logoPosition: item.pos }));
                        setHasSaved(false);
                      }}
                      className={`p-2.5 rounded-xl border flex flex-col items-center gap-1.5 transition-all cursor-pointer ${
                        formState.logoPosition === item.pos
                          ? 'border-[#00C48C] bg-emerald-50 text-[#00C48C] font-bold'
                          : 'border-neutral-200 text-neutral-600 hover:border-neutral-300'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="text-xs">{item.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Section D: ICÔNES & DISPOSITION */}
          <div className="bg-white rounded-2xl p-5 border border-neutral-200/80 shadow-xs space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-neutral-100">
              <Sliders className="w-4 h-4 text-[#00C48C]" />
              <h2 className="text-sm font-bold text-[#111827]">D. Styles d'icônes & Disposition</h2>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-700 mb-2">
                Style des icônes
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {[
                  { id: 'filled' as IconStyle, label: 'Pastilles Remplies' },
                  { id: 'outline' as IconStyle, label: 'Traits Épurés (Outline)' },
                  { id: 'badged' as IconStyle, label: 'Badges Colorés' },
                  { id: 'none' as IconStyle, label: 'Sans icônes' },
                ].map(item => (
                  <button
                    key={item.id}
                    onClick={() => {
                      setFormState(prev => ({ ...prev, iconStyle: item.id }));
                      setHasSaved(false);
                    }}
                    className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                      formState.iconStyle === item.id
                        ? 'border-[#00C48C] bg-emerald-50 text-[#00C48C] font-bold'
                        : 'border-neutral-200 text-neutral-600 hover:border-neutral-300'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                Note de bas de page personnalisée
              </label>
              <input
                type="text"
                value={formState.receiptFooterMessage || ''}
                onChange={e => {
                  setFormState(prev => ({ ...prev, receiptFooterMessage: e.target.value }));
                  setHasSaved(false);
                }}
                placeholder="Ex: Merci pour votre confiance ! À très bientôt."
                className="w-full text-xs px-3 py-2 rounded-xl border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-[#00C48C]/20"
              />
            </div>
          </div>
        </div>

        {/* Right Column: Live Faithful Document Preview */}
        <div className="lg:col-span-7 sticky top-20 space-y-4">
          {/* Preview Mode Switcher */}
          <div className="flex items-center justify-between bg-white p-2 rounded-2xl border border-neutral-200/80 shadow-xs">
            <span className="text-xs font-bold text-neutral-500 uppercase tracking-wider pl-2">
              Aperçu en direct
            </span>
            <div className="flex items-center gap-1 bg-neutral-100 p-1 rounded-xl">
              <button
                onClick={() => setPreviewMode('invoice')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  previewMode === 'invoice'
                    ? 'bg-white text-[#111827] shadow-xs'
                    : 'text-neutral-500 hover:text-neutral-800'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Facture</span>
              </button>
              <button
                onClick={() => setPreviewMode('receipt')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  previewMode === 'receipt'
                    ? 'bg-white text-[#111827] shadow-xs'
                    : 'text-neutral-500 hover:text-neutral-800'
                }`}
              >
                <Receipt className="w-3.5 h-3.5" />
                <span>Reçu de paiement</span>
              </button>
            </div>
          </div>

          {/* DOCUMENT PREVIEW CONTAINER */}
          <div className="bg-neutral-100/70 p-4 sm:p-6 rounded-3xl border border-neutral-200/90 flex justify-center">
            {/* Condition 1: Modèle REÇU & SIGNATURE sélectionné */}
            {((previewMode === 'invoice' && formState.invoiceTemplate === 'recu_signature') ||
              (previewMode === 'receipt' && formState.receiptTemplate === 'recu_signature')) ? (
              <div
                className="w-full max-w-[580px] bg-white rounded-2xl shadow-xl p-6 sm:p-8 space-y-6 border-2 transition-all"
                style={{
                  borderColor: formState.primaryColor,
                  fontFamily: "'Poppins', sans-serif",
                }}
              >
                {/* En-tête : Logo & Titre Reçu */}
                <div
                  className={`flex items-start gap-4 pb-6 border-b border-neutral-200 ${
                    formState.logoPosition === 'center'
                      ? 'flex-col items-center text-center'
                      : formState.logoPosition === 'right'
                      ? 'flex-row-reverse justify-between'
                      : 'justify-between'
                  }`}
                >
                  <div className={`flex items-center gap-3.5 ${formState.logoPosition === 'center' ? 'flex-col text-center' : ''}`}>
                    {currentBoutique?.logo ? (
                      <img
                        src={currentBoutique.logo}
                        alt={currentBoutique.name}
                        className="w-14 h-14 object-cover rounded-2xl border border-neutral-100 shadow-sm"
                      />
                    ) : (
                      <div
                        className="w-14 h-14 rounded-2xl flex items-center justify-center font-black text-white text-xl shadow-sm"
                        style={{ backgroundColor: formState.primaryColor }}
                      >
                        {currentBoutique?.name?.substring(0, 2).toUpperCase() || 'BT'}
                      </div>
                    )}
                    <div>
                      <h3
                        className="text-lg sm:text-xl font-black tracking-tight"
                        style={{ color: formState.secondaryColor }}
                      >
                        {currentBoutique?.name || 'Ma Boutique'}
                      </h3>
                      <p className="text-xs text-neutral-500 mt-0.5">
                        {currentBoutique?.city || 'Dakar'} · {currentBoutique?.phone || '+221 77 000 00 00'}
                      </p>
                    </div>
                  </div>

                  <div className={formState.logoPosition === 'center' ? 'text-center' : 'text-right'}>
                    <div
                      className="inline-block px-3.5 py-1 rounded-xl text-xs sm:text-sm font-black uppercase tracking-wider text-white shadow-xs"
                      style={{ backgroundColor: formState.primaryColor }}
                    >
                      REÇU N° RC-2026-0042
                    </div>
                    <div className="text-xs text-neutral-500 mt-1.5 font-medium">
                      Date : {new Date().toLocaleDateString('fr-FR')}
                    </div>
                  </div>
                </div>

                {/* Bloc Montant du reçu */}
                <div
                  className="p-4 sm:p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between text-white shadow-sm gap-2"
                  style={{ backgroundColor: formState.primaryColor }}
                >
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider opacity-90 block">
                      MONTANT DU REÇU
                    </span>
                    <span className="text-[11px] font-medium opacity-90">Règlement validé et certifié</span>
                  </div>
                  <div className="text-2xl sm:text-3xl font-black font-mono tracking-tight">
                    {previewAmount.toLocaleString()} {previewCurrency}
                  </div>
                </div>

                {/* Lignes en pointillés ................................. */}
                <div className="space-y-4 text-xs sm:text-sm text-neutral-800 pt-1 font-mono">
                  <div className="flex items-baseline gap-2">
                    <span className="font-sans font-bold text-neutral-900 shrink-0">Reçu de M. / Mme :</span>
                    <span className="flex-1 border-b-2 border-dotted border-neutral-400 tracking-widest text-neutral-800 font-bold font-sans">
                      Aïssatou Diallo
                    </span>
                  </div>

                  <div className="flex items-baseline gap-2">
                    <span className="font-sans font-bold text-neutral-900 shrink-0">La somme de :</span>
                    <span className="flex-1 border-b-2 border-dotted border-neutral-400 tracking-widest text-neutral-700 italic font-sans">
                      {previewAmount.toLocaleString()} {previewCurrency}
                    </span>
                  </div>

                  <div className="flex items-baseline gap-2">
                    <span className="font-sans font-bold text-neutral-900 shrink-0">Pour motif / règlement :</span>
                    <span className="flex-1 border-b-2 border-dotted border-neutral-400 tracking-widest text-neutral-700 font-sans">
                      Commande tissus Bazin Riche & confection express
                    </span>
                  </div>

                  <div className="flex items-baseline gap-2">
                    <span className="font-sans font-bold text-neutral-900 shrink-0">Mode de règlement :</span>
                    <span className="flex-1 border-b-2 border-dotted border-neutral-400 tracking-widest text-neutral-700 font-sans">
                      Paiement validé · Mobile Money / Espèces / Virement
                    </span>
                  </div>

                  <div className="flex items-baseline gap-2 opacity-60">
                    <span className="flex-1 border-b-2 border-dotted border-neutral-300 tracking-widest">
                      ........................................................................................................
                    </span>
                  </div>
                </div>

                {/* Section Signature */}
                <div className="pt-6 border-t border-neutral-200 grid grid-cols-2 gap-6 sm:gap-8">
                  <div className="text-center">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400 block mb-10">
                      Signature du client
                    </span>
                    <div className="border-t border-dashed border-neutral-400 pt-1 text-[11px] text-neutral-400 italic">
                      Bon pour accord & décharge
                    </div>
                  </div>

                  <div className="text-center">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-800 block mb-10">
                      Signature & Cachet
                    </span>
                    <div
                      className="border-t-2 pt-1 text-[11px] font-bold"
                      style={{ borderColor: formState.primaryColor, color: formState.primaryColor }}
                    >
                      {currentBoutique?.name || 'La Direction'}
                    </div>
                  </div>
                </div>

                {/* Footer Notes & Branding */}
                <div className="pt-3 border-t border-neutral-100 flex items-center justify-between text-xs text-neutral-400">
                  <div>
                    {formState.receiptFooterMessage || formState.invoiceFooterMessage || 'Merci pour votre confiance !'}
                  </div>
                  <div className="flex items-center gap-1.5 text-[10px]">
                    <span>Certifié par</span>
                    <PayperLogo size="sm" />
                  </div>
                </div>
              </div>
            ) : previewMode === 'invoice' ? (
              /* INVOICE PREVIEW CLASSIQUE */
              <div
                className="w-full max-w-[580px] bg-white rounded-2xl shadow-lg border p-6 sm:p-8 space-y-6 transition-all"
                style={{
                  borderColor: formState.primaryColor,
                  borderWidth: formState.invoiceTemplate === 'signature_border' ? '3px' : '1px',
                }}
              >
                {/* Header based on logo position */}
                <div
                  className={`flex items-start gap-4 pb-6 border-b border-neutral-100 ${
                    formState.logoPosition === 'center'
                      ? 'flex-col items-center text-center'
                      : formState.logoPosition === 'right'
                      ? 'flex-row-reverse justify-between'
                      : 'justify-between'
                  }`}
                >
                  <div className={formState.logoPosition === 'center' ? 'text-center' : ''}>
                    {currentBoutique?.logo ? (
                      <img
                        src={currentBoutique.logo}
                        alt={currentBoutique.name}
                        className="w-14 h-14 object-contain rounded-xl border border-neutral-100 p-0.5"
                      />
                    ) : (
                      <div
                        className="w-14 h-14 rounded-xl flex items-center justify-center font-black text-white text-lg shadow-sm"
                        style={{ backgroundColor: formState.primaryColor }}
                      >
                        {currentBoutique?.name?.substring(0, 2).toUpperCase() || 'BT'}
                      </div>
                    )}
                    <h3
                      className="text-lg font-black mt-2 tracking-tight"
                      style={{ color: formState.secondaryColor }}
                    >
                      {currentBoutique?.name || 'Ma Boutique'}
                    </h3>
                    <p className="text-xs text-neutral-500">
                      {currentBoutique?.city || 'Afrique'} · {currentBoutique?.phone || '+221 77 000 00 00'}
                    </p>
                  </div>

                  <div className={formState.logoPosition === 'center' ? 'text-center' : 'text-right'}>
                    <span
                      className="inline-block px-3 py-1 rounded-lg text-xs font-black uppercase tracking-wider text-white shadow-xs"
                      style={{ backgroundColor: formState.primaryColor }}
                    >
                      Facture N° FAC-2026-001
                    </span>
                    <div className="text-xs text-neutral-400 mt-1.5">
                      Date : {new Date().toLocaleDateString('fr-FR')}
                    </div>
                    <div className="text-xs font-semibold text-neutral-700 mt-1">
                      Client : Aïssatou Diallo
                    </div>
                  </div>
                </div>

                {/* Items Table */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs font-bold uppercase tracking-wider text-neutral-400 pb-2 border-b border-neutral-100">
                    <span>Désignation</span>
                    <span>Montant</span>
                  </div>
                  <div className="flex justify-between items-center py-2 text-xs font-medium text-neutral-800">
                    <div>
                      <div className="font-bold">Lot de tissus Bazin Riche (x2)</div>
                      <div className="text-[10px] text-neutral-400">Qualité supérieure brodée</div>
                    </div>
                    <span className="font-mono font-bold">50 000 {previewCurrency}</span>
                  </div>
                  <div className="flex justify-between items-center py-2 text-xs font-medium text-neutral-800">
                    <div>
                      <div className="font-bold">Livraison express domicile</div>
                      <div className="text-[10px] text-neutral-400">Expédition Dakar Plateau</div>
                    </div>
                    <span className="font-mono font-bold">25 000 {previewCurrency}</span>
                  </div>
                </div>

                {/* Total Box */}
                <div
                  className="p-4 rounded-xl flex items-center justify-between text-white shadow-sm"
                  style={{ backgroundColor: formState.primaryColor }}
                >
                  <span className="text-xs font-bold uppercase tracking-wider">Total à payer</span>
                  <span className="text-xl font-black font-mono">
                    {previewAmount.toLocaleString()} {previewCurrency}
                  </span>
                </div>

                {/* Footer Notes */}
                <div className="text-center pt-2 border-t border-neutral-100 text-[11px] text-neutral-400">
                  {formState.invoiceFooterMessage || 'Modalités de règlement : Paiement par Mobile Money ou Virement bancaire.'}
                </div>
              </div>
            ) : (
              /* RECEIPT PREVIEW (Ticket de caisse compact) */
              <div
                className={`w-full max-w-[360px] bg-white rounded-2xl shadow-xl p-6 space-y-4 border transition-all ${
                  formState.receiptTemplate === 'thermal_ticket'
                    ? 'border-dashed border-2 border-neutral-300 font-mono text-xs'
                    : 'border-neutral-200'
                }`}
              >
                {/* Receipt Header */}
                <div className="text-center pb-3 border-b border-neutral-100">
                  {currentBoutique?.logo ? (
                    <img
                      src={currentBoutique.logo}
                      alt={currentBoutique.name}
                      className="w-12 h-12 object-contain rounded-xl mx-auto mb-2 border border-neutral-100 p-0.5"
                    />
                  ) : (
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center font-black text-white text-sm mx-auto mb-2 shadow-xs"
                      style={{ backgroundColor: formState.primaryColor }}
                    >
                      {currentBoutique?.name?.substring(0, 2).toUpperCase() || 'BT'}
                    </div>
                  )}
                  <h4 className="font-black text-base text-[#111827]">
                    {currentBoutique?.name || 'Ma Boutique'}
                  </h4>
                  <p className="text-[11px] text-neutral-500">
                    Reçu de règlement officiel
                  </p>
                  <div
                    className="inline-block mt-2 px-3 py-0.5 rounded-full text-[10px] font-black uppercase text-white"
                    style={{ backgroundColor: formState.primaryColor }}
                  >
                    Payé · Encaissé
                  </div>
                </div>

                {/* Receipt Metadata */}
                <div className="space-y-1.5 text-xs text-neutral-600">
                  <div className="flex justify-between">
                    <span className="text-neutral-400">Transaction :</span>
                    <span className="font-mono font-bold">#REC-8842</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-400">Date :</span>
                    <span>{new Date().toLocaleDateString('fr-FR')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-400">Client :</span>
                    <span className="font-semibold text-neutral-800">Aïssatou Diallo</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-400">Règlement :</span>
                    <span className="font-semibold text-emerald-600">Mobile Money validé</span>
                  </div>
                </div>

                {/* Amount Paid */}
                <div
                  className="p-3.5 rounded-xl text-center text-white my-3"
                  style={{ backgroundColor: formState.primaryColor }}
                >
                  <div className="text-[10px] font-bold uppercase tracking-wider opacity-90">
                    Montant encaissé
                  </div>
                  <div className="text-2xl font-black font-mono">
                    {previewAmount.toLocaleString()} {previewCurrency}
                  </div>
                </div>

                {/* Custom Receipt Footer Message */}
                <div className="text-center text-[11px] text-neutral-500 pt-2 border-t border-dashed border-neutral-200">
                  {formState.receiptFooterMessage || 'Merci pour votre confiance ! À très bientôt.'}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
