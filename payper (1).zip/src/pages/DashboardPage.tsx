import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Wallet,
  Clock,
  FileCheck2,
  Search,
  MoreVertical,
  Eye,
  Trash2,
  CheckCircle2,
  Plus,
  ArrowUpRight,
  TrendingUp,
  Share2,
} from 'lucide-react';
import { Invoice } from '../types';
import { getInvoices, updateInvoice, deleteInvoice, getBoutique, getSubscription } from '../lib/storage';
import { formatCurrency, formatDate } from '../lib/invoice';
import { checkPlanLimits } from '../lib/subscription';
import { useToast } from '../components/common/Toast';
import { useLayoutActions } from '../components/layout/AppLayout';
import { WelcomeMessageOverlay } from '../components/dashboard/WelcomeMessageOverlay';
import { InteractiveTour } from '../components/dashboard/InteractiveTour';
import { HelpCircle } from 'lucide-react';

interface DashboardPageProps {
  onNavigate: (path: string) => void;
  onOpenNewInvoice?: () => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  onNavigate,
  onOpenNewInvoice,
}) => {
  const { showToast } = useToast();
  const { openNewInvoice } = useLayoutActions();

  const handleOpenNewInvoice = () => {
    if (onOpenNewInvoice) onOpenNewInvoice();
    else openNewInvoice();
  };
  const [invoices, setInvoices] = useState<Invoice[]>(getInvoices());
  const [boutique, setBoutique] = useState(getBoutique());
  const [filterStatus, setFilterStatus] = useState<'all' | 'paid' | 'pending'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  // ÉTAPE 8 & 9 : Message de bienvenue et Tutoriel interactif
  const [showWelcomeMessage, setShowWelcomeMessage] = useState<boolean>(() => {
    const shouldShow = sessionStorage.getItem('payper_show_welcome_banner') === 'true';
    if (shouldShow) {
      sessionStorage.removeItem('payper_show_welcome_banner');
      return true;
    }
    return false;
  });

  const [showTour, setShowTour] = useState<boolean>(() => {
    const shouldStartTour = localStorage.getItem('payper_trigger_tour') === 'true';
    if (shouldStartTour) {
      localStorage.removeItem('payper_trigger_tour');
      // If welcome message is also showing, we will trigger tour right after welcome disappears
      const willShowWelcome = sessionStorage.getItem('payper_show_welcome_banner') === 'true';
      return !willShowWelcome;
    }
    return false;
  });

  const subscription = getSubscription();
  const status = checkPlanLimits();

  const reloadData = () => {
    setInvoices(getInvoices());
    setBoutique(getBoutique());
  };

  useEffect(() => {
    const handleUpdate = () => reloadData();
    const handleStartTour = () => setShowTour(true);
    window.addEventListener('payper_invoices_updated', handleUpdate);
    window.addEventListener('payper_boutique_updated', handleUpdate);
    window.addEventListener('payper_start_tour', handleStartTour);
    return () => {
      window.removeEventListener('payper_invoices_updated', handleUpdate);
      window.removeEventListener('payper_boutique_updated', handleUpdate);
      window.removeEventListener('payper_start_tour', handleStartTour);
    };
  }, []);

  // Close popup menus when clicking outside
  useEffect(() => {
    const handleClickOutside = () => setActiveMenuId(null);
    window.addEventListener('click', handleClickOutside);
    return () => window.removeEventListener('click', handleClickOutside);
  }, []);

  // Stats calculation
  const defaultCurrency = boutique?.devise || 'FCFA';

  const totalPaid = useMemo(() => {
    return invoices
      .filter(i => i.isPaid)
      .reduce((sum, i) => sum + (Number(i.amount) || 0), 0);
  }, [invoices]);

  const totalPending = useMemo(() => {
    return invoices
      .filter(i => !i.isPaid)
      .reduce((sum, i) => sum + (Number(i.amount) || 0), 0);
  }, [invoices]);

  // Counts for filter pills
  const countAll = invoices.length;
  const countPaid = invoices.filter(i => i.isPaid).length;
  const countPending = invoices.filter(i => !i.isPaid).length;

  // Filtered invoices
  const filteredInvoices = useMemo(() => {
    return invoices.filter(inv => {
      // Status filter
      if (filterStatus === 'paid' && !inv.isPaid) return false;
      if (filterStatus === 'pending' && inv.isPaid) return false;

      // Search filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchClient = inv.clientName.toLowerCase().includes(query);
        const matchDesc = inv.description.toLowerCase().includes(query);
        const matchId = inv.id.toLowerCase().includes(query);
        if (!matchClient && !matchDesc && !matchId) return false;
      }

      return true;
    });
  }, [invoices, filterStatus, searchQuery]);

  const handleMarkAsPaid = (inv: Invoice, e?: React.MouseEvent) => {
    e?.stopPropagation();
    const updated = { ...inv, isPaid: true };
    updateInvoice(updated);
    reloadData();
    showToast('Marqué comme payé !', 'success');
  };

  const handleDeleteInvoice = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (window.confirm('Voulez-vous vraiment supprimer cette facture ?')) {
      deleteInvoice(id);
      reloadData();
      showToast('Facture supprimée.', 'info');
      setActiveMenuId(null);
    }
  };

  return (
    <div className="space-y-7 animate-in fade-in duration-300">
      {/* Top Banner / Welcome Greetings */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#111827] tracking-tight">
            Bonjour, {boutique?.name || 'Boutique'} 👋
          </h1>
          <p className="text-sm text-neutral-500 mt-1">
            Voici l'état en temps réel de vos factures et encaissements.
          </p>
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={() => setShowTour(true)}
            className="flex items-center gap-1.5 py-2 px-3 rounded-xl text-xs font-semibold text-neutral-600 bg-neutral-100 hover:bg-neutral-200/80 hover:text-neutral-900 transition-colors cursor-pointer"
            title="Lancer le tutoriel interactif"
          >
            <HelpCircle className="w-4 h-4 text-[#FF8A00]" />
            <span className="hidden sm:inline">Visite guidée</span>
          </button>
          <button
            id="tour-new-invoice-btn"
            onClick={handleOpenNewInvoice}
            className="flex items-center gap-2 py-2.5 px-4 rounded-xl text-sm font-semibold text-white bg-[#FF8A00] hover:bg-[#e67c00] shadow-sm shadow-orange-500/20 active:scale-95 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Nouvelle facture</span>
          </button>
        </div>
      </div>

      {/* 3 Metric Cards */}
      <div id="tour-stats-cards" className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Card 1: Total encaissé */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-white rounded-2xl p-5 sm:p-6 border border-neutral-100 shadow-sm relative overflow-hidden"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">
              Total encaissé
            </span>
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-[#00C48C] flex items-center justify-center">
              <Wallet className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl sm:text-3xl font-black text-[#111827] font-mono tabular-nums">
              {formatCurrency(totalPaid, defaultCurrency)}
            </div>
            <div className="flex items-center gap-1.5 text-xs text-[#00C48C] mt-2 font-medium">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>{countPaid} facture(s) réglée(s)</span>
            </div>
          </div>
        </motion.div>

        {/* Card 2: En attente */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.08 }}
          className="bg-white rounded-2xl p-5 sm:p-6 border border-neutral-100 shadow-sm relative overflow-hidden"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">
              En attente
            </span>
            <div className="w-10 h-10 rounded-xl bg-orange-50 text-[#FF8A00] flex items-center justify-center">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl sm:text-3xl font-black text-[#111827] font-mono tabular-nums">
              {formatCurrency(totalPending, defaultCurrency)}
            </div>
            <div className="flex items-center gap-1.5 text-xs text-[#FF8A00] mt-2 font-medium">
              <span>{countPending} facture(s) à relancer</span>
            </div>
          </div>
        </motion.div>

        {/* Card 3: Factures ce mois */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.16 }}
          className="bg-white rounded-2xl p-5 sm:p-6 border border-neutral-100 shadow-sm relative overflow-hidden"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">
              Factures ce mois
            </span>
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <FileCheck2 className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-4">
            <div className="text-2xl sm:text-3xl font-black text-[#111827] font-mono tabular-nums">
              {status.invoicesThisMonth} /{' '}
              {status.invoicesLimit === 'unlimited' ? '∞' : status.invoicesLimit}
            </div>
            <div className="flex items-center justify-between text-xs text-neutral-500 mt-2">
              <span className="capitalize">Forfait : {subscription.plan}</span>
              {subscription.plan === 'free' && (
                <button
                  onClick={() => onNavigate('/pricing')}
                  className="font-semibold text-[#FF8A00] hover:underline cursor-pointer"
                >
                  Augmenter →
                </button>
              )}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Invoices Section with Search & Filter Pills */}
      <div id="tour-invoices-section" className="bg-white rounded-2xl border border-neutral-100 shadow-sm overflow-hidden">
        {/* Filter bar */}
        <div className="p-4 sm:p-5 border-b border-neutral-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          {/* Segmented Filter Pills */}
          <div className="flex items-center gap-1.5 bg-neutral-100/80 p-1 rounded-xl">
            <button
              onClick={() => setFilterStatus('all')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                filterStatus === 'all'
                  ? 'bg-white text-neutral-900 shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Tous ({countAll})
            </button>
            <button
              onClick={() => setFilterStatus('paid')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                filterStatus === 'paid'
                  ? 'bg-white text-[#00C48C] shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Payé ✓ ({countPaid})
            </button>
            <button
              onClick={() => setFilterStatus('pending')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                filterStatus === 'pending'
                  ? 'bg-white text-[#FF8A00] shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              En attente ⏳ ({countPending})
            </button>
          </div>

          {/* Search Input */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Rechercher client ou description..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-neutral-50 border border-neutral-200/80 rounded-xl pl-9 pr-3.5 py-2 text-xs text-neutral-900 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-all"
            />
          </div>
        </div>

        {/* Invoices List / Table */}
        <AnimatePresence mode="wait">
          <motion.div
            key={filterStatus + searchQuery}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
          >
            {filteredInvoices.length === 0 ? (
              <div className="py-16 px-4 text-center">
                <div className="w-14 h-14 rounded-2xl bg-neutral-100 flex items-center justify-center text-neutral-400 mx-auto mb-3">
                  <FileCheck2 className="w-7 h-7" />
                </div>
                <h3 className="text-base font-bold text-neutral-800">
                  {invoices.length === 0
                    ? 'Aucune facture pour le moment'
                    : 'Aucun résultat trouvé'}
                </h3>
                <p className="text-xs text-neutral-500 max-w-sm mx-auto mt-1 mb-5">
                  {invoices.length === 0
                    ? 'Créez votre première facture professionnelle et partagez-la directement en image sur WhatsApp.'
                    : 'Essayez de modifier vos filtres ou termes de recherche.'}
                </p>
                {invoices.length === 0 && (
                  <button
                    onClick={handleOpenNewInvoice}
                    className="inline-flex items-center gap-2 py-2.5 px-5 rounded-xl text-xs font-semibold text-white bg-[#FF8A00] hover:bg-[#e67c00] shadow-sm transition-all cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Créer ma première facture</span>
                  </button>
                )}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-neutral-100 bg-neutral-50/50 text-[11px] font-bold uppercase tracking-wider text-neutral-400">
                      <th className="py-3.5 px-4 sm:px-6">Client</th>
                      <th className="py-3.5 px-4">Description</th>
                      <th className="py-3.5 px-4 text-right">Montant</th>
                      <th className="py-3.5 px-4">Statut</th>
                      <th className="py-3.5 px-4 sm:px-6 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {filteredInvoices.map(inv => (
                      <tr
                        key={inv.id}
                        onClick={() => onNavigate(`/invoice/${inv.id}`)}
                        className="hover:bg-neutral-50/80 transition-colors cursor-pointer group"
                      >
                        {/* Client Column */}
                        <td className="py-4 px-4 sm:px-6">
                          <div className="font-bold text-neutral-900 group-hover:text-[#FF8A00] transition-colors">
                            {inv.clientName}
                          </div>
                          <div className="text-[11px] text-neutral-400 font-mono mt-0.5">
                            {inv.id} · {formatDate(inv.date)}
                          </div>
                        </td>

                        {/* Description Column */}
                        <td className="py-4 px-4 max-w-xs">
                          <div className="truncate text-neutral-700 font-medium">
                            {inv.description}
                          </div>
                          <div className="text-[11px] text-neutral-400">
                            {inv.clientCity || 'Dakar'}
                          </div>
                        </td>

                        {/* Montant Column */}
                        <td className="py-4 px-4 text-right font-black text-neutral-900 font-mono tabular-nums text-sm">
                          {formatCurrency(inv.amount, inv.devise)}
                        </td>

                        {/* Statut Column */}
                        <td className="py-4 px-4">
                          {inv.isPaid ? (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-50 text-[#00C48C] border border-emerald-100">
                              <span className="w-1.5 h-1.5 rounded-full bg-[#00C48C]" />
                              Payé ✓
                            </span>
                          ) : (
                            <div className="flex items-center gap-2">
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-orange-50 text-[#FF8A00] border border-orange-100">
                                <span className="w-1.5 h-1.5 rounded-full bg-[#FF8A00]" />
                                En attente ⏳
                              </span>
                              <button
                                onClick={e => handleMarkAsPaid(inv, e)}
                                title="Marquer comme payé"
                                className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-50 hover:bg-emerald-100 text-[#00C48C] transition-colors cursor-pointer"
                              >
                                <span>Marquer Payé ✓</span>
                              </button>
                            </div>
                          )}
                        </td>

                        {/* Actions Column */}
                        <td className="py-4 px-4 sm:px-6 text-right relative">
                          <div
                            className="inline-block text-left"
                            onClick={e => e.stopPropagation()}
                          >
                            <button
                              onClick={e => {
                                e.stopPropagation();
                                setActiveMenuId(activeMenuId === inv.id ? null : inv.id);
                              }}
                              className="p-1.5 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 rounded-lg transition-colors cursor-pointer"
                              aria-label="Options"
                            >
                              <MoreVertical className="w-4 h-4" />
                            </button>

                            {activeMenuId === inv.id && (
                              <div className="absolute right-6 top-10 w-44 bg-white rounded-xl shadow-xl border border-neutral-100 py-1.5 z-20 animate-in fade-in zoom-in-95 duration-100">
                                <button
                                  onClick={() => {
                                    setActiveMenuId(null);
                                    onNavigate(`/invoice/${inv.id}`);
                                  }}
                                  className="w-full text-left px-3.5 py-2 text-xs font-medium text-neutral-700 hover:bg-neutral-50 flex items-center gap-2 cursor-pointer"
                                >
                                  <Eye className="w-3.5 h-3.5 text-neutral-400" />
                                  <span>Voir facture</span>
                                </button>

                                {!inv.isPaid && (
                                  <button
                                    onClick={() => {
                                      setActiveMenuId(null);
                                      handleMarkAsPaid(inv);
                                    }}
                                    className="w-full text-left px-3.5 py-2 text-xs font-medium text-[#00C48C] hover:bg-emerald-50 flex items-center gap-2 cursor-pointer"
                                  >
                                    <CheckCircle2 className="w-3.5 h-3.5" />
                                    <span>Marquer Payé ✓</span>
                                  </button>
                                )}

                                <div className="border-t border-neutral-100 my-1" />

                                <button
                                  onClick={() => handleDeleteInvoice(inv.id)}
                                  className="w-full text-left px-3.5 py-2 text-xs font-medium text-red-600 hover:bg-red-50 flex items-center gap-2 cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5 text-red-500" />
                                  <span>Supprimer</span>
                                </button>
                              </div>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* ÉTAPE 8 : Message temporaire de bienvenue au centre */}
      {showWelcomeMessage && (
        <WelcomeMessageOverlay
          onDismiss={() => {
            setShowWelcomeMessage(false);
            // ÉTAPE 9 : Lancer automatiquement le tutoriel interactif
            setShowTour(true);
          }}
        />
      )}

      {/* ÉTAPE 9 : Tutoriel interactif du tableau de bord */}
      <InteractiveTour
        isOpen={showTour}
        onClose={() => setShowTour(false)}
        onComplete={() => {
          showToast('Visite terminée ! Vous maîtrisez désormais PAYPER.', 'success');
        }}
      />
    </div>
  );
};
