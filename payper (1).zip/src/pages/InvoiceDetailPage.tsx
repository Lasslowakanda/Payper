import React, { useState, useRef } from 'react';
import html2canvas from 'html2canvas';
import {
  Download,
  Share2,
  Send,
  Link as LinkIcon,
  CheckCircle2,
  ArrowLeft,
  Trash2,
  Printer,
  Bell,
  Clock,
  ExternalLink,
} from 'lucide-react';
import { Invoice } from '../types';
import { getInvoiceById, updateInvoice, deleteInvoice, getSubscription } from '../lib/storage';
import { generatePublicInvoiceUrl, generateWhatsAppMessage, buildWhatsAppUrl } from '../lib/share';
import { generateInvoiceImage, downloadInvoiceImage, captureInvoiceBlob } from '../lib/invoice';
import {
  generateReminderMessage,
  buildReminderWhatsAppUrl,
  recordReminderLog,
  hasReminderBeenSent,
} from '../lib/automations';
import { InvoiceCardA4 } from '../components/invoices/InvoiceCardA4';
import { WhatsAppModal } from '../components/invoices/WhatsAppModal';
import { useToast } from '../components/common/Toast';
import { PayperLoader } from '../components/payper-loader';

interface InvoiceDetailPageProps {
  invoiceId: string;
  onNavigate: (path: string) => void;
}

export const InvoiceDetailPage: React.FC<InvoiceDetailPageProps> = ({
  invoiceId,
  onNavigate,
}) => {
  const { showToast } = useToast();
  const [invoice, setInvoice] = useState<Invoice | null>(() => getInvoiceById(invoiceId));
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);

  const subscription = getSubscription();
  const showPayperWatermark = subscription.plan !== 'pro';

  if (!invoice) {
    return (
      <div className="py-20 text-center">
        <h2 className="text-xl font-bold text-neutral-800">Facture introuvable</h2>
        <p className="text-sm text-neutral-500 mt-1 mb-5">
          Cette facture a peut-être été supprimée ou l'identifiant est incorrect.
        </p>
        <button
          onClick={() => onNavigate('/invoices')}
          className="px-4 py-2 rounded-xl text-xs font-semibold text-white bg-[#FF8A00]"
        >
          Retour aux factures
        </button>
      </div>
    );
  }

  const handleDownloadImage = async () => {
    setIsGeneratingImage(true);
    try {
      const clientClean = invoice.clientName.replace(/[^a-zA-Z0-9]/g, '_');
      const filename = `Facture-${invoice.id}-${clientClean}.png`;

      await generateInvoiceImage('facture-a-capturer', filename, invoice);
      showToast('Facture téléchargée sur votre appareil !', 'success');
    } catch (err) {
      console.error(err);
      showToast('Erreur lors du téléchargement de l’image.', 'error');
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleCopyPublicLink = async () => {
    try {
      const publicUrl = generatePublicInvoiceUrl(invoice);
      await navigator.clipboard.writeText(publicUrl);
      showToast('Lien copié dans le presse-papier !', 'success');
    } catch (err) {
      console.error('Failed to copy', err);
      showToast('Lien généré pour le partage.', 'info');
    }
  };

  const handleNativeShare = async () => {
    const publicUrl = generatePublicInvoiceUrl(invoice);
    const message = generateWhatsAppMessage(invoice);

    if (navigator.share) {
      try {
        const result = await captureInvoiceBlob('facture-a-capturer', invoice);
        if (result && navigator.canShare && navigator.canShare({ files: [new File([result.blob], `Facture-${invoice.id}.png`, { type: 'image/png' })] })) {
          const file = new File([result.blob], `Facture-${invoice.id}.png`, { type: 'image/png' });
          await navigator.share({
            title: `Facture ${invoice.id} - ${invoice.boutiqueName}`,
            text: message,
            url: publicUrl,
            files: [file],
          });
          return;
        }

        await navigator.share({
          title: `Facture ${invoice.id} - ${invoice.boutiqueName}`,
          text: message,
          url: publicUrl,
        });
      } catch (e) {
        // user cancelled or fallback
      }
    } else {
      handleCopyPublicLink();
    }
  };

  const handleMarkAsPaid = () => {
    const updated = { ...invoice, isPaid: true };
    updateInvoice(updated);
    setInvoice(updated);
    showToast('Marqué comme payé !', 'success');
  };

  const handleDelete = () => {
    if (confirm('Voulez-vous vraiment supprimer cette facture ?')) {
      deleteInvoice(invoice.id);
      showToast('Facture supprimée', 'info');
      onNavigate('/invoices');
    }
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return '';
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString('fr-FR', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      });
    } catch {
      return dateStr;
    }
  };

  const handleSendReminder = (type: 'J+1' | 'J+3' | 'J+7') => {
    if (!invoice) return;
    const url = buildReminderWhatsAppUrl(invoice, type, invoice.payment_link);
    const message = generateReminderMessage(invoice, type, invoice.payment_link);

    // Record log
    recordReminderLog({
      invoice_id: invoice.id,
      boutique_id: invoice.store_id || '',
      client_name: invoice.clientName,
      whatsapp_number: invoice.whatsappNumber,
      reminder_type: type,
      channel: 'WHATSAPP',
      status: 'SENT',
      message_content: message,
      public_url: generatePublicInvoiceUrl(invoice),
    });

    showToast(`Relance ${type} générée ! Redirection vers WhatsApp...`, 'success');
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleToggleReminders = () => {
    if (!invoice) return;
    const updated = {
      ...invoice,
      reminders_enabled: invoice.reminders_enabled === false ? true : false,
    };
    updateInvoice(updated);
    setInvoice(updated);
    showToast(
      updated.reminders_enabled ? 'Relances automatiques activées ✓' : 'Relances automatiques désactivées',
      'info'
    );
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Top action header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <button
          onClick={() => onNavigate('/invoices')}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-600 hover:text-neutral-900 transition-colors self-start cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Retour aux factures</span>
        </button>

        <div className="flex flex-wrap items-center gap-2">
          {!invoice.isPaid && (
            <button
              onClick={handleMarkAsPaid}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-white bg-[#00C48C] hover:bg-[#00ad7a] transition-all shadow-xs cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Marquer Payé ✓</span>
            </button>
          )}

          <button
            onClick={handleDelete}
            className="p-2 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-colors cursor-pointer"
            title="Supprimer la facture"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Automations V1: Relances Automatiques J+1 / J+3 / J+7 Section */}
      {!invoice.isPaid && (
        <div className="bg-gradient-to-r from-orange-50/60 via-amber-50/40 to-neutral-50 border border-orange-200/80 rounded-2xl p-4 sm:p-5 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-orange-200/60">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-[#FF8A00] text-white flex items-center justify-center shadow-xs">
                <Bell className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-[#111827]">
                    Relances Automatiques & Suivi des impayés
                  </h3>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-orange-100 text-[#FF8A00] font-extrabold uppercase">
                    V1 Automations
                  </span>
                </div>
                <p className="text-xs text-neutral-500">
                  {invoice.dueDate
                    ? `Échéance fixée au ${formatDate(invoice.dueDate)}`
                    : "Pas d'échéance spécifique"}
                  {invoice.reminders_enabled !== false
                    ? ' · Relances programmées à J+1, J+3 et J+7 (09:00)'
                    : ' · Relances automatiques désactivées sur cette facture'}
                </p>
              </div>
            </div>

            <button
              onClick={handleToggleReminders}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer self-start sm:self-auto ${
                invoice.reminders_enabled !== false
                  ? 'bg-emerald-50 text-[#00C48C] border-emerald-200 hover:bg-emerald-100'
                  : 'bg-neutral-100 text-neutral-600 border-neutral-200 hover:bg-neutral-200'
              }`}
            >
              {invoice.reminders_enabled !== false ? '✓ Relances actives' : 'Relances désactivées'}
            </button>
          </div>

          <div className="pt-3 flex flex-wrap items-center justify-between gap-3">
            <span className="text-xs text-neutral-600">
              Envoyer manuellement un rappel courtois pré-rédigé avec lien de paiement :
            </span>
            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => handleSendReminder('J+1')}
                className="px-3 py-1.5 rounded-xl bg-white border border-neutral-200 hover:border-[#FF8A00] hover:text-[#FF8A00] text-xs font-bold text-neutral-700 shadow-2xs transition-all cursor-pointer"
              >
                Rappel J+1
              </button>
              <button
                onClick={() => handleSendReminder('J+3')}
                className="px-3 py-1.5 rounded-xl bg-white border border-neutral-200 hover:border-[#FF8A00] hover:text-[#FF8A00] text-xs font-bold text-neutral-700 shadow-2xs transition-all cursor-pointer"
              >
                Rappel J+3
              </button>
              <button
                onClick={() => handleSendReminder('J+7')}
                className="px-3 py-1.5 rounded-xl bg-white border border-neutral-200 hover:border-red-400 hover:text-red-500 text-xs font-bold text-neutral-700 shadow-2xs transition-all cursor-pointer"
              >
                Dernier rappel J+7
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Action Bar */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-neutral-100 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-[#111827]">
            Facture {invoice.id} · {invoice.clientName}
          </h2>
          <p className="text-xs text-neutral-500">
            Télécharge l'image ou partage directement avec ton client sur WhatsApp.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 sm:gap-2.5 w-full md:w-auto">
          {/* Download Image Button */}
          <button
            onClick={handleDownloadImage}
            disabled={isGeneratingImage}
            className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 py-2.5 px-3.5 sm:px-4 rounded-xl text-xs font-bold text-neutral-800 bg-neutral-100 hover:bg-neutral-200 transition-all cursor-pointer disabled:opacity-85 min-h-[42px]"
          >
            {isGeneratingImage ? (
              <PayperLoader
                variant="download"
                size="sm"
                inline={true}
                text="Génération..."
              />
            ) : (
              <>
                <Download className="w-4 h-4 text-neutral-600 shrink-0" />
                <span className="truncate">Télécharger l'image</span>
              </>
            )}
          </button>

          {/* WhatsApp Primary Button */}
          <button
            onClick={() => setIsWhatsAppModalOpen(true)}
            className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 py-2.5 px-4 sm:px-5 rounded-xl text-xs font-bold text-white bg-[#25D366] hover:bg-[#20ba5a] transition-all shadow-sm shadow-emerald-600/20 active:scale-95 cursor-pointer min-h-[42px]"
          >
            <Send className="w-4 h-4 shrink-0" />
            <span className="truncate">Envoyer sur WhatsApp</span>
          </button>

          {/* Copy Public Link Button */}
          <button
            onClick={handleCopyPublicLink}
            className="inline-flex items-center justify-center gap-1.5 py-2.5 px-3.5 rounded-xl text-xs font-semibold text-neutral-700 bg-white border border-neutral-200 hover:bg-neutral-50 transition-all cursor-pointer min-h-[42px]"
            title="Copier le lien partageable"
          >
            <LinkIcon className="w-3.5 h-3.5 shrink-0" />
            <span className="hidden sm:inline">Copier le lien</span>
          </button>

          {/* Native Mobile Share if available */}
          {typeof navigator !== 'undefined' && 'share' in navigator && (
            <button
              onClick={handleNativeShare}
              className="inline-flex items-center justify-center p-2.5 rounded-xl text-neutral-700 bg-white border border-neutral-200 hover:bg-neutral-50 transition-all cursor-pointer sm:hidden min-h-[42px] min-w-[42px]"
              title="Partager"
            >
              <Share2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* A4 Invoice Card Container */}
      <div className="py-2">
        <InvoiceCardA4
          invoice={invoice}
          showPayperWatermark={showPayperWatermark}
        />
      </div>

      {/* WhatsApp Modal Dialog */}
      <WhatsAppModal
        isOpen={isWhatsAppModalOpen}
        onClose={() => setIsWhatsAppModalOpen(false)}
        invoice={invoice}
        onDownloadImage={handleDownloadImage}
      />
    </div>
  );
};
