import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  FileText,
  Search,
  Plus,
  MoreVertical,
  Eye,
  Trash2,
  CheckCircle2,
  Clock,
  ArrowUpDown,
  Filter,
} from 'lucide-react';
import { Invoice } from '../types';
import { getInvoices, updateInvoice, deleteInvoice } from '../lib/storage';
import { formatCurrency, formatDate } from '../lib/invoice';
import { useToast } from '../components/common/Toast';
import { useLayoutActions } from '../components/layout/AppLayout';

interface InvoicesPageProps {
  onNavigate: (path: string) => void;
  onOpenNewInvoice?: () => void;
}

export const InvoicesPage: React.FC<InvoicesPageProps> = ({
  onNavigate,
  onOpenNewInvoice,
}) => {
  const { showToast } = useToast();
  const { openNewInvoice } = useLayoutActions();

  const handleOpenNewInvoice = () => {
    if (onOpenNewInvoice) onOpenNewInvoice();
    else openNewInvoice();
  };
  const [invoices, setInvoices] = useState<Invoice[]>(getInvoices());
  const [filterStatus, setFilterStatus] = useState<'all' | 'paid' | 'pending'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  const reloadData = () => setInvoices(getInvoices());

  useEffect(() => {
    const handleUpdate = () => reloadData();
    window.addEventListener('payper_invoices_updated', handleUpdate);
    window.addEventListener('payper_boutique_updated', handleUpdate);
    return () => {
      window.removeEventListener('payper_invoices_updated', handleUpdate);
      window.removeEventListener('payper_boutique_updated', handleUpdate);
    };
  }, []);

  useEffect(() => {
    const handleClick = () => setActiveMenuId(null);
    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, []);

  const countAll = invoices.length;
  const countPaid = invoices.filter(i => i.isPaid).length;
  const countPending = invoices.filter(i => !i.isPaid).length;

  const filteredInvoices = useMemo(() => {
    return invoices.filter(inv => {
      if (filterStatus === 'paid' && !inv.isPaid) return false;
      if (filterStatus === 'pending' && inv.isPaid) return false;

      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchClient = inv.clientName.toLowerCase().includes(query);
        const matchDesc = inv.description.toLowerCase().includes(query);
        const matchId = inv.id.toLowerCase().includes(query);
        if (!matchClient && !matchDesc && !matchId) return false;
      }
      return true;
    });
  }, [invoices, filterStatus, searchQuery]);

  const handleMarkAsPaid = (inv: Invoice, e?: React.MouseEvent) => {
    e?.stopPropagation();
    const updated = { ...inv, isPaid: true };
    updateInvoice(updated);
    reloadData();
    showToast('Marqué comme payé !', 'success');
  };

  const handleDelete = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (window.confirm('Voulez-vous vraiment supprimer cette facture ?')) {
      deleteInvoice(id);
      reloadData();
      showToast('Facture supprimée.', 'info');
      setActiveMenuId(null);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#111827] tracking-tight">
            Factures ({invoices.length})
          </h1>
          <p className="text-sm text-neutral-500 mt-1">
            Gérez, téléchargez et envoyez toutes vos factures commerciales.
          </p>
        </div>

        <button
          onClick={handleOpenNewInvoice}
          className="flex items-center gap-2 py-2.5 px-4 rounded-xl text-sm font-semibold text-white bg-[#FF8A00] hover:bg-[#e67c00] shadow-sm shadow-orange-500/20 active:scale-95 transition-all cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>+ Nouvelle facture</span>
        </button>
      </div>

      {/* Main Table Card */}
      <div className="bg-white rounded-2xl border border-neutral-100 shadow-sm overflow-hidden">
        {/* Controls */}
        <div className="p-4 sm:p-5 border-b border-neutral-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-1.5 bg-neutral-100/80 p-1 rounded-xl">
            <button
              onClick={() => setFilterStatus('all')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                filterStatus === 'all'
                  ? 'bg-white text-neutral-900 shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Toutes ({countAll})
            </button>
            <button
              onClick={() => setFilterStatus('paid')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                filterStatus === 'paid'
                  ? 'bg-white text-[#00C48C] shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              Payées ({countPaid})
            </button>
            <button
              onClick={() => setFilterStatus('pending')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                filterStatus === 'pending'
                  ? 'bg-white text-[#FF8A00] shadow-xs'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              En attente ({countPending})
            </button>
          </div>

          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Rechercher client, numéro, description..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-neutral-50 border border-neutral-200/80 rounded-xl pl-9 pr-3.5 py-2 text-xs text-neutral-900 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-all"
            />
          </div>
        </div>

        {/* Table content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={filterStatus + searchQuery}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
          >
            {filteredInvoices.length === 0 ? (
              <div className="py-16 px-4 text-center">
                <FileText className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
                <h3 className="text-base font-bold text-neutral-800">
                  Aucune facture trouvée
                </h3>
                <p className="text-xs text-neutral-500 max-w-sm mx-auto mt-1 mb-5">
                  Aucune facture ne correspond aux critères sélectionnés.
                </p>
                <button
                  onClick={handleOpenNewInvoice}
                  className="inline-flex items-center gap-2 py-2 px-4 rounded-xl text-xs font-semibold text-white bg-[#FF8A00] hover:bg-[#e67c00]"
                >
                  <Plus className="w-4 h-4" />
                  <span>Créer une facture</span>
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-neutral-100 bg-neutral-50/50 text-[11px] font-bold uppercase tracking-wider text-neutral-400">
                      <th className="py-3.5 px-4 sm:px-6">N° / Date</th>
                      <th className="py-3.5 px-4">Client</th>
                      <th className="py-3.5 px-4">Description</th>
                      <th className="py-3.5 px-4 text-right">Montant</th>
                      <th className="py-3.5 px-4">Statut</th>
                      <th className="py-3.5 px-4 sm:px-6 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {filteredInvoices.map(inv => (
                      <tr
                        key={inv.id}
                        onClick={() => onNavigate(`/invoice/${inv.id}`)}
                        className="hover:bg-neutral-50/80 transition-colors cursor-pointer group"
                      >
                        <td className="py-4 px-4 sm:px-6 font-mono">
                          <span className="font-bold text-[#111827] group-hover:text-[#FF8A00] transition-colors">
                            {inv.id}
                          </span>
                          <div className="text-[11px] text-neutral-400 font-sans">
                            {formatDate(inv.date)}
                          </div>
                        </td>

                        <td className="py-4 px-4 font-bold text-neutral-800">
                          {inv.clientName}
                          <div className="text-[11px] text-neutral-400 font-normal">
                            {inv.clientCity}
                          </div>
                        </td>

                        <td className="py-4 px-4 max-w-xs truncate text-neutral-600 font-medium">
                          {inv.description}
                        </td>

                        <td className="py-4 px-4 text-right font-black text-neutral-900 font-mono tabular-nums text-sm">
                          {formatCurrency(inv.amount, inv.devise)}
                        </td>

                        <td className="py-4 px-4">
                          {inv.isPaid ? (
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-50 text-[#00C48C] border border-emerald-100">
                              <span className="w-1.5 h-1.5 rounded-full bg-[#00C48C]" />
                              Payé ✓
                            </span>
                          ) : (
                            <div className="flex items-center gap-2">
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-orange-50 text-[#FF8A00] border border-orange-100">
                                <span className="w-1.5 h-1.5 rounded-full bg-[#FF8A00]" />
                                En attente ⏳
                              </span>
                              <button
                                onClick={e => handleMarkAsPaid(inv, e)}
                                className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-50 hover:bg-emerald-100 text-[#00C48C] transition-colors"
                              >
                                Marquer Payé ✓
                              </button>
                            </div>
                          )}
                        </td>

                        <td className="py-4 px-4 sm:px-6 text-right relative">
                          <div
                            className="inline-block text-left"
                            onClick={e => e.stopPropagation()}
                          >
                            <button
                              onClick={e => {
                                e.stopPropagation();
                                setActiveMenuId(activeMenuId === inv.id ? null : inv.id);
                              }}
                              className="p-1.5 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 rounded-lg transition-colors cursor-pointer"
                            >
                              <MoreVertical className="w-4 h-4" />
                            </button>

                            {activeMenuId === inv.id && (
                              <div className="absolute right-6 top-10 w-44 bg-white rounded-xl shadow-xl border border-neutral-100 py-1.5 z-20 animate-in fade-in zoom-in-95 duration-100">
                                <button
                                  onClick={() => {
                                    setActiveMenuId(null);
                                    onNavigate(`/invoice/${inv.id}`);
                                  }}
                                  className="w-full text-left px-3.5 py-2 text-xs font-medium text-neutral-700 hover:bg-neutral-50 flex items-center gap-2"
                                >
                                  <Eye className="w-3.5 h-3.5 text-neutral-400" />
                                  <span>Voir facture</span>
                                </button>

                                {!inv.isPaid && (
                                  <button
                                    onClick={() => {
                                      setActiveMenuId(null);
                                      handleMarkAsPaid(inv);
                                    }}
                                    className="w-full text-left px-3.5 py-2 text-xs font-medium text-[#00C48C] hover:bg-emerald-50 flex items-center gap-2"
                                  >
                                    <CheckCircle2 className="w-3.5 h-3.5" />
                                    <span>Marquer Payé ✓</span>
                                  </button>
                                )}

                                <div className="border-t border-neutral-100 my-1" />

                                <button
                                  onClick={() => handleDelete(inv.id)}
                                  className="w-full text-left px-3.5 py-2 text-xs font-medium text-red-600 hover:bg-red-50 flex items-center gap-2"
                                >
                                  <Trash2 className="w-3.5 h-3.5 text-red-500" />
                                  <span>Supprimer</span>
                                </button>
                              </div>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};
