import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Check,
  Lock,
  Crown,
  Zap,
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  Clock,
  CheckCircle2,
  XCircle,
  RefreshCw,
  CreditCard,
  Smartphone,
  ChevronRight,
  HelpCircle,
  X,
  Loader2,
} from 'lucide-react';
import {
  PLANS_DATA,
  isSubscriptionActive,
  initiateSubscriptionCheckout,
  confirmSubscriptionPayment,
  fetchServerSubscriptionStatus,
  cancelSubscriptionOnServer,
} from '../lib/subscription';
import { getSubscription, saveSubscription, getCurrentUser, resetToFreePlan } from '../lib/storage';
import { SubscriptionPlan, SubscriptionStatus, Subscription } from '../types';
import { useToast } from '../components/common/Toast';
import { GreenGlowButton } from '../components/common/GreenGlowButton';

interface PricingPageProps {
  onPlanChanged?: () => void;
}

export const PricingPage: React.FC<PricingPageProps> = ({ onPlanChanged }) => {
  const { showToast } = useToast();
  const currentUser = getCurrentUser();
  const userId = currentUser?.id || 'default_user';

  const [subscription, setSubscription] = useState<Subscription>(() => getSubscription());
  const [selectedPlanForCheckout, setSelectedPlanForCheckout] = useState<SubscriptionPlan | null>(null);
  const [selectedProvider, setSelectedProvider] = useState<'wave' | 'orange_money' | 'card'>('wave');
  const [phoneNumber, setPhoneNumber] = useState(currentUser?.phone || '+221 77 000 00 00');
  const [isProcessingCheckout, setIsProcessingCheckout] = useState(false);
  const [pendingTransactionId, setPendingTransactionId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'checkout' | 'verify'>('checkout');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [simulatedOutcome, setSimulatedOutcome] = useState<'confirmed' | 'failed' | 'expired'>('confirmed');

  const currentPlan = subscription.plan || 'free';
  const currentStatus: SubscriptionStatus = subscription.status || (currentPlan === 'free' ? 'inactive' : 'inactive');
  const isActive = isSubscriptionActive(subscription);

  // Sync status on mount from backend
  useEffect(() => {
    refreshServerStatus();
  }, [userId]);

  const refreshServerStatus = async () => {
    setIsRefreshing(true);
    try {
      const serverSub = await fetchServerSubscriptionStatus(userId);
      setSubscription(serverSub);
      saveSubscription(serverSub);
    } catch {
      // fallback
    } finally {
      setIsRefreshing(false);
    }
  };

  const getStatusBadge = (status: SubscriptionStatus, plan: SubscriptionPlan) => {
    if (plan === 'free') {
      return (
        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-neutral-100 text-neutral-600 uppercase tracking-wider">
          Gratuit
        </span>
      );
    }

    switch (status) {
      case 'active':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-[#00C48C] uppercase tracking-wider flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            <span>Actif & Payé</span>
          </span>
        );
      case 'pending':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-100 text-amber-700 uppercase tracking-wider flex items-center gap-1">
            <Clock className="w-3 h-3 animate-spin" />
            <span>Paiement en attente</span>
          </span>
        );
      case 'expired':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-red-100 text-red-600 uppercase tracking-wider flex items-center gap-1">
            <AlertCircle className="w-3 h-3" />
            <span>Expiré</span>
          </span>
        );
      case 'payment_failed':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-rose-100 text-rose-700 uppercase tracking-wider flex items-center gap-1">
            <XCircle className="w-3 h-3" />
            <span>Paiement échoué</span>
          </span>
        );
      case 'cancelled':
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-neutral-200 text-neutral-700 uppercase tracking-wider">
            Annulé
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-neutral-100 text-neutral-600 uppercase tracking-wider">
            Inactif
          </span>
        );
    }
  };

  const handleOpenCheckout = (plan: SubscriptionPlan) => {
    if (plan === 'free') {
      // Revert to free
      const freeSub = resetToFreePlan();
      setSubscription(freeSub);
      showToast('Votre compte est repassé au forfait Gratuit.', 'info');
      if (onPlanChanged) onPlanChanged();
      return;
    }

    setSelectedPlanForCheckout(plan);
    setActiveTab('checkout');
    setPendingTransactionId(null);
  };

  const handleInitiatePayment = async () => {
    if (!selectedPlanForCheckout || selectedPlanForCheckout === 'free') return;

    setIsProcessingCheckout(true);
    try {
      const response = await initiateSubscriptionCheckout(userId, selectedPlanForCheckout, selectedProvider);

      if (response.success && response.subscription) {
        setPendingTransactionId(response.transactionId);
        setSubscription(response.subscription);
        saveSubscription(response.subscription);
        setActiveTab('verify');
        showToast(
          `Paiement initialisé (Réf: ${response.transactionId}). Statut : En attente.`,
          'info'
        );
      } else {
        showToast(response.error || 'Erreur lors de l\'initialisation', 'error');
      }
    } catch (err: any) {
      showToast('Erreur de connexion au serveur de paiement.', 'error');
    } finally {
      setIsProcessingCheckout(false);
    }
  };

  const handleConfirmPaymentBackend = async (outcome: 'confirmed' | 'failed' | 'expired') => {
    if (!pendingTransactionId && !subscription.lastPaymentId) {
      showToast('Aucune transaction en attente à confirmer.', 'error');
      return;
    }

    setIsProcessingCheckout(true);
    const txId = pendingTransactionId || subscription.lastPaymentId || `pay_${Date.now()}`;

    try {
      const response = await confirmSubscriptionPayment(userId, txId, outcome);

      if (response.success && response.subscription) {
        setSubscription(response.subscription);
        saveSubscription(response.subscription);

        if (outcome === 'confirmed') {
          showToast(`Paiement confirmé par le backend ! Plan ${response.subscription.plan.toUpperCase()} actif.`, 'success');
          setSelectedPlanForCheckout(null);
          if (onPlanChanged) onPlanChanged();
        } else if (outcome === 'expired') {
          showToast('Abonnement marqué comme expiré (date de fin dépassée).', 'info');
        }
      } else {
        // Payment failed case
        if (response.subscription) {
          setSubscription(response.subscription);
          saveSubscription(response.subscription);
        }
        showToast(response.error || 'Paiement refusé par le serveur de paiement.', 'error');
      }
    } catch (err: any) {
      showToast('Erreur lors de la confirmation.', 'error');
    } finally {
      setIsProcessingCheckout(false);
    }
  };

  const handleCancelSubscription = async () => {
    if (!window.confirm('Voulez-vous vraiment annuler votre abonnement payant ?')) return;

    setIsProcessingCheckout(true);
    try {
      const response = await cancelSubscriptionOnServer(userId);
      if (response.success && response.subscription) {
        setSubscription(response.subscription);
        saveSubscription(response.subscription);
        showToast('Abonnement annulé.', 'info');
        if (onPlanChanged) onPlanChanged();
      }
    } catch {
      showToast('Erreur lors de l\'annulation.', 'error');
    } finally {
      setIsProcessingCheckout(false);
    }
  };

  return (
    <div className="space-y-10 max-w-6xl mx-auto py-4 animate-in fade-in duration-300">
      {/* Title Header */}
      <div className="text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-orange-50 text-[#FF8A00] text-xs font-bold mb-3 border border-orange-100">
          <Zap className="w-3.5 h-3.5" />
          <span>Abonnements & Sécurité des Paiements</span>
        </div>
        <h1 className="text-2xl sm:text-4xl font-black text-[#111827] tracking-tight">
          Tarifs transparents & Gestion sécurisée
        </h1>
        <p className="text-sm sm:text-base text-neutral-500 mt-2 leading-relaxed">
          Déverrouillez les fonctionnalités professionnelles uniquement après confirmation vérifiée du paiement par le backend.
        </p>

        {/* Current Active Status Pill */}
        <div className="mt-4 inline-flex items-center gap-2.5 px-4 py-2 bg-white rounded-2xl border border-neutral-200/90 shadow-2xs text-xs">
          <span className="text-neutral-500">Statut de votre compte :</span>
          <span className="font-bold text-[#111827] capitalize">{currentPlan}</span>
          {getStatusBadge(currentStatus, currentPlan)}
          <button
            onClick={refreshServerStatus}
            disabled={isRefreshing}
            className="p-1 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 transition-colors cursor-pointer ml-1"
            title="Rafraîchir auprès du serveur"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-[#FF8A00]' : ''}`} />
          </button>
        </div>

        {subscription.endDate && (
          <div className="text-[11px] text-neutral-400 mt-1 font-mono">
            {isActive ? (
              <span>Valide jusqu'au {new Date(subscription.endDate).toLocaleDateString('fr-FR')}</span>
            ) : currentStatus === 'expired' ? (
              <span className="text-red-500 font-semibold">Expiré le {new Date(subscription.endDate).toLocaleDateString('fr-FR')}</span>
            ) : null}
          </div>
        )}
      </div>

      {/* 3 Pricing Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 items-stretch">
        {PLANS_DATA.map(plan => {
          const isCurrent = currentPlan === plan.id;
          const isPro = plan.id === 'pro';
          const isStandard = plan.id === 'standard';

          return (
            <motion.div
              key={plan.id}
              whileHover={{ y: -4 }}
              transition={{ duration: 0.2 }}
              className={`relative bg-white rounded-3xl p-6 sm:p-8 flex flex-col justify-between border transition-all ${
                isStandard
                  ? 'border-[#00C48C] shadow-lg ring-2 ring-[#00C48C]/20'
                  : 'border-neutral-200/90 shadow-sm'
              }`}
            >
              {/* Badge Popular */}
              {plan.isPopular && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3.5 py-1 rounded-full bg-[#00C48C] text-white text-[11px] font-bold uppercase tracking-wider shadow-sm flex items-center gap-1">
                  <Zap className="w-3 h-3 fill-current" />
                  <span>Recommandé commerçants</span>
                </div>
              )}

              <div>
                {/* Plan Name & Tagline */}
                <div className="flex items-center justify-between gap-2 mb-2">
                  <h3 className="text-xl font-bold text-[#111827]">
                    {plan.name}
                  </h3>
                  {isCurrent && getStatusBadge(currentStatus, currentPlan)}
                </div>

                <p className="text-xs text-neutral-500 min-h-[36px] leading-relaxed">
                  {plan.tagline}
                </p>

                {/* Price Display */}
                <div className="my-6 pb-6 border-b border-neutral-100">
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-3xl sm:text-4xl font-black text-[#111827] font-mono tabular-nums">
                      {plan.priceUSD}
                    </span>
                    <span className="text-xs text-neutral-400 font-medium">
                      {plan.period}
                    </span>
                  </div>
                  <div className="text-xs text-neutral-400 mt-1">
                    Soit <span className="font-semibold text-neutral-700">{plan.priceFCFA}</span> facturés en monnaie locale
                  </div>
                </div>

                {/* Features List */}
                <ul className="space-y-3 mb-8 text-xs">
                  {plan.features.map((feat, idx) => (
                    <li key={idx} className="flex items-start gap-2.5">
                      {feat.included ? (
                        <div className="w-4 h-4 rounded-full bg-emerald-100 text-[#00C48C] flex items-center justify-center shrink-0 mt-0.5">
                          <Check className="w-2.5 h-2.5 stroke-[3]" />
                        </div>
                      ) : (
                        <div className="w-4 h-4 rounded-full bg-neutral-100 text-neutral-400 flex items-center justify-center shrink-0 mt-0.5">
                          <Lock className="w-2.5 h-2.5" />
                        </div>
                      )}

                      <div className="flex-1">
                        <span
                          className={
                            feat.included
                              ? 'text-neutral-800 font-medium'
                              : 'text-neutral-400'
                          }
                        >
                          {feat.text}
                        </span>
                        {feat.lockNote && (
                          <span className="block text-[10px] text-neutral-400 italic mt-0.5">
                            {feat.lockNote}
                          </span>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action Button */}
              <div className="pt-2">
                {isCurrent && isActive ? (
                  <div className="space-y-2">
                    <button
                      disabled
                      className="w-full py-3 px-4 rounded-xl text-xs font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 cursor-default flex items-center justify-center gap-1.5"
                    >
                      <CheckCircle2 className="w-4 h-4 text-[#00C48C]" />
                      <span>Votre forfait actuel est actif</span>
                    </button>
                    {plan.id !== 'free' && (
                      <button
                        onClick={handleCancelSubscription}
                        className="w-full py-1.5 text-[11px] text-neutral-400 hover:text-red-500 transition-colors cursor-pointer text-center"
                      >
                        Résilier l'abonnement
                      </button>
                    )}
                  </div>
                ) : (
                  <GreenGlowButton
                    fullWidth
                    size="md"
                    onClick={() => handleOpenCheckout(plan.id)}
                  >
                    <span>
                      {plan.id === 'free'
                        ? 'Repasser au Gratuit'
                        : `Souscrire à ${plan.name} (${plan.priceUSD})`}
                    </span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </GreenGlowButton>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* MODAL DE PAIEMENT SÉCURISÉ & VÉRIFICATION BACKEND */}
      <AnimatePresence>
        {selectedPlanForCheckout && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedPlanForCheckout(null)}
              className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.94, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, y: 15 }}
              className="relative w-full max-w-lg bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-neutral-100 z-10 space-y-6"
            >
              <button
                onClick={() => setSelectedPlanForCheckout(null)}
                className="absolute top-5 right-5 p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-black uppercase tracking-wider text-[#00C48C] bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-100">
                    Passerelle Sécurisée
                  </span>
                  <span className="text-xs text-neutral-400">Paiement vérifié serveur</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-black text-[#111827]">
                  Souscription au Forfait {selectedPlanForCheckout.toUpperCase()}
                </h3>
                <p className="text-xs text-neutral-500 mt-1">
                  Montant exact :{' '}
                  <strong className="text-neutral-900">
                    {selectedPlanForCheckout === 'standard' ? '5 USD (3 000 FCFA)' : '12 USD (7 500 FCFA)'}
                  </strong>{' '}
                  par mois.
                </p>
              </div>

              {activeTab === 'checkout' ? (
                /* ÉTAPE 1 : CHOIX DU MOYEN DE PAIEMENT */
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-2">
                      Moyen de règlement
                    </label>
                    <div className="grid grid-cols-3 gap-2.5">
                      {[
                        { id: 'wave', label: 'Wave', note: 'Sénégal & CIV', color: 'bg-sky-50 border-sky-200 text-sky-800' },
                        { id: 'orange_money', label: 'Orange Money', note: 'Afrique de l\'Ouest', color: 'bg-orange-50 border-orange-200 text-orange-800' },
                        { id: 'card', label: 'Carte Bancaire', note: 'Visa / Mastercard', color: 'bg-purple-50 border-purple-200 text-purple-800' },
                      ].map(prov => (
                        <button
                          key={prov.id}
                          type="button"
                          onClick={() => setSelectedProvider(prov.id as any)}
                          className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                            selectedProvider === prov.id
                              ? `${prov.color} ring-2 ring-emerald-500/30 font-bold border-emerald-400`
                              : 'bg-white border-neutral-200 hover:border-neutral-300 text-neutral-700'
                          }`}
                        >
                          <div className="text-xs font-bold">{prov.label}</div>
                          <div className="text-[10px] text-neutral-400 mt-0.5">{prov.note}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-700 uppercase tracking-wider mb-1.5">
                      Numéro de téléphone ou identifiant débiteur
                    </label>
                    <input
                      type="text"
                      value={phoneNumber}
                      onChange={e => setPhoneNumber(e.target.value)}
                      className="w-full text-xs px-3.5 py-2.5 rounded-xl border border-neutral-200 bg-neutral-50 font-mono text-neutral-900 focus:outline-none focus:ring-2 focus:ring-[#00C48C]/30"
                    />
                  </div>

                  <div className="p-3 rounded-2xl bg-amber-50/80 border border-amber-200 text-xs text-amber-900 space-y-1">
                    <div className="font-bold flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>Règle de sécurité PAYPER :</span>
                    </div>
                    <p className="text-[11px] leading-relaxed text-amber-800">
                      Le statut reste « en attente » (pending) jusqu'à ce que le backend valide la réception des fonds. Le simple clic ne déverrouille rien sans confirmation fiable.
                    </p>
                  </div>

                  <div className="pt-2">
                    <GreenGlowButton
                      fullWidth
                      size="md"
                      loading={isProcessingCheckout}
                      loadingText="Initialisation du paiement..."
                      onClick={handleInitiatePayment}
                    >
                      <span>Initier le paiement sécurisé</span>
                      <ArrowRight className="w-4 h-4" />
                    </GreenGlowButton>
                  </div>
                </div>
              ) : (
                /* ÉTAPE 2 : EN ATTENTE & VÉRIFICATION PAR LE BACKEND */
                <div className="space-y-4">
                  <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-center space-y-2">
                    <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mx-auto">
                      <Clock className="w-5 h-5 animate-spin" />
                    </div>
                    <div className="text-sm font-bold text-amber-900">
                      Transaction #{pendingTransactionId || subscription.lastPaymentId}
                    </div>
                    <p className="text-xs text-amber-800 max-w-xs mx-auto">
                      Statut actuel : <strong className="uppercase">En attente (Pending)</strong>.
                      Le webhook ou le serveur de paiement doit certifier la réception pour activer le forfait.
                    </p>
                  </div>

                  {/* Contrôleur de test / simulation pour les 9 scénarios de test */}
                  <div className="border border-neutral-200 rounded-2xl p-3.5 bg-neutral-50 space-y-2.5">
                    <div className="text-xs font-bold text-neutral-800 flex items-center justify-between">
                      <span>Console de validation du serveur :</span>
                      <span className="text-[10px] text-neutral-400 font-mono">Simulateur Backend</span>
                    </div>
                    <p className="text-[11px] text-neutral-500">
                      Permet de tester tous les états réels exigés (Paiement confirmé, en attente, échoué, expiré) :
                    </p>
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        type="button"
                        onClick={() => handleConfirmPaymentBackend('confirmed')}
                        disabled={isProcessingCheckout}
                        className="py-2 px-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1 shadow-xs"
                      >
                        {isProcessingCheckout ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                        <span>Confirmer</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleConfirmPaymentBackend('failed')}
                        disabled={isProcessingCheckout}
                        className="py-2 px-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1 shadow-xs"
                      >
                        {isProcessingCheckout ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <XCircle className="w-3.5 h-3.5" />}
                        <span>Échec</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleConfirmPaymentBackend('expired')}
                        disabled={isProcessingCheckout}
                        className="py-2 px-2.5 rounded-xl bg-neutral-700 hover:bg-neutral-800 text-white text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1 shadow-xs"
                      >
                        {isProcessingCheckout ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <AlertCircle className="w-3.5 h-3.5" />}
                        <span>Expirer</span>
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2">
                    <button
                      type="button"
                      onClick={() => setActiveTab('checkout')}
                      className="text-xs font-semibold text-neutral-500 hover:text-neutral-800 cursor-pointer"
                    >
                      ← Revenir au choix du moyen
                    </button>

                    <button
                      type="button"
                      onClick={() => setSelectedPlanForCheckout(null)}
                      className="text-xs font-semibold text-neutral-500 hover:text-neutral-800 cursor-pointer"
                    >
                      Fermer
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Assurance des paiements locaux & Documentation des prestataires */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-neutral-200/90 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-neutral-100">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-[#00C48C] flex items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-[#111827]">
                Architecture de Sécurité des Abonnements Payants
              </h4>
              <p className="text-xs text-neutral-500 mt-0.5">
                Vérification stricte côté serveur avec signature HMAC anti-falsification.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs font-semibold text-neutral-700 bg-neutral-50 px-3.5 py-2 rounded-xl border border-neutral-200">
            <span>Devises prises en charge :</span>
            <span className="font-mono text-neutral-900 font-bold">USD · FCFA · CDF · GNF</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-neutral-600">
          <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200/80 space-y-2">
            <div className="font-bold text-neutral-900 flex items-center gap-1.5">
              <span className="text-[#00C48C]">●</span>
              <span>Prestataires Prévus dans l'Architecture</span>
            </div>
            <ul className="space-y-1 text-neutral-600 text-[11px] list-disc list-inside">
              <li><strong>Wave Checkout API</strong> : Portefeuille Mobile Money Afrique de l'Ouest</li>
              <li><strong>Orange Money Web Payment</strong> : Paiement mobile sécurisé avec OTP</li>
              <li><strong>Paystack / Flutterwave</strong> : Cartes Visa/Mastercard & Mobile Money Panafricain</li>
            </ul>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200/80 space-y-2">
            <div className="font-bold text-neutral-900 flex items-center gap-1.5">
              <span className="text-[#FF8A00]">●</span>
              <span>Intégration Réelle en Production</span>
            </div>
            <p className="text-[11px] leading-relaxed text-neutral-600">
              Aucune clé secrète n'est exposée dans le frontend. Pour activer les encaissements bancaires en direct, il suffit de renseigner les clés secrètes API côté serveur (variables <code>WAVE_API_KEY</code>, <code>PAYSTACK_SECRET_KEY</code>) sur le backend.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
