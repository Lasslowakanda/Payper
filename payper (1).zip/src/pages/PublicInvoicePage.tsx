import React, { useState } from 'react';
import { Download, Share2, Plus, ArrowRight } from 'lucide-react';
import { Invoice } from '../types';
import { decodePublicInvoiceUrl } from '../lib/share';
import { generateInvoiceImage } from '../lib/invoice';
import { InvoiceCardA4 } from '../components/invoices/InvoiceCardA4';
import { PayperLogo } from '../components/common/PayperLogo';
import { useToast } from '../components/common/Toast';
import { PayperLoader } from '../components/payper-loader';

interface PublicInvoicePageProps {
  onGoToOnboarding: () => void;
}

export const PublicInvoicePage: React.FC<PublicInvoicePageProps> = ({
  onGoToOnboarding,
}) => {
  const { showToast } = useToast();
  const [invoice] = useState<Invoice | null>(() => decodePublicInvoiceUrl());
  const [isGenerating, setIsGenerating] = useState(false);

  const handleDownload = async () => {
    if (!invoice) return;

    setIsGenerating(true);
    try {
      const clientClean = invoice.clientName.replace(/[^a-zA-Z0-9]/g, '_');
      const filename = `Facture-${invoice.id}-${clientClean}.png`;

      await generateInvoiceImage('facture-a-capturer', filename, invoice);
      showToast('Facture téléchargée sur votre appareil !', 'success');
    } catch (e) {
      console.error(e);
      showToast('Erreur lors du téléchargement de l’image.', 'error');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleShare = async () => {
    if (!invoice) return;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Facture ${invoice.id} - ${invoice.boutiqueName}`,
          text: `Facture de ${invoice.boutiqueName} pour ${invoice.clientName}`,
          url: window.location.href,
        });
      } catch {
        // cancelled
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      showToast('Lien de la facture copié !', 'success');
    }
  };

  if (!invoice) {
    return (
      <div className="min-h-screen bg-[#FAFAFA] flex flex-col items-center justify-center p-6 text-center">
        <PayperLogo size="lg" className="mb-4" />
        <h2 className="text-xl font-bold text-neutral-800">Facture introuvable ou lien expiré</h2>
        <p className="text-sm text-neutral-500 max-w-sm mt-1 mb-6">
          Les informations de cette facture publique n'ont pas pu être chargées.
        </p>
        <button
          onClick={onGoToOnboarding}
          className="py-2.5 px-5 rounded-xl text-xs font-semibold text-white bg-[#FF8A00] flex items-center gap-2"
        >
          <span>Créer ma boutique sur Payper</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FAFAFA] text-[#111827] flex flex-col">
      {/* Top Banner: Facture générée par Payper + CTA Crée ta boutique gratuitement */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-neutral-200 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <PayperLogo size="sm" />
          <span className="hidden sm:inline text-xs text-neutral-400 font-medium">
            Facture certifiée en lecture seule
          </span>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={onGoToOnboarding}
            className="flex items-center gap-1.5 py-1.5 px-3.5 rounded-xl text-xs font-semibold text-white bg-[#FF8A00] hover:bg-[#e67c00] transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Crée ta boutique gratuitement</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-4xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* Quick action bar */}
        <div className="flex items-center justify-between bg-white rounded-2xl p-4 border border-neutral-200 shadow-xs">
          <div>
            <h1 className="text-sm font-bold text-[#111827]">
              Facture de {invoice.boutiqueName}
            </h1>
            <p className="text-xs text-neutral-500">
              Émise le {new Date(invoice.date).toLocaleDateString('fr-FR')} pour {invoice.clientName}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownload}
              disabled={isGenerating}
              className="inline-flex items-center justify-center gap-1.5 py-2 px-3.5 rounded-xl text-xs font-bold text-neutral-800 bg-neutral-100 hover:bg-neutral-200 transition-colors cursor-pointer min-w-[160px]"
            >
              {isGenerating ? (
                <PayperLoader
                  variant="download"
                  size="sm"
                  inline={true}
                  text="Génération..."
                />
              ) : (
                <>
                  <Download className="w-3.5 h-3.5 text-neutral-600" />
                  <span>Télécharger l'image</span>
                </>
              )}
            </button>

            <button
              onClick={handleShare}
              className="inline-flex items-center gap-1.5 py-2 px-3 rounded-xl text-xs font-semibold text-neutral-700 bg-white border border-neutral-200 hover:bg-neutral-50 transition-colors cursor-pointer"
              title="Partager cette facture"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Partager</span>
            </button>
          </div>
        </div>

        {/* The Invoice A4 presentation */}
        <InvoiceCardA4 invoice={invoice} showPayperWatermark={true} />

        {/* Bottom invitation */}
        <div className="bg-gradient-to-r from-orange-50 to-emerald-50 rounded-2xl p-6 border border-orange-100 text-center space-y-3">
          <PayperLogo size="md" className="mx-auto" />
          <h3 className="text-base font-bold text-neutral-900">
            Tu vends des produits ou services en Afrique ?
          </h3>
          <p className="text-xs text-neutral-600 max-w-md mx-auto">
            Rejoins les entrepreneurs qui utilisent Payper pour envoyer des factures nettes en images sur WhatsApp et se faire payer plus vite.
          </p>
          <div>
            <button
              onClick={onGoToOnboarding}
              className="inline-flex items-center gap-2 py-2.5 px-6 rounded-xl text-xs font-bold text-white bg-[#FF8A00] hover:bg-[#e67c00] shadow-md shadow-orange-500/20"
            >
              <span>Créer ma boutique gratuitement →</span>
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};
