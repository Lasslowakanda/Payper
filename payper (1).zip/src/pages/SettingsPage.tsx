import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Store,
  Crown,
  UploadCloud,
  CheckCircle2,
  Save,
  Download,
  Trash2,
  RefreshCw,
  ExternalLink,
  Play,
  LogOut,
  User,
  Layers,
  Database,
  Palette,
} from 'lucide-react';
import { GreenGlowButton } from '../components/common/GreenGlowButton';
import {
  getBoutique,
  saveBoutique,
  getSubscription,
  getInvoices,
  getBoutiques,
  getUserAccount,
} from '../lib/storage';
import {
  isSupabaseConnected,
  getSupabaseConfig,
  syncAllDataWithSupabase,
} from '../lib/supabase';
import { checkPlanLimits } from '../lib/subscription';
import { CURRENCIES } from '../lib/invoice';
import { Boutique, Currency } from '../types';
import { useToast } from '../components/common/Toast';
import { PayperLoader } from '../components/payper-loader';
import { LogoutModal } from '../components/common/LogoutModal';

interface SettingsPageProps {
  onNavigate: (path: string) => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ onNavigate }) => {
  const { showToast } = useToast();
  const [boutique, setBoutique] = useState<Boutique>(() => getBoutique() || {
    name: 'Ma Boutique',
    devise: 'FCFA',
    city: 'Dakar, Sénégal',
  });

  const [name, setName] = useState(boutique.name);
  const [devise, setDevise] = useState<Currency>(boutique.devise);
  const [city, setCity] = useState(boutique.city || 'Dakar, Sénégal');
  const [logo, setLogo] = useState<string | undefined>(boutique.logo);
  const [isDragging, setIsDragging] = useState(false);
  const [isLogoutOpen, setIsLogoutOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  const boutiques = getBoutiques();
  const user = getUserAccount();
  const subscription = getSubscription();
  const usageStatus = checkPlanLimits();
  const supabaseConfig = getSupabaseConfig();

  const handleSyncCloud = async () => {
    setIsSyncing(true);
    try {
      const res = await syncAllDataWithSupabase();
      if (res.success) {
        showToast(res.message, 'success');
      } else {
        showToast(res.message, 'error');
      }
    } catch {
      showToast('Erreur lors de la synchronisation avec Supabase.', 'error');
    } finally {
      setIsSyncing(false);
    }
  };

  useEffect(() => {
    const handleBoutiqueChange = () => {
      const active = getBoutique();
      if (active) {
        setBoutique(active);
        setName(active.name);
        setDevise(active.devise);
        setCity(active.city || '');
        setLogo(active.logo);
      }
    };
    window.addEventListener('payper_boutique_updated', handleBoutiqueChange);
    return () => window.removeEventListener('payper_boutique_updated', handleBoutiqueChange);
  }, []);

  const handleImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      showToast('Fichier image invalide.', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = e => {
      if (typeof e.target?.result === 'string') {
        setLogo(e.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveBoutique = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      showToast('Le nom de la boutique est obligatoire.', 'error');
      return;
    }

    const updated: Boutique = {
      ...boutique,
      name: name.trim(),
      devise,
      city: city.trim(),
      logo,
    };

    saveBoutique(updated);
    setBoutique(updated);
    showToast('Paramètres de la boutique enregistrés !', 'success');
  };

  const handleExportData = () => {
    try {
      const data = {
        boutique: getBoutique(),
        invoices: getInvoices(),
        subscription: getSubscription(),
        exportedAt: new Date().toISOString(),
      };
      const json = JSON.stringify(data, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `payper_sauvegarde_${new Date().toISOString().slice(0, 10)}.json`;
      link.click();
      URL.revokeObjectURL(url);
      showToast('Sauvegarde exportée avec succès !', 'success');
    } catch {
      showToast('Erreur lors de l’export.', 'error');
    }
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto py-2 animate-in fade-in duration-300">
      {/* Title */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-[#111827] tracking-tight">
          Paramètres
        </h1>
        <p className="text-sm text-neutral-500 mt-1">
          Gère l'identité de ta boutique, ta devise par défaut et ton abonnement.
        </p>
      </div>

      {/* Section 1: Boutique Profile */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-neutral-100 shadow-sm">
        {/* Active Boutique indicator banner */}
        <div className="mb-6 p-4 rounded-xl bg-orange-50/60 border border-orange-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="text-xl">🏪</span>
            <div>
              <div className="text-xs text-neutral-500">Boutique actuellement active</div>
              <div className="text-sm font-bold text-[#111827]">{boutique.name}</div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('/boutiques')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-[#FF8A00] bg-white border border-orange-200 hover:bg-orange-50 transition-colors cursor-pointer self-start sm:self-auto"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Gérer toutes mes boutiques ({boutiques.length})</span>
          </button>
        </div>

        <div className="flex items-center gap-3 pb-6 border-b border-neutral-100">
          <div className="w-10 h-10 rounded-xl bg-orange-50 text-[#FF8A00] flex items-center justify-center">
            <Store className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-[#111827]">
              Informations de la boutique
            </h2>
            <p className="text-xs text-neutral-500">
              Ces informations apparaîtront sur toutes les factures générées pour cette boutique.
            </p>
          </div>
        </div>

        <form onSubmit={handleSaveBoutique} className="space-y-5 mt-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                Nom de la boutique *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3.5 py-2.5 text-sm text-neutral-900 focus:outline-none focus:ring-2 focus:ring-[#FF8A00]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                Ville / Pays
              </label>
              <input
                type="text"
                value={city}
                onChange={e => setCity(e.target.value)}
                placeholder="Ex: Dakar, Sénégal"
                className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3.5 py-2.5 text-sm text-neutral-900 focus:outline-none focus:ring-2 focus:ring-[#FF8A00]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 items-center">
            <div>
              <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                Devise par défaut
              </label>
              <select
                value={devise}
                onChange={e => setDevise(e.target.value as Currency)}
                className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3.5 py-2.5 text-sm font-medium text-neutral-900 focus:outline-none focus:ring-2 focus:ring-[#FF8A00]"
              >
                {CURRENCIES.map(curr => (
                  <option key={curr.code} value={curr.code}>
                    {curr.flag} {curr.code} - {curr.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Logo update */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                Logo de la boutique
              </label>
              <div className="flex items-center gap-3">
                {logo ? (
                  <img
                    src={logo}
                    alt="Logo"
                    className="w-12 h-12 rounded-xl object-cover border border-neutral-200"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-xl bg-orange-50 border border-orange-100 flex items-center justify-center font-bold text-xs text-[#FF8A00]">
                    Logo
                  </div>
                )}
                <label className="cursor-pointer px-3 py-2 rounded-xl text-xs font-semibold bg-neutral-100 hover:bg-neutral-200 text-neutral-700 transition-colors">
                  <span>Remplacer logo</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={e => e.target.files?.[0] && handleImageFile(e.target.files[0])}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          </div>

          <div className="pt-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <button
              type="button"
              onClick={() => onNavigate('/customization')}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#00C48C] hover:text-[#00ad7a] transition-colors cursor-pointer"
            >
              <Palette className="w-4 h-4" />
              <span>Personnaliser les modèles, couleurs & reçus (Offre Standard 5 USD) →</span>
            </button>

            <GreenGlowButton
              type="submit"
              size="md"
              className="w-full sm:w-auto"
            >
              <Save className="w-4 h-4" />
              <span>Enregistrer les modifications</span>
            </GreenGlowButton>
          </div>
        </form>
      </div>

      {/* Section 2: Subscription & Limits */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-neutral-100 shadow-sm">
        <div className="flex items-center justify-between pb-6 border-b border-neutral-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <Crown className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#111827]">
                Mon abonnement Payper
              </h2>
              <p className="text-xs text-neutral-500">
                Gère ton forfait et surveille tes quotas mensuels.
              </p>
            </div>
          </div>

          <span className="px-3 py-1 rounded-full text-xs font-extrabold uppercase tracking-wider bg-orange-50 text-[#FF8A00] border border-orange-200">
            {subscription.plan.toUpperCase()}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-6">
          <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-100">
            <span className="text-xs text-neutral-500 font-medium">Factures ce mois :</span>
            <div className="text-xl font-black text-neutral-900 font-mono mt-1">
              {usageStatus.invoicesThisMonth} /{' '}
              {usageStatus.invoicesLimit === 'unlimited' ? 'Illimitées' : usageStatus.invoicesLimit}
            </div>
          </div>

          <div className="bg-neutral-50 p-4 rounded-xl border border-neutral-100">
            <span className="text-xs text-neutral-500 font-medium">Clients gérés :</span>
            <div className="text-xl font-black text-neutral-900 font-mono mt-1">
              {usageStatus.clientsCount} /{' '}
              {usageStatus.clientsLimit === 'unlimited' ? 'Illimités' : usageStatus.clientsLimit}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2">
          <div className="text-xs text-neutral-500">
            Besoin de factures illimitées et de factures HD ?
          </div>
          <button
            onClick={() => onNavigate('/pricing')}
            className="py-2.5 px-4 rounded-xl text-xs font-semibold text-neutral-800 bg-neutral-100 hover:bg-neutral-200 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <span>Voir les abonnements & changer de plan</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Section 3: Data Safety */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-neutral-100 shadow-sm">
        <h2 className="text-base font-bold text-[#111827] mb-1">
          Sauvegarde & Données locales
        </h2>
        <p className="text-xs text-neutral-500 mb-6">
          Vos factures sont conservées en toute sécurité dans votre navigateur local. Vous pouvez télécharger une sauvegarde JSON à tout moment.
        </p>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={handleExportData}
            className="inline-flex items-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Exporter mes factures (JSON)</span>
          </button>

          <button
            onClick={() => {
              sessionStorage.removeItem('payper_splash_seen');
              window.location.reload();
            }}
            className="inline-flex items-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold text-[#FF8A00] bg-orange-50 hover:bg-orange-100 transition-colors cursor-pointer border border-orange-200"
          >
            <Play className="w-4 h-4" />
            <span>Revoir le Splash Screen Payper (4s)</span>
          </button>
        </div>
      </div>

      {/* Section 3b: Cloud Database & Supabase Synchronization */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-neutral-100 shadow-sm">
        <div className="flex items-center justify-between pb-4 border-b border-neutral-100 mb-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
              <Database className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-[#111827]">
                  Connexion Base de Données Cloud Supabase
                </h2>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Connecté
                </span>
              </div>
              <p className="text-xs text-neutral-500">
                Vos comptes, boutiques, factures et clients sont synchronisés avec votre projet Supabase.
              </p>
            </div>
          </div>

          <button
            onClick={handleSyncCloud}
            disabled={isSyncing}
            className="inline-flex items-center gap-2 py-2.5 px-4 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 transition-colors cursor-pointer shadow-sm"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? 'Synchronisation...' : 'Synchroniser maintenant'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs mb-4">
          <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-100">
            <span className="text-neutral-400 block font-semibold mb-0.5">Instance Supabase</span>
            <span className="text-xs font-mono font-bold text-neutral-800 break-all">
              {supabaseConfig.url}
            </span>
          </div>

          <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-100">
            <span className="text-neutral-400 block font-semibold mb-0.5">Architecture</span>
            <span className="text-xs font-bold text-neutral-800">
              Offline-First + Synchronisation Cloud temps réel
            </span>
          </div>
        </div>

        <div className="rounded-xl bg-neutral-50 p-3.5 border border-neutral-100">
          <span className="text-xs font-bold text-neutral-700 block mb-2">Tables actives synchronisées :</span>
          <div className="flex flex-wrap gap-2 text-[11px]">
            <span className="px-2.5 py-1 rounded-lg bg-white border border-neutral-200 text-neutral-700 font-medium">
              👤 <strong className="text-neutral-900">profiles</strong> (Comptes utilisateurs & PIN sécurisé)
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-white border border-neutral-200 text-neutral-700 font-medium">
              🏬 <strong className="text-neutral-900">boutiques</strong> (Multi-boutiques & Devises)
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-white border border-neutral-200 text-neutral-700 font-medium">
              👥 <strong className="text-neutral-900">clients</strong> (Annuaire clients par boutique)
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-white border border-neutral-200 text-neutral-700 font-medium">
              🧾 <strong className="text-neutral-900">invoices</strong> (Factures & Articles)
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-white border border-neutral-200 text-neutral-700 font-medium">
              📦 <strong className="text-neutral-900">products</strong> (Catalogue produits & Stock)
            </span>
          </div>
        </div>
      </div>

      {/* Section 4: User Account & Independent Déconnexion */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-neutral-100 shadow-sm">
        <div className="flex items-center justify-between pb-6 border-b border-neutral-100 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-neutral-100 text-neutral-700 flex items-center justify-center">
              <User className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#111827]">
                Compte Utilisateur PAYPER
              </h2>
              <p className="text-xs text-neutral-500">
                Votre compte centralise l’accès à toutes vos boutiques ({boutiques.length}).
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsLogoutOpen(true)}
            className="flex items-center gap-1.5 py-2 px-3.5 rounded-xl text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-100 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Déconnexion</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-100">
            <span className="text-neutral-400 block font-semibold mb-0.5">Utilisateur</span>
            <span className="text-sm font-bold text-[#111827]">{user.name}</span>
          </div>

          <div className="p-3.5 rounded-xl bg-neutral-50 border border-neutral-100">
            <span className="text-neutral-400 block font-semibold mb-0.5">Identifiant</span>
            <span className="text-sm font-bold text-[#111827]">
              {user.phone || user.email || 'Non renseigné'}
            </span>
          </div>
        </div>

        <div className="mt-4 p-3.5 rounded-xl bg-blue-50/60 border border-blue-100 text-xs text-blue-800 leading-relaxed">
          <strong>Déconnexion indépendante :</strong> La déconnexion déconnecte votre compte
          utilisateur PAYPER sans supprimer aucune de vos boutiques ni leurs factures.
        </div>
      </div>

      {/* Section 5: Payper Flow System Showcase */}
      <div className="bg-white rounded-2xl p-6 sm:p-8 border border-neutral-100 shadow-sm">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#FF8A00] to-[#00C48C] text-white flex items-center justify-center font-bold">
            P
          </div>
          <div>
            <h2 className="text-base font-bold text-[#111827]">
              Système de Chargement Propriétaire « Payper Flow »
            </h2>
            <p className="text-xs text-neutral-500">
              Identité visuelle unique : Facture → Traitement → Validation aux couleurs Orange #FF8A00 et Vert #00C48C.
            </p>
          </div>
        </div>

        {/* Preview of PAYPER Symbolic Loading Identity */}
        <p className="text-xs text-neutral-500 mb-2">
          Identité visuelle de chargement PAYPER basée sur des symboles animés :
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
          <div className="bg-neutral-50/70 p-3.5 rounded-xl border border-neutral-100 flex flex-col items-center text-center">
            <PayperLoader variant="orders" size="md" />
            <span className="text-[11px] font-bold text-neutral-700 mt-2">Commandes</span>
            <span className="text-[10px] text-neutral-400">Colis animé</span>
          </div>

          <div className="bg-neutral-50/70 p-3.5 rounded-xl border border-neutral-100 flex flex-col items-center text-center">
            <PayperLoader variant="products" size="md" />
            <span className="text-[11px] font-bold text-neutral-700 mt-2">Produits</span>
            <span className="text-[10px] text-neutral-400">Panier animé</span>
          </div>

          <div className="bg-neutral-50/70 p-3.5 rounded-xl border border-neutral-100 flex flex-col items-center text-center">
            <PayperLoader variant="payment" size="md" />
            <span className="text-[11px] font-bold text-neutral-700 mt-2">Paiements</span>
            <span className="text-[10px] text-neutral-400">Carte bancaire</span>
          </div>

          <div className="bg-neutral-50/70 p-3.5 rounded-xl border border-neutral-100 flex flex-col items-center text-center">
            <PayperLoader variant="transactions" size="md" />
            <span className="text-[11px] font-bold text-neutral-700 mt-2">Transactions</span>
            <span className="text-[10px] text-neutral-400">Monnaie animée</span>
          </div>

          <div className="bg-neutral-50/70 p-3.5 rounded-xl border border-neutral-100 flex flex-col items-center text-center">
            <PayperLoader variant="invoice" size="md" />
            <span className="text-[11px] font-bold text-neutral-700 mt-2">Factures</span>
            <span className="text-[10px] text-neutral-400">Document animé</span>
          </div>

          <div className="bg-neutral-50/70 p-3.5 rounded-xl border border-neutral-100 flex flex-col items-center text-center">
            <PayperLoader variant="clients" size="md" />
            <span className="text-[11px] font-bold text-neutral-700 mt-2">Clients</span>
            <span className="text-[10px] text-neutral-400">Groupe animé</span>
          </div>

          <div className="bg-neutral-50/70 p-3.5 rounded-xl border border-neutral-100 flex flex-col items-center text-center">
            <PayperLoader variant="analytics" size="md" />
            <span className="text-[11px] font-bold text-neutral-700 mt-2">Analytics</span>
            <span className="text-[10px] text-neutral-400">Graphique animé</span>
          </div>

          <div className="bg-neutral-50/70 p-3.5 rounded-xl border border-neutral-100 flex flex-col items-center text-center">
            <PayperLoader variant="notifications" size="md" />
            <span className="text-[11px] font-bold text-neutral-700 mt-2">Notifications</span>
            <span className="text-[10px] text-neutral-400">Cloche animée</span>
          </div>
        </div>
      </div>

      <LogoutModal
        isOpen={isLogoutOpen}
        onClose={() => setIsLogoutOpen(false)}
        onLogoutConfirmed={() => onNavigate('/welcome')}
      />
    </div>
  );
};
