import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  UploadCloud,
  CheckCircle2,
  Globe,
  MessageCircle,
  ArrowRight,
  ArrowLeft,
  Check,
  ShieldCheck,
  AlertCircle,
  MapPin,
  Flag,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { PayperLogo } from '../components/common/PayperLogo';
import { CURRENCIES } from '../lib/invoice';
import {
  SUPPORTED_COUNTRIES,
  getCountryByCode,
  getCountryByName,
  validatePhoneNumber,
} from '../lib/countries';
import { Currency, Boutique } from '../types';
import { saveBoutique, saveSubscription, getBoutique, getUserAccount } from '../lib/storage';
import { useToast } from '../components/common/Toast';
import { PayperLoader } from '../components/payper-loader';
import { GreenGlowButton } from '../components/common/GreenGlowButton';

interface WelcomePageProps {
  onComplete: () => void;
}

export const WelcomePage: React.FC<WelcomePageProps> = ({ onComplete }) => {
  const { showToast } = useToast();
  const currentUser = getUserAccount();

  // Find country matching the user's registered phone
  const matchedCountry =
    SUPPORTED_COUNTRIES.find(c => currentUser.phone?.startsWith(c.code)) ||
    SUPPORTED_COUNTRIES.find(c => c.country === 'Sénégal') ||
    SUPPORTED_COUNTRIES[0];

  const initialDigits = currentUser.phone
    ? currentUser.phone.replace(matchedCountry.code, '').replace(/\D/g, '')
    : '';

  // Current step: 1 (Informations principales) or 2 (Présence en ligne)
  const [currentStep, setCurrentStep] = useState<1 | 2>(1);

  // Step 1 States
  const [boutiqueName, setBoutiqueName] = useState('');
  const [logoPreview, setLogoPreview] = useState<string>('');
  const [selectedCountry, setSelectedCountry] = useState(matchedCountry.country);
  const [city, setCity] = useState(matchedCountry.defaultCity);
  const [devise, setDevise] = useState<Currency>(matchedCountry.currency);
  const [isDragging, setIsDragging] = useState(false);
  const [isAutoTransitioning, setIsAutoTransitioning] = useState(false);

  // Step 2 States
  const [website, setWebsite] = useState('');
  const [selectedCountryCode, setSelectedCountryCode] = useState(matchedCountry.code);
  const [whatsappDigits, setWhatsappDigits] = useState(initialDigits);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccessAnimated, setIsSuccessAnimated] = useState(false);

  // Validation state for phone
  const phoneValidation = validatePhoneNumber(selectedCountryCode, whatsappDigits);
  const activeCountry = getCountryByCode(selectedCountryCode);

  // Track if user interacted with city / last required field
  const hasInteractedWithLastField = useRef(false);
  const autoTransitionTimeout = useRef<NodeJS.Timeout | null>(null);

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (autoTransitionTimeout.current) {
        clearTimeout(autoTransitionTimeout.current);
      }
    };
  }, []);

  // Compute clean WhatsApp Link dynamically
  const cleanDigits = whatsappDigits.replace(/[^0-9]/g, '');
  const fullWhatsAppNumber = cleanDigits
    ? `${selectedCountryCode}${cleanDigits}`
    : '';

  const generatedWhatsAppLink = fullWhatsAppNumber && phoneValidation.isValid
    ? `https://wa.me/${fullWhatsAppNumber.replace(/[^0-9]/g, '')}`
    : '';

  const handleImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      showToast('Veuillez sélectionner un fichier image valide.', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = e => {
      if (typeof e.target?.result === 'string') {
        setLogoPreview(e.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleImageFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleImageFile(e.target.files[0]);
    }
  };

  /**
   * Country change handler on Step 1:
   * When country changes, code, default city, and currency automatically update!
   */
  const handleStep1CountryChange = (countryName: string) => {
    setSelectedCountry(countryName);
    const countryObj = getCountryByName(countryName);
    setSelectedCountryCode(countryObj.code);
    setCity(countryObj.defaultCity);
    setDevise(countryObj.currency);

    if (boutiqueName.trim().length >= 2) {
      triggerAutomaticTransitionIfReady(boutiqueName, countryObj.defaultCity, false);
    }
  };

  /**
   * Country code change handler on Step 2:
   * Synchronizes country and city if user changes it on step 2
   */
  const handleStep2CountryCodeChange = (code: string) => {
    setSelectedCountryCode(code);
    const countryObj = getCountryByCode(code);
    setSelectedCountry(countryObj.country);
    setCity(countryObj.defaultCity);
    setDevise(countryObj.currency);
  };

  /**
   * AUTOMATIC TRANSITION ENGINE (Page 1 -> Page 2)
   * Triggered when the last required field is filled and all required fields are valid.
   * NO "Continuer" button is displayed on Page 1.
   */
  const triggerAutomaticTransitionIfReady = (
    nameVal: string,
    cityVal: string,
    immediate = false
  ) => {
    const isNameValid = nameVal.trim().length >= 2;
    const isCityValid = cityVal.trim().length >= 2;

    if (isNameValid && isCityValid && !isAutoTransitioning && currentStep === 1) {
      if (autoTransitionTimeout.current) {
        clearTimeout(autoTransitionTimeout.current);
      }

      setIsAutoTransitioning(true);

      const delay = immediate ? 200 : 700;

      autoTransitionTimeout.current = setTimeout(() => {
        // 1. Save step 1 data into payper_boutique
        const existing: Partial<Boutique> = getBoutique() || {};
        const step1Boutique: Boutique = {
          name: nameVal.trim(),
          logo: logoPreview || existing.logo,
          devise: devise,
          country: selectedCountry,
          countryCode: selectedCountryCode,
          city: cityVal.trim(),
          createdAt: existing.createdAt || new Date().toISOString(),
          website: existing.website,
          phone: existing.phone,
          whatsappNumber: existing.whatsappNumber,
          whatsappLink: existing.whatsappLink,
        };
        saveBoutique(step1Boutique);

        // 2. Transition automatically to Page 2
        setCurrentStep(2);
        setIsAutoTransitioning(false);
      }, delay);
    }
  };

  // Step 1 field change handlers
  const handleCityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setCity(val);
    hasInteractedWithLastField.current = true;

    if (boutiqueName.trim().length >= 2 && val.trim().length >= 2) {
      triggerAutomaticTransitionIfReady(boutiqueName, val, false);
    }
  };

  const handleCityBlur = () => {
    if (boutiqueName.trim().length >= 2 && city.trim().length >= 2) {
      triggerAutomaticTransitionIfReady(boutiqueName, city, true);
    }
  };

  const handleBoutiqueNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setBoutiqueName(val);
    if (hasInteractedWithLastField.current && val.trim().length >= 2 && city.trim().length >= 2) {
      triggerAutomaticTransitionIfReady(val, city, false);
    }
  };

  /**
   * FINAL VALIDATION (Step 2 Submit)
   * The phone number MUST be valid for the chosen country.
   * If invalid, the user CANNOT create their boutique or access anything!
   */
  const handleFinalSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!phoneValidation.isValid) {
      showToast(
        phoneValidation.message ||
          `Veuillez saisir un numéro de téléphone valide pour ${activeCountry.country}.`,
        'error'
      );
      return;
    }

    setIsSubmitting(true);

    const existing: Partial<Boutique> = getBoutique() || {};
    const finalBoutique: Boutique = {
      id: existing.id || `btq_${Date.now()}`,
      userId: currentUser.id,
      name: boutiqueName.trim() || existing.name || 'Ma Boutique',
      logo: logoPreview || existing.logo,
      devise: devise || existing.devise || 'FCFA',
      country: selectedCountry,
      countryCode: selectedCountryCode,
      city: city.trim() || existing.city || `${activeCountry.defaultCity}, ${activeCountry.country}`,
      phone: fullWhatsAppNumber,
      website: website.trim() || undefined,
      whatsappNumber: fullWhatsAppNumber,
      whatsappLink: generatedWhatsAppLink || undefined,
      createdAt: existing.createdAt || new Date().toISOString(),
      isActive: true,
    };

    saveBoutique(finalBoutique);

    // Initial subscription setup
    saveSubscription({
      plan: 'free',
      status: 'inactive',
      startDate: new Date().toISOString(),
      invoicesThisMonth: 0,
    });

    setIsSuccessAnimated(true);

    // Trigger celebratory confetti
    try {
      confetti({
        particleCount: 90,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#FF8A00', '#00C48C', '#ffffff', '#FFD166'],
      });
    } catch {
      // silent
    }

    showToast('Boutique configurée avec succès ! Bienvenue sur Payper.', 'success');

    setIsSubmitting(false);
    window.location.hash = '/dashboard';
    onComplete();
  };

  /**
   * Action when clicking the fixed bottom CTA « Créer ma boutique »
   * Redirige DIRECTEMENT vers le tableau de bord (/dashboard)
   */
  const handleFixedCtaClick = () => {
    if (isSubmitting || isAutoTransitioning) return;

    if (currentStep === 1) {
      const finalName = boutiqueName.trim() || 'Ma Boutique';
      const finalCity = city.trim() || activeCountry.defaultCity;
      const phoneToUse = fullWhatsAppNumber || currentUser.phone || `${selectedCountryCode}770000000`;

      setIsSubmitting(true);

      const existing: Partial<Boutique> = getBoutique() || {};
      const newBoutique: Boutique = {
        id: existing.id || `btq_${Date.now()}`,
        userId: currentUser.id,
        name: finalName,
        logo: logoPreview || existing.logo,
        devise: devise || 'FCFA',
        country: selectedCountry,
        countryCode: selectedCountryCode,
        city: finalCity,
        phone: phoneToUse,
        whatsappNumber: phoneToUse,
        whatsappLink: `https://wa.me/${phoneToUse.replace(/[^0-9]/g, '')}`,
        createdAt: existing.createdAt || new Date().toISOString(),
        isActive: true,
      };

      saveBoutique(newBoutique);
      saveSubscription({
        plan: 'free',
        status: 'inactive',
        startDate: new Date().toISOString(),
        invoicesThisMonth: 0,
      });

      setIsSuccessAnimated(true);

      try {
        confetti({
          particleCount: 90,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#FF8A00', '#00C48C', '#ffffff', '#FFD166'],
        });
      } catch {}

      showToast(`Boutique « ${newBoutique.name} » créée ! Redirection vers votre tableau de bord...`, 'success');

      setIsSubmitting(false);
      window.location.hash = '/dashboard';
      onComplete();
      return;
    }

    // Step 2 final submit: check phone validation or fallback to user account phone
    const phoneToUse = fullWhatsAppNumber || currentUser.phone || `${selectedCountryCode}770000000`;
    setIsSubmitting(true);

    const existing: Partial<Boutique> = getBoutique() || {};
    const finalBoutique: Boutique = {
      id: existing.id || `btq_${Date.now()}`,
      userId: currentUser.id,
      name: boutiqueName.trim() || existing.name || 'Ma Boutique',
      logo: logoPreview || existing.logo,
      devise: devise || existing.devise || 'FCFA',
      country: selectedCountry,
      countryCode: selectedCountryCode,
      city: city.trim() || existing.city || `${activeCountry.defaultCity}, ${activeCountry.country}`,
      phone: phoneToUse,
      website: website.trim() || undefined,
      whatsappNumber: phoneToUse,
      whatsappLink: generatedWhatsAppLink || (phoneToUse ? `https://wa.me/${phoneToUse.replace(/[^0-9]/g, '')}` : undefined),
      createdAt: existing.createdAt || new Date().toISOString(),
      isActive: true,
    };

    saveBoutique(finalBoutique);
    saveSubscription({
      plan: 'free',
      status: 'inactive',
      startDate: new Date().toISOString(),
      invoicesThisMonth: 0,
    });

    setIsSuccessAnimated(true);

    try {
      confetti({
        particleCount: 90,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#FF8A00', '#00C48C', '#ffffff', '#FFD166'],
      });
    } catch {}

    showToast(`Boutique « ${finalBoutique.name} » configurée ! Redirection vers votre tableau de bord...`, 'success');

    setIsSubmitting(false);
    window.location.hash = '/dashboard';
    onComplete();
  };

  return (
    <div
      className="min-h-screen bg-[#FF8A00] flex flex-col items-center justify-center p-4 sm:p-6 antialiased relative"
      style={{ paddingBottom: 'calc(110px + env(safe-area-inset-bottom, 0px))' }}
    >
      {/* Halo d'ambiance lumineux */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-96 bg-gradient-to-b from-orange-400/40 via-orange-500/20 to-transparent blur-3xl pointer-events-none -z-10" />

      {/* Central Card 500px */}
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-[500px] bg-white rounded-2xl p-6 sm:p-9 shadow-xl border border-neutral-100 relative overflow-hidden mb-6"
      >
        {/* Barres vertes de progression (sans mention étape) */}
        <div className="mb-6">
          <div className="grid grid-cols-2 gap-2 mb-2">
            <div
              className={`h-2 rounded-full transition-all duration-300 ${
                currentStep >= 1 ? 'bg-[#00C48C] shadow-sm shadow-emerald-500/30' : 'bg-neutral-100'
              }`}
            />
            <div
              className={`h-2 rounded-full transition-all duration-300 ${
                currentStep >= 2 ? 'bg-[#00C48C] shadow-sm shadow-emerald-500/30' : 'bg-neutral-100'
              }`}
            />
          </div>
          <div className="flex items-center justify-between text-[11px] font-semibold text-neutral-500">
            <span>{currentStep === 1 ? 'Informations boutique' : 'Coordonnées & Contact'}</span>
            <span className="text-[#00C48C] font-bold">{currentStep === 1 ? '50%' : '100%'}</span>
          </div>
        </div>

        {/* Central Brand Logo */}
        <div className="flex flex-col items-center text-center mb-6">
          <PayperLogo size="lg" className="mb-4" />
        </div>

        <AnimatePresence mode="wait">
          {/* ================= PAGE 1 : INFORMATIONS PRINCIPALES ================= */}
          {currentStep === 1 && (
            <motion.div
              key="step-1"
              initial={{ opacity: 0, x: -18 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -24 }}
              transition={{ duration: 0.3, ease: 'easeInOut' }}
              className="space-y-4"
            >
              <div className="text-center mb-4">
                <h1 className="text-2xl sm:text-3xl font-extrabold text-[#111827] tracking-tight">
                  Crée ta boutique
                </h1>
                <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
                  Renseigne les informations de ta boutique pour générer des factures conformes.
                </p>
              </div>

              {/* Nom de la boutique (Obligatoire) */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-neutral-700 uppercase tracking-wider">
                    Nom de ta boutique *
                  </label>
                  {boutiqueName.trim().length >= 2 && (
                    <span className="text-[11px] font-medium text-[#00C48C] flex items-center gap-0.5">
                      <Check className="w-3 h-3 stroke-[3]" /> Prêt
                    </span>
                  )}
                </div>
                <input
                  type="text"
                  required
                  placeholder="Ex: Boutique Fatou ou Tech SARL"
                  value={boutiqueName}
                  onChange={handleBoutiqueNameChange}
                  className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-4 py-2.5 sm:py-3 text-sm text-neutral-900 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-all"
                />
              </div>

              {/* Logo de la boutique */}
              <div>
                <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                  Logo de ta boutique
                </label>

                {logoPreview ? (
                  <motion.div
                    initial={{ scale: 0.8, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="flex items-center gap-4 p-3 bg-neutral-50 border border-neutral-200 rounded-xl"
                  >
                    <div className="relative">
                      <img
                        src={logoPreview}
                        alt="Logo boutique"
                        className="w-14 h-14 rounded-full object-cover border-2 border-[#00C48C] shadow-sm"
                      />
                      <div className="absolute -top-1 -right-1 bg-white rounded-full p-0.5 shadow-xs">
                        <CheckCircle2 className="w-4 h-4 text-[#00C48C]" />
                      </div>
                    </div>

                    <div className="flex-1 text-left">
                      <div className="text-xs font-bold text-neutral-800">Logo sélectionné</div>
                      <div className="text-[11px] text-neutral-500">Visible sur toutes vos factures</div>
                      <label className="mt-1 inline-block text-xs font-semibold text-[#FF8A00] hover:underline cursor-pointer">
                        Changer l'image
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleFileChange}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </motion.div>
                ) : (
                  <label
                    onDragOver={e => {
                      e.preventDefault();
                      setIsDragging(true);
                    }}
                    onDragLeave={() => setIsDragging(false)}
                    onDrop={handleDrop}
                    className={`flex flex-col items-center justify-center p-3 sm:p-4 border-2 border-dashed rounded-xl cursor-pointer transition-colors ${
                      isDragging
                        ? 'border-[#FF8A00] bg-orange-50/40'
                        : 'border-neutral-200 hover:border-[#FF8A00] bg-neutral-50/50'
                    }`}
                  >
                    <UploadCloud className="w-5 h-5 text-neutral-400 mb-1" />
                    <span className="text-xs font-semibold text-neutral-700">
                      Clique ou glisse ton logo ici
                    </span>
                    <span className="text-[10px] text-neutral-400 mt-0.5">
                      PNG, JPG ou WEBP (recommandé carré)
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </label>
                )}
              </div>

              {/* Sélection du Pays (Change la ville & l'indicatif automatiquement) */}
              <div>
                <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                  Pays de la boutique *
                </label>
                <select
                  value={selectedCountry}
                  onChange={e => handleStep1CountryChange(e.target.value)}
                  className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-4 py-2.5 text-sm font-medium text-neutral-900 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-all cursor-pointer"
                >
                  {SUPPORTED_COUNTRIES.map(c => (
                    <option key={c.country} value={c.country}>
                      {c.flag} {c.country} ({c.code})
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-neutral-400 mt-1">
                  Met à jour l'indicatif téléphonique et la ville par défaut.
                </p>
              </div>

              {/* Ville (Pré-remplie automatiquement lors du choix du pays) */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-semibold text-neutral-700 uppercase tracking-wider">
                    Ville * (Dernier champ obligatoire)
                  </label>
                  {city.trim().length >= 2 && (
                    <span className="text-[11px] font-medium text-[#00C48C] flex items-center gap-0.5">
                      <Check className="w-3 h-3 stroke-[3]" /> Prêt
                    </span>
                  )}
                </div>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    required
                    placeholder="Ex: Dakar, Abidjan, Cotonou..."
                    value={city}
                    onChange={handleCityChange}
                    onBlur={handleCityBlur}
                    className="w-full bg-neutral-50 border border-neutral-200 rounded-xl pl-10 pr-4 py-2.5 text-sm text-neutral-900 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-all"
                  />
                </div>
              </div>

              {/* Devise principale */}
              <div>
                <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                  Devise principale
                </label>
                <select
                  value={devise}
                  onChange={e => setDevise(e.target.value as Currency)}
                  className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-4 py-2 text-sm font-medium text-neutral-900 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-all"
                >
                  {CURRENCIES.map(curr => (
                    <option key={curr.code} value={curr.code}>
                      {curr.flag} {curr.code} ({curr.label})
                    </option>
                  ))}
                </select>
              </div>

              {/* Zone de statut / transition automatique (AUCUN bouton continuer) */}
              <div className="pt-2">
                {isAutoTransitioning ? (
                  <motion.div
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center justify-center gap-2 text-xs font-medium"
                  >
                    <CheckCircle2 className="w-4 h-4 text-[#00C48C] shrink-0" />
                    <span>Informations validées ! Passage automatique à l'étape 2...</span>
                  </motion.div>
                ) : (
                  <div className="text-center p-2 text-xs text-neutral-400">
                    {boutiqueName.trim().length >= 2 && city.trim().length >= 2 ? (
                      <div>
                        <span className="text-[#00C48C] font-medium flex items-center justify-center gap-1">
                          <Check className="w-3.5 h-3.5 stroke-[3]" /> Informations prêtes pour créer votre boutique
                        </span>
                        <button
                          type="button"
                          onClick={() => setCurrentStep(2)}
                          className="mt-2 text-xs font-semibold text-[#FF8A00] hover:underline cursor-pointer flex items-center justify-center gap-1 mx-auto"
                        >
                          <span>Personnaliser WhatsApp & site web (Étape 2)</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <span>Remplis le nom et la ville, ou clique directement sur « Créer ma boutique » ci-dessous.</span>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {/* ================= PAGE 2 : PRÉSENCE EN LIGNE & TÉLÉPHONE ================= */}
          {currentStep === 2 && (
            <motion.div
              key="step-2"
              initial={{ opacity: 0, x: 24 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 24 }}
              transition={{ duration: 0.35, ease: 'easeInOut' }}
              className="space-y-4"
            >
              <div className="text-center mb-4">
                <button
                  type="button"
                  onClick={() => setCurrentStep(1)}
                  className="inline-flex items-center gap-1 text-[11px] font-semibold text-neutral-400 hover:text-neutral-700 transition-colors mb-2 cursor-pointer"
                >
                  <ArrowLeft className="w-3 h-3" />
                  <span>Modifier les informations de base</span>
                </button>

                <h1 className="text-xl sm:text-2xl font-extrabold text-[#111827] tracking-tight leading-snug">
                  Donnez à votre boutique une présence en ligne
                </h1>
                <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto leading-relaxed">
                  Ajoutez vos coordonnées pour permettre à vos clients de vous retrouver et de vous contacter facilement.
                </p>
              </div>

              <form onSubmit={handleFinalSubmit} className="space-y-4">
                {/* Numéro WhatsApp & Téléphone (OBLIGATOIRE et PRIORITAIRE, BIEN VISIBLE SUR MOBILE) */}
                <div className="bg-amber-50/40 sm:bg-transparent p-3 sm:p-0 rounded-2xl border sm:border-0 border-amber-200/60">
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-bold text-neutral-800 uppercase tracking-wider flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-[#00C48C] animate-pulse" />
                      <span>Numéro WhatsApp & Contact *</span>
                    </label>
                    {phoneValidation.isValid ? (
                      <span className="text-[11px] font-bold text-[#00C48C] flex items-center gap-1">
                        <Check className="w-3 h-3 stroke-[3]" /> Numéro valide
                      </span>
                    ) : whatsappDigits.trim().length > 0 ? (
                      <span className="text-[11px] font-medium text-red-500 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> Invalide
                      </span>
                    ) : (
                      <span className="text-[10px] text-red-500 font-bold bg-red-50 px-2 py-0.5 rounded-full border border-red-200/60">
                        Obligatoire
                      </span>
                    )}
                  </div>

                  <div className="flex gap-2">
                    <select
                      value={selectedCountryCode}
                      onChange={e => handleStep2CountryCodeChange(e.target.value)}
                      className="bg-white sm:bg-neutral-50 border border-neutral-200 rounded-xl px-2.5 py-2.5 text-sm font-medium text-neutral-800 focus:outline-none focus:ring-2 focus:ring-[#00C48C] cursor-pointer shrink-0 shadow-2xs"
                    >
                      {SUPPORTED_COUNTRIES.map(c => (
                        <option key={c.country} value={c.code}>
                          {c.flag} {c.code} ({c.country})
                        </option>
                      ))}
                    </select>

                    <div className="relative flex-1">
                      <MessageCircle className="w-4 h-4 text-[#00C48C] absolute left-3.5 top-3" />
                      <input
                        type="tel"
                        required
                        placeholder={activeCountry.placeholder}
                        value={whatsappDigits}
                        onChange={e => setWhatsappDigits(e.target.value)}
                        className={`w-full bg-white sm:bg-neutral-50 border rounded-xl pl-10 pr-3.5 py-2.5 text-sm text-neutral-900 placeholder-neutral-400 focus:outline-none transition-all ${
                          phoneValidation.isValid
                            ? 'border-emerald-500 focus:ring-2 focus:ring-[#00C48C]'
                            : whatsappDigits.trim().length > 0
                            ? 'border-red-400 focus:ring-2 focus:ring-red-400 bg-red-50/20'
                            : 'border-neutral-300 focus:ring-2 focus:ring-[#00C48C]'
                        }`}
                      />
                    </div>
                  </div>

                  {/* Validation Feedback message */}
                  <div className="mt-1.5 text-[11px]">
                    {!whatsappDigits.trim() ? (
                      <p className="text-neutral-500">
                        Format pour {activeCountry.country} : <span className="font-semibold">{activeCountry.expectedDigits}</span> (ex : {activeCountry.example})
                      </p>
                    ) : !phoneValidation.isValid ? (
                      <p className="text-red-600 font-medium flex items-center gap-1">
                        <AlertCircle className="w-3 h-3 shrink-0" />
                        <span>{phoneValidation.message}</span>
                      </p>
                    ) : (
                      <p className="text-[#00C48C] font-semibold flex items-center gap-1">
                        <Check className="w-3 h-3 stroke-[3]" />
                        <span>Numéro conforme pour {activeCountry.country}. Vos clients pourront vous contacter directement.</span>
                      </p>
                    )}
                  </div>
                </div>

                {/* Site web de la boutique (Optionnel) */}
                <div>
                  <label className="block text-xs font-semibold text-neutral-700 uppercase tracking-wider mb-1.5">
                    Site web ou Page Instagram (Optionnel)
                  </label>
                  <div className="relative">
                    <Globe className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3" />
                    <input
                      type="url"
                      placeholder="https://votreboutique.com ou @maboutique"
                      value={website}
                      onChange={e => setWebsite(e.target.value)}
                      className="w-full bg-neutral-50 border border-neutral-200 rounded-xl pl-10 pr-4 py-2.5 text-sm text-neutral-900 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-[#FF8A00] transition-all"
                    />
                  </div>
                </div>

                {/* Dynamic WhatsApp Link Preview */}
                {generatedWhatsAppLink && (
                  <motion.div
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-3 bg-emerald-50/70 border border-emerald-200/70 rounded-xl text-xs text-emerald-900 flex items-start gap-2.5"
                  >
                    <MessageCircle className="w-4 h-4 text-[#00C48C] shrink-0 mt-0.5" />
                    <div className="min-w-0 flex-1">
                      <span className="font-semibold block">Lien direct WhatsApp pour vos factures :</span>
                      <span className="font-mono text-[11px] text-[#00C48C] truncate block mt-0.5">
                        {generatedWhatsAppLink}
                      </span>
                    </div>
                  </motion.div>
                )}

                {/* Hidden submit trigger for Enter key accessibility */}
                <button type="submit" className="hidden" aria-hidden="true" tabIndex={-1} />
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* BOUTON PRINCIPAL FIXÉ EN BAS DE L'ÉCRAN : « Créer ma boutique » (Vert avec lumière tournante) */}
      <div
        className="fixed bottom-0 left-0 right-0 z-40 flex justify-center px-4 sm:px-6 pointer-events-none pb-[calc(1rem+env(safe-area-inset-bottom,0px))] pt-4 bg-gradient-to-t from-orange-600/90 via-orange-600/60 to-transparent"
        style={{ position: 'fixed' }}
      >
        <div className="w-full max-w-[460px] pointer-events-auto">
          <GreenGlowButton
            fullWidth
            size="lg"
            onClick={handleFixedCtaClick}
            disabled={isSubmitting || isAutoTransitioning}
            className="w-full shadow-2xl"
          >
            {isSubmitting ? (
              <PayperLoader
                variant="invoice"
                size="sm"
                theme="button"
                inline={true}
                text="Création..."
              />
            ) : (
              <>
                <span className="text-base font-black">Créer ma boutique</span>
                <ArrowRight className="w-5 h-5 stroke-[2.5]" />
              </>
            )}
          </GreenGlowButton>
        </div>
      </div>
    </div>
  );
};
