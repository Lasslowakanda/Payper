export type Currency = 'FCFA' | 'CDF' | 'GNF' | 'USD';

export interface UserAccount {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  country?: string;
  countryCode?: string;
  isLoggedIn: boolean;
  createdAt: string;
}

export interface Boutique {
  id?: string;
  userId?: string;
  ownerPhone?: string; // Numéro de téléphone du compte propriétaire (isolation stricte par compte)
  name: string;
  slug?: string; // Adresse / identifiant public (ex: maboutique)
  paymentMethod?: 'wave' | 'orange_money' | 'airtel_money' | 'moov_money' | 'mtn' | 'card';
  logo?: string;
  devise: Currency;
  country?: string;
  countryCode?: string;
  city?: string;
  phone?: string;
  website?: string;
  whatsappNumber?: string;
  whatsappLink?: string;
  createdAt?: string;
  isActive?: boolean;
  customization?: DocumentCustomization;
}

export type InvoiceTemplateId = 'classic_a4' | 'modern_clean' | 'signature_border' | 'minimal_ticket' | 'recu_signature';
export type ReceiptTemplateId = 'thermal_ticket' | 'modern_slip' | 'executive_receipt' | 'compact_badge' | 'recu_signature';
export type LogoPosition = 'left' | 'center' | 'right';
export type IconStyle = 'outline' | 'filled' | 'badged' | 'none';
export type InfoAlignment = 'left' | 'center' | 'split';

export interface DocumentCustomization {
  invoiceTemplate: InvoiceTemplateId;
  receiptTemplate: ReceiptTemplateId;
  primaryColor: string; // Hex color e.g. '#00C48C', '#FF8A00', '#2563EB'
  secondaryColor: string; // Hex color e.g. '#111827', '#0F172A'
  accentColor?: string;
  logoPosition: LogoPosition;
  iconStyle: IconStyle;
  infoAlignment: InfoAlignment;
  showWatermark?: boolean;
  receiptFooterMessage?: string;
  invoiceFooterMessage?: string;
  updatedAt?: string;
}

export type SubscriptionPlan = 'free' | 'standard' | 'pro';

export type SubscriptionStatus =
  | 'inactive'
  | 'pending'
  | 'active'
  | 'expired'
  | 'cancelled'
  | 'payment_failed';

export interface Subscription {
  id?: string;
  userId?: string;
  plan: SubscriptionPlan;
  status: SubscriptionStatus;
  startDate: string;
  endDate?: string; // Date d'expiration (ex: 30 jours après paiement)
  invoicesThisMonth: number;
  lastPaymentId?: string;
  paymentProvider?: 'wave' | 'orange_money' | 'card' | 'paystack' | 'flutterwave' | 'manual';
  amountUSD?: number;
  currency?: string;
  autoRenew?: boolean;
  updatedAt?: string;
  signature?: string; // Signature HMAC serveur anti-falsification
}

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  price: number;
  total: number;
}

export interface Invoice {
  id: string; // e.g. INV-2026-1001
  clientName: string;
  clientCity: string;
  whatsappNumber?: string;
  description: string;
  amount: number;
  devise: Currency;
  date: string;
  dueDate?: string;
  boutiqueName: string;
  boutiqueLogo?: string;
  boutiqueCity?: string;
  isPaid: boolean;
  notes?: string;
  items?: InvoiceItem[];
  createdAt: string;

  // Automations V1 Fields
  user_id?: string;
  store_id?: string;
  client_id?: string;
  invoice_number?: string;
  status?: 'PENDING' | 'PAID';
  issue_date?: string;
  due_date?: string;
  reminders_enabled?: boolean;
  payment_link?: string;
  is_recurring?: boolean;
  recurring_schedule_id?: string;
  customization?: DocumentCustomization;
}

export type ReminderType = 'J+1' | 'J+3' | 'J+7';

export interface ReminderLog {
  id: string;
  invoice_id: string;
  boutique_id: string;
  client_name: string;
  whatsapp_number?: string;
  reminder_type: ReminderType;
  sent_at: string;
  channel: 'WHATSAPP' | 'EMAIL' | 'SMS';
  status: 'SENT' | 'FAILED' | 'READY_TO_SEND';
  message_content: string;
  public_url?: string;
}

export type RecurrenceFrequency = 'WEEKLY' | 'MONTHLY' | 'QUARTERLY';

export interface RecurringSchedule {
  id: string;
  boutique_id: string;
  client_name: string;
  client_city?: string;
  whatsapp_number?: string;
  description: string;
  amount: number;
  currency: Currency;
  frequency: RecurrenceFrequency;
  next_run_date: string;
  due_date_offset_days: number; // e.g. 7 days
  reminders_enabled: boolean;
  status: 'ACTIVE' | 'PAUSED' | 'CANCELLED';
  created_at: string;
  last_generated_at?: string;
  generated_invoices_count: number;
  payment_link?: string;
  notes?: string;
}

export interface AutomationSettings {
  auto_reminders_enabled: boolean; // Master toggle
  timezone: string; // e.g. 'Africa/Dakar'
  send_hour: string; // e.g. '09:00'
  custom_payment_link?: string;
  custom_reminder_message?: string;
}

export interface ClientSummary {
  name: string;
  city: string;
  whatsappNumber?: string;
  invoicesCount: number;
  totalBilled: number;
  totalPaid: number;
  totalPending: number;
  currency: Currency;
  lastInvoiceDate: string;
  lastInvoiceId: string;
}

export interface PlanLimits {
  invoicesPerMonth: number | 'unlimited';
  clientsLimit: number | 'unlimited';
  hdImages: boolean;
  customColors: boolean;
  removePayperBranding: boolean;
  advancedStats: boolean;
  invoiceTemplates: boolean;
  customization: boolean;
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  message: string;
}
